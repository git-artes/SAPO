package sapo.red;

import java.util.ArrayList;

import sapo.predicciones.Modelo;

/**
 * Esta clase representa una antena.
 * 
 * @author Grupo de proyecto SAPO
 */
public class Antena {

	/**
	 * El nombre de la antena
	 * 
	 */
	String nombre;

	/**
	 * El canal de frecuencias asociado
	 */
	CanalFrecuencias canal;

	/**
	 * La potencia de trasmisionen dBm
	 */
	double potencia;

	/**
	 * El downtilt en grados
	 * 
	 */
	double tilt;

	/**
	 * El azimut en grados (sentido horario)
	 */
	double azimut;

	/**
	 * El modelo de propagación asociado
	 */
	Modelo modelo;

	/**
	 * El tipo de antena asociado
	 */
	TipoAntena tipo;

	/**
	 * El nombre del sitio donde esta ubicada
	 */
	String sitio;

	/**
	 * El nombre de la radiobase donde esta
	 */
	String rb;

	/**
	 * El indice a partir del cual empezar la busqueda en el patron de radiacion
	 * horizontal
	 */
	int indiceH;

	/**
	 * El indice a partir del cual empezar la busqueda en el patron de radiacion
	 * vertical
	 */
	int indiceV;

	/**
	 * Indice auxiliar para busqueda en el patron de radiacion
	 */
	int indice;

	/**
	 * Construye una antena vacia
	 * 
	 */
	public Antena() {
		sitio = " ";
		rb = " ";
		nombre = " ";
	}

	/**
	 * Construye una antena a partir del nombre, la potencia, el tilt y el
	 * azimut
	 */

	public Antena(String nombre, double potencia, double tilt, double azimut) {
		this.nombre = nombre;
		this.potencia = potencia;
		this.tilt = tilt;
		this.azimut = azimut;
		sitio = " ";
		rb = " ";
		nombre = " ";
		ArrayList<Double> frecuencias = new ArrayList<Double>();
		frecuencias.add(Double.valueOf("800E6"));
		try {
			canal = new CanalFrecuencias("Nuevo_Canal", frecuencias);
		} catch (CanalMalDefinidoException e) {
			e.printStackTrace();
		}
		indiceH = 0;
		indiceV = 0;
	}

	/**
	 * Construye una antena especificando todos los parametros
	 */
	public Antena(String nombre, double potencia, double tilt, double azimut,
			Modelo modelo, CanalFrecuencias canalF, TipoAntena tipoAntena) {
		this(nombre, potencia, tilt, azimut);
		this.modelo = modelo;
		this.canal = canalF;
		this.tipo = tipoAntena;
	}

	@Override
	public String toString() {
		return "Antena: " + this.nombre + "\n Potencia: " + potencia
				+ "\n Tilt: " + tilt + "\n Azimut: " + azimut + "\n Sitio: "
				+ sitio + "\n Radiobase: " + this.rb + "\n Modelo asociado: "
				+ modelo + "\n Canal asociado: " + canal + "\n Tipo asociado: "
				+ tipo.toString() + "\n";

	}

	/**
	 * Vuelve los indices de busqueda en el patron de radiacion a 0
	 * 
	 */
	public void resetearIndices() {
		indiceH = 0;
		indiceV = 0;
	}

	/**
	 * Sobreescribe el método de Object. Establece que dos antenas son iguales
	 * si tienen el mismo nombre, misma radiobase y mismo sitio
	 * 
	 * @return true si son iguales
	 */
	@Override
	public boolean equals(Object o) {
		Antena a = (Antena) o;
		boolean nombre = a.nombre.equals(this.nombre);
		boolean radiobase = a.rb.equals(this.rb);
		boolean sitio = a.sitio.equals(this.sitio);
		return nombre && sitio && radiobase;
	}

	/**
	 * Devuelve el nombre del sitio
	 */
	public String getSitio() {
		return sitio;
	}

	/**
	 * Devuelve el nombre de la radiobase e
	 */
	public String getRB() {
		return rb;
	}

	/**
	 * Devuelve la frecuencia maxima del canal, para uso en calculos de
	 * atenuacion
	 * 
	 * @return frecuencia en Hz
	 */
	public double getFrecuencia() {
		return canal.getFrecuenciaMaxima() * 1E6;
	}

	/**
	 * Setea el nombre del sitio al cual pertenece
	 */
	public void setSitio(String sitio) {
		this.sitio = sitio;
	}

	/**
	 * Setea el nombre de la radiobase a la cual pertenece
	 */
	public void setRB(String rb) {
		this.rb = rb;
	}

	/**
	 * Setea la potencia de trasmision
	 * 
	 * @param potencia
	 *            potencia en dBm
	 */
	public void setPotencia(double potencia) {
		this.potencia = potencia;
	}

	/**
	 * Setea el nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Setea el canal de frecuencias
	 */
	public void setCanal(CanalFrecuencias canal) {
		this.canal = canal;
		// this.frecuencia =
		// Double.parseDouble(canal.getFrecuencias().get(0).toString())*1E6;
	}

	/**
	 * Devuelve el canal de frecuencias
	 */
	public CanalFrecuencias getCanal() {
		return canal;
	}

	/**
	 * Setea el downtilt
	 * 
	 * @param tilt
	 *            downtilt en grados
	 */
	public void setTilt(double tilt) {
		this.tilt = tilt;
	}

	/**
	 * Setea el azimut
	 * 
	 * @param azimut
	 *            azimut en grados
	 */
	public void setAzimut(double azimut) {
		this.azimut = azimut;
	}

	/*
	 * public void setFrecuencia(double f){ this.frecuencia = f; }
	 */

	/**
	 * Setea el tipo de antena
	 */
	public void setTipo(TipoAntena tipo) {
		this.tipo = tipo;
	}

	/**
	 * Devuelve el tipo de antena
	 */
	public TipoAntena getTipo() {
		return this.tipo;
	}

	/**
	 * Setea el modelo
	 */
	public void setModelo(Modelo modelo) {
		this.modelo = modelo;
	}

	/**
	 * Devuelve la potencia de trasmision
	 * 
	 * @return potencia en dBm
	 * 
	 */
	public double getPotencia() {
		return potencia;
	}

	/**
	 * Devuelve el nombre de la antena
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Devuelve el dowtilt
	 * 
	 * @return el dowtilt en grados
	 */
	public double getTilt() {
		return tilt;
	}

	/**
	 * Devuelve el azimut
	 * 
	 * @return el azimut en grados
	 */
	public double getAzimut() {
		return azimut;
	}

	/**
	 * Calcula la ganancia en una determinada direcion, se le pasa el angulo
	 * relativo horizontal y parámetro diferencia de alturas sobre distancia
	 * plana para el cálculo del ángulo vertical. Hace correciones segun tilt y
	 * azimut.
	 * 
	 * @return ganancia en dB
	 */
	public double getGanancia(double anguloH, double anguloV) {
// GM: Al modificar la entrada de estos métodos no tendrían que modificarse
// todos los modelos de propagación lo usen? 
// Antes entraba angulo y altura/dist, ahora anguloH y anguloV.
		if (tipo.esIsotropica()) {
			return tipo.getGanancia();

		} else {
			anguloH = anguloH - azimut;
			anguloV = anguloV - tilt;
			// GM: Estos chequeos ya los hago en getGananciaAngulo!!!
//			if (anguloH < 0)
//				anguloH = anguloH + 360;
//			if (anguloV < 0)
//				anguloV = anguloV + 360;
			
			double correccionH = tipo.patronH.getGananciaAngulo(anguloH);
			double correccionV = tipo.patronV.getGananciaAngulo(anguloV);
			//GM: se suman??
			return (tipo.getGanancia() + correccionH + correccionV);
		}
	}

	/**
	 * Busca en el patron de radiacion la ganancia para un determinado angulo,
	 * si no aparece interpola, arranca desde indice
	 */
	double calcularGanancia(double angulo, PatronRadiacion patron, int indice) {
		this.indice = indice;
		boolean encontro = false;
		double angulo1 = 0;
		double angulo2 = 0;
		double ganancia1 = 0;
		double ganancia2 = 0;
		double ganancia = 0;
		try {
			if (indice >= patron.getTamanio())
				indice = indice - patron.getTamanio();
			angulo1 = patron.getAngulo(indice);
			angulo2 = patron.getAngulo(indice + 1);
			while (!encontro) {
				if (!(angulo >= angulo1 && angulo <= angulo2)) {
					if (angulo < angulo1) {
						indice--;
					} else {
						indice++;
						if (indice == patron.getTamanio())
							indice = 0;
					}
					angulo1 = patron.getAngulo(indice);
					angulo2 = patron.getAngulo(indice + 1);
				} else {
					encontro = true;
				}
			}
			ganancia1 = patron.getGananciaPosicion(indice);
			ganancia2 = patron.getGananciaPosicion(indice + 1);

		} catch (IndexOutOfBoundsException ex) {
			ganancia1 = patron.getGananciaPosicion(indice);
			ganancia2 = patron.getGananciaPosicion(0);
			angulo2 = patron.getAngulo(0);

		} finally {
			if (angulo1 == angulo2) {
				ganancia = ganancia1;
			} else {
				if ((angulo1 >= 180 && angulo1 <= 360)
						&& (angulo2 >= 0 && angulo2 <= 180)) {
					angulo2 = angulo2 + 360;
					if (angulo >= 0 && angulo <= 180) {
						angulo = angulo + 360;
					}
				}
				ganancia = ganancia1
						+ ((ganancia2 - ganancia1) / (angulo2 - angulo1))
						* (angulo - angulo1);
			}
		}
		return ganancia;
	}

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */
	public String getXML() {

		StringBuffer result = new StringBuffer("<Antena>");
		result.append("          <Nombre>" + nombre + "</Nombre>\r\n");
		result.append("          <Potencia>" + potencia + "</Potencia>\r\n");
		result.append("          <Tilt>" + tilt + "</Tilt>\r\n");
		result.append("          <Azimut>" + azimut + "</Azimut>\r\n");
		if (modelo != null) {
			// String nombreModelo = modelo.getNombreModelo();
			String nombreModelo = modelo.getNombre();
			if (nombreModelo != null) {
				result.append("          <ModeloAntena>" + nombreModelo
						+ "</ModeloAntena>\r\n");
			}
		}

		if (canal != null) {
			String nombreCanalF = canal.getNombre();
			if (nombreCanalF != null) {
				result.append("          <CanalFrecuenciaAntena>"
						+ nombreCanalF + "</CanalFrecuenciaAntena>\r\n");
			}
		}
		if (tipo != null) {
			String nombreTipoAntena = tipo.getNombre();
			if (nombreTipoAntena != null) {
				result.append("          <TipoDeAntena>" + nombreTipoAntena
						+ "</TipoDeAntena>\r\n");
			}
		}
		result.append("        </Antena>\r\n");
		return result.toString();

	}

	/**
	 * Devuelve el modelo
	 * 
	 * @return el modelo
	 */
	public Modelo getModelo() {
		return this.modelo;
	}

}
