package sapo.red;

import java.util.ArrayList;

import sapo.ifusuario.menues.PatronMalIngresadoException;
import sapo.red.patronesEspeciales.PatronIsotropica;

/**
 * Esta clase representa un tipo de antena.
 * 
 * @author Grupo de proyecto SAPO
 */
public class TipoAntena {

	/**
	 * nombre que identifica el tipo de antena
	 * 
	 */
	String nombre;

	/**
	 * ganancia en la direccion de maxima propagacion, en dBi
	 * 
	 */
	double ganancia;

	/**
	 * indica si es isotropica o directiva
	 */
	boolean isotropica;

	/**
	 * indica quÃ© patrón de radiación tiene antena
	 */
	String tipoPatronDeRadacion;

	/**
	 * contiene 2 ArrayList, uno con la lista de angulos y otro con las
	 * correspondientes ganancias en el plano horizontal. Las ganancias deben
	 * ser relativas a la ganancia en la direccion de maxima propagacion. El
	 * angulo 0 corresponde a dicha direccion (ganancia 0). Los angulos deberan
	 * estar entre 0 y 360.
	 */
	PatronRadiacion patronH;

	/**
	 * contiene 2 ArrayList, uno con la lista de angulos y otro con las
	 * correspondientes ganancias en el plano vertical. Las ganancias deben ser
	 * relativas a la ganancia en la direccion de maxima propagacion. El angulo
	 * 0 corresponde a dicha direccion (ganancia 0). Los angulos deberan estar
	 * entre 0 y 360.
	 */
	PatronRadiacion patronV;

	public static final String ISOTROPICA = "Isotropica";

	public static final String DIRECTIVA = "Directiva";

	public static final String DIPOLO = "Dipolo";
	
	public static final String TNU = "TNU";

	/**
	 * Crea una nueva instanica de un tipo de antena. Al igual que en la
	 * creación de patrones de radiación, no se verifica que los datos
	 * númericos estén correctos. En nuestra implementación en particular
	 * esto es función de la interfaz con el usuario.
	 * 
	 * @param nombre
	 * @param ganancia
	 * @param patronH
	 * @param patronV
	 * @throws TipoAntenaMalDefinidoException
	 *             Cuando el nombre es vacío
	 */
	public TipoAntena(String nombre, double ganancia, Object[] patronH,
			Object[] patronV) throws TipoAntenaMalDefinidoException {
		if (nombre.equals("")) {
			throw new TipoAntenaMalDefinidoException(
					"El nombre del tipo de antena no puede ser vacío");
		}
		this.nombre = nombre;
		this.ganancia = ganancia;
		this.isotropica = false;
		this.patronH = new PatronRadiacion(patronH);
		this.patronV = new PatronRadiacion(patronV);
		ArrayList a = (ArrayList) patronH[0];
		ArrayList b = (ArrayList) patronV[0];

	}

	public TipoAntena(String nombre, double ganancia, String tipoPatron) {
		this.nombre = nombre;
		this.ganancia = ganancia;
		if (tipoPatron.equals(ISOTROPICA)) {
			this.isotropica = true;
		}
		// TODO
	}

	/**
	 * Crea una nueva instanica de un tipo de antena. Al igual que en la
	 * creaciï¿œn de patrones de radiaciï¿œn, no se verifica que los datos
	 * nï¿œmericos estï¿œn correctos. En nuestra implementaciï¿œn en
	 * particular esto es funciï¿œn de la interfaz con el usuario.
	 * 
	 * @param nombre
	 * @param ganancia
	 * @param patronH
	 * @param patronV
	 * @throws TipoAntenaMalDefinidoException
	 *             Cuando el nombre es vacï¿œo
	 */
	public TipoAntena(String nombre, double ganancia, Object[] patronH,
			Object[] patronV, String tipoPatronDeRadiacion)
			throws TipoAntenaMalDefinidoException {
		if (nombre.equals("")) {
			throw new TipoAntenaMalDefinidoException(
					"El nombre del tipo de antena no puede ser vacï¿œo");
		}
		this.nombre = nombre;
		this.ganancia = ganancia;
		this.isotropica = false;
		this.patronH = new PatronRadiacion(patronH);
		this.patronV = new PatronRadiacion(patronV);
		ArrayList a = (ArrayList) patronH[0];
		ArrayList b = (ArrayList) patronV[0];
		this.tipoPatronDeRadacion = tipoPatronDeRadiacion;

	}

	/**
	 * Crea un nuevo tipo de antena omnidireccional.
	 * 
	 * @param nombre
	 * @throws TipoAntenaMalDefinidoException
	 *             Cuando el nombre es vacío
	 */
	public TipoAntena(String nombre) throws TipoAntenaMalDefinidoException {
		if (nombre.equals("")) {
			throw new TipoAntenaMalDefinidoException(
					"El nombre del tipo de antena no puede ser vacío");
		}
		this.nombre = nombre;
		this.ganancia = 0;
		this.isotropica = true;
		this.tipoPatronDeRadacion = ISOTROPICA;
		this.patronH = new PatronIsotropica();
		this.patronV = new PatronIsotropica();
	}

	public TipoAntena(String nombre, String ganancia, boolean isotropica,
			String tipoPatron, PatronRadiacion patronH, PatronRadiacion patronV)
			throws PatronMalIngresadoException, NumberFormatException, TipoAntenaMalDefinidoException {
		if (esNumerico(ganancia)) {
			this.nombre = nombre;
			this.ganancia = Double.parseDouble(ganancia);
			this.tipoPatronDeRadacion = tipoPatron;
			this.patronH = patronH;
			this.patronV = patronV;
		}
	}

	/**
	 * Devuelve el nombre
	 * 
	 * @return el nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Indica si es isotropica o directiva
	 * 
	 * @return true si es isotropica
	 */
	public boolean esIsotropica() {
		return isotropica;
	}

	/**
	 * Devuelve la ganancia maxima
	 * 
	 * @return la ganancia maxima en dBi
	 */
	public double getGanancia() {
		return ganancia;
	}

	/**
	 * Devuelve el patron de radiacion horizontal
	 * 
	 * @return el patron de radiacion horizontal
	 */
	public PatronRadiacion getPatronHorizontal() {
		return patronH;
	}

	/**
	 * Devuelve el patron de radiacion vertical
	 * 
	 * @return el patron de radiacion vertical
	 */
	public PatronRadiacion getPatronVertical() {
		return patronV;
	}

	/**
	 * Setea la ganancia maxima en dBi
	 * 
	 * @param ganancia
	 *            - la ganancia maxima en dBi
	 */
	public void setGanancia(double ganancia) {
		this.ganancia = ganancia;
	}

	/**
	 * Setea el nombre
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Sobreescribe el método de Object. Establece que dos tipos de antenas son
	 * iguales si tienen el mismo nombre
	 * 
	 * @return true si son iguales
	 */
	@Override
	public boolean equals(Object o) {
		return ((TipoAntena) o).getNombre().equals(this.getNombre());
	}

	@Override
	public String toString() {
		String tipo = this.tipoPatronDeRadacion;

		return "Nombre Tipo: " + this.nombre + "\n Tipo: " + tipo + "\n";
	}

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */
	public String getXML() {

		StringBuffer result = new StringBuffer("<TipoAntena>");
		result.append("          <NombreTipo>" + nombre + "</NombreTipo>\r\n");
		String tipo;
		if (isotropica == true) {
			tipo = TipoAntena.ISOTROPICA;
			result.append("          <Tipo>" + tipo + "</Tipo>\r\n");
			result.append("          <Ganancia>" + ganancia + "</Ganancia>\r\n");
		} else {
			tipo = TipoAntena.DIRECTIVA;
			result.append("          <Tipo>" + tipo + "</Tipo>\r\n");
			result.append("          <Ganancia>" + ganancia + "</Ganancia>\r\n");
			boolean esHorizontal = true;
			result.append(patronH.getXML(esHorizontal));
			esHorizontal = false;
			result.append(patronV.getXML(esHorizontal));

		}

		result.append("      </TipoAntena>\r\n");
		return result.toString();

	}

	public String getPatronDeRadiacion() {
		return this.tipoPatronDeRadacion;
	}

	public void setPatronDeRadiacion(String patron)
			throws TipoAntenaMalDefinidoException {
		if (patron.equals(TipoAntena.DIPOLO)
				|| patron.equals(TipoAntena.DIRECTIVA)
				|| patron.equals(TipoAntena.TNU)
				|| patron.equals(TipoAntena.ISOTROPICA)) {
			this.tipoPatronDeRadacion = patron;
		} else {
			throw new TipoAntenaMalDefinidoException(
					"El patrÃ³n de radiaciÃ³n no es vÃ¡lido");
		}
	}

	public String getTipoPatron() {
		return this.tipoPatronDeRadacion;
	}

	private boolean esNumerico(String s) throws TipoAntenaMalDefinidoException {
		try {
			Double.parseDouble(s);
			return true;
		} catch (NumberFormatException e) {
			throw new TipoAntenaMalDefinidoException(
					"Los valores de la potencia debe ser num�rico.");
		}
	}
}
