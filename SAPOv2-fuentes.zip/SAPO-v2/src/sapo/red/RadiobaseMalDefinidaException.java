package sapo.red;

/**
 * Esta excepción es lanzada al definir una radiobase, si la altura es negativa.
 * @author Grupo de proyecto SAPO
 */
public class RadiobaseMalDefinidaException extends Exception {

	public RadiobaseMalDefinidaException(String mensaje) {
		super(mensaje);
	}

}
