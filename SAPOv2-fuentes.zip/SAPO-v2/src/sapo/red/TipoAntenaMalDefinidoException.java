
package sapo.red;

/**
 * Esta excepción es lanzada al definir un tipo de antena, si el nombre es vacio.
 * @author Grupo de proyecto SAPO
 */
public class TipoAntenaMalDefinidoException extends Exception {

	public TipoAntenaMalDefinidoException(String mensaje) {
		super(mensaje);
	}

}
