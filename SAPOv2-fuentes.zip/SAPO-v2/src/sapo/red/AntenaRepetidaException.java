package sapo.red;

/**
 * Esta excepción es lanzada al agregar una antena a una radiobase, 
 * si ya existe una con el mismo nombre.
 * @author Grupo de proyecto SAPO
 */
public class AntenaRepetidaException extends Exception {

	public AntenaRepetidaException(String mensaje) {
		super(mensaje);
	}

}
