package sapo.red;

/**
 * Esta exception es lanzada cuando hay algún problema al generar el
 * FeatureSitio.
 * 
 * @author Grupo de proyecto SAPO
 *  
 */
public class FeatureSitioMalFormadoException extends Exception {

	public FeatureSitioMalFormadoException(String mensaje) {
		super(mensaje);
	}

}
