package sapo.red;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Esta clase representa un canal de frecuencias.
 * @author Grupo de proyecto SAPO
 */
public class CanalFrecuencias {

	String nombre;

	ArrayList<Double> frecuencias;

	public CanalFrecuencias(String nombre, ArrayList<Double> canal)
			throws CanalMalDefinidoException {
		if (nombre.equals("")) {
			throw new CanalMalDefinidoException(
					"No se pueden definir canales sin nombre");
		}
		this.nombre = nombre;
		this.frecuencias = canal;
	}

	public CanalFrecuencias(String nombre) throws CanalMalDefinidoException {
		if (nombre.equals("")) {
			throw new CanalMalDefinidoException(
					"No se pueden definir canales sin nombre");
		}
		this.nombre = nombre;

	}


	public String getNombre() {
		return nombre;
	}


	public ArrayList<Double> getFrecuencias() {
		return frecuencias;
	}

	public void setNombre(String nombre) {
		this.setNombre(nombre);
	}


	/**
	 * Devuelve la frecuencia maxima del canal
	 * 
	 * @return frecuencia en MHz
	 */
	public double getFrecuenciaMaxima() {
		double frecuenciaMaxima = frecuencias.get(0);
		Iterator<Double> iterador = frecuencias.iterator();
		while (iterador.hasNext()) {
			double frecuencia = Double.parseDouble(iterador.next().toString());
			if (frecuencia > frecuenciaMaxima) {
				frecuenciaMaxima = frecuencia;
			}
		}
		return frecuenciaMaxima;
	}

	@Override
	public String toString() {
		return "\n Nombre Canal: " + nombre + "\n Frecuencias: \n"
				+ frecuencias;
	}

	@Override
	public boolean equals(Object o) {
		return ((CanalFrecuencias) o).getNombre().equals(this.getNombre());
	}

	/**
	 * Dado cf, devuelve si esta instancia tiene alguna frecuencia en común.
	 * 
	 */
	public boolean frecuenciaEnComun(CanalFrecuencias cf) {
		Iterator<Double> iteradorPropio = this.frecuencias.iterator();
		Iterator<Double> iteradorAjeno;
		Double frecuencia;
		while (iteradorPropio.hasNext()) {
			frecuencia = (Double) iteradorPropio.next();
			iteradorAjeno = cf.frecuencias.iterator();
			while (iteradorAjeno.hasNext()) {
				if (((Double) iteradorAjeno.next()).equals(frecuencia))
					return true;
			}
		}
		return false;
	}

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */
	
	public String getXML() {

		StringBuffer result = new StringBuffer("<CanalFrecuencia>");
		result.append("          <Nombre>" + nombre + "</Nombre>\r\n");
		Iterator<Double> iterador = frecuencias.iterator();
		while (iterador.hasNext()) {
			StringBuffer result1 = new StringBuffer("<Frecuencia>");
			double frecuencia = Double.parseDouble(iterador.next().toString());
			result1.append("          <Valor>" + frecuencia + "</Valor>\r\n");
			result1.append("        </Frecuencia>\r\n");
			result.append(result1.toString());
		}
		result.append("        </CanalFrecuencia>\r\n");
		return result.toString();

	}

}