package sapo.red;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Esta clase representa una radiobase ("torre" con una determinada altura).
 * @author Grupo de proyecto SAPO
 */
public class Radiobase {

	/**
	 * La altura de la radiobase en metros
	 */
	double altura;

	/**
	 * La lista de antenas
	 */
	ArrayList antenas;

	/**
	 * El nombre del sitio en el cual se ubica 
	 */
	String sitio; 

	/**
	 * El nombre de la radiobase
	 */
	String nombre;

	boolean habilitado;

	/**
	 * 
	 * @param nombre
	 * @param altura
	 * @param arregloAnt
	 * @throws RadiobaseMalDefinidaException 
	 *             cuando la altura es negativa
	 */
	public Radiobase(String nombre, double altura, ArrayList arregloAnt)
			throws RadiobaseMalDefinidaException {
		if (altura < 0)
			throw new RadiobaseMalDefinidaException(
					"La altura debe ser mayor que cero. ");
		this.nombre = nombre;
		this.altura = altura;
		this.sitio = " ";
		this.antenas = arregloAnt;
		Iterator i = antenas.iterator();
		while (i.hasNext()) {
			Antena antena = (Antena) i.next();
			antena.setRB(nombre);
			//antena.setSitio(this.sitio);
		}
		habilitado = true;
	}

	/**
	 * 
	 * @param nombre
	 * @param altura
	 * @throws RadiobaseMalDefinidaException 
	 *             Cuando la altura es negativa
	 */
	public Radiobase(String nombre, double altura)
			throws RadiobaseMalDefinidaException {
		if (altura < 0)
			throw new RadiobaseMalDefinidaException(
					"La altura debe ser mayor que cero. ");
		this.nombre = nombre;
		this.altura = altura;
		this.habilitado = true;
		this.sitio = " ";
		antenas = new ArrayList();
		//this.sitio = sitio;
	}

	public Radiobase() {
		this.nombre = " ";
		this.altura = 0;
		this.habilitado = true;
		this.sitio = " ";
		antenas = new ArrayList();
	}

	/**
	 * Construye una radiobase copia de la que se le pase.

	 */
	public Radiobase(Radiobase rb) {
		this.nombre = rb.getNombre();
		this.altura = rb.getAltura();
		this.antenas = rb.getAntenas();
		Iterator i = antenas.iterator();
		while (i.hasNext()) {
			Antena antena = (Antena) i.next();
			antena.setRB(nombre);
		}
		habilitado = true;
		this.sitio = rb.sitio;
	}

	/**
	 * @return Returns the sitio.
	 */
	public String getSitio() {
		return sitio;
	}

	/**
	 * Método friendly para que el único que pueda cambiarle el nombre del sitio
	 * sea el propio sitio. Además de cambiarle el sitio a la radiobase, se la
	 * cambia sus antenas.

	 */
	public void setSitio(String sitio) {
		this.sitio = sitio;
		Antena antena;
		Iterator i = this.antenas.iterator();
		while (i.hasNext()) {
			antena = (Antena) i.next();
			antena.setSitio(sitio);
			antena.setRB(this.nombre);
		}
	}

	/**
	 *Setea el nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
		Iterator i = antenas.iterator();
		while (i.hasNext()) {
			Antena antena = (Antena) i.next();
			antena.setRB(nombre);
		}
	}

	/**
	 *Setea la altura
	 */
	public void setAltura(double altura) throws RadiobaseMalDefinidaException {
		if (altura <= 0)
			throw new RadiobaseMalDefinidaException(
					"La altura debe ser mayor que cero. ");
		this.altura = altura;
	}

	/**
	 * Devuelve el nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Devuelve la altura.
	 */
	public double getAltura() {
		return altura;
	}

	/**
	 * @return Devuelve las antenas.
	 */
	public ArrayList getAntenas() {
		return antenas;
	}

	@Override
	public String toString() {
		String devolucion = nombre + " Altura: " + altura + " nro.Antenas: "
				+ antenas.size() + "\n" + "antenas: \n" + antenas;
		return devolucion;
	}

	/**
	 * Devuelve la antena con el nombre especificado
	 */
	public Antena getAntena(String nombre) {
		int i = 0;
		while (i < antenas.size()) {
			Antena antena = (Antena) antenas.get(i);
			if (antena.getNombre().equals(nombre)) {
				return antena;
			}
			i++;
		}
		return null;
	}

	/**
	 * Agrega la antena a la radioBase. Además le asigna el sitio y la
	 * radiobase.
	 * 
	 * @param antena
	 * @throws AntenaRepetidaException 
	 *             Si ya existe una antena con el mismo nombre en esta
	 *             radiobase.
	 */
	public void agregarAntena(Antena antena) throws AntenaRepetidaException {
		antena.setRB(this.nombre);
		antena.setSitio(this.sitio);
		if (antenas.indexOf(antena) != -1) {
			AntenaRepetidaException are = new AntenaRepetidaException(
					"Ya existe una antena con el nombre " + antena.getNombre()
							+ " en esta radiobase. ");
			throw are;
		}
		antenas.add(antena);
	}

	public void borrarAntena(Antena antena) {
		antenas.remove(antena);
	}

	@Override
	public boolean equals(Object o) {
		return ((Radiobase) o).getNombre().equals(this.nombre)
				&& ((Radiobase) o).sitio.equals(this.sitio);
	}

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */
	
	public String getXML() {

		StringBuffer result = new StringBuffer("<Radiobase>");
		result.append("          <Nombre>" + nombre + "</Nombre>\r\n");
		result.append("          <Altura>" + altura + "</Altura>\r\n");
		result.append("          <Habilitada>" + habilitado
				+ "</Habilitada>\r\n");

		Iterator iterator = antenas.iterator();
		while (iterator.hasNext()) {
			Antena antena = (Antena) iterator.next();
			result.append(antena.getXML());
		}

		result.append("        </Radiobase>\r\n");
		return result.toString();

	}

}
