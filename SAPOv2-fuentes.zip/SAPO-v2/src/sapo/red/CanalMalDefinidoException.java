package sapo.red;

/**
 * Esta excepción es lanzada al definir un canal de frecuencias, si el nombre es vacio.
 * @author Grupo de proyecto SAPO
 */
public class CanalMalDefinidoException extends Exception {

	public CanalMalDefinidoException(String mensaje) {
		super(mensaje);
	}

}
