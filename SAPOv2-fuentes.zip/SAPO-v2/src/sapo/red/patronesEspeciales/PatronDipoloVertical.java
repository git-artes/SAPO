package sapo.red.patronesEspeciales;

import sapo.red.PatronRadiacion;

public class PatronDipoloVertical extends PatronRadiacion {

	public PatronDipoloVertical(Object[] datos) {
		super(datos);
	}

	public PatronDipoloVertical() {
		for (int i = 0; i < 360; i++) {
			this.angulos.add((double) i);
//			double aux = 1.5*Math.pow(Math.sin(i/360.0*2*Math.PI),2);
			double aux = Math.pow(Math.sin(i/360.0*2*Math.PI),3);
			aux = 10*Math.log10(Math.abs(aux));
			this.ganancias.add(aux);
		}
	}
}

// for (int i = 0; i < 360; i++) {
// angulos360.add((double)i);
// gananciasIsotropicaH.add(0.0);
// gananciasIsotropicaV.add(0.0);
// gananciasDipoloH.add(0.0);
// gananciasDipoloV.add(Math.abs(3.0/2.0*Math.sin(i/360.0*2*Math.PI)));
// // TODO Agregar informaci�n TNU
// gananciasTNUH.add(0.0);
// gananciasTNUV.add(0.0);