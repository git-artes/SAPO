package sapo.red.patronesEspeciales;

import sapo.red.PatronRadiacion;

public class PatronDipoloHorizontal extends PatronRadiacion {

	public PatronDipoloHorizontal(Object[] datos) {
		super(datos);
	}

	public PatronDipoloHorizontal() {
		for (int i = 0; i < 360; i++) {
			this.angulos.add((double) i);
			this.ganancias.add(0.0);
		}
	}
}

// for (int i = 0; i < 360; i++) {
// angulos360.add((double)i);
// gananciasIsotropicaH.add(0.0);
// gananciasIsotropicaV.add(0.0);
// gananciasDipoloH.add(0.0);
// gananciasDipoloV.add(Math.abs(3.0/2.0*Math.sin(i/360.0*2*Math.PI)));
// // TODO Agregar informaci�n TNU
// gananciasTNUH.add(0.0);
// gananciasTNUV.add(0.0);