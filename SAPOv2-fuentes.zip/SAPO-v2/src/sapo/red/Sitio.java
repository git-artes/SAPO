package sapo.red;

import java.util.ArrayList;
import java.util.Iterator;

import org.geotools.feature.AttributeType;
import org.geotools.feature.AttributeTypeFactory;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureType;
import org.geotools.feature.FeatureTypeFactory;

import sapo.capas.ElementoCapa;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Point;

/**
 * Esta clase representa un sitio de coordernadas (x, y) en el mapa.
 * @author Grupo de proyecto SAPO
 */
public class Sitio implements ElementoCapa {

	/**
	 * El feature asociado con el sitio
	 */
	Feature fSitio;

	/**
	 * el nombre del sitio
	 */
	String nombre;

	/**
	 * La coordenada x
	 */
	double x;

	/**
	 * La coordenada y
	 */
	double y;

	/**
	 * La lista de radiobases
	 */
	public ArrayList radiobases;

	//constructores
	public Sitio(double x, double y, String nombre) {
		this.nombre = nombre;
		this.x = x;
		this.y = y;
		radiobases = new ArrayList();
	}

	public Sitio(double x, double y, String nombre, ArrayList arregloRB) {
		this(x, y, nombre);
		this.radiobases = arregloRB;
		Iterator i = radiobases.iterator();
		while (i.hasNext()) {
			((Radiobase) (i.next())).setSitio(nombre);
		}
	}

	public Sitio(double x, double y) {
		this(x, y, " ");
	}

	public Sitio(String nombre) {
		this(0, 0, nombre);
	}

	public Sitio() {
		this(0, 0, " ");
	}

	/**
	 * Hace una copia del sitio.
	 * 
	 */
	public Sitio(Sitio sitio) {
		this.nombre = sitio.getNombre();
		this.x = sitio.getX();
		this.y = sitio.getY();
		this.radiobases = sitio.getRadiobases();
		Iterator i = radiobases.iterator();
		while (i.hasNext()) {
			((Radiobase) (i.next())).setSitio(nombre);
		}
	}

	
	public String getNombre() {
		return nombre;
	}


	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	/**
	 * Devuelve la radiobase con el nombre indicado y si ésta no se encuentra
	 * devuelve null.

	 */
	public Radiobase getRadiobase(String nombre) {
		int i = 0;
		while (i < radiobases.size()) {
			Radiobase radiobase = (Radiobase) radiobases.get(i);
			if (radiobase.getNombre().equals(nombre)) {
				return radiobase;
			}
			i++;
		}
		return null;
	}

	@Override
	public String toString() {
		return "\n Sitio: " + nombre + "\n Radiobases: \n"
				+ radiobases.toString();
	}

	/**
	 * agrega la radioBase al sitio.
	 * 
	 * @param rb
	 * @throws RadiobaseRepetidaException 
	 *              Si la radiobase ya existe.
	 */
	public void agregarRB(Radiobase rb) throws RadiobaseRepetidaException {
		rb.setSitio(this.nombre);
		if (radiobases.indexOf(rb) != -1) {
			RadiobaseRepetidaException rre = new RadiobaseRepetidaException(
					"Ya existe una radiobase con el nombre " + rb.getNombre()
							+ " definida para este sitio");
			throw rre;
		}
		radiobases.add(rb);
	}

	public void borrarRB(Radiobase rb) {
		radiobases.remove(rb);
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
		Iterator iterador = this.radiobases.iterator();
		while (iterador.hasNext()) {
			((Radiobase) iterador.next()).setSitio(nombre);
		}
	}

	public void setPosicion(double x, double y) {
		this.x = x;
		this.y = y;
	}


	public ArrayList getRadiobases() {
		return radiobases;
	}

	@Override
	public boolean equals(Object o) {
		//return ((Sitio)o).getNombre().equals(this.getNombre());

		if (((Sitio) o).getNombre().equals(this.getNombre())) {
			return true;
		} else if ((((Sitio) o).getX() == this.getX())
				& (((Sitio) o).getY() == this.getY())) {
			return true;
		} else
			return false;

	}

	@Override
	public Feature getFeature() {
		try {
			crearFeatureSitio(x, y);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		return fSitio;
	}

	/**
	 * Crea un feature para Sitio
	 * 
	 * @param x 
	 * *            Coordenada x del Sitio
	 * @param y
	 *            Coordenada y del Sitio
	 */
	public void crearFeatureSitio(double x, double y)
			throws FeatureSitioMalFormadoException {
		try {
			GeometryFactory gf = new GeometryFactory();
			Point punto = gf.createPoint(new Coordinate(x, y));
			//Point punto = new Point(new Coordinate(x,y), new
			// PrecisionModel(), 1);
			AttributeType atribPunto = AttributeTypeFactory.newAttributeType(
					"punto", Point.class);
			FeatureType ftPunto;
			ftPunto = FeatureTypeFactory.newFeatureType(
					new AttributeType[] { atribPunto }, "punto");
			fSitio = ftPunto.create(new Object[] { punto }, "punto");
		} catch (Exception e) {
			FeatureSitioMalFormadoException f = new FeatureSitioMalFormadoException(
					"Feature Sitio Mal Formado");
			throw f;
		}

	}

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */
	
	public String getXML() {

		//StringBuffer result = new StringBuffer("<Sitio nombre='" + nombre
		// +"'>\r\n");
		StringBuffer result = new StringBuffer("<Sitio>");
		result.append("          <Nombre>" + nombre + "</Nombre>\r\n");
		result.append("          <CoordenadaX>" + x + "</CoordenadaX>\r\n");
		result.append("          <CoordenadaY>" + y + "</CoordenadaY>\r\n");
		//	result.append(" <Habilitado>"
		//			+ habilitado
		//			+ "</Habilitado>\r\n");

		Iterator iterator = radiobases.iterator();
		while (iterator.hasNext()) {
			Radiobase rb = (Radiobase) iterator.next();
			result.append(rb.getXML());
		}

		result.append("        </Sitio>\r\n");
		return result.toString();

	}
	
	public double asinh(double x) {
		return Math.log(x + Math.sqrt(Math.pow(x, 2) + 1.0));
	}

	public double atanh(double x) {
		return 0.5 * Math.log((1.0 + x) / (1.0 - x));
	}

	/**
	 * Transforma coordenadas geográficas (WGS 84) a coordenadas proyectadas
	 * del tipo SIRGAS 2000 proyección UTM 21S.
	 *
	 * @author Grupo de proyecto SAPO-TVDT
	 */
	public double[] cambioCoord(double lat, double lon) {

		// Ecuaciones y parámetros SIRGAS 2000
		final double LATO = 0.0;
		final double LONGO = -57.0 * Math.PI / 180.0;
		final double FN = 10000000.0;
		final double FE = 500000.0;
		final double KO = 0.9996;
		final double A = 6378137.0;
		final double F = 0.0033528107;

		double e = Math.sqrt(2 * F - Math.pow(F, 2));
		double n = F / (2.0 - F);
		double B = (A / (1.0 + n))
				* (1.0 + Math.pow(n, 2) / 4.0 + Math.pow(n, 4) / 64.0);
		double h1 = n / 2.0 - (2.0 / 3.0) * Math.pow(n, 2) + (5.0 / 16.0)
				* Math.pow(n, 3) + (41.0 / 180.0) * Math.pow(n, 4);
		double h2 = (13.0 / 48.0) * Math.pow(n, 2) - (3.0 / 5.0)
				* Math.pow(n, 3) + (557.0 / 1440.0) * Math.pow(n, 4);
		double h3 = (61.0 / 240.0) * Math.pow(n, 3) - (103.0 / 140.0)
				* Math.pow(n, 4);
		double h4 = (49561.0 / 161280.0) * Math.pow(n, 4);

		double E;
		double N;

		lat = lat * Math.PI / 180.0; // paso a radianes
		lon = lon * Math.PI / 180.0; // paso a radianes

		double mo = 0.0;
		double q = asinh(Math.tan(lat)) - e * atanh(e * Math.sin(lat));
		double beta = Math.atan(Math.sinh(q));
		double etaO = atanh(Math.cos(beta) * Math.sin(lon - LONGO));
		double xi0 = Math.asin(Math.sin(beta) * Math.cosh(etaO));
		double xi1 = h1 * Math.sin(2 * xi0) * Math.cosh(2 * etaO);
		double eta1 = h1 * Math.cos(2 * xi0) * Math.sinh(2 * etaO);
		double xi2 = h2 * Math.sin(4 * xi0) * Math.cosh(4 * etaO);
		double eta2 = h2 * Math.cos(4 * xi0) * Math.sinh(4 * etaO);
		double xi3 = h3 * Math.sin(6 * xi0) * Math.cosh(6 * etaO);
		double eta3 = h3 * Math.cos(6 * xi0) * Math.sinh(6 * etaO);
		double xi4 = h4 * Math.sin(8 * xi0) * Math.cosh(8 * etaO);
		double eta4 = h4 * Math.cos(8 * xi0) * Math.sinh(8 * etaO);
		double xi = xi0 + xi1 + xi2 + xi3 + xi4;
		double eta = etaO + eta1 + eta2 + eta3 + eta4;
		E = FE + KO * B * eta;
		N = FN + KO * (B * xi - mo);		
		return new double[]{E, N};
	}


}
