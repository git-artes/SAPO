package sapo.red;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Esta clase representa un patron de radiacion, constituido por una lista de
 * ángulos en grados ordenados y sus respectivas ganancias relativas en dB.
 * 
 * @author Grupo de proyecto SAPO
 */
public class PatronRadiacion {

	/**
	 * Lista de angulos ordenada creciente, comenzando de . Los angulos son el
	 * grados y estan entre 0 y 360.
	 */
	public ArrayList<Double> angulos;

	/**
	 * Lista de ganancias relativo a la ganancia maxima, en dB
	 */
	public ArrayList<Double> ganancias;

	/**
	 * Crea un nuevo patrón de radiación con los valores que se le pasen. NO
	 * se verifica que los parámetros estén correctos. Esto es responsabilidad
	 * del usuario y en esta implementación en particular lo hace la interfaz
	 * de usuario.
	 * 
	 * @param datos
	 *            Un array de dos posiciones, donde en la primera irá un
	 *            ArrayList con los datos de los ángulos y en el segunda otra
	 *            ArrayList con los datos correspondientes a la ganancia para
	 *            cada ángulo.
	 */
	public PatronRadiacion(Object[] datos) {
		angulos = (ArrayList<Double>) datos[0];
		ganancias = (ArrayList<Double>) datos[1];
	}

	public PatronRadiacion() {
		angulos = new ArrayList<Double>();
		ganancias = new ArrayList<Double>();
	}

	public Object[] getDatos() {
		return new Object[] { angulos, ganancias };
	}

	/**
	 * Devuelve el angulo correspondiente al indice i de la tabla
	 * 
	 * @param i
	 *            el indice
	 * @return la ganancia relatia en dB
	 */
	public double getAngulo(int i) {
		return Double.parseDouble(angulos.get(i).toString());
	}

	/**
	 * Devuelve la ganancia correspondiente al indice i de la tabla
	 * 
	 * @param i
	 *            - el indice
	 * @return la ganancia relatia en dB
	 */
	public double getGananciaPosicion(int i) {
		/*
		 * if (i >= angulos.size()){ i=i-angulos.size(); }
		 */
		return Double.parseDouble(ganancias.get(i).toString());
	}

	/**
	 * Devuelve el tamanio de la lista de datos
	 * 
	 * @return el tamanio
	 */
	public int getTamanio() {
		return angulos.size();
	}

	/**
	 * Devuelve la ganancia para un ángulo dado
	 */

	public double getGananciaAngulo(double angulo) {
		double G = 0;
		if (angulo > 360.0) {
			angulo = angulo - Math.floor(angulo / 360) * 360;
		} else if (angulo < 0.0) {
			// GM: Antes estaba sin el módulo y cuando el ángulo era negativo, el floor daba el int Negativo, y el ángulo daba fruta.
			angulo = angulo - Math.floor(Math.abs(angulo / 360.0)) * 360.0 + 360.0;
		}
		double anguloMin = angulos.get(0);
		double anguloMax = angulos.get(angulos.size() - 1);

		// En el caso de que el ángulo sea menor al más chico de la tabla
		// tengo que interpolar con el valor del ángulo más alto
		if (angulo <= anguloMin) {
			double ganMin = ganancias.get(0);
			double ganMax = ganancias.get(ganancias.size() - 1);
			anguloMax = anguloMax - 360;
			G = ganMax + (ganMin - ganMax) / (anguloMin - anguloMax)
					* (angulo - anguloMax);
			return G;
			// En el caso de que el ángulo sea mayor al más grande de la tabla
			// tengo que interpolar con el valor del ángulo más chico
		} else {
			if (angulo > anguloMax) {
				double ganMin = ganancias.get(0);
				double ganMax = ganancias.get(ganancias.size() - 1);
				angulo = angulo - 360.0;
				anguloMax = anguloMax - 360.0;
				G = ganMax + (ganMin - ganMax)
						/ (anguloMin - anguloMax) * (angulo - anguloMax);
				return G;
			} else {
				// Hallo el valor de la ganancia interpolando
				double gan1 = 0;
				double gan2 = 0;
				Iterator<Double> it = angulos.iterator();
				while (it.hasNext()) {
					double anguloAux = it.next();
					if (anguloAux > angulo) {
						int indice = angulos.indexOf(anguloAux);
						gan2 = ganancias.get(indice);
						gan1 = ganancias.get(indice - 1);
						double anguloAux1 = angulos.get(indice - 1);
						G = gan1 + (gan2 - gan1)
								/ (anguloAux - anguloAux1)
								* (angulo - anguloAux1);
						return G;
					}
				}
			}
			return G;
		}
	}

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */

	public String getXML(boolean esHorizontal) {
		StringBuffer result1 = new StringBuffer("");
		if (esHorizontal) {
			result1 = new StringBuffer("<PatronH>");
		} else {
			result1 = new StringBuffer("<PatronV>");
		}
		// StringBuffer result1 = new StringBuffer("<Valor>");
		Iterator<Double> iteradorA = angulos.iterator();
		Iterator<Double> iteradorG = ganancias.iterator();
		while (iteradorA.hasNext()) {

			double angulo = Double.parseDouble(iteradorA.next().toString());
			double ganancia = Double.parseDouble(iteradorG.next().toString());
			StringBuffer result2 = new StringBuffer("<Angulo>");
			result2.append("          <Valor>" + angulo + "</Valor>\r\n");
			result2.append("      </Angulo>\r\n");
			result1.append(result2.toString());
			StringBuffer result3 = new StringBuffer("<Ganancia>");
			result3.append("          <Valor>" + ganancia + "</Valor>\r\n");
			result3.append("      </Ganancia>\r\n");
			result1.append(result3.toString());

		}
		if (esHorizontal) {
			result1.append("      </PatronH>\r\n");
		} else {
			result1.append("      </PatronV>\r\n");
		}
		return result1.toString();

	}

}
