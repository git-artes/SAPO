package sapo.red;

/**
 * Esta excepción es lanzada al agregar una radiobase a un sitio, 
 * si ya existe una con el mismo nombre.
 * @author Grupo de proyecto SAPO
 */
public class RadiobaseRepetidaException extends Exception {

	RadiobaseRepetidaException(String mensaje) {
		super(mensaje);
	}

}
