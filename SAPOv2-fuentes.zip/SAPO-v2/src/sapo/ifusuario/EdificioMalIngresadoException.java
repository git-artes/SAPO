package sapo.ifusuario;

/**
 * Esta excepción es lanzada al crear un edificio, si alguno de los parametros 
 * (ancho, profundidad, distancia, altura) es negativo o no es un valor numérico.
 * @author Grupo de proyecto SAPO
 */

public class EdificioMalIngresadoException extends Exception {

	public EdificioMalIngresadoException(String mensaje) {
		super(mensaje);
	}

}
