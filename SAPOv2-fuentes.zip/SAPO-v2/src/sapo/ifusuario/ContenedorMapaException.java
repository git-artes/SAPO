package sapo.ifusuario;

public class ContenedorMapaException extends Exception{
	
	public ContenedorMapaException(String mensaje) {
		super(mensaje);
	}

}