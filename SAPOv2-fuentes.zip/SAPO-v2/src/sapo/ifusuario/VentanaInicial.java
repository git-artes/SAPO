package sapo.ifusuario;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import sapo.principal.Comandos;
import sapo.principal.Principal;

public class VentanaInicial extends JFrame {

	
	public VentanaInicial(ActionListener aL){
		super();
	
	
	GridBagLayout gblVentanaInicial = new GridBagLayout();
	gblVentanaInicial.columnWidths = new int[] { 300 };
	gblVentanaInicial.rowHeights = new int[] { 50, 80, 80, 80, 30 };
	gblVentanaInicial.columnWeights = new double[] { 1.0 };
	gblVentanaInicial.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0 };
	this.setLayout(gblVentanaInicial);
	this.setSize(new Dimension(300, 440));
//	this.setTitle(Principal.TITULO);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setExtendedState(Frame.NORMAL);
	this.setLocationRelativeTo(null);
	this.setResizable(false);

	JButton botonNuevoProyecto = new JButton(
	"<html><img align=\"middle\" src='file:res/new_file.png' height='40' width='40'><span style=\"display:inline-block; vertical-align:middle; font-size:10px \"> <u>N</u>uevo Proyecto </span></html>");
//			"<html><style type='text/css'>body {font-size:10px;text-align:left;vertical-align:middle;}</style><body><p><img src='file:res/new_file.png' style=\"vertical-align:middle\" alt='Nuevo Proyecto' height='40' width='40'><u>N</u>uevo Proyecto</p></body></html>");
	botonNuevoProyecto.setMnemonic(KeyEvent.VK_N);
	botonNuevoProyecto.setActionCommand(Comandos.CREAR_PROYECTO);
	botonNuevoProyecto.addActionListener(aL);

	JButton botonAbrirProyecto = new JButton(
			"<html><img align=\"middle\" src='file:res/open_file.png' height='40' width='40'><span style=\"display:inline-block; vertical-align:middle; font-size:10px \"> <u>A</u>brir Proyecto </span></html>");
//			"<html><style type='text/css'>body {font-size:10px;text-align:left;vertical-align:middle;}</style><body><p><img src='file:res/open_file.png' alt='Abrir Proyecto' height='40' width='40'><u>A</u>brir Proyecto</p></body></html>");
	botonAbrirProyecto.setMnemonic(KeyEvent.VK_A);
	botonAbrirProyecto.setActionCommand(Comandos.ABRIR_PROYECTO);
	botonAbrirProyecto.addActionListener(aL);

	GridBagConstraints gbcVentanaInicial = new GridBagConstraints();
	gbcVentanaInicial.insets = new Insets(5, 5, 5, 5);
	gbcVentanaInicial.fill = GridBagConstraints.VERTICAL;
	gbcVentanaInicial.anchor = GridBagConstraints.NORTH;
	gbcVentanaInicial.weightx = 0.0;
	gbcVentanaInicial.weighty = 0.0;
	gbcVentanaInicial.gridx = 0;
	gbcVentanaInicial.gridy = 0;
	// TODO Arreglar fuente y alineación
	JLabel bienvenido = new JLabel(
			"<html><p align=\"center\" style=\"font-size:14px\">Bienvenido a SAPO vMichigan</p><p align=\"center\" style=\"font-size:10px\">Análisis de Propagación Outdoor</p></html>");
			
//			"<html><style type='text/css'> body {font-size:16px; margin-left:auto; margin-right:auto;}</style><body><p>Bienvenido a SAPO</p></body></html>");
	// bienvenido.setFont(new Font("bienvenido", Font.BOLD, 20));
	bienvenido.setAlignmentY(Component.CENTER_ALIGNMENT);
	bienvenido.setAlignmentX(Component.CENTER_ALIGNMENT);
	bienvenido.setVerticalAlignment(SwingConstants.CENTER);
	this.add(bienvenido, gbcVentanaInicial);
	gbcVentanaInicial.fill = GridBagConstraints.HORIZONTAL;
	gbcVentanaInicial.gridy = 1;
	gbcVentanaInicial.gridwidth = 1;
	this.add(botonNuevoProyecto, gbcVentanaInicial);

	gbcVentanaInicial.gridx = 0;
	gbcVentanaInicial.gridy = 2;
	this.add(botonAbrirProyecto, gbcVentanaInicial);

	JPanel panelInferior = new JPanel();

	JButton botonAyuda = new JButton(
			"<html><style type='text/css'>body {font-size:6px;text-align:center; margin-left:auto; margin-right:auto; margin-top:auto; margin-bottom:auto}</style><body><img src='file:res/ayuda.png' alt='Nuevo Proyecto' height='25' width='25'><br><p>A<u>y</u>uda</p></body></html>");
	botonAyuda.setPreferredSize(new Dimension(80, 60));
	botonAyuda.setMnemonic(KeyEvent.VK_Y);
	botonAyuda.setActionCommand(Comandos.MANUAL);
	botonAyuda.addActionListener(aL);

	JButton botonAbout = new JButton(
			"<html><style type='text/css'>body {font-size:6px;text-align:center; margin-left:auto; margin-right:auto; margin-top:auto; margin-bottom:auto}</style><body><img src='file:res/about.png' alt='Nuevo Proyecto' height='25' width='25'><br><p>Ac<u>e</u>rca de</p></body></html>");
	botonAbout.setPreferredSize(new Dimension(80, 60));
	botonAbout.setMnemonic(KeyEvent.VK_E);
	botonAbout.setActionCommand(Comandos.ACERCA_DE);
	botonAbout.addActionListener(aL);

	JButton botonDocumentacion = new JButton(
			"<html><style type='text/css'>body {font-size:6px;text-align:center; margin-left:auto; margin-right:auto; margin-top:auto; margin-bottom:auto}</style><body><img src='file:res/documentacion.png' alt='Nuevo Proyecto' height='25' width='25' align='middle'><br><p><u>D</u>ocument.</p></body></html>");
	botonDocumentacion.setPreferredSize(new Dimension(80, 60));
	botonDocumentacion.setMnemonic(KeyEvent.VK_D);
	botonDocumentacion.setActionCommand(Comandos.DOCUMENTACION);
	botonDocumentacion.addActionListener(aL);

	panelInferior.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 5));
	panelInferior.add(botonAyuda);
	panelInferior.add(botonAbout);
	panelInferior.add(botonDocumentacion);

	gbcVentanaInicial.fill = GridBagConstraints.HORIZONTAL;
	gbcVentanaInicial.anchor = GridBagConstraints.WEST;
	gbcVentanaInicial.gridx = 0;
	gbcVentanaInicial.gridy = 3;

	this.add(panelInferior, gbcVentanaInicial);

	JLabel nombres = new JLabel("Proyecto SAPO TVDT - 2013");
	nombres.setFont(new Font("Dialog", Font.PLAIN, 8));

	nombres.setHorizontalAlignment(SwingConstants.RIGHT);
	gbcVentanaInicial.anchor = GridBagConstraints.EAST;
	gbcVentanaInicial.gridx = 0;
	gbcVentanaInicial.gridy = 4;
	this.add(nombres, gbcVentanaInicial);

	this.pack();

	}
	
}
