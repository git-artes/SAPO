package sapo.ifusuario;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JToolBar;

import sapo.principal.Comandos;

public class Toolbar extends JToolBar {

	private JButton botonGuardarProyecto;
	private JButton botonCerrarProyecto;
	private JButton botonCargarCapaManzanas;
	private JButton botonCargarCapaAlturas;
	private JButton botonCargarCapaEdificios;
	private JButton botonCrearModelo;
	private JButton botonAgregarAntena;
	private JButton botonCrearCanalFrecuencias;
	private JButton botonCrearSitio;
	private JButton botonEditarDatosProyecto; 
	private JButton botonEditarDatosUsuario;
	private JButton botonRealizarPrediccion;
	private JButton botonVerificarLOS;
	private JButton botonAbrirPrediccion;
	private JButton botonGuardarPrediccion;
	private JButton botonQuitarPrediccion;
	private JButton botonInformacionPrediccion;
	
	public Toolbar(ActionListener aL){
	super();
	setPreferredSize(new Dimension (200, 36));
	
	FlowLayout flow = new FlowLayout();
	flow.setAlignment(FlowLayout.LEFT);
	flow.setHgap(5);
	flow.setVgap(0);
	setLayout(flow);
	
	botonGuardarProyecto = new JButton("<html><img src='file:res/save_file.png' alt='Nuevo Proyecto' height='20' width='20'></html>");
	botonGuardarProyecto.setSize(new Dimension(20,20));
	botonGuardarProyecto.setActionCommand(Comandos.GUARDAR_PROYECTO);
	botonGuardarProyecto.addActionListener(aL);
	botonGuardarProyecto.setEnabled(true);
	botonGuardarProyecto.setToolTipText("Guardar proyecto");
	add(botonGuardarProyecto);

	
	botonCerrarProyecto = new JButton("<html><style='margin:0'> <img src='file:res/close_file.png' alt='Nuevo Proyecto' height='20' width='20'></html>");
	botonCerrarProyecto.setSize(new Dimension(20,20));
	botonCerrarProyecto.setActionCommand(Comandos.CERRAR_PROYECTO);
	botonCerrarProyecto.addActionListener(aL);
	botonCerrarProyecto.setEnabled(true);
	botonCerrarProyecto.setToolTipText("Cerrar proyecto");
	add(botonCerrarProyecto);
	
	botonEditarDatosProyecto = new JButton("<html><img src='file:res/proyecto.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonEditarDatosProyecto .setSize(new Dimension(20,20));
	botonEditarDatosProyecto .setActionCommand(Comandos.EDITAR_PROYECTO);
	botonEditarDatosProyecto .addActionListener(aL);
	botonEditarDatosProyecto .setEnabled(true);
	botonEditarDatosProyecto .setToolTipText("Editar datos de Proyecto");
	add(botonEditarDatosProyecto);
	
	botonEditarDatosUsuario = new JButton("<html><img src='file:res/usuario.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonEditarDatosUsuario .setSize(new Dimension(20,20));
	botonEditarDatosUsuario .setActionCommand(Comandos.EDITAR_PERFIL);
	botonEditarDatosUsuario .addActionListener(aL);
	botonEditarDatosUsuario .setEnabled(true);
	botonEditarDatosUsuario .setToolTipText("Editar perfil de Usuario");
	add(botonEditarDatosUsuario);
	
	addSeparator();
	
	botonCargarCapaAlturas = new JButton("<html><img src='file:res/alturas.png' alt='Capa Alturas' height='20' width='20'></html>");
	botonCargarCapaAlturas.setSize(new Dimension(20,20));
	botonCargarCapaAlturas.setActionCommand(Comandos.ABRIR_ALTURAS);
	botonCargarCapaAlturas.addActionListener(aL);
	botonCargarCapaAlturas.setToolTipText("Agregar capa de terreno");
	botonCargarCapaAlturas.setEnabled(true);
	// TODO Agregar ayuda cuando se coloca el mouse sobre el botón
	
	add(botonCargarCapaAlturas);
	
	botonCargarCapaManzanas= new JButton("<html><img src='file:res/manzanas.png' alt='Capa Manzanas' height='20' width='20'></html>");
	botonCargarCapaManzanas.setSize(new Dimension(20,20));
	botonCargarCapaManzanas.setActionCommand(Comandos.ABRIR_MANZANAS);
	botonCargarCapaManzanas.addActionListener(aL);
	botonCargarCapaManzanas.setEnabled(false);
	botonCargarCapaManzanas.setToolTipText("Agregar capa de Manzanas");
	add(botonCargarCapaManzanas);
	
	botonCargarCapaEdificios= new JButton("<html><img src='file:res/edificios.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonCargarCapaEdificios.setSize(new Dimension(20,20));
	botonCargarCapaEdificios.setActionCommand(Comandos.ABRIR_EDIFICIOS);
	botonCargarCapaEdificios.addActionListener(aL);
	botonCargarCapaEdificios.setEnabled(false);
	botonCargarCapaEdificios.setToolTipText("Agregar capa de Edificios");
	add(botonCargarCapaEdificios);

	addSeparator();
	
	botonCrearModelo= new JButton("<html><img src='file:res/modelo.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonCrearModelo .setSize(new Dimension(20,20));
	botonCrearModelo .setActionCommand(Comandos.AGREGAR_MODELO);
	botonCrearModelo .addActionListener(aL);
	botonCrearModelo .setEnabled(true);
	botonCrearModelo .setToolTipText("Crear nuevo Modelo");
	add(botonCrearModelo);

	
	botonAgregarAntena = new JButton("<html><img src='file:res/antena.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonAgregarAntena .setSize(new Dimension(20,20));
	botonAgregarAntena .setActionCommand(Comandos.AGREGAR_TIPO_ANTENA);
	botonAgregarAntena .addActionListener(aL);
	botonAgregarAntena .setEnabled(true);
	botonAgregarAntena .setToolTipText("Agregar nueva Antena");
	add(botonAgregarAntena);

	botonCrearCanalFrecuencias = new JButton("<html><img src='file:res/frecuencias.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonCrearCanalFrecuencias .setSize(new Dimension(20,20));
	botonCrearCanalFrecuencias .setActionCommand(Comandos.AGREGAR_CANAL);
	botonCrearCanalFrecuencias .addActionListener(aL);
	botonCrearCanalFrecuencias .setEnabled(true);
	botonCrearCanalFrecuencias .setToolTipText("Agregar nuevo Canal");
	add(botonCrearCanalFrecuencias);

	botonCrearSitio = new JButton("<html><img src='file:res/sitio.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonCrearSitio .setSize(new Dimension(20,20));
	botonCrearSitio .setActionCommand(Comandos.AGREGAR_SITIO);
	botonCrearSitio .addActionListener(aL);
	botonCrearSitio .setEnabled(false);
	botonCrearSitio .setToolTipText("Agregar nuevo Sitio");
	add(botonCrearSitio);
	
	addSeparator();
	
	botonRealizarPrediccion = new JButton("<html><img src='file:res/prediccion.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonRealizarPrediccion  .setSize(new Dimension(20,20));
	botonRealizarPrediccion  .setActionCommand(Comandos.ESTIMAR_PREDICCION);
	botonRealizarPrediccion  .addActionListener(aL);
	botonRealizarPrediccion  .setEnabled(true);
	botonRealizarPrediccion  .setToolTipText("Realizar Predicci�n");
	add(botonRealizarPrediccion);
	
	botonVerificarLOS = new JButton("<html><img src='file:res/LOS.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonVerificarLOS  .setSize(new Dimension(20,20));
	botonVerificarLOS  .setActionCommand(Comandos.ESTIMAR_LOS);
	botonVerificarLOS  .addActionListener(aL);
	botonVerificarLOS  .setEnabled(true);
	botonVerificarLOS  .setToolTipText("Verificar LOS");
	add(botonVerificarLOS);
	
	botonAbrirPrediccion = new JButton("<html><img src='file:res/abrir_prediccion.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonAbrirPrediccion  .setSize(new Dimension(20,20));
	botonAbrirPrediccion  .setActionCommand(Comandos.ABRIR_PREDICCION);
	botonAbrirPrediccion  .addActionListener(aL);
	botonAbrirPrediccion  .setEnabled(true);
	botonAbrirPrediccion  .setToolTipText("Abrir Predicci�n");
	add(botonAbrirPrediccion);
	
	botonGuardarPrediccion = new JButton("<html><img src='file:res/guardar_prediccion.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonGuardarPrediccion  .setSize(new Dimension(20,20));
	botonGuardarPrediccion  .setActionCommand(Comandos.GUARDAR_PREDICCION);
	botonGuardarPrediccion  .addActionListener(aL);
	botonGuardarPrediccion  .setEnabled(false);
	botonGuardarPrediccion  .setToolTipText("Guardar Predicci�n");
	add(botonGuardarPrediccion);
	
	botonQuitarPrediccion = new JButton("<html><img src='file:res/quitar_prediccion.png' alt='Capa Edificios' height='20' width='20'></html>");
	botonQuitarPrediccion   .setSize(new Dimension(20,20));
	botonQuitarPrediccion   .setActionCommand(Comandos.CERRAR_PREDICCION);
	botonQuitarPrediccion   .addActionListener(aL);
	botonQuitarPrediccion   .setEnabled(false);
	botonQuitarPrediccion   .setToolTipText("Quitar Predicci�n");
	add(botonQuitarPrediccion );
	
	
	}
	
	public void disableAlturas(){
		this.botonCargarCapaAlturas.setEnabled(false);
	}
	
	public void disableManzanas(){
		this.botonCargarCapaManzanas.setEnabled(false);
	}
	
	public void disableEdificios(){
		this.botonCargarCapaEdificios.setEnabled(false);
	}
	
	public void enableSitio(){
		this.botonCrearSitio.setEnabled(true);
	}
	
	public void enableManzanas(){
		this.botonCargarCapaManzanas.setEnabled(true);
	}
	
	public void enableEdificios(){
		this.botonCargarCapaEdificios.setEnabled(true);
	}
	
	public void enablePredicciones(){
		this.botonRealizarPrediccion.setEnabled(true);
		this.botonVerificarLOS.setEnabled(true);
		this.botonAbrirPrediccion.setEnabled(true);
		this.botonGuardarPrediccion.setEnabled(false);
		this.botonQuitarPrediccion.setEnabled(false);
	}
	
	public void disablePredicciones(){
		this.botonRealizarPrediccion.setEnabled(false);
		this.botonVerificarLOS.setEnabled(false);
		this.botonAbrirPrediccion.setEnabled(false);
		this.botonGuardarPrediccion.setEnabled(true);
		this.botonQuitarPrediccion.setEnabled(true);
	}
}