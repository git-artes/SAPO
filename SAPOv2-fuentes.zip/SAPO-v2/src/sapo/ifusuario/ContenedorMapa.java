package sapo.ifusuario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.Iterator;

import javax.swing.SwingConstants;
import javax.swing.UIManager;

import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.gc.GridCoverage;
import org.geotools.gui.swing.ColorBar;
import org.geotools.styling.ColorMap;
import org.geotools.styling.RasterSymbolizer;
import org.geotools.styling.StyleBuilder;

import sapo.capas.ElementoCapa;
import sapo.capas.estilos.EstiloResultados;
import sapo.capas.estilos.EstiloSitios;
import sapo.predicciones.PrediccionMultiAntena;
import sapo.proyecto.PerfilUsuario;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Sitio;
import sapo.vectorial.Edificio;
import sapo.vectorial.Manzana;

import com.jgoodies.looks.plastic.PlasticXPLookAndFeel;

import sapo.ifusuario.ContenedorMapaException;

/**
 * Esta clase es la encargada del manejo de las capas que constituyen el mapa.
 * @author Grupo de proyecto SAPO
 */

public class ContenedorMapa extends ContenedorMapaGeneral {

	/**
	 * El mapa
	 */
	Mapa mapa;

	/**
	 * La barra de colores para los niveles de potencia
	 */
	ColorBar cbPrediccion;

	/**
	 * La URL donde estï¿œ el archivo de alturas
	 */
	URL dirCapaAlturas;

	/**
	 * La URL donde estï¿œ el archivo de edificios
	 */
	URL dirCapaEdificios;

	/**
	 * La URL donde estï¿œ el archivo de manzanas
	 */
	URL dirCapaManzanas;

	/**
	 * Construye un ContenedorMapa vacï¿œo. Inicializa los popups.
	 * 
	 * @param eL 
	 *            quien escucha los eventos que s egeneran en el ContenedorMapa
	 * @throws Exception 
	 */
	public ContenedorMapa(EventListener eL) throws Exception {
		super();
		this.mapa = new Mapa();
		this.setMapContext(mapa);
		this.setLayout(new BorderLayout());

		//listeners
		this.addMouseListener((MouseListener) eL);
		this.addMouseMotionListener((MouseMotionListener) eL);

		this.setMagnifierBorder(new Color(200, 240, 120));
		this.setMagnifierGlass(Color.ORANGE);

		try {
			UIManager.setLookAndFeel(new PlasticXPLookAndFeel());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Crea la capa de sitios a partir de un ArrayList de sitios
	 * 
	 * @param sitios 
	 *            los sitios a agregar en la capa
	 * @throws SitioMalPosicionadoException 
	 * @throws Exception
	 */
	public void crearCapaSitios(ArrayList sitios) throws SitioMalPosicionadoException, Exception {
		for (int i = 0; i < sitios.size(); i++) {
			mapa.agregarSitio((Sitio) sitios.get(i));
		}
		mapa.capaSitios.setStyle(new EstiloSitios());
		mapa.capaSitiosSeleccionados.setStyle(new EstiloSitios(true));
	}

	// METODOS GET

	/**
	 * Devuelve el mapa
	 */
	public Mapa getMapa() {
		return mapa;
	}

	/**
	 * 
	 * Guarda la direccion del archivo de alturas que fue abierto para luego
	 * pasarselo al proyecto en caso de querer guardarlo
	 * 
	 * @return la URL del archivo de alturas
	 *  
	 */

	public URL getLinkCapaAlturas() {
		return dirCapaAlturas;
	}

	/**
	 * 
	 * Este metodo guarda la direccion del archivo de edificios que fue abierto
	 * para luego pasarselo al proyecto en caso de querer guardarlo

	 */

	public URL getLinkCapaEdificios() {
		return dirCapaEdificios;
	}

	/**
	 * 
	 * Este metodo guarda la direccion del archivo de cuadras que fue abierto
	 * para luego pasarselo al proyecto en caso de querer guardarlo
	 * 

	 *  
	 */

	public URL getLinkCapaCuadras() {
		return dirCapaManzanas;
	}

	// METODOS PPALES PARA MANIPULAR CAPAS

	/**
	 * Crea la capa de manzanas a partir de la featureCollection especificada
	 * 
	 * @param fc 
	 *            la FeatureCollection
	 * @throws IOException
	 */
	public void crearCapaManzanas(FeatureCollection fc) throws IOException {
		Iterator i = fc.iterator();
		while (i.hasNext()) {
			Feature f = (Feature) i.next();
			//Calle calle = new Calle(f);
			//mapa.capaManzanas.agregar((ElementoCapa)calle);
			Manzana manzana = new Manzana(f);
			mapa.capaManzanas.agregar((ElementoCapa) manzana, fc);
		}
		mapa.capaManzanas.recargarEstilo();
		this.agregarBarraEscala();
	}

	/**
	 * Crea la capa de edificios a partir de la featureCollection especificada
	 * 
	 * @param fc 
	 *            la FeatureCollection
	 * @throws IOException
	 */
	public void crearCapaEdificios(FeatureCollection fc) throws IOException {
		Iterator i = fc.iterator();
		int contador = 0;
		while (i.hasNext()) {
			Feature f = (Feature) i.next();
			//String hola = f.getAttribute(1).toString();
			contador++;
			System.out.println(contador);
			Edificio edificio = new Edificio(f);
			mapa.capaEdificios.agregar((ElementoCapa) edificio, fc);
		}
		mapa.capaEdificios.recargarEstilo();
	}
	
	
	/**
	 * Crea la capa de alturas a partir de la grilla especificada
	 * 
	 * @param grilla 
	 *            la Grilla
	 * @throws IOException
	 */

	public void crearCapaAlturas(Grilla grilla) throws IOException {
		mapa.capaAlturas.agregar((ElementoCapa) grilla);
		this.agregarBarraEscala();
	}

	/**
	 * Agrega la predicciï¿œn al mapa, haciï¿œndolo visible.
	 * 
	 * @param prediccion 
	 *            la PrediccionMultiAntena
	 */
	public void crearCapaResultados(PrediccionMultiAntena predicciones, Proyecto proy) throws ContenedorMapaException{
		try {
			Grilla[] grillasResultados = predicciones.getCoveragesAMostrar();
			for (int j = 0; j < grillasResultados.length; j++) {
				mapa.capaResultados.agregar((ElementoCapa) grillasResultados[j]);
			}
			if(proy.getPerfilUsuario().intAutomaticos()){
				((EstiloResultados)(mapa.capaResultados.getStyle())).setMaxMin(
						predicciones.getMax() + Math.abs(predicciones.getMax()*0.01),
						predicciones.getMin() - Math.abs(predicciones.getMin()*0.01));
			}else{			
				if(proy.getPerfilUsuario().getIntCapaResults()[0] < predicciones.getMin() || proy.getPerfilUsuario().getIntCapaResults()[3] > predicciones.getMax()){
					ContenedorMapaException e = new ContenedorMapaException("Los rangos elegidos para la representación de resultados se solapan!"+ "\n" +"Se recomienda cambiar los valores A y D para que se ajusten a su predicción."); 
					throw e;
				}else{
					((EstiloResultados)(mapa.capaResultados.getStyle())).setColorMap(
							predicciones.getMax() + Math.abs(predicciones.getMax()*0.01),
							predicciones.getMin() - Math.abs(predicciones.getMin()*0.01), proy.getPerfilUsuario().getIntCapaResults());
				}				
			}
			
			//esto que viene ahora es para hacer la barra de colores
			Grilla gResultados = grillasResultados[0];
			
			//GM: Importo los colores de la predicción.
			Color[] coloresAux = ((EstiloResultados) mapa.capaResultados
					.getStyle()).getColores();
			
			Color[] colores = new Color[coloresAux.length - 1];
			Color[][] colores2 = new Color[1][colores.length];
			for (int j = 0; j < colores.length; j++){
				colores[j] = new Color(coloresAux[j].getRed(), coloresAux[j].getGreen(), coloresAux[j].getBlue());
				colores2[0][j] = colores[j];
			}
			
			//construyo una GridCoverage auxiliar para que los colores de la ColorBar coincidan con los del estilo.  
			GridCoverage gcAuxiliar = new GridCoverage("", gResultados
					.getRaster(), gResultados.getGridCoverage()
					.getCoordinateSystem(), gResultados.getGridCoverage()
					.getEnvelope(), null, null, null, colores2, null);
			cbPrediccion = new ColorBar(gcAuxiliar);
			
			//GM: Para que imprima rangos:
			cbPrediccion.setColors(colores);
			//cbPrediccion.setOrientation(SwingConstants.VERTICAL);
			//this.add(cbPrediccion, BorderLayout.EAST); //GM: Antes: North
			this.add(cbPrediccion, BorderLayout.NORTH);
			
			mapa.capaResultados.recargarEstilo();
			this.validate();
		} catch (IOException e) {
			e.printStackTrace(System.out);
		}
	}
	/**
	 * Agrega las grillas correspondientes a las interferencias.

	 */
	public void crearCapaInterferencia(PrediccionMultiAntena predicciones) {
		try {
			Grilla[] grillasInterferencia = predicciones
			.getCoveragesInterferencia();
			for (int j = 0; j < grillasInterferencia.length; j++) {
				mapa.capaResultados.agregar((ElementoCapa) grillasInterferencia[j]);
			}
			((EstiloResultados)(mapa.capaResultados.getStyle())).setMaxMin(
					predicciones.getMaxInter() + Math.abs(predicciones.getMaxInter()*0.01),
					predicciones.getMinInter() - Math.abs(predicciones.getMinInter()*0.01));
			
			//esto que viene ahora es para hacer la barra de colores
			Grilla gInter = grillasInterferencia[0];
			Color[] colores = ((EstiloResultados) mapa.capaResultados
					.getStyle()).getColores();
			Color[][] colores2 = new Color[1][colores.length];
			for (int j = 0; j < colores2[0].length; j++)
				colores2[0][j] = colores[j];
			//construyo una GridCoverage auxiliar para que los colores de la ColorBar coincidan con los del estilo.  
			GridCoverage gcAuxiliar = new GridCoverage(
					"",
					gInter.getRaster(),
					gInter.getGridCoverage().getCoordinateSystem(),
					gInter.getGridCoverage().getEnvelope(),
					null,
					null,
					null,
					colores2,
					null);
			cbPrediccion = new ColorBar(gcAuxiliar);
			this.add(cbPrediccion, BorderLayout.NORTH);
			mapa.capaResultados.recargarEstilo();
			this.validate();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	/**
	 * Agrega las grillas correspondientes a las coberturas.
	 * 
	 * @param predicciones
	 * @param perfil 
	 *            el perfil con el que se harï¿œ la predicciï¿œn de cobertura.
	 */
	public void crearCapaCobertura(
			PrediccionMultiAntena predicciones,
			PerfilUsuario perfil) {
		try {
			Grilla[] grillasCobertura = predicciones
			.getCoveragesCobertura(perfil);
			for (int j = 0; j < grillasCobertura.length; j++) {
				mapa.capaResultados.agregar((ElementoCapa) grillasCobertura[j]);
			}
			((EstiloResultados)(mapa.capaResultados.getStyle())).setMaxMin(2.0, -0.01);
			mapa.capaResultados.recargarEstilo();
			this.validate();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	/**
	 * 
	 * Vacia la capa Resultados de Mapa.
	 * 
	 *  
	 */

	public void quitarCapaResultados() {
		try {
			this.mapa.capaResultados.vaciar();
			this.remove(this.cbPrediccion);
			this.validate();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	/**
	 * Hace visible o no la capa de alturas dependiendo de visible.

	 */
	public void mostrarCapaAlturas(boolean visible) {
		this.mapa.capaAlturas.setVisible(visible);
		this.validate();
	}

	/**
	 * Hace visible o no la capa de edificios dependiende de visible.
	 * 

	 */
	public void mostrarCapaEdificios(boolean visible) {
		this.mapa.capaEdificios.setVisible(visible);
		this.validate();
	}

	/**
	 * Hace visible o no la capa de manzanas dependiende de visible.
	 * 
	 * @param visible
	 */
	public void mostrarCapaManzanas(boolean visible) {
		this.mapa.capaManzanas.setVisible(visible);
		this.validate();
	}

	/**
	 * Hace visible o no la capa de predicciones dependiende de visible.
* 
	 * @param visible
	 */
	public void mostrarCapaPredicciones(boolean visible) {
		this.mapa.capaResultados.setVisible(visible);
		this.validate();
	}

	public void quitarBarra() {
		try {
			this.remove(this.cbPrediccion);
			this.validate();
		} catch (Exception e) {
		}//si va para acï¿œ es porque no lo tiene
	}

}
