package sapo.ifusuario;

import java.io.IOException;

import org.geotools.map.DefaultMapContext;

import sapo.capas.CapaVectorial;
import sapo.capas.estilos.EstiloEdificios;
import sapo.capas.estilos.EstiloManzanas;

/**
 * Esta clase define la agrupación de capas (mapa) del Generador de Edificios.
 * @author Grupo de Proyecto SAPO.
 */
public class MapaEdificios extends DefaultMapContext {

	/**
	 * La capa de manzanas
	 */
	public CapaVectorial capaManzanas = new CapaVectorial();

	/**
	 * El índice de la capa de manzanas
	 */
	public final static int INDICE_MANZANAS = 0;

	/**
	 * La capa de la manzana seleccionada
	 */
	public CapaVectorial capaManzanaElegida = new CapaVectorial();

	/**
	 * El índice de la capa de la manzana seleccionada
	 */
	public final static int INDICE_MANZANA_SELECCIONADA = 1;

	/**
	 * La capa de edificios
	 */
	public CapaVectorial capaEdificios = new CapaVectorial();

	/**
	 * El índice de la capa de edificios
	 */
	public final static int INDICE_EDIFICIOS = 2;

	/**
	 * La capa de la cuadra seleccionada
	 */
	public CapaVectorial capaCuadraElegida = new CapaVectorial();

	/**
	 * El índice de la capa de la cuadra seleccionada
	 */
	public final static int INDICE_CUADRA_SELECCIONADA = 3;

	/**
	 * La capa de la esquina seleccionada
	 */
	public CapaVectorial capaEsquinaElegida = new CapaVectorial();

	/**
	 * El índice de la capa de la esquina seleccionada
	 */
	public final static int INDICE_ESQUINA_SELECCIONADA = 4;

	/**
	 * La capa de el edificio seleccionado
	 */
	public CapaVectorial capaEdificioElegido = new CapaVectorial();

	/**
	 * El índice de la capa de el edificio seleccionado
	 */
	public final static int INDICE_EDIFICIO_SELECCIONAD0 = 5;

	/**
	 * Crea un mapa para el Generador de Edificios
	 * 
	 * @param capaInicial 
	 *            la capa inicial de manzanas
	 * @param capaEdificios 
	 *            la capa inicial de edificios, puede estar vacia
	 */
	public MapaEdificios(CapaVectorial capaInicial, CapaVectorial capaEdificios) throws IOException{

		capaManzanas = capaInicial;
		this.capaEdificios = capaEdificios;

		capaManzanaElegida.setStyle(new EstiloManzanas(true));//manzana elegida
		capaEdificios.setStyle(new EstiloEdificios());//edificios creados
		capaEsquinaElegida.setStyle(new EstiloManzanas(EstiloManzanas.ESQUINA));//esquinas
																				// elegidas
		capaCuadraElegida.setStyle(new EstiloManzanas(EstiloManzanas.CUADRA));//cuadra
																			  // elegida
		capaEdificioElegido.setStyle(new EstiloEdificios(true));//edificio
																// elegido

		addLayer(INDICE_MANZANAS, capaManzanas); //0
		addLayer(INDICE_MANZANA_SELECCIONADA, capaManzanaElegida); //1
		addLayer(INDICE_EDIFICIOS, capaEdificios); //2
		addLayer(INDICE_CUADRA_SELECCIONADA, capaCuadraElegida); //3
		addLayer(INDICE_ESQUINA_SELECCIONADA, capaEsquinaElegida); //4
		addLayer(INDICE_EDIFICIO_SELECCIONAD0, capaEdificioElegido); //5

	}

}
