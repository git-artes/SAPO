package sapo.ifusuario;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import sapo.predicciones.PrediccionMultiAntena;
import sapo.predicciones.PrediccionUniAntena;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;
import sapo.red.Sitio;

/**
 * Esta clase define la ventana qu edespliega la información de las 
 * antenas involucradas en una predicción.  
 * @author Grupo de proyecto SAPO
 *  
 */

public class VentanaInfoPrediccion extends JDialog implements ActionListener {

	ArrayList antenas;

	Proyecto proyecto;

	JPanel[] paneles;

	JPanel panelActual;

	int nroPanelActual;

	JButton anterior = new JButton("< Anterior");

	JButton cerrar = new JButton("Cerrar");

	JButton siguiente = new JButton("Siguiente >");

	int cantidadAntenas;

	int cantidadHojas;

	PrediccionMultiAntena prediccion;

	public VentanaInfoPrediccion(JFrame duenio,
			PrediccionMultiAntena prediccion, Proyecto proyecto)
			throws DatosNoDisponiblesException {
		super(duenio, true);
		this.setTitle("Información de Prediccion");
		//this.setSize(new Dimension(600,420));
		//this.setLocationRelativeTo(duenio);

		//inicializacion de los campos
		this.proyecto = proyecto;
		this.nroPanelActual = 0;
		this.cantidadAntenas = prediccion.getPredicciones().size();
		this.cantidadHojas = (int) Math.ceil(cantidadAntenas / 4.0);
		this.paneles = new JPanel[cantidadHojas];
		this.panelActual = new JPanel();

		//if (cantidadAntenas<=2) this.setSize(new Dimension(300,420));

		String[] nombres;
		Antena antena;
		JPanel panelAntena;

		Iterator i = prediccion.getPredicciones().iterator();
		int n = 2;
		if (this.cantidadAntenas == 1)
			n = 1;

		for (int j = 0; j < this.cantidadHojas; j++) {
			paneles[j] = new JPanel(new GridLayout(n, n, 10, 10));
			int k = 0;
			while (i.hasNext() && k < 4) {
				nombres = (((PrediccionUniAntena) i.next()).getNombreAntena())
						.split("\\x2E"); //2E es el ASCII del punto
				antena = proyecto.getSitio(nombres[0]).getRadiobase(nombres[1])
						.getAntena(nombres[2]);
				if (antena == null) {
					throw new DatosNoDisponiblesException(
							"Alguna de las antenas involucradas en la prediccion ha sido cambiada o borrada del proyecto.");
				}
				panelAntena = this.crearPanelAntena(antena);
				paneles[j].add(panelAntena);
				k++;
			}
			if (k <= 2 && j != 0) {
				for (int m = k; m < 4 - k; m++) {
					paneles[j].add(new JPanel());
				}
			}
		}

		//agrregar los campos
		this.agregarCampos();
		this.pack();
		this.setLocationRelativeTo(duenio);

		//estado inicial
		anterior.setEnabled(false);
		if (nroPanelActual == cantidadHojas - 1) {
			siguiente.setEnabled(false);
		}

		//listeners
		anterior.addActionListener(this);
		siguiente.addActionListener(this);
		cerrar.addActionListener(this);

	}

	private void agregarCampos() {

		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		c.weightx = 1;
		c.weighty = 1;
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = GridBagConstraints.REMAINDER;

		//this.panelActual = paneles[nroPanelActual];
		this.panelActual.add(paneles[nroPanelActual]);
		this.getContentPane().add(panelActual, c);

		c.fill = GridBagConstraints.NONE;
		JPanel panelBotones = new JPanel(new GridLayout(1, 3, 3, 3));
		panelBotones.add(anterior);
		panelBotones.add(cerrar);
		panelBotones.add(siguiente);
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);
	}

	private JPanel crearPanelAntena(Antena antena) {
		JPanel panelAntena = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);
		//JPanel panel = new JPanel(new GridLayout(8,2,3,3));
		panelAntena.setBorder(BorderFactory.createTitledBorder(antena
				.getSitio()
				+ "." + antena.getRB() + "." + antena.getNombre()));

		Sitio sitio = proyecto.getSitio(antena.getSitio());
		String omnidireccional = "omnidireccional";
		if (!antena.getTipo().esIsotropica())
			omnidireccional = "directiva";

		JPanel panel = new JPanel(new GridLayout(8, 1, 3, 3));
		panel.add(new JLabel("Posición: "));
		panel.add(new JLabel("Altura: "));
		panel.add(new JLabel("Potencia: "));
		panel.add(new JLabel("Tilt: "));
		panel.add(new JLabel("Azimut: "));
		panel.add(new JLabel("Frecuencias:"));
		panel.add(new JLabel("Tipo:"));
		panel.add(new JLabel("Modelo:"));
		panelAntena.add(panel, c);

		panel = new JPanel(new GridLayout(8, 1, 3, 3));
		panel.add(new JLabel("(" + sitio.getX() + ", " + sitio.getY() + ")"));
		panel.add(new JLabel(sitio.getRadiobase(antena.getRB()).getAltura()
				+ " m"));
		panel.add(new JLabel(antena.getPotencia() + " dBm"));
		panel.add(new JLabel(antena.getTilt() + " grados"));
		panel.add(new JLabel(antena.getAzimut() + " grados"));
		panel.add(new JLabel(antena.getCanal().getNombre() + " ("
				+ antena.getCanal().getFrecuenciaMaxima() + " MHz)"));
		panel.add(new JLabel(antena.getTipo().getNombre() + " ("
				+ omnidireccional + ")"));
		panel.add(new JLabel(antena.getModelo().getNombre() + " ("
				+ antena.getModelo().getNombreModelo() + ")"));
		panelAntena.add(panel, c);

		return panelAntena;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(cerrar)) {
			this.setVisible(false);
			this.dispose();
		} else if (e.getSource().equals(siguiente)) {
			this.nroPanelActual++;
			this.panelActual.removeAll();
			this.panelActual.add(paneles[nroPanelActual]);
			//this.panelActual = paneles[nroPanelActual];
			anterior.setEnabled(true);
			if (nroPanelActual == cantidadHojas - 1) {
				siguiente.setEnabled(false);
			}
			this.validate();
			this.repaint();

		} else if (e.getSource().equals(anterior)) {
			this.nroPanelActual--;
			this.panelActual.removeAll();
			this.panelActual.add(paneles[nroPanelActual]);
			//this.panelActual = paneles[nroPanelActual];
			siguiente.setEnabled(true);
			if (nroPanelActual == 0) {
				anterior.setEnabled(false);
			}
			this.validate();
			this.repaint();
		}
	}

}