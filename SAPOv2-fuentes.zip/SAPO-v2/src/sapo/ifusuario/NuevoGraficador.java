package sapo.ifusuario;

import java.awt.Color;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class NuevoGraficador{
	
//	XYSeriesCollection dataset;
	String titulo;

	public NuevoGraficador(String titulo) {
		this.titulo = titulo;
	}

	public XYSeriesCollection getDataset(String serie1, String serie2, double[] ejeX1, double[] ejeY1, double[] ejeX2, double[] ejeY2) {

		final XYSeries series1 = new XYSeries(serie1);
		int largo1 = ejeX1.length;
		for(int i = 0; i < largo1; i++){
       		series1.add(ejeX1[i], ejeY1[i]);
       	}

        final XYSeries series2 = new XYSeries(serie2);
        int largo2 = ejeX2.length;
        for(int j = 0; j < largo2; j++){
       		series2.add(ejeX2[j], ejeY2[j]);
       	}

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series1);
        dataset.addSeries(series2);
        return dataset;
    }
    
	public JFreeChart createChart(String tituloEjeX, String tituloEjeY, XYSeriesCollection dataset, boolean mostrarLineasSerie1, boolean mostrarLineasSerie2, boolean mostrarPuntosSerie1, boolean mostrarPuntosSerie2) {
		
		final JFreeChart chart = ChartFactory.createXYLineChart(this.titulo, tituloEjeX, tituloEjeY, dataset, PlotOrientation.VERTICAL,true, true, false);
		chart.setBackgroundPaint(Color.white);

		final XYPlot plot = chart.getXYPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);

		NumberAxis ejeY = (NumberAxis)plot.getRangeAxis();
		ejeY.setAutoRangeIncludesZero(false); // Para que no incluya el cero en el eje Y.
		
		final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		
		renderer.setSeriesLinesVisible(0, mostrarLineasSerie1);
		renderer.setSeriesLinesVisible(1, mostrarLineasSerie2);
		renderer.setSeriesShapesVisible(0, mostrarPuntosSerie1);
		renderer.setSeriesShapesVisible(1, mostrarPuntosSerie2);
		
		plot.setRenderer(renderer);

		// change the auto tick unit selection to integer units only...
		final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
		rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

        return chart;
    }
}