package sapo.ifusuario;

import java.awt.event.ActionListener;
import java.util.EventListener;

import sapo.ifusuario.menues.Popup;
import sapo.principal.Comandos;

/**
 * Esta clase define el explorador que contiene los canales de frecuencia.
 * @author Grupo de proyecto SAPO
 */

public class ExploradorCanales extends Explorador {

	/**
	 * El nivel del nodo raíz
	 */
	public final static int NIVEL_RAIZ = 0;

	/**
	 * El nivel de los nodos que representan los canales
	 */
	public final static int NIVEL_CANALES = 1;

	/**
	 * Construye un explorador para los canales de frecuencia
	 * 
	 * @param eL 
	 *            Quien va a escuchar los eventos que ocurran en el explorador
	 */
	protected ExploradorCanales(EventListener eL) {
		super(eL, "CANALES disponibles");
		arbol.addMouseListener(this);
		popupNivel0 = new Popup((ActionListener) eL,
				new String[] { Comandos.AGREGAR_CANAL });
		popupNivel1 = new Popup((ActionListener) eL, new String[] {
				Comandos.EDITAR_CANAL, Comandos.BORRAR_CANAL });
	}

}
