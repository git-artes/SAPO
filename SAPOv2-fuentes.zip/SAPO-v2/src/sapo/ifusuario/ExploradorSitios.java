package sapo.ifusuario;

import java.awt.event.ActionListener;
import java.util.EventListener;

import javax.swing.tree.DefaultMutableTreeNode;

import sapo.ifusuario.menues.Popup;
import sapo.principal.Comandos;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 *Esta clase define el explorador que contiene los sitios, radiobases y antenas.
 * @author Grupo de proyecto SAPO
 */

public class ExploradorSitios extends Explorador {

	/**
	 * El nivel del nodo raíz
	 */
	public final static int NIVEL_RAIZ = 0;

	/**
	 * El nivel de los nodos que representan los sitios
	 */
	public final static int NIVEL_SITIOS = 1;

	/**
	 * El nivel de los nodos que representan las radiobases
	 */
	public final static int NIVEL_RADIOBASES = 2;

	/**
	 * El nivel de los nodos que representan las antenas
	 */
	public final static int NIVEL_ANTENAS = 3;

	/**
	 * Construye un explorador para los sitios, radiobases y antenas
	 * 
	 * @param eL 
	 *            Quien va a escuchar los eventos que ocurran en el explorador
	 */

	protected ExploradorSitios(EventListener eL) {
		super(eL, "SITIOS");
		popupNivel0 = new Popup((ActionListener) eL,
				new String[] { Comandos.AGREGAR_SITIO });
		popupNivel1 = new Popup((ActionListener) eL, new String[] {
				Comandos.EDITAR_SITIO, Comandos.BORRAR_SITIO });
		popupNivel2 = new Popup((ActionListener) eL, new String[] {
				Comandos.EDITAR_RADIOBASE, Comandos.BORRAR_RADIOBASE });
		popupNivel3 = new Popup((ActionListener) eL, new String[] {
				Comandos.EDITAR_ANTENA, Comandos.BORRAR_ANTENA });
	}

	/**
	 * Agrega un sitio al explorador, con sus radiobases y antenas
	 * 
	 * @param sitio 
	 *            el sitio a agregar
	 */
	protected void agregarSitio(Sitio sitio) {
		DefaultMutableTreeNode nodoSitio = agregarNodo(nodoRaiz, sitio
				.getNombre());
		for (int i = 0; i < sitio.getRadiobases().size(); i++) {
			Radiobase radiobase = (Radiobase) sitio.getRadiobases().get(i);
			DefaultMutableTreeNode nodoRB = agregarNodo(nodoSitio, radiobase
					.getNombre());
			for (int j = 0; j < radiobase.getAntenas().size(); j++) {
				Antena antena = (Antena) radiobase.getAntenas().get(j);
				agregarNodo(nodoRB, antena.getNombre());
			}
		}
		seleccionar(nodoSitio);
	}

	/**
	 * Susituye el sitio seleccionado por uno nuevo
	 * 
	 * @param sitioNuevo 
	 *            el nuevo sitio
	 */
	protected void editarSitio(Sitio sitioNuevo) {
		DefaultMutableTreeNode nodoSeleccionado = (DefaultMutableTreeNode) (arbol
				.getSelectionPath().getLastPathComponent());
		nodoSeleccionado.removeAllChildren();
		modelo.reload(nodoSeleccionado);
		nodoSeleccionado.setUserObject(sitioNuevo.getNombre());
		for (int i = 0; i < sitioNuevo.getRadiobases().size(); i++) {
			Radiobase radiobase = (Radiobase) sitioNuevo.getRadiobases().get(i);
			DefaultMutableTreeNode nodoRB = agregarNodo(nodoSeleccionado,
					radiobase.getNombre());
			for (int j = 0; j < radiobase.getAntenas().size(); j++) {
				Antena antena = (Antena) radiobase.getAntenas().get(j);
				agregarNodo(nodoRB, antena.getNombre());
			}
		}
		seleccionar(nodoSeleccionado);
	}

	/**
	 * Sustituye la radiobase seleccionada por una nueva
	 * 
	 * @param rbNueva 
	 *            la nueva radiobase
	 */
	protected void editarRB(Radiobase rbNueva) {
		DefaultMutableTreeNode nodoSeleccionado = (DefaultMutableTreeNode) (arbol
				.getSelectionPath().getLastPathComponent());
		nodoSeleccionado.removeAllChildren();
		modelo.reload(nodoSeleccionado);
		nodoSeleccionado.setUserObject(rbNueva.getNombre());
		for (int j = 0; j < rbNueva.getAntenas().size(); j++) {
			Antena antena = (Antena) rbNueva.getAntenas().get(j);
			agregarNodo(nodoSeleccionado, antena.getNombre());
		}
		seleccionar(nodoSeleccionado);
	}

	/**
	 * Selecciona un sitio en el explorador
	 * 
	 * @param nombreSitio 
	 *            el nombre del sitio a seleccionar
	 */
	protected void seleccionarSitio(String nombreSitio) {
		int i = 0;
		while (i < nodoRaiz.getChildCount()) {
			//DefaultMutableTreeNode nodo =
			// (DefaultMutableTreeNode)nodoRaiz.children().nextElement();
			DefaultMutableTreeNode nodo = (DefaultMutableTreeNode) nodoRaiz
					.getChildAt(i);
			String sitio = (String) nodo.getUserObject();
			if (sitio.equals(nombreSitio)) {
				seleccionar(nodo);
				return;
			}
			i++;
		}
	}

	/**
	 * Devuelve, de acuerdo a que nodo se haya seleccionado, los nombres del
	 * sitio, la radiobse y la antena seleccionados
	 * 
	 * @return el nombre del sitio, la radiobase y la antena. Alguno de ellos
	 *         puede ser null
	 */
	protected String[] getSelecciones() {
		String sitio = null;
		String rb = null;
		String antena = null;
		DefaultMutableTreeNode nodoSeleccionado = (DefaultMutableTreeNode) (arbol
				.getSelectionPath().getLastPathComponent());
		if (this.getNivelSeleccionado() == ExploradorSitios.NIVEL_SITIOS) {
			sitio = (String) nodoSeleccionado.getUserObject();
		}
		if (this.getNivelSeleccionado() == ExploradorSitios.NIVEL_RADIOBASES) {
			DefaultMutableTreeNode padreNodoSeleccionado = (DefaultMutableTreeNode) (nodoSeleccionado
					.getParent());
			sitio = (String) padreNodoSeleccionado.getUserObject();
			rb = (String) nodoSeleccionado.getUserObject();
		}
		if (this.getNivelSeleccionado() == ExploradorSitios.NIVEL_ANTENAS) {
			DefaultMutableTreeNode padreNodoSeleccionado = (DefaultMutableTreeNode) (nodoSeleccionado
					.getParent());
			DefaultMutableTreeNode abueloNodoSeleccionado = (DefaultMutableTreeNode) (padreNodoSeleccionado
					.getParent());
			sitio = (String) abueloNodoSeleccionado.getUserObject();
			rb = (String) padreNodoSeleccionado.getUserObject();
			antena = (String) nodoSeleccionado.getUserObject();
		}
		return new String[] { sitio, rb, antena };
	}

}
