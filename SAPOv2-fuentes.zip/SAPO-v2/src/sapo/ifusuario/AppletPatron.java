package sapo.ifusuario;

/*
 * Copyright (c) 1995, 2008, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.RenderingHints.Key;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.text.AttributedCharacterIterator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JApplet;
import javax.swing.JFrame;

/* 
 * This is like the FontDemo applet in volume 1, except that it 
 * uses the Java 2D APIs to define and render the graphics and text.
 */

public class AppletPatron extends JApplet {

	public ArrayList<Double> angulos = new ArrayList<Double>();
	public ArrayList<Double> ganancias = new ArrayList<Double>();

	private int anchoApp;
	private int altoApp;
	private final int margen = 10;
	private int radio0db = 10;
	private int radio3db = (int) Math.round(radio0db * .75);
	private int radio10db = (int) Math.round(radio0db * .5);
	private int radio100db = (int) Math.round(radio0db * .25);
	private int centroX;
	private int centroY;
	private boolean esPatronH;

	final static Color bg = Color.white;
	final static Color fg = Color.black;
	final static Color red = Color.red;
	final static Color white = Color.white;

	public AppletPatron() {
		super();
	}

	public AppletPatron(int anchoApp, int altoApp, ArrayList<Double> angulos,
			ArrayList<Double> ganancias, boolean esPatronH) {
		this.angulos = angulos;
		this.ganancias = ganancias;
		this.altoApp = altoApp;
		this.anchoApp = anchoApp;
		this.esPatronH = esPatronH;
		actualizarTamano();
	}

	public void init() {
		// Initialize drawing colors
		setBackground(bg);
		setForeground(fg);
	}

	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g.clearRect(0, 0, anchoApp, altoApp);
		GeneralPath polyline = new GeneralPath(GeneralPath.WIND_NON_ZERO,
				angulos.size());

		Iterator<Double> it = angulos.iterator();
		double angAux;
		double potAux;
		double x = 0;
		double y = 0;

		angAux = it.next();
		potAux = ganancias.get(0);

//		if (potAux > -3)
//			potAux = 75.0 + (25.0 / 3.0 * (3 + potAux));
//		else if (potAux > -6)
//			potAux = 50.0 + (25.0 / 3.0 * (6 + potAux));
//		else if (potAux > -9)
//			potAux = 25.0 + (25.0 / 3.0 * (9 + potAux));
//		else if (potAux > -12)
//			potAux = 0.0 + (25.0 / 3.0 * (12 + potAux));
//		else
//			potAux = 0.0;
		
		double umbral;
		if (esPatronH)
			umbral = -20.0; // Umbral para graficar patrón horizontal
		else
			umbral = -47.0; // Umbral para graficar patrón vertical.
		
		if (potAux > umbral)
			potAux = (potAux / - umbral + 1)*radio0db;
		else
			potAux = 0.0;

		// GM: angAux está en grados!!
		x = centroX + potAux * Math.sin(angAux * Math.PI / 180.0);
		y = centroY - potAux * Math.cos(angAux * Math.PI / 180.0);

//		x = centroX + potAux * Math.sin(angAux);
//		y = centroY + potAux * Math.cos(angAux);
		polyline.moveTo(x, y);

		while (it.hasNext()) {
			angAux = it.next();
			potAux = ganancias.get(angulos.indexOf(angAux));

//			if (potAux > -3)
//				potAux = 75.0 + (25.0 / 3.0 * (3 + potAux));
//			else if (potAux > -6)
//				potAux = 50.0 + (25.0 / 3.0 * (6 + potAux));
//			else if (potAux > -9)
//				potAux = 25.0 + (25.0 / 3.0 * (9 + potAux));
//			else if (potAux > -12)
//				potAux = 0.0 + (25.0 / 3.0 * (12 + potAux));
//			else
//				potAux = 0.0;

			if (potAux > umbral)
				potAux = (potAux / - umbral + 1)*radio0db;
			else
				potAux = 0.0;
			
			x = centroX + potAux * Math.sin(angAux / 360.0 * 2 * Math.PI);
			y = centroY - potAux * Math.cos(angAux / 360.0 * 2 * Math.PI);
			
//			x = centroX + potAux * Math.sin(angAux / 360.0 * 2 * Math.PI);
//			y = centroY + potAux * Math.cos(angAux / 360.0 * 2 * Math.PI);
			polyline.lineTo(x, y);
		}

		polyline.closePath();

		BasicStroke verde = new BasicStroke(2.0f);

		g2.setStroke(verde);

		g2.setColor(Color.blue);
		g2.draw(polyline);

		g2.setColor(Color.black);

		float dash1[] = { 1.0f };
		BasicStroke dashed = new BasicStroke(1.0f, BasicStroke.CAP_BUTT,
				BasicStroke.JOIN_MITER, 10.0f, dash1, 0.0f);
		g2.setStroke(dashed);

		g2.drawOval(centroX - radio0db, centroY - radio0db, radio0db * 2,
				radio0db * 2);
		g2.drawOval(centroX - radio3db, centroY - radio3db, radio3db * 2,
				radio3db * 2);
		g2.drawOval(centroX - radio10db, centroY - radio10db, radio10db * 2,
				radio10db * 2);
		g2.drawOval(centroX - radio100db, centroY - radio100db, radio100db * 2,
				radio100db * 2);
	}

	public void actualizarTamano() {
		this.centroX = (int) Math.round((anchoApp - margen) / 2);
		this.centroY = (int) Math.round((altoApp - margen) / 2);
		this.radio0db = (int) Math.min(centroX, centroY);
		this.radio3db = (int) Math.round(radio0db * .75);
		this.radio10db = (int) Math.round(radio0db * .5);
		this.radio100db = (int) Math.round(radio0db * .25);
	}

	public void setAltoApp(int altoApp) {
		this.altoApp = altoApp;
		actualizarTamano();
		init();
	}

	public void setAnchoApp(int anchoApp) {
		this.anchoApp = anchoApp;
		actualizarTamano();
		init();
	}
}