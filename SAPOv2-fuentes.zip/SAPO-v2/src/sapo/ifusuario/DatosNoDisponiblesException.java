package sapo.ifusuario;

/**
 * Esta excepción es lanzada al solicitar información de antenas de una predicción, 
 * si alguna de las antenas fue borrada o cambiada del proyecto.
 * @author Grupo de proyecto SAPO
 */

public class DatosNoDisponiblesException extends Exception {

	public DatosNoDisponiblesException(String mensaje) {
		super(mensaje);
	}

}
