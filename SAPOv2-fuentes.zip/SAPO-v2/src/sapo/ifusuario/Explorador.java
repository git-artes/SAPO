package sapo.ifusuario;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.EventListener;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import sapo.ifusuario.menues.Popup;

/**
 * Esta clase constituye la base para la creación de un explorador.
 * @author Grupo de proyecto SAPO
 */

public class Explorador extends JPanel implements MouseListener {

	/**
	 * El árbol
	 */
	public JTree arbol;

	/**
	 * El nodo raiz del arbol
	 */
	protected DefaultMutableTreeNode nodoRaiz;

	/**
	 * El modelo del árbol
	 */
	protected DefaultTreeModel modelo;

	/**
	 * Popup a desplegar al clickear en los niveles 1, 2 y 3 del árbol
	 */
	Popup popupNivel0;

	/**
	 * Popup a desplegar al clickear en los niveles 1, 2 y 3 del árbol
	 */
	Popup popupNivel1;

	/**
	 * Popup a desplegar al clickear en los niveles 1, 2 y 3 del árbol
	 */
	Popup popupNivel2;

	/**
	 * Popup a desplegar al clickear en los niveles 1, 2 y 3 del árbol
	 */
	Popup popupNivel3;

	/**
	 * Quien va a escuchar los eventos que ocurran en el árbol
	 */
	EventListener eL;

	/**
	 * Crea un Explorador con el título y el EventListener indicados
	 * 
	 * @param eL 
	 *            Quien va a escuchar los eventos que ocurran en el explorador
	 * @param titulo 
	 *            El título del explorador
	 */
	public Explorador(EventListener eL, String titulo) {
		super(new GridLayout(1, 0));
		this.setPreferredSize(new Dimension(150, 480));
		nodoRaiz = new DefaultMutableTreeNode(titulo);
		modelo = new DefaultTreeModel(nodoRaiz);

		arbol = new JTree(modelo);
		arbol.setEditable(false); //esto es para que no puedan cambiar los
								  // nodos clickeando...

		//this.eL = eL;
		arbol.addMouseListener(this);
		arbol.addMouseListener((MouseListener) eL);

		arbol.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		arbol.setShowsRootHandles(true);

		this.add(new JScrollPane(arbol));

		popupNivel0 = new Popup();
		popupNivel1 = new Popup();
		popupNivel2 = new Popup();
		popupNivel3 = new Popup();

	}

	/*
	 * public void agregarListener(EventListener a){
	 * arbol.addMouseListener((MouseListener)a); }
	 */

	/**
	 * Selecciona el nodo indicado en el árbol
	 * 
	 * @param nodo 
	 *            el nodo a seleccionar
	 */
	public void seleccionar(DefaultMutableTreeNode nodo) {
		arbol.setSelectionPath(new TreePath(nodo));
	}

	/**
	 * Cambia el nombre al nodo seleccionado
	 * 
	 * @param nombre 
	 *            el nuevo nombre
	 */
	public void renombrarNodo(String nombre) {
		TreePath p = arbol.getSelectionPath();
		DefaultMutableTreeNode nodoSeleccionado = (DefaultMutableTreeNode) (p
				.getLastPathComponent());
		nodoSeleccionado.setUserObject(nombre);
		arbol.scrollPathToVisible(p);
		modelo.reload(nodoSeleccionado);
	}

	/**
	 * Devuelve el nombre del nodo seleccionado
	 * 

	 */
	public String getSeleccion() {
		DefaultMutableTreeNode nodoSeleccionado = (DefaultMutableTreeNode) (arbol
				.getSelectionPath().getLastPathComponent());
		return (String) nodoSeleccionado.getUserObject();
	}

	/**
	 * 
	 * Borra todos los nodos menos el nodo raiz
	 *  
	 */

	public void vaciar() {
		nodoRaiz.removeAllChildren();
		modelo.reload();
	}

	/**
	 * 
	 * Borra el nodo seleccionado
	 *  
	 */

	public void borrarNodo() {
		TreePath seleccion = arbol.getSelectionPath();
		if (seleccion != null) {
			DefaultMutableTreeNode nodoSeleccionado = (DefaultMutableTreeNode) (seleccion
					.getLastPathComponent());
			MutableTreeNode padre = (MutableTreeNode) (nodoSeleccionado
					.getParent());
			if (padre != null) {
				modelo.removeNodeFromParent(nodoSeleccionado);
			}
		}
	}

	/**
	 * Agrega un hijo al nodo seleccionado
	 * 
	 * @param hijo -
	 *            el objeto a asociar al nodo hijo
	 */
	public DefaultMutableTreeNode agregarNodo(Object hijo) {
		DefaultMutableTreeNode nodoPadre = null;
		TreePath padrePath = arbol.getSelectionPath();
		if (padrePath == null) {
			nodoPadre = nodoRaiz;
		} else {
			nodoPadre = (DefaultMutableTreeNode) (padrePath
					.getLastPathComponent());
		}
		return agregarNodo(nodoPadre, hijo);
	}

	/*
	 * public DefaultMutableTreeNode agregarNodo(DefaultMutableTreeNode
	 * padre,Object hijo) { return agregarNodo(padre, hijo, false); }
	 */

	/**
	 * Agrega un hijo a un determinado nodo
	 * 
	 * @param padre 
	 *            el nodo padre
	 * @param hijo 
	 *            el objeto a asociar al nodo hijo
	 */
	public DefaultMutableTreeNode agregarNodo(DefaultMutableTreeNode padre,
			Object hijo) {
		DefaultMutableTreeNode nodoHijo = new DefaultMutableTreeNode(hijo);
		if (padre == null) {
			padre = nodoRaiz;
		}
		modelo.insertNodeInto(nodoHijo, padre, padre.getChildCount());
		arbol.scrollPathToVisible(new TreePath(nodoHijo.getPath()));
		return nodoHijo;
	}

	/**
	 * 
	 * Devuelve el nivel en el arbol del nodo seleccionado
	 * 
	 * @return un entero coorespondiente al nivel seleccionado. 0 es el nodo
	 *         raíz.
	 */

	public int getNivelSeleccionado() {
		TreePath seleccion = arbol.getSelectionPath();
		if (seleccion != null) {
			DefaultMutableTreeNode NodoSeleccionado = (DefaultMutableTreeNode) (seleccion
					.getLastPathComponent());
			return NodoSeleccionado.getLevel();
		}
		return -1;
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
 */
	@Override
	public void mouseClicked(MouseEvent e) {
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
 */
	@Override
	public void mouseEntered(MouseEvent e) {
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
 */
	@Override
	public void mouseExited(MouseEvent e) {
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
 */
	@Override
	public void mousePressed(MouseEvent e) {
		if (e.isPopupTrigger()) {
			mostrarPopup(e);
		}
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
 */
	@Override
	public void mouseReleased(MouseEvent e) {
		if (e.isPopupTrigger()) {
			mostrarPopup(e);
		}
	}

	/**
	 * Muestra un popup de acuerdo al nivel que se haya seleccionado con el
	 * mouse
	 * 
	 * @param e	 
	 *            el evento disparador del popup
	 */
	void mostrarPopup(MouseEvent e) {

		if (this.getNivelSeleccionado() == 0) {
			popupNivel0.show(e.getComponent(), e.getX(), e.getY());
		} else if (this.getNivelSeleccionado() == 1) {
			popupNivel1.show(e.getComponent(), e.getX(), e.getY());
		} else if (this.getNivelSeleccionado() == 2) {
			popupNivel2.show(e.getComponent(), e.getX(), e.getY());
		} else if (this.getNivelSeleccionado() == 3) {
			popupNivel3.show(e.getComponent(), e.getX(), e.getY());
		}

	}

}
