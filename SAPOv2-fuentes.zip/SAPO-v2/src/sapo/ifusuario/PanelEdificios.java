package sapo.ifusuario;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.geotools.feature.Feature;

import sapo.ifusuario.menues.BarraInferior;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.LineSegment;
import com.vividsolutions.jts.geom.Polygon;

/**
 * Esta clase define el panel para el ingreso y despliegue de datos del 
 * Generador de Edificios.
 * @author Grupo de Proyecto SAPO.
 */
public class PanelEdificios extends JPanel implements ActionListener {

	JButton agregarEdif = new JButton("Agregar Edificio");

	JButton eliminarEdif = new JButton("Eliminar Edificio");

	JButton aceptar = new JButton("Agregar");

	JButton salir = new JButton("Salir");

	JButton guardar = new JButton("Guardar");

	JTextArea texto = new JTextArea(" ");

	JPanel nuevoEdif = new JPanel();

	Polygon manzana;

	Feature manzanaElegida;

	Feature edificio;

	ArrayList esquinas = new ArrayList();

	ArrayList cuadras = new ArrayList();;

	JFrame ventana;

	JTextField ancho = new JTextField("");

	JTextField profundidad = new JTextField("     ");

	JTextField altura = new JTextField("");

	JTextField distancia = new JTextField("");

	JLabel etiquetaAncho = new JLabel("Ancho (m)");

	JLabel etiquetaProf = new JLabel("Profundidad (m)");

	JLabel etiquetaAltura = new JLabel("Altura (m)");

	JLabel etiquetaDist = new JLabel("Dist. esquina (m)");

	JLabel esquina = new JLabel("Esquina");

	JLabel cuadra = new JLabel("Cuadra");


	JComboBox listaEsquinas = new JComboBox();


	JComboBox listaCuadras = new JComboBox();

	String manzanaId;

	/**
	 * Crea un panel para el Generador de Edificios

	 */
	public PanelEdificios(ActionListener aL, BarraInferior barra) {
		super();
		this.setPreferredSize(new Dimension(210, 470));
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.NONE;

		add(agregarEdif, c);

		nuevoEdif.setPreferredSize(new Dimension(195, 190));
		nuevoEdif.setLayout(new GridBagLayout());
		GridBagConstraints c1 = new GridBagConstraints();
		c1.insets = new Insets(2, 2, 2, 2);

		c1.weightx = 1;
		c1.weighty = 1;
		nuevoEdif.setBorder(BorderFactory.createTitledBorder("Nuevo Edificio"));
		JPanel aux = new JPanel(new GridLayout(6, 2, 2, 2));

		aux.add(etiquetaAltura);
		aux.add(altura);
		aux.add(cuadra);
		aux.add(listaCuadras);
		aux.add(etiquetaAncho);
		aux.add(ancho);
		aux.add(etiquetaProf);
		aux.add(profundidad);
		aux.add(esquina);
		aux.add(listaEsquinas);
		aux.add(etiquetaDist);
		aux.add(distancia);

		c1.gridwidth = GridBagConstraints.REMAINDER;
		c1.fill = GridBagConstraints.HORIZONTAL;
		nuevoEdif.add(aux, c1);
		c1.gridwidth = GridBagConstraints.REMAINDER;
		c1.fill = GridBagConstraints.CENTER;
		nuevoEdif.add(aceptar, c1);

		c.fill = GridBagConstraints.BOTH;
		add(nuevoEdif, c);

		c.fill = GridBagConstraints.NONE;
		add(eliminarEdif, c);

		c.fill = GridBagConstraints.BOTH;

		JScrollPane panelTexto = new JScrollPane(texto);
		//texto.setPreferredSize(new Dimension(200, 200));
		panelTexto.setPreferredSize(new Dimension(195, 150));
		add(panelTexto, c);

		add(barra, c);

		aux = new JPanel(new GridLayout(1, 2, 5, 5));
		aux.add(guardar);
		aux.add(salir);

		c.fill = GridBagConstraints.CENTER;
		add(aux, c);

		this.setPanelHabilitado(false);
		agregarEdif.setEnabled(false);
		eliminarEdif.setEnabled(false);

		aceptar.addActionListener(aL);
		listaEsquinas.addActionListener(aL);
		listaCuadras.addActionListener(aL);
		agregarEdif.addActionListener(this);
		eliminarEdif.addActionListener(aL);
		salir.addActionListener(aL);
		guardar.addActionListener(aL);

	}

	public void setPanelHabilitado(boolean b) {
		etiquetaAltura.setEnabled(b);
		altura.setEnabled(b);
		cuadra.setEnabled(b);
		listaCuadras.setEnabled(b);
		etiquetaAncho.setEnabled(b);
		ancho.setEnabled(b);
		etiquetaProf.setEnabled(b);
		profundidad.setEnabled(b);
		esquina.setEnabled(b);
		listaEsquinas.setEnabled(b);
		etiquetaDist.setEnabled(b);
		distancia.setEnabled(b);
		aceptar.setEnabled(b);
		if (b) {
			ancho.setText("");
			profundidad.setText("");
			altura.setText("");
			distancia.setText("");
		}
	}

	public void agregarEdificio() {

		listaEsquinas.removeAllItems();
		listaCuadras.removeAllItems();
		String item;
		int j;
		for (j = 0; j < esquinas.size() - 1; j++) {
			item = "Esquina " + j;
			listaEsquinas.addItem(item);
			item = "Cuadra " + (j) + "-" + (j + 1);
			listaCuadras.addItem(item);
		}
		item = "Esquina " + j;
		listaEsquinas.addItem(item);
		item = "Cuadra " + (j) + "-" + (0);
		listaCuadras.addItem(item);
	}

	public Coordinate getEsquinaElegida() {
		int j = listaEsquinas.getSelectedIndex();
		if (j == -1)
			j = 0;
		return (Coordinate) esquinas.get(j);
	}

	public LineSegment getCuadraElegida() {
		int j = listaCuadras.getSelectedIndex();
		if (j == -1)
			j = 0;
		return (LineSegment) cuadras.get(j);
	}

	public void setTextoManzana(Polygon poligono) {
		String texto = "Seleccionó la manzana de esquinas:\n";
		Coordinate[] esquinasAux = poligono.getCoordinates();
		LineSegment cuadra;
		esquinas = new ArrayList();
		cuadras = new ArrayList();
		String coordenadas = "(" + String.valueOf(Math.round(esquinasAux[0].x))
				+ "," + String.valueOf(Math.round(esquinasAux[0].y)) + ")";
		texto = texto + 0 + " - " + coordenadas + "\n";
		esquinas.add(esquinasAux[0]);
		int k = 1;
		for (int j = 1; j < esquinasAux.length - 1; j++) {
			cuadra = new LineSegment(esquinasAux[j - 1], esquinasAux[j]);
			if (cuadra.getLength() > 0.1) {
				coordenadas = "("
						+ String.valueOf(Math.round(esquinasAux[j].x)) + ","
						+ String.valueOf(Math.round(esquinasAux[j].y)) + ")";
				texto = texto + k + " - " + coordenadas + "\n";
				esquinas.add(esquinasAux[j]);
				cuadra = new LineSegment((Coordinate) esquinas.get(k - 1),
						(Coordinate) esquinas.get(k));
				cuadras.add(cuadra);
				k++;
			}
		}
		cuadra = new LineSegment((Coordinate) esquinas.get(k - 1),
				(Coordinate) esquinas.get(0));
		cuadras.add(cuadra);
		this.texto.setText(texto);
	}

	public void setTextoEdificio(Polygon poligono, double altura) {
		String texto = "Seleccionó el edificio de altura:\n" + altura
				+ "m y coordenadas:\n";
		Coordinate[] vertices = poligono.getCoordinates();
		String coordenadas = "(" + String.valueOf(Math.round(vertices[0].x))
				+ "," + String.valueOf(Math.round(vertices[0].y)) + ")";
		texto = texto + coordenadas + "\n";
		for (int j = 1; j < vertices.length - 1; j++) {
			LineSegment pared = new LineSegment(vertices[j - 1], vertices[j]);
			if (pared.getLength() > 0.01) {
				coordenadas = "(" + String.valueOf(Math.round(vertices[j].x))
						+ "," + String.valueOf(Math.round(vertices[j].y)) + ")";
				texto = texto + coordenadas + "\n";
			}
		}
		this.texto.setText(texto);
	}

	public void setPoligono(Polygon poligono) {
		manzana = poligono;
	}

	public Polygon getPoligono() {
		return manzana;
	}


	public Feature getEdificio() {
		return edificio;
	}


	public void setManzanaElegida(Feature manzana) {
		this.manzanaElegida = manzana;
	}


	public Feature getManzanaElegida() {
		return this.manzanaElegida;
	}


	public void setEdificio(Feature edificio) {
		this.edificio = edificio;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (((JButton) e.getSource()).equals(agregarEdif)) {
			this.setPanelHabilitado(true);
			this.agregarEdificio();
			//menu.desplegar();
		}

	}

	public JButton getEliminar() {
		return eliminarEdif;
	}

	public JButton getAgregar() {
		return agregarEdif;
	}


	public JButton getSalir() {
		return salir;
	}


	public JButton getGuardar() {
		return guardar;
	}


	public JComboBox getListaEsquinas() {
		return listaEsquinas;
	}


	public JComboBox getListaCuadras() {
		return listaCuadras;
	}

	public JButton getAceptar() {
		return aceptar;
	}


	public double getAltura() throws EdificioMalIngresadoException {
		try {
			double resultado = Double.parseDouble(altura.getText());
			if (resultado < 0) {
				throw new EdificioMalIngresadoException(
						"La altura del edificio debe ser mayor o igual a 0.");
			}
			return resultado;
		} catch (NumberFormatException ex) {
			throw new EdificioMalIngresadoException(
					"El formato de los datos debe ser numérico.");
		}
	}


	public double getAncho() throws EdificioMalIngresadoException {
		try {
			double resultado = Double.parseDouble(ancho.getText());
			if (resultado <= 0) {
				throw new EdificioMalIngresadoException(
						"El ancho del edificio debe ser mayor a 0.");
			}
			return resultado;
		} catch (NumberFormatException ex) {
			throw new EdificioMalIngresadoException(
					"El formato de los datos debe ser numérico.");
		}
	}


	public double getProfundidad() throws EdificioMalIngresadoException {
		try {
			double resultado = Double.parseDouble(profundidad.getText());
			if (resultado <= 0) {
				throw new EdificioMalIngresadoException(
						"La profundidad del edificio debe ser mayor a 0.");
			}
			return resultado;
		} catch (NumberFormatException ex) {
			throw new EdificioMalIngresadoException(
					"El formato de los datos debe ser numérico.");
		}
	}


	public double getDistancia() throws EdificioMalIngresadoException {
		try {
			double resultado = Double.parseDouble(distancia.getText());
			if (resultado < 0) {
				throw new EdificioMalIngresadoException(
						"La distancia a la esquina de referencia debe ser mayor o igual a 0.");
			}
			return resultado;
		} catch (NumberFormatException ex) {
			throw new EdificioMalIngresadoException(
					"El formato de los datos debe ser numérico.");
		}
	}

}
