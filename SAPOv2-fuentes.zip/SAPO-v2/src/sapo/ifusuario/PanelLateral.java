package sapo.ifusuario;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;

import sapo.predicciones.Modelo;
import sapo.principal.Principal;
import sapo.red.Antena;
import sapo.red.CanalFrecuencias;
import sapo.red.Radiobase;
import sapo.red.Sitio;
import sapo.red.TipoAntena;

public class PanelLateral extends JPanel {
	private JScrollPane scrollTipoAntenas;
	private JScrollPane scrollCanales;
	private JScrollPane scrollSitios;
	private JScrollPane scrollModelos;
	private GridLayout gridPanelLateral;
	public JList<TipoAntena> listaAntenas;
	public JList<CanalFrecuencias> listaCanales;
	public JList<Modelo> listaModelos;
	public JList<Sitio> listaSitios;
	private DefaultListModel<TipoAntena> modeloListaAntenas;
	private DefaultListModel<CanalFrecuencias> modeloListaCanales;
	private DefaultListModel<Modelo> modeloListaModelos;
	private DefaultListModel<Sitio> modeloListaSitios;

	public PanelLateral(MouseListener mL) {
		super();

		setBorder(new EmptyBorder(0, 0, 0, 0));

		gridPanelLateral = new GridLayout(4, 1, 0, 0);
		setLayout(gridPanelLateral);

		// Inicializo panel de Antenas
		modeloListaAntenas = new DefaultListModel<TipoAntena>();
		listaAntenas = new JList<TipoAntena>(modeloListaAntenas);
		listaAntenas
				.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);

		listaAntenas.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		listaAntenas.setFixedCellWidth(Principal.tamanoPanelIzquiera);
		listaAntenas.setVisibleRowCount(-1);
		listaAntenas.addMouseListener(mL);
		scrollTipoAntenas = new JScrollPane(listaAntenas);
		scrollTipoAntenas
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		JViewport tituloAntenas = new JViewport();
		JLabel labelAntenas = new JLabel("Antenas");
		labelAntenas.setHorizontalAlignment(JLabel.CENTER);
		tituloAntenas.add(labelAntenas);
		scrollTipoAntenas.setColumnHeader(tituloAntenas);

		// Inicializo panel de Sitios
		modeloListaSitios = new DefaultListModel<Sitio>();
		listaSitios = new JList<Sitio>(modeloListaSitios);
		listaSitios
				.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		listaSitios.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		listaSitios.setFixedCellWidth(Principal.tamanoPanelIzquiera);
		listaSitios.setVisibleRowCount(-1);
		listaSitios.addMouseListener(mL);
		scrollSitios = new JScrollPane(listaSitios);
		scrollSitios
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		JViewport tituloSitios = new JViewport();
		JLabel labelSitios = new JLabel("Sitios");
		labelSitios.setHorizontalAlignment(JLabel.CENTER);
		tituloSitios.add(labelSitios);
		scrollSitios.setColumnHeader(tituloSitios);

		// Inicializo panel de Modelos
		modeloListaModelos = new DefaultListModel<Modelo>();
		listaModelos = new JList<Modelo>(modeloListaModelos);
		listaModelos
				.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		listaModelos.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		listaModelos.setFixedCellWidth(Principal.tamanoPanelIzquiera);
		listaModelos.setVisibleRowCount(-1);
		listaModelos.addMouseListener(mL);
		scrollModelos = new JScrollPane(listaModelos);
		scrollModelos
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		JViewport tituloModelos = new JViewport();
		JLabel labelModelos = new JLabel("Modelos");
		labelModelos.setHorizontalAlignment(JLabel.CENTER);
		tituloModelos.add(labelModelos);
		scrollModelos.setColumnHeader(tituloModelos);

		// Inicializo panel de Canales
		modeloListaCanales = new DefaultListModel<CanalFrecuencias>();
		listaCanales = new JList<CanalFrecuencias>(modeloListaCanales);
		listaCanales
				.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		listaCanales.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		listaCanales.setFixedCellWidth(Principal.tamanoPanelIzquiera);
		listaCanales.setVisibleRowCount(-1);
		listaCanales.addMouseListener(mL);
		scrollCanales = new JScrollPane(listaCanales);
		scrollCanales
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		JViewport tituloCanales = new JViewport();
		JLabel labelCanales = new JLabel("Canales");
		labelCanales.setHorizontalAlignment(JLabel.CENTER);
		tituloCanales.add(labelCanales);
		scrollCanales.setColumnHeader(tituloCanales);

		// Agrego las listas al panel lateral
		add(scrollTipoAntenas);
		add(scrollSitios);
		add(scrollModelos);
		add(scrollCanales);

	}

	protected class Renderer extends JLabel implements ListCellRenderer {
		private Font uhOhFont;
		private String icono;
		private final String iconoRB = "res/mario.png";

		public Renderer(String URLicono) {
			setOpaque(true);
			setHorizontalAlignment(LEFT);
			setVerticalAlignment(CENTER);
			icono = URLicono;

		}

		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			String s = "<html><p><img src='file:res/" + this.icono
					+ ".png' alt='' height='15' width='15'><b>";
			if (value instanceof TipoAntena) {

				setText(s + ((TipoAntena) value).getNombre() + "</b><p>Tipo: "
						+ ((TipoAntena) value).getTipoPatron()
						+ "<br>Ganancia: " + ((TipoAntena) value).getGanancia()
						+ " dB</p></html>");

			} else if (value instanceof Sitio) {
				String radiobases = "<br>Radiobases:";
				ArrayList<Radiobase> rb = ((Sitio) value).getRadiobases();
				String ant = "<p>Antenas:";
				Iterator<Radiobase> i = rb.iterator();
				Radiobase rbAux;
				while (i.hasNext()) {
					rbAux = i.next();
					ArrayList<Antena> antenas = (rbAux).getAntenas();
					Iterator<Antena> j = antenas.iterator();
					while (j.hasNext()) {

						ant = ant
								+ "<p><img src='file:res/antena.png' alt='' height='15' width='15'>"
								+ j.next().getNombre();
					}

					radiobases = radiobases + "<br><img src='file:"
							+ this.iconoRB + "' alt='' height='15' width='15'>"
							+ rbAux.getNombre();
				}
				// }

				setText(s + ((Sitio) value).getNombre() + "</b>" + radiobases
						+ ant + "</p></html>");

			} else if (value instanceof CanalFrecuencias) {
				setText(s + ((CanalFrecuencias) value).getNombre() + "</b>"
						+ "</p></html>");
			} else if (value instanceof Modelo) {
				setText(s + ((Modelo) value).getNombre() + "</b></p></html>");
			} else {
				setText(value.toString());
			}

			Color background;
			Color foreground;

			// check if this cell represents the current DnD drop location
			JList.DropLocation dropLocation = list.getDropLocation();
			if (dropLocation != null && !dropLocation.isInsert()
					&& dropLocation.getIndex() == index) {

				background = Color.BLUE;
				foreground = Color.WHITE;

				// check if this cell is selected
			} else if (isSelected && cellHasFocus) {
				background = new Color(195, 212, 232);//Color.RED;
				foreground = Color.BLACK;//Color.WHITE;

				// unselected, and not the DnD drop location
			} else {
				background = Color.WHITE;
				foreground = Color.BLACK;
			}
			;

			setBackground(background);
			setForeground(foreground);

			return this;
		}
	}

	public void refrescarElementos(Object elemento, ArrayList array) {
		if (elemento instanceof TipoAntena) {
			Renderer renderer = new Renderer("antena");
			listaAntenas.setCellRenderer(renderer);
			modeloListaAntenas.removeAllElements();
			for (Object o : array) {
				modeloListaAntenas.addElement((TipoAntena) o);
			}

		} else if (elemento instanceof Sitio) {
			Renderer renderer = new Renderer("sitio");
			listaSitios.setCellRenderer(renderer);
			modeloListaSitios.removeAllElements();
			for (Object o : array) {
				modeloListaSitios.addElement((Sitio) o);
			}

		} else if (elemento instanceof Modelo) {
			Renderer renderer = new Renderer("idea");
			listaModelos.setCellRenderer(renderer);
			modeloListaModelos.removeAllElements();
			for (Object o : array) {
				modeloListaModelos.addElement((Modelo) o);
			}

		} else if (elemento instanceof CanalFrecuencias) {
			Renderer renderer = new Renderer("frecuencias");
			listaCanales.setCellRenderer(renderer);
			modeloListaCanales.removeAllElements();
			for (Object o : array) {
				modeloListaCanales.addElement((CanalFrecuencias) o);
			}
		}

	}

	public TipoAntena getTipoAntenaSeleccionada() {
		TipoAntena tipo = (TipoAntena) listaAntenas.getSelectedValue();
		return tipo;
	}

	public boolean hayTipoAntenaSeleccionada() {
		TipoAntena tipo = (TipoAntena) listaAntenas.getSelectedValue();
		if (tipo == null)
			return false;
		else
			return true;
	}

	public boolean hayCanalSeleccionado() {
		CanalFrecuencias canal = (CanalFrecuencias) listaCanales
				.getSelectedValue();
		if (canal == null)
			return false;
		else
			return true;
	}

	public boolean haySitioSeleccionado() {
		Sitio sitio = (Sitio) listaSitios.getSelectedValue();
		if (sitio == null)
			return false;
		else
			return true;
	}

	public boolean hayModeloSeleccionado() {
		Modelo modelo = (Modelo) listaModelos.getSelectedValue();
		if (modelo == null)
			return false;
		else
			return true;
	}
}