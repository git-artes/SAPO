package sapo.ifusuario;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

/**
 * Esta clase define la ventana del "Acerca de" de SAPO
 * @author Grupo de proyecto SAPO
 */

public class VentanaAcercaDe extends JDialog implements ActionListener {

	JButton aceptar;


	public VentanaAcercaDe(JFrame duenio) {
		super(duenio, true);
		aceptar = new JButton("Aceptar");
		aceptar.addActionListener(this);
		Border bordeSapo, bordeOtros;
		bordeSapo = BorderFactory.createTitledBorder("SAPO v2.0 \"Michigan\"");
		bordeOtros = BorderFactory.createTitledBorder("Bibliotecas");
		JLabel sapo = new JLabel(
				"<html><div align=center>"
						+ "Software de Análisis de Propagación Outdoor v2.0 'Michigan'<br><br>"
						+ "Software diseñado y desarrollado como trabajo final <br>"
						+ "para la obtención del título de Ingeniero Electricista <br>"
						+ "en la Facultad de Ingeniería de la Universidad de la República. <br><br>"
						+ "Autores v1.0: <br>" + "Eliana Katz <br>"
						+ "Federico Larroca <br>"
						+ "Ximena Martino <br><br>"
						+ "Autores v2.0 'Michigan': <br>" + "Andrés Gómez-Caram <br>"
						+ "Agustín Labandera <br>"
						+ "Gonzalo Marín<br></div></html>", JLabel.CENTER);
		JLabel otros = new JLabel(
				"<html><div align=center> SAPO fue desarrollado en Java. <br>"
						+ "Utiliza las siguientes bibliotecas: <br><br>"
						+ "geotools v2.0: http://www.geotools.org/ <br>"
						+ "JTS v1.4: http://www.vividsolutions.com/jts/jtshome.htm <br>"
						+ "jgoodies v1.0.5: https://jgoodies.dev.java.net/ <br>"
						+ "geoapi v1.1.0alpha: http://geoapi.sourceforge.net/<br>"
						+ "SSJ v1.1.7: http://www.iro.umontreal.ca/~simardr/ssj/<br>"
						+ "JFreeChart v1.0.17: http://www.jfree.org/jfreechart/<br>"
						+ "JExcelAPI v2.6.12: http://jexcelapi.sourceforge.net/<br>"
						+ "</div></html>", JLabel.CENTER);
		try {
			URL fondoURL = new File("data/LOGOSAPOabout.gif").toURL();
			sapo.setIcon(new ImageIcon(fondoURL));
			sapo.setVerticalTextPosition(JLabel.BOTTOM);
			sapo.setHorizontalTextPosition(JLabel.CENTER);
		} catch (MalformedURLException e) {
		}
		sapo.setBorder(bordeSapo);
		otros.setBorder(bordeOtros);
		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.insets = new Insets(3, 3, 3, 3);
		c.weightx = 1;
		c.anchor = GridBagConstraints.CENTER;
		this.getContentPane().add(sapo, c);
		c.gridy = 1;
		this.getContentPane().add(otros, c);
		this.setSize(300, 400);
		this.pack();
		this.setLocationRelativeTo(duenio);
	}

	/*
	 *  (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent arg0) {
		this.setVisible(false);
		this.dispose();
	}

}
