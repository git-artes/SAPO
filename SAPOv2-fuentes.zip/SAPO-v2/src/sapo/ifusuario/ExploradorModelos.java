package sapo.ifusuario;

import java.awt.event.ActionListener;
import java.util.EventListener;

import sapo.ifusuario.menues.Popup;
import sapo.principal.Comandos;

/**
 * Esta clase define el explorador que contiene los modelos de propagación.
 * @author Grupo de proyecto SAPO
 */

public class ExploradorModelos extends Explorador {

	/**
	 * El nivel del nodo raíz
	 */
	public final static int NIVEL_RAIZ = 0;

	/**
	 * El nivel de los nodos que representan los modelos
	 */
	public final static int NIVEL_MODELOS = 1;

	/**
	 * Construye un explorador para los modelos de porpagación
	 * 
	 * @param eL 
	 *            Quien va a escuchar los eventos que ocurran en el explorador
	 */
	protected ExploradorModelos(EventListener eL) {
		super(eL, "MODELOS disponibles");
		popupNivel0 = new Popup((ActionListener) eL,
				new String[] { Comandos.AGREGAR_MODELO });
		popupNivel1 = new Popup((ActionListener) eL, new String[] {
				Comandos.EDITAR_MODELO, Comandos.BORRAR_MODELO });
	}
}
