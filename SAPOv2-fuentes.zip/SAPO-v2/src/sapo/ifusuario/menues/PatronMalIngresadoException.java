
package sapo.ifusuario.menues;

/**
* Esta excepción es lanzada al crear un tipo de antena, si el patrón de radiación 
* contiene campos vacíos, ángulos fuera del rango aceptado o ganancias negativas.
 *  @author Grupo de proyecto SAPO
 */

public class PatronMalIngresadoException extends Exception {

	public PatronMalIngresadoException(String mensaje) {
		super(mensaje);
	}

}
