package sapo.ifusuario.menues;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import sapo.principal.Comandos;
import sapo.proyecto.PerfilUsuario;
import sapo.proyecto.PerfilUsuarioMalDefinidoException;
import sapo.proyecto.Proyecto;

/**
 * Esta clase define la ventana de creación/edición de un proyecto.
 * @author Grupo de proyecto SAPO
 */

public class VentanaProyecto extends JDialog implements ActionListener {

	JTextField nombre;

	JTextField autor;

	JTextField fecha;
	
	JTextField alturaReceptor;
	
	JTextField sensibilidad;
	
	JTextField CIMinima;

	JTextArea observaciones;
	
	PerfilUsuario perfil;

	JButton aceptar = new JButton("Aceptar");

	JButton cancelar = new JButton("Cancelar");

	/**
	 * Construye una ventana para crear un un nuevo proyecto

	 */
	public VentanaProyecto(ActionListener a, JFrame duenio) {
		super(duenio, true);
		this.setTitle("Nuevo Proyecto");
		this.setSize(new Dimension(295, 282));
		//this.setResizable(false);
		this.setLocationRelativeTo(duenio);
		
		//inicializacion de los componentes
		nombre = new JTextField("Nuevo Proyecto");
		autor = new JTextField("GLM");
		alturaReceptor = new JTextField("10");
		sensibilidad = new JTextField("-110");
		CIMinima = new JTextField("0");
		fecha = new JTextField(new Date().toLocaleString().split(" ")[0]);
		observaciones = new JTextArea();

		//agregar campos
		this.agregarCampos();

		//listeners
		aceptar.addActionListener(a);
		cancelar.addActionListener(this);
		aceptar.setActionCommand(Comandos.CONFIRMAR_CREAR_PROYECTO);

		this.pack();
		this.setLocationRelativeTo(duenio);
		
	}

	/**
	 * Construye una ventana para la edicion de un proyecto
	*/
	public VentanaProyecto(Proyecto proyecto, ActionListener a, JFrame duenio) {
		super(duenio, true);
		this.setTitle("Editar Proyecto");
		this.setSize(new Dimension(295, 282));
		//this.setResizable(false);
		this.setLocationRelativeTo(duenio);

		//inicializacion de los componentes
		nombre = new JTextField(proyecto.getNombre());
		autor = new JTextField(proyecto.getAutor());
		fecha = new JTextField(proyecto.getFecha());
		alturaReceptor = new JTextField(Double.toString(proyecto.getPerfilUsuario().getAltura()));
		sensibilidad = new JTextField(Double.toString(proyecto.getPerfilUsuario().getSensibilidad()));
		CIMinima = new JTextField(Double.toString(proyecto.getPerfilUsuario().getCI()));
		observaciones = new JTextArea(proyecto.getObservaciones());

		//		agregar campos
		this.agregarCampos();

		//listeners
		aceptar.addActionListener(a);
		cancelar.addActionListener(this);
		aceptar.setActionCommand(Comandos.CONFIRMAR_EDITAR_PROYECTO);

		this.pack();
		this.setLocationRelativeTo(duenio);
	}

	private void agregarCampos() {
		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory.createTitledBorder("Datos del Proyecto"));

		c.fill = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.CENTER;
		c.weightx = 1;
		c.weighty = 1;
		panel.add(new JLabel(" Nombre: "), c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;
		panel.add(nombre, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Autor: "), c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;
		panel.add(autor, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Fecha: "), c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;
		panel.add(fecha, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Altura receptor (m): "), c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;
		panel.add(alturaReceptor, c);

		
		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Sensibilidad (dBm): "), c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;
		panel.add(sensibilidad, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel("C/I Mínima: "), c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;
		panel.add(CIMinima, c);
		
		c.fill = GridBagConstraints.BOTH;
		getContentPane().add(panel, c);

		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.gridwidth = GridBagConstraints.REMAINDER;
		getContentPane().add(new JLabel("   Observaciones: "), c);

		//c.fill = GridBagConstraints.BOTH;
		//c.gridheight = 10;

		/*
		 * gb.setConstraints(observaciones, c);
		 * observaciones.setPreferredSize(new Dimension(200,200));
		 * observaciones.setMinimumSize(new Dimension(0,200));
		 * getContentPane().add(observaciones);
		 */
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.CENTER;
		JScrollPane panelObservaciones = new JScrollPane(observaciones);
		//observaciones.setSize(new Dimension(255,90));
		panelObservaciones.setPreferredSize(new Dimension(220, 90));
		//panelObservaciones.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		getContentPane().add(panelObservaciones, c);

		/*
		 * c.fill = GridBagConstraints.BOTH; getContentPane().add(panel, c);
		 */

		JPanel panelBotones = new JPanel(new GridLayout(1, 2, 3, 3));
		aceptar.setMnemonic(KeyEvent.VK_A);
		cancelar.setMnemonic(KeyEvent.VK_C);
		panelBotones.add(aceptar);
		panelBotones.add(cancelar);
		//c.fill = GridBagConstraints.HORIZONTAL;
		//c.gridwidth = GridBagConstraints.RELATIVE;
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);
	}

	public Proyecto getProyecto(Proyecto proyecto) {
		proyecto.setNombre(nombre.getText());
		proyecto.setAutor(autor.getText());
		proyecto.setFecha(fecha.getText());
		try {
			perfil = new PerfilUsuario(Double.parseDouble(alturaReceptor.getText()),Double.parseDouble(sensibilidad.getText()),Double.parseDouble(CIMinima.getText()));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			
		} catch (PerfilUsuarioMalDefinidoException e) {
			// TODO Auto-generated catch block
			new PerfilUsuarioMalDefinidoException("La altura del receptor, la sensibilidad y la C/I mínima deben ser valores numéricos");
		}
		proyecto.setPerfilUsuario(perfil);
		proyecto.setObservaciones(observaciones.getText());
		return proyecto;
	}

	/**
	 * 
	 * Crea un Proyecto nuevo a aprtir de los datos de la ventana

	 *  
	 */

	public Proyecto getProyecto() {
		return this.getProyecto(new Proyecto());
	}

	/*
	 *  (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.setVisible(false);
		this.dispose();
	}

	
	
}
