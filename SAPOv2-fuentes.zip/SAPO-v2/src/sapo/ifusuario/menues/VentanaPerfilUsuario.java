package sapo.ifusuario.menues;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import sapo.principal.Comandos;
import sapo.proyecto.PerfilUsuario;
import sapo.proyecto.PerfilUsuarioMalDefinidoException;

/**
 * Esta clase define la ventana de edición del perfil de usuario del proyecto.
 * @author Grupo de proyecto SAPO
 */

public class VentanaPerfilUsuario extends JDialog implements ActionListener {

	JTextField altura;

	JTextField sensibilidad;

	JTextField CI;

	JButton aceptar = new JButton("Aceptar");

	JButton aceptarDefinitivo = new JButton();

	JButton cancelar = new JButton("Cancelar");

	PerfilUsuario perfilUsuario;
	
	JTextField valorA;
	
	JTextField valorB;
	
	JTextField valorC;
	
	JTextField valorD;
	
	JCheckBox intervalosAutoCheck;
	

	/**
	 * Construye una ventana para editar el perfil de usuario
	 * @throws IOException 

	 */
	public VentanaPerfilUsuario(PerfilUsuario perfil, ActionListener aL,
			JFrame duenio) throws IOException {
		super(duenio, true);
		this.setTitle("Editar perfil de usuario");
		this.setSize(new Dimension(350, 350));

		altura = new JTextField(String.valueOf(perfil.getAltura()));
		sensibilidad = new JTextField(String.valueOf(perfil.getSensibilidad()));
		CI = new JTextField(String.valueOf(perfil.getCI()));
		
		//inicializo 
		valorA = new JTextField(String.valueOf(-100.0));
		valorB = new JTextField(String.valueOf(-80.0));
		valorC = new JTextField(String.valueOf(-60.0));
		valorD = new JTextField(String.valueOf(-40.0));
		
		aceptar.addActionListener(this);
		aceptarDefinitivo.addActionListener(aL);
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_EDITAR_PERFIL);
		cancelar.addActionListener(this);

		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		c.weightx = 1;
		c.weighty = 1;
		c.gridwidth = GridBagConstraints.RELATIVE;
		this.getContentPane().add(new JLabel("Altura del receptor (m):"), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.getContentPane().add(altura, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		this.getContentPane().add(
				new JLabel("Sensibilidad del receptor (dBm):"), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.getContentPane().add(sensibilidad, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		this.getContentPane().add(new JLabel("C/I minima:"), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.getContentPane().add(CI, c);
		
		JPanel panelResults = new JPanel(new GridBagLayout());
		GridBagConstraints c2 = new GridBagConstraints();
		TitledBorder borde;
		borde = BorderFactory.createTitledBorder("Intervalos capa de predicciones");
		panelResults.setBorder(borde);
		c2.gridx = 0;
		c2.gridy = 0;
		c2.gridwidth = GridBagConstraints.REMAINDER;
		c2.anchor = GridBagConstraints.CENTER;
		c2.fill = GridBagConstraints.HORIZONTAL;
		c2.weightx = 0;
		c2.insets = new Insets(3, 3, 3, 3);
		
//		InputStream imageStream = this.getClass().getResourceAsStream("res/paleta.png");
//		BufferedImage image = ImageIO.read(imageStream);
//		JLabel picLabel = new JLabel(new ImageIcon(image));
		JLabel picLabel = new JLabel("<html><img src='file:res/paleta.png' alt='Paleta' height='45' width='296' align='center'></html>");
		panelResults.add(picLabel, c2);
		
		c2.gridy = 1;
		c2.gridx = 0;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.FIRST_LINE_START;
		c2.fill = GridBagConstraints.NONE;
		panelResults.add(new JLabel("Valor A [dBm | dB(uV/m)]: "), c2);
		
		c2.gridx = 1;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.LAST_LINE_END;
		c2.fill = GridBagConstraints.HORIZONTAL;
		panelResults.add(valorA, c2);
		
		c2.gridy = 2;
		c2.gridx = 0;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.FIRST_LINE_START;
		c2.fill = GridBagConstraints.NONE;
		panelResults.add(new JLabel("Valor B [dBm | dB(uV/m)]: "), c2);

		c2.gridy = 2;
		c2.gridx = 1;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.LAST_LINE_END;
		c2.fill = GridBagConstraints.HORIZONTAL;
		panelResults.add(valorB, c2);
		
		c2.gridy = 3;
		c2.gridx = 0;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.FIRST_LINE_START;
		c2.fill = GridBagConstraints.NONE;
		panelResults.add(new JLabel("Valor C [dBm | dB(uV/m)]: "), c2);

		c2.gridy = 3;
		c2.gridx = 1;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.LAST_LINE_END;
		c2.fill = GridBagConstraints.HORIZONTAL;
		panelResults.add(valorC, c2);
		
		c2.gridy = 4;
		c2.gridx = 0;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.FIRST_LINE_START;
		c2.fill = GridBagConstraints.NONE;
		panelResults.add(new JLabel("Valor D [dBm | dB(uV/m)]: "), c2);

		c2.gridy = 4;
		c2.gridx = 1;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.LAST_LINE_END;
		c2.fill = GridBagConstraints.HORIZONTAL;
		panelResults.add(valorD, c2);

		c2.gridy = 5;
		c2.gridx = 0;
		c2.gridheight = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.FIRST_LINE_START;
		c2.fill = GridBagConstraints.NONE;
		intervalosAutoCheck = new JCheckBox("Intervalos por defecto");
		panelResults.add(intervalosAutoCheck, c2);
		intervalosAutoCheck.addActionListener(this);

//		cm = sb.createColorMap(new double[] { min, min + (max - min) / 5,
//				min + 2 * (max - min) / 5, min + 3 * (max - min) / 5, min + 4 * (max - min) / 5, max},

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.anchor = GridBagConstraints.LAST_LINE_END;
		
		this.getContentPane().add(panelResults, c);

		JPanel panelBotones = new JPanel(new GridLayout(1, 2, 2, 2));
		panelBotones.add(aceptar);
		panelBotones.add(cancelar);
		c.fill = GridBagConstraints.NONE;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);
		
		if(perfil.intAutomaticos()){
			intervalosAutoCheck.setSelected(true);
			valorA.setEnabled(false);
			valorB.setEnabled(false);
			valorC.setEnabled(false);
			valorD.setEnabled(false);
		}else{
			intervalosAutoCheck.setSelected(false);
			double[] valores = perfil.getIntCapaResults();
			valorA.setText(String.valueOf(valores[0]));
			valorB.setText(String.valueOf(valores[1]));
			valorC.setText(String.valueOf(valores[2]));
			valorD.setText(String.valueOf(valores[3]));
		}
		
		//this.pack();
		this.setLocationRelativeTo(duenio);
	}

	/**
	 * 
	 * Intenta crear un perfil de usuario con los datos ingresados.
	 * 
	 * @return
	 * @throws PerfilUsuarioMalDefinidoException -
	 *             Si los valores son no númericos
	 * @throws PerfilUsuarioMalIngresadoException -
	 *             Si con los valores numéricos no se pudo crear el perfil.
	 *  
	 */

	PerfilUsuario crearPerfil() throws PerfilUsuarioMalDefinidoException,
			PerfilUsuarioMalIngresadoException {
		double alt = 0;
		double sens = 0;
		double ci = 0;
		double[] intervalos = new double[]{0.0, 0.0, 0.0, 0.0};
		boolean defecto = false;
		try {
			alt = Double.parseDouble(this.altura.getText());
			sens = Double.parseDouble(this.sensibilidad.getText());
			ci = Double.parseDouble(this.CI.getText());
			if(intervalosAutoCheck.isSelected()){
				defecto = true;
			}else{
				defecto = false;
				intervalos[0] = Double.parseDouble(this.valorA.getText());
				intervalos[1] = Double.parseDouble(this.valorB.getText());
				intervalos[2] = Double.parseDouble(this.valorC.getText());
				intervalos[3] = Double.parseDouble(this.valorD.getText());
				
				boolean sorted = true;
				int i = 0;
				while (sorted && i < intervalos.length - 1){
				    if (intervalos[i] > intervalos[i+1]) {
				        sorted = false;
				    }
				    i++;
				}
				if(!sorted){
					throw new PerfilUsuarioMalIngresadoException("Los intervalos deben estar ordenados.");
				}
				
			}
		} catch (NumberFormatException e) {
			throw new PerfilUsuarioMalIngresadoException(
					"Los valores deben ser numéricos");
		}
		if(defecto){
			return new PerfilUsuario(alt, sens, ci);
		}else{
			return new PerfilUsuario(alt, sens, ci, intervalos);
		}
	}

	/**
	 * 
	 * Devuelve el perfil de esta ventana.
	 * 
	 * @return
	 *  
	 */

	public PerfilUsuario getPerfil() {
		return this.perfilUsuario;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(intervalosAutoCheck)) {
			if(intervalosAutoCheck.isSelected()){
				valorA.setEnabled(false);
				valorB.setEnabled(false);
				valorC.setEnabled(false);
				valorD.setEnabled(false);
			}else{
				valorA.setEnabled(true);
				valorB.setEnabled(true);
				valorC.setEnabled(true);
				valorD.setEnabled(true);
			}	
		}
		
		if (e.getSource().equals(cancelar)) {
			this.setVisible(false);
			this.dispose();
		} else if (e.getSource().equals(this.aceptar)) {
			try {
				this.perfilUsuario = this.crearPerfil();
				aceptarDefinitivo.doClick();
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(this, ex.getMessage(), "Error",
						JOptionPane.WARNING_MESSAGE);
			}
		}
	}
}
