package sapo.ifusuario.menues;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import sapo.principal.Comandos;
import sapo.red.CanalFrecuencias;
import sapo.red.CanalMalDefinidoException;

/**
 * Esta clase define la ventana de creaciï¿œn/ediciï¿œn de un canal de
 * frecuencias.
 * 
 * @author Grupo de proyecto SAPO
 */

public class VentanaCanalFrecuencias extends JDialog implements ActionListener,
		ListSelectionListener {

	JTextField nombre;

	JTextField frecuencia;

	JButton agregar = new JButton("Agregar");

	JButton quitar = new JButton("Quitar");

	JButton aceptar = new JButton("Aceptar");

	JButton cancelar = new JButton("Cancelar");

	JButton aceptarDefinitivo = new JButton();

	JList listaCanal;

	DefaultListModel modeloCanal = new DefaultListModel();

	JScrollPane panelCanal;

	ArrayList<Double> frecuencias;

	CanalFrecuencias canal;

	/**
	 * Construye una ventana para crear un nuevo canal
	 */

	public VentanaCanalFrecuencias(ActionListener a, JFrame duenio) {
		this(null, a, duenio, false);
	}

	/**
	 * Construye una ventana para editar un nuevo canal existente
	 */

	public VentanaCanalFrecuencias(CanalFrecuencias canal, ActionListener a,
			JFrame duenio) {
		this(canal, a, duenio, true);
	}

	/**
	 * Construye una ventana para crear/editar canales
	 */

	public VentanaCanalFrecuencias(CanalFrecuencias canal, ActionListener a,
			JFrame duenio, Boolean editar) {
		super(duenio, true);
		this.setSize(new Dimension(250, 350));
		this.setResizable(false);

		// inicializacion de los componentes
		frecuencia = new JTextField();
		listaCanal = new JList(modeloCanal);
		listaCanal.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				// listeners
		aceptar.addActionListener(this);
		aceptarDefinitivo.addActionListener(a);
		cancelar.addActionListener(this);
		agregar.addActionListener(this);
		quitar.addActionListener(this);
		listaCanal.addListSelectionListener(this); 

		if (editar) {
			this.setTitle("Editar Canal de Frecuencias");
			aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_EDITAR_CANAL);
			nombre = new JTextField(canal.getNombre());
			frecuencias = canal.getFrecuencias();
			Iterator<Double> i = frecuencias.iterator();
			while (i.hasNext()) {
				modeloCanal.addElement(i.next() + "MHz");
			}


		} else {
			frecuencias = new ArrayList<Double>();
			aceptar.setEnabled(false);
			this.setTitle("Nuevo Canal de Frecuencias");
			aceptarDefinitivo
					.setActionCommand(Comandos.CONFIRMAR_AGREGAR_CANAL);
			nombre = new JTextField("Nuevo canal");
		}

		// agregar campos
		this.agregarCampos();
		// this.pack();
		this.setLocationRelativeTo(duenio);

		// estado inicial
		quitar.setEnabled(false);

	}

	private void agregarCampos() {
		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.RELATIVE;
		c.weightx = 1;
		c.weighty = 1;
		getContentPane().add(new JLabel(" Nombre: "), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		getContentPane().add(nombre, c);

		c.gridwidth = GridBagConstraints.RELATIVE;
		getContentPane().add(new JLabel(" Frecuencia(MHz): "), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		getContentPane().add(frecuencia, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.REMAINDER;
		this.getContentPane().add(agregar, c);

		panelCanal = new JScrollPane(listaCanal);
		panelCanal.setPreferredSize(new Dimension(160, 120));
		panelCanal
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		this.getContentPane().add(panelCanal, c);
		this.getContentPane().add(quitar, c);

		JPanel panelBotones = new JPanel(new GridLayout(1, 2, 5, 5));
		panelBotones.add(aceptar);
		panelBotones.add(cancelar);
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);

	}

	/**
	 * 
	 * Intenta crear un canal de frecuencias con los datos ingresados.
	 * 
	 * @return
	 * @throws CanalMalDefinidoException
	 *             - si el nombre es vacï¿œo
	 * 
	 */

	public CanalFrecuencias crearCanal() throws CanalMalDefinidoException {
		return new CanalFrecuencias(nombre.getText(), frecuencias);
	}

	/**
	 * Devuelve el canal creado por la ventana.
	 * 
	 * @return
	 */

	public CanalFrecuencias getCanal() {
		return this.canal;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(cancelar)) {
			this.setVisible(false);
			this.dispose();
		} else if (e.getSource().equals(agregar)) {
			try {
				if (Double.parseDouble(frecuencia.getText()) > 0) {
					frecuencias.add(Double.valueOf(frecuencia.getText()));
					modeloCanal.addElement(frecuencia.getText() + "MHz");
					aceptar.setEnabled(true);
				} else {
					JOptionPane.showMessageDialog(this,
							"La frecuencia debe ser positiva.", "Error",
							JOptionPane.WARNING_MESSAGE);
				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(this,
						"Debe ingresar un valor numï¿œrico.", "Error",
						JOptionPane.WARNING_MESSAGE);
			} finally {
				frecuencia.setText("");
			}

		} else if (e.getSource().equals(quitar)) {
			frecuencias.remove(listaCanal.getSelectedValue());
			modeloCanal.remove(listaCanal.getSelectedIndex());
			if (modeloCanal.isEmpty()) {
				aceptar.setEnabled(false);
			}
		} else if (e.getSource().equals(aceptar)) {
			try {
				this.canal = this.crearCanal();
				aceptarDefinitivo.doClick();
			} catch (CanalMalDefinidoException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage(), "Error",
						JOptionPane.WARNING_MESSAGE);
			}
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		quitar.setEnabled(true);
		if (listaCanal.getSelectedIndex() == -1) {
			quitar.setEnabled(false);
		}
	}

}
