package sapo.ifusuario.menues;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import sapo.principal.Comandos;
import sapo.red.Antena;
import sapo.red.AntenaRepetidaException;
import sapo.red.Radiobase;
import sapo.red.RadiobaseMalDefinidaException;

/**
 * Esta clase define la ventana de creación/edición de una radiobase.
 * @author Grupo de proyecto SAPO
 */
public class VentanaRB extends JDialog implements ActionListener,
		ListSelectionListener {


	JTextField nombre;

	JTextField altura;

	JTextField nroAntenas;

	JList<String> listaAntenas;

	DefaultListModel<String> modeloListaAntenas;

	JButton agregarAntena = new JButton("Agregar");

	JButton editarAntena = new JButton(" Editar ");

	JButton borrarAntena = new JButton(" Borrar ");

	JButton aceptar = new JButton("Aceptar");

	JButton aceptarDefinitivo = new JButton();

	JButton cancelar = new JButton("Cancelar");

	Radiobase rb;

	/**
	 * Construye una ventana para crear una radiobase nueva
	 * 
	 * @param a
	 * @param duenio
	 * @param sePuedeCrearAntena 
	 *            indica si el proyecto está en condiciones de crear una antena
	 */
	public VentanaRB(ActionListener a, JFrame duenio, boolean sePuedeCrearAntena) {
		super(duenio, true);
		this.setTitle("Nueva RadioBase");
		this.setSize(new Dimension(280, 280));
		this.setLocationRelativeTo(duenio);

		//		inicializacion de componentes
		this.nombre = new JTextField("Nueva RB");
		this.altura = new JTextField("1");
		this.listaAntenas = new JList<String>();
		this.modeloListaAntenas = new DefaultListModel<String>();
		this.listaAntenas.setModel(modeloListaAntenas);

		//agregar campos
		this.agregarCampos();
		this.pack();
		this.setLocationRelativeTo(duenio);

		//estado inicial
		agregarAntena.setEnabled(sePuedeCrearAntena);
		editarAntena.setEnabled(false);
		borrarAntena.setEnabled(false);

		//listeners
		this.agregarListeners(a);
		aceptarDefinitivo
				.setActionCommand(Comandos.CONFIRMAR_AGREGAR_RADIOBASE);
	}

	/**
	 * Construye una ventana para editar una radiobase existente
	 * 
	 * @param rb
	 * @param a
	 * @param dialogo
	 * @param sePuedeCrearAntena 
	 *            indica si se puede crear una antena
	 */
	public VentanaRB(Radiobase rb, ActionListener a, JFrame duenio,
			boolean sePuedeCrearAntena) {

		super(duenio, true);
		this.setTitle("Editar RadioBase");
		this.setSize(new Dimension(280, 260));
		this.setLocationRelativeTo(duenio);
		this.rb = new Radiobase(rb);

		//		inicializacion de componentes
		this.nombre = new JTextField(rb.getNombre());
		this.altura = new JTextField(String.valueOf(rb.getAltura()));
		this.listaAntenas = new JList<String>();
		this.modeloListaAntenas = new DefaultListModel<String>();
		this.listaAntenas.setModel(modeloListaAntenas);

		ArrayList antenas = rb.getAntenas();
		Iterator i = antenas.iterator();
		while (i.hasNext()) {
			modeloListaAntenas.addElement(((Antena) i.next()).getNombre());
		}

		//agregar campos
		this.agregarCampos();
		this.pack();
		this.setLocationRelativeTo(duenio);

		//estado inicial
		agregarAntena.setEnabled(sePuedeCrearAntena);
		editarAntena.setEnabled(false);
		borrarAntena.setEnabled(false);

		//listeners
		this.agregarListeners(a);
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_EDITAR_RADIOBASE);

	}

	private void agregarListeners(ActionListener a) {
		aceptar.addActionListener(this);
		aceptarDefinitivo.addActionListener(a);
		cancelar.addActionListener(this);
		agregarAntena.addActionListener(this);
		agregarAntena.addActionListener(a);
		agregarAntena.setActionCommand(Comandos.AGREGAR_ANTENA);
		editarAntena.addActionListener(this);
		editarAntena.addActionListener(a);
		editarAntena.setActionCommand(Comandos.EDITAR_ANTENA);
		borrarAntena.addActionListener(this);
		borrarAntena.addActionListener(a);
		borrarAntena.setActionCommand(Comandos.BORRAR_ANTENA);
		listaAntenas.addListSelectionListener(this);
		listaAntenas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	}

	protected void agregarCampos() {
		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory
				.createTitledBorder("Características de la Radiobase"));

		c.weightx = 1;
		c.weighty = 1;
		panel.add(new JLabel(" Nombre: "), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(nombre, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Altura (m): "), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(altura, c);

		c.fill = GridBagConstraints.BOTH;
		getContentPane().add(panel, c);

		panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory.createTitledBorder("Antenas"));

		c.gridwidth = GridBagConstraints.RELATIVE;
		//c.fill = GridBagConstraints.BOTH;
		c.gridheight = 3;
		JScrollPane panelRB = new JScrollPane(listaAntenas);
		panelRB.setPreferredSize(new Dimension(130, 20));
		panelRB
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		//getContentPane().add(listaRB, c);
		panel.add(panelRB, c);

		c.gridheight = 1;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.NONE;
		panel.add(agregarAntena, c);
		panel.add(editarAntena, c);
		panel.add(borrarAntena, c);

		c.fill = GridBagConstraints.BOTH;
		getContentPane().add(panel, c);

		c.fill = GridBagConstraints.NONE;
		JPanel panelBotones = new JPanel(new GridLayout(1, 2, 3, 3));
		panelBotones.add(aceptar);
		panelBotones.add(cancelar);
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);

	}

	/**
	 * @return Returns the nombre.
	 */
	String getNombre() {
		return nombre.getText().replace(' ', '_');
	}

	/**
	 * Agrega las antenas de rb a la radiobase de esta ventana.
	 * 
	 * @param rb
	 */
	public void setRadiobase(Radiobase radiobaseNueva) {
		ArrayList antenasNuevas = radiobaseNueva.getAntenas();
		Iterator it = antenasNuevas.iterator();
		while (it.hasNext()) {
			try {
				Antena antenaAAgregar = (Antena) it.next();
				System.out
						.println("***************Antena a agregar***********************"
								+ antenaAAgregar);
				this.rb.agregarAntena(antenaAAgregar);
			} catch (AntenaRepetidaException e) {
				//e.printStackTrace(); Aca entra cuando radiobaseNueva es ella
				// misma. No queremos agregar nada en ese caso.
			}
		}
	}

	/**
	 * @return Returns the altura.
 */
	double getAltura() throws RadiobaseMalIngresadaException {
		try {
			return Double.parseDouble(altura.getText());
		} catch (NumberFormatException e) {
			throw new RadiobaseMalIngresadaException(
					"Los valores deben ser numéricos. ");
		}
	}

	public void agregarAntena(String nombre) {
		modeloListaAntenas.addElement(nombre);
		editarAntena.setEnabled(true);
		borrarAntena.setEnabled(true);
	}

	public String getAntenaSeleccionada() {
		return (String) listaAntenas.getSelectedValue();
	}

	public void borrarAntena(String nombre) {
		modeloListaAntenas.removeElement(nombre);
		if (modeloListaAntenas.isEmpty()) {
			//modeloListaAntena.addElement(SIN_RADIOBASES);
			editarAntena.setEnabled(false);
			borrarAntena.setEnabled(false);
		}
	}

	/**
	 * 
	 * Intenta crear una radiobase con los datos provistos por el usuario.
	 * 
	 * @return
	 * @throws RadiobaseMalIngresadaException
	 * @throws RadiobaseMalDefinidaException
	 *  
	 */

	Radiobase crearRadioBase() throws RadiobaseMalDefinidaException,
			RadiobaseMalIngresadaException {

		if (rb == null)
			rb = new Radiobase();
		if (this.getNombre().equals("")) {
			throw new RadiobaseMalIngresadaException(
					"La radiobase debe tener nombre");
		}
		rb.setNombre(this.getNombre());
		rb.setAltura(this.getAltura());
		return rb;
	}

	/**
	 * 
	 * Devuelve la radiobase creada por esta ventana
	 * 
	 * @return
	 *  
	 */

	public Radiobase getRadiobase() {
		return this.rb;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(cancelar)) {
			this.setVisible(false);
			this.dispose();
		} else if (e.getSource().equals(aceptar)) {
			try {
				this.rb = this.crearRadioBase();
				aceptarDefinitivo.doClick();
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(this, ex.getMessage(), "Error",
						JOptionPane.WARNING_MESSAGE);
				ex.printStackTrace(System.out);
			}
		} else if (e.getSource().equals(this.borrarAntena)) {
			if (listaAntenas.isSelectionEmpty()) {
				editarAntena.setEnabled(false);
				borrarAntena.setEnabled(false);
			}
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (listaAntenas.isSelectionEmpty()) {
			editarAntena.setEnabled(false);
			borrarAntena.setEnabled(false);
		} else {
			editarAntena.setEnabled(true);
			borrarAntena.setEnabled(true);
		}
	}

}
