package sapo.ifusuario.menues;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import sapo.predicciones.Cost231WI;
import sapo.predicciones.Cost231WISimple;
import sapo.predicciones.Erceg;
import sapo.predicciones.ITU_R_P1546;
import sapo.predicciones.Modelo;
import sapo.predicciones.ModeloMalDefinidoException;
import sapo.predicciones.Mopem;
import sapo.predicciones.OkumuraHata;
import sapo.predicciones.TierraPlana;
import sapo.predicciones.TierraPlanaAproximada;
import sapo.predicciones.Vacio;
import sapo.predicciones.VoglerIkegami;
import sapo.predicciones.VoglerSaundersBonar;
import sapo.principal.Comandos;

/**
 * Esta clase se utiliza como gui para crear los modelos disponibles. Es un
 * diálogo con dos etapas: primero se elije el modelo y luego se utiliza el
 * método getPanelCreacion() del modelo seleccionado para crear una instancia de
 * ese modelo.
 * 
 * @author Grupo de proyecto SAPO
 */

public class VentanaCrearModelos extends JDialog implements ActionListener,
		ListSelectionListener {

	JPanel panelNombre;

	JPanel panelPrincipal;

	JPanel panelBotones;

	JTextField nombre;

	//JLabel etiqNombre;
	//JPanel panelBotones;
	JButton anterior;

	//JLabel etiqNombre;
	//JPanel panelBotones;
	JButton siguiente;

	//JLabel etiqNombre;
	//JPanel panelBotones;
	JButton cancelar;

	//JLabel etiqNombre;
	//JPanel panelBotones;
	JButton aceptar;

	//JLabel etiqNombre;
	//JPanel panelBotones;
	JButton aceptarDefinitivo;

	final String VACIO = " Propagación en Vacío";

	final String TIERRA_PLANA = " Propagación sobre un plano conductor";

	final String TIERRA_PLANA_APROXIMADA = " Propagación sobre un plano conductor (aproximación)";

	final String P1546 = " Recomendación ITU-R P.1546-4";
	
	final String O_H_C = " Modelo de Okumura-Hata COST231";

	final String COST231_WI = " Modelo COST231 Walfisch-Ikegami";

	final String COST231_WI_SIMPLE = " Modelo COST231 Walfisch-Ikegami simplificado";

	final String MOPEM = " Modelo MOPEM";

	final String ERCEG_SUI = " Modelo de Erceg (SUI)";

	final String LOS = " Verificador Línea de Vista";

	final String VOGLER_SB = " Vogler de Saunders & Bonar";

	final String VOGLER_IKEGAMI = " Vogler-Ikegami";

	//despues borrar
	final String ORI = " Orientacion";

	final String[] modelosDisponibles = new String[] { VACIO, TIERRA_PLANA,
			TIERRA_PLANA_APROXIMADA, P1546, O_H_C, COST231_WI, COST231_WI_SIMPLE,
			MOPEM, VOGLER_IKEGAMI, VOGLER_SB, ERCEG_SUI };

	JList listaModelos;

	Modelo modelo;

	JFrame duenio;

	/**
	 * Simplemente inicializa los atributos de la clase.
	 *  
	 */
	public VentanaCrearModelos(String titulo, JFrame duenio, ActionListener aL) {
		super(duenio, true);
		//this.setSize(new Dimension(290,200));
		//this.setLocationRelativeTo(duenio);
		this.setTitle(titulo);
		this.getContentPane().setLayout(new GridBagLayout());
		this.duenio = duenio;

		listaModelos = new JList(modelosDisponibles);
		listaModelos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listaModelos.setLayoutOrientation(JList.VERTICAL);
		listaModelos.addListSelectionListener(this);
		//listaModelos.setVisibleRowCount(-1);
		JScrollPane panel = new JScrollPane(listaModelos);
		panel.setPreferredSize(new Dimension(290, 190));
		nombre = new JTextField();

		GridBagConstraints c = new GridBagConstraints();
		c.weightx = 1;
		c.weighty = 1;
		//c.fill = GridBagConstraints.HORIZONTAL;

		panelNombre = new JPanel();
		//panelNombre.add(new JLabel(" Elija un nombre para la implementacion
		// del modelo:"));
		//panelNombre.add(nombre);

		c.insets = new Insets(3, 3, 3, 3);

		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 1;
		c.gridwidth = 2;
		//c.fill = GridBagConstraints.HORIZONTAL;
		this.getContentPane().add(panelNombre, c);
		//c.fill = GridBagConstraints.CENTER;

		c.gridx = 0;
		c.gridy = 1;
		c.gridheight = 4;
		c.gridwidth = 2;
		panelPrincipal = new JPanel(new BorderLayout());
		panelPrincipal.add(panel, BorderLayout.CENTER);
		JLabel titulito = new JLabel(
				"Seleccione el modelo que desea implementar: ");
		panelPrincipal.add(titulito, BorderLayout.NORTH);
		c.fill = GridBagConstraints.BOTH;
		this.getContentPane().add(panelPrincipal, c);
		c.fill = GridBagConstraints.NONE;

		anterior = new JButton("< Anterior");
		anterior.addActionListener(this);
		cancelar = new JButton("Cancelar");
		cancelar.addActionListener(this);
		siguiente = new JButton("Siguiente >");
		siguiente.addActionListener(this);
		aceptar = new JButton("Aceptar");
		aceptar.addActionListener(this);
		aceptarDefinitivo = new JButton();
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_AGREGAR_MODELO);
		aceptarDefinitivo.addActionListener(aL);
		panelBotones = new JPanel(new GridLayout(1, 3, 2, 2));
		panelBotones.add(anterior);
		anterior.setEnabled(false);
		siguiente.setEnabled(false);
		panelBotones.add(cancelar);
		panelBotones.add(siguiente);

		c.gridy = 5;
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);
		//this.setVisible(true);
		this.pack();
		this.setLocationRelativeTo(duenio);

	}

	public VentanaCrearModelos(Modelo modelo, JFrame duenio, ActionListener aL) {
		super(duenio, true);
		//this.setSize(new Dimension(295,270));
		//this.setLocationRelativeTo(duenio);
		this.setTitle("Editar modelo");
		this.getContentPane().setLayout(new GridBagLayout());

		this.modelo = modelo;

		nombre = new JTextField(modelo.getNombre());

		GridBagConstraints c = new GridBagConstraints();
		c.weightx = 1;
		c.weighty = 1;
		//c.fill = GridBagConstraints.HORIZONTAL;

		panelNombre = new JPanel(new GridLayout(2, 1, 3, 3));
		panelNombre.add(new JLabel("Nombre de la implementación del modelo:"));
		panelNombre.add(nombre);

		c.insets = new Insets(3, 3, 3, 3);

		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		this.getContentPane().add(panelNombre, c);
		//c.fill = GridBagConstraints.CENTER;

		c.gridx = 0;
		c.gridy = 1;
		c.gridheight = 4;
		c.gridwidth = 2;
		panelPrincipal = new JPanel(new BorderLayout());
		panelPrincipal.add(this.modelo.getPanelCreacion(), BorderLayout.CENTER);

		//this.resize(new
		// Dimension((int)(modelo.getPanelCreacion().getTamanioVentana().getWidth()+5),(int)(modelo.getPanelCreacion().getTamanioVentana().getHeight()+50)));
		c.fill = GridBagConstraints.BOTH;
		this.getContentPane().add(panelPrincipal, c);
		c.fill = GridBagConstraints.NONE;

		cancelar = new JButton("Cancelar");
		cancelar.addActionListener(this);
		aceptar = new JButton("Aceptar");
		aceptar.addActionListener(this);
		aceptarDefinitivo = new JButton();
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_EDITAR_MODELO);
		aceptarDefinitivo.addActionListener(aL);

		panelBotones = new JPanel(new GridLayout(1, 3, 2, 2));
		panelBotones.add(aceptar);
		panelBotones.add(cancelar);
		//panelBotones.add(siguiente);

		c.gridy = 5;
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);

		this.pack();
		this.setLocationRelativeTo(duenio);
	}

	/**
	 * 
	 * Intenta crear un modelo con los datos ingresados
	 * 
	 * @return
	 * @throws ModeloMalDefinidoException -
	 *             Cuando los datos ingresados no son correctos
	 *  
	 */

	Modelo crearModelo() throws ModeloMalDefinidoException {
		Modelo nuevoModelo = this.modelo.getPanelCreacion().getModelo();
		nuevoModelo.setNombre(nombre.getText());
		return nuevoModelo;
	}

	/**
	 * @return Returns the modelo.
	 */
	public Modelo getModelo() {
		return this.modelo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent accion) {
		if (accion.getSource().equals(cancelar)) {
			setVisible(false);
			this.dispose();

		} else if (accion.getSource().equals(siguiente)) {
			if (!listaModelos.isSelectionEmpty()) {
				anterior.setEnabled(true);
				panelBotones.remove(siguiente);
				panelBotones.remove(cancelar);//new!!
				panelBotones.add(aceptar);
				panelBotones.add(cancelar);//new!!
				panelPrincipal.removeAll();

				panelNombre.setLayout(new GridLayout(2, 1, 3, 3));
				panelNombre.add(new JLabel(
						"Nombre de la implementacion del modelo:"));
				panelNombre.add(nombre);

				if (listaModelos.getSelectedValue().equals(this.VACIO)) {
					this.modelo = new Vacio();
				} else if (listaModelos.getSelectedValue().equals(
						this.TIERRA_PLANA)) {
					this.modelo = new TierraPlana();
				} else if (listaModelos.getSelectedValue().equals(
						this.TIERRA_PLANA_APROXIMADA)) {
					this.modelo = new TierraPlanaAproximada();
				} else if (listaModelos.getSelectedValue().equals(this.P1546)) {
					this.modelo = new ITU_R_P1546();
				} else if (listaModelos.getSelectedValue().equals(this.O_H_C)) {
					this.modelo = new OkumuraHata();
				} else if (listaModelos.getSelectedValue().equals(
						this.COST231_WI)) {
					this.modelo = new Cost231WI();
				} else if (listaModelos.getSelectedValue().equals(
						this.ERCEG_SUI)) {
					this.modelo = new Erceg();
				} else if (listaModelos.getSelectedValue().equals(this.MOPEM)) {
					this.modelo = new Mopem();
				} else if (listaModelos.getSelectedValue().equals(
						this.VOGLER_SB)) {
					this.modelo = new VoglerSaundersBonar();
				} else if (listaModelos.getSelectedValue().equals(
						this.VOGLER_IKEGAMI)) {
					this.modelo = new VoglerIkegami();
				} else if (listaModelos.getSelectedValue().equals(
						this.COST231_WI_SIMPLE)) {
					this.modelo = new Cost231WISimple();
				}

				//panelNombre.setLayout((new GridLayout(1,2,2,2)));
				//panelNombre.add(new JLabel(" Nombre:"));
				//panelNombre.add(nombre);
				//panelNombre.setPreferredSize(new
				// Dimension(this.modelo.getPanelCreacion().getTamanioVentana().width,
				// 0));

				panelPrincipal.add(this.modelo.getPanelCreacion(),
						BorderLayout.CENTER);
				//this.resize(this.modelo.getPanelCreacion().getTamanioVentana());
				//this.resize(new
				// Dimension((int)(modelo.getPanelCreacion().getTamanioVentana().getWidth()+5),(int)(modelo.getPanelCreacion().getTamanioVentana().getHeight()+50)));
				this.pack();
				this.setLocationRelativeTo(duenio);
				this.validate();
				this.repaint();
			}
		} else if (accion.getSource().equals(anterior)) {

			panelNombre.removeAll();
			//panelNombre.add(new JLabel(" Elija un nombre para la
			// implementacion del modelo:"));
			//panelNombre.add(nombre);

			JScrollPane panel = new JScrollPane(listaModelos);
			panel.setPreferredSize(new Dimension(290, 130));
			panelPrincipal.removeAll();
			panelPrincipal.add(panel, BorderLayout.CENTER);
			JLabel titulito = new JLabel(
					"Seleccione el modelo que desea implementar: ");
			panelPrincipal.add(titulito, BorderLayout.NORTH);
			//this.resize(new Dimension(295,215));

			anterior.setEnabled(false);
			panelBotones.remove(aceptar);
			panelBotones.add(siguiente);

			this.pack();
			this.setLocationRelativeTo(duenio);
			this.validate();
			this.repaint();
		} else if (accion.getSource().equals(aceptar)) {
			try {
				this.modelo = this.crearModelo();
				aceptarDefinitivo.doClick();
			} catch (ModeloMalDefinidoException e) {
				JOptionPane.showMessageDialog(this, e.getMessage(), "Error",
						JOptionPane.WARNING_MESSAGE);
			}
		}

	}

	public void valueChanged(ListSelectionEvent arg0) {
		siguiente.setEnabled(true);

	}

}