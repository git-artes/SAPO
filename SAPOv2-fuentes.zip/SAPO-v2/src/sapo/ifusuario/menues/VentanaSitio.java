package sapo.ifusuario.menues;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import sapo.principal.Comandos;
import sapo.red.Radiobase;
import sapo.red.RadiobaseRepetidaException;
import sapo.red.Sitio;

/**
 * Esta clase define la ventana de creación/edición de un sitio.
 * 
 * @author Grupo de proyecto SAPO
 */
public class VentanaSitio extends JDialog implements ActionListener,
		ListSelectionListener {

	JTextField posicionX;

	JTextField posicionY;

	JTextField nombre;

	JLabel posx;

	JLabel posy;

	JRadioButton radioWGS84;

	JRadioButton radioSIRGAS2000;

	ButtonGroup grupoCRS;

	JList listaRB;

	DefaultListModel modeloListaRB;

	JButton agregarRB = new JButton("Agregar");

	JButton editarRB = new JButton(" Editar ");

	JButton borrarRB = new JButton(" Borrar ");

	JButton aceptar = new JButton("Aceptar");

	JButton aceptarDefinitivo = new JButton();

	JButton cancelar = new JButton("Cancelar");

	Sitio sitio;

	/**
	 * Construye una ventana para crear un nuevo sitio
	 */
	public VentanaSitio(ActionListener a, JFrame duenio) {
		super(duenio, true);
		this.setTitle("Nuevo Sitio");
		this.setSize(new Dimension(300, 300));

		// inicializacion de componentes
		this.nombre = new JTextField("Nuevo Sitio");
		this.posicionX = new JTextField("0");
		this.posicionY = new JTextField("0");
		this.posx = new JLabel(" Posición x: ");
		this.posy = new JLabel(" Posición y: ");
		this.radioSIRGAS2000 = new JRadioButton("<html>SIRGAS2000 /<br>UTM zona 21S</html>");
		this.radioWGS84 = new JRadioButton("WGS84");
		this.grupoCRS = new ButtonGroup();
		this.grupoCRS.add(radioSIRGAS2000);
		this.grupoCRS.add(radioWGS84);
		this.listaRB = new JList();
		this.modeloListaRB = new DefaultListModel();
		this.listaRB.setModel(modeloListaRB);

		// agregar campos
		this.agregarCampos();
//		this.pack();
		this.setLocationRelativeTo(duenio);

		// estado inicial
		editarRB.setEnabled(false);
		borrarRB.setEnabled(false);

		// listeners
		this.agregarListeners(a);
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_AGREGAR_SITIO);
	}

	/**
	 * Construye una ventana para editar un sitio existente
	 */

	public VentanaSitio(Sitio sitio, ActionListener a, JFrame duenio) {
		super(duenio, true);
		this.setTitle("Editar Sitio");
		this.setSize(new Dimension(300, 300));
		this.setLocationRelativeTo(duenio);
		this.sitio = new Sitio(sitio);

		// inicializacion de componentes
		this.nombre = new JTextField(sitio.getNombre());
		this.posicionX = new JTextField(String.valueOf(sitio.getX()));
		this.posicionY = new JTextField(String.valueOf(sitio.getY()));
		this.posx = new JLabel(" Posición x: ");
		this.posy = new JLabel(" Posición y: ");
		this.radioSIRGAS2000 = new JRadioButton("SIRGAS 2000");
		this.radioWGS84 = new JRadioButton("WGS84");
		this.grupoCRS = new ButtonGroup();
		this.grupoCRS.add(radioSIRGAS2000);
		this.grupoCRS.add(radioWGS84);
		this.listaRB = new JList();
		this.modeloListaRB = new DefaultListModel();
		this.listaRB.setModel(modeloListaRB);

		ArrayList radiobases = sitio.getRadiobases();
		Iterator i = radiobases.iterator();
		while (i.hasNext()) {
			modeloListaRB.addElement(((Radiobase) i.next()).getNombre());
		}

		// agregar campos
		this.agregarCampos();
//		this.pack();
		this.setLocationRelativeTo(duenio);

		// estado inicial
		editarRB.setEnabled(false);
		borrarRB.setEnabled(false);

		// listeners
		this.agregarListeners(a);
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_EDITAR_SITIO);
	}

	/**
	 * 
	 * Define el Layout y agrega todos los campos en la ventana
	 * 
	 */

	private void agregarCampos() {
		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory
				.createTitledBorder("Características del sitio"));

		c.weightx = 1;
		c.weighty = 1;
		panel.add(new JLabel(" Nombre: "), c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(nombre, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(posx, c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(posicionX, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(posy, c);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(posicionY, c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(radioSIRGAS2000, c);
		radioSIRGAS2000.setSelected(true);		

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(radioWGS84, c);

		c.fill = GridBagConstraints.BOTH;
		getContentPane().add(panel, c);

		panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory.createTitledBorder("Radiobases"));

		c.gridwidth = GridBagConstraints.RELATIVE;
		// c.fill = GridBagConstraints.BOTH;
		c.gridheight = 3;
		JScrollPane panelRB = new JScrollPane(listaRB);
		panelRB.setPreferredSize(new Dimension(130, 20));
		panelRB.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		// getContentPane().add(listaRB, c);
		panel.add(panelRB, c);

		c.gridheight = 1;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.NONE;
		panel.add(agregarRB, c);
		panel.add(editarRB, c);
		panel.add(borrarRB, c);

		c.fill = GridBagConstraints.BOTH;
		getContentPane().add(panel, c);

		c.fill = GridBagConstraints.NONE;
		JPanel panelBotones = new JPanel(new GridLayout(1, 2, 3, 3));
		panelBotones.add(aceptar);
		panelBotones.add(cancelar);
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);
	}

	private void agregarListeners(ActionListener a) {
		aceptar.addActionListener(this);
		aceptarDefinitivo.addActionListener(a);
		cancelar.addActionListener(this);
		agregarRB.addActionListener(this);
		agregarRB.addActionListener(a);
		agregarRB.setActionCommand(Comandos.AGREGAR_RADIOBASE);
		editarRB.addActionListener(this);
		editarRB.addActionListener(a);
		editarRB.setActionCommand(Comandos.EDITAR_RADIOBASE);
		borrarRB.addActionListener(this);
		borrarRB.addActionListener(a);
		borrarRB.setActionCommand(Comandos.BORRAR_RADIOBASE);
		listaRB.addListSelectionListener(this);
		listaRB.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		radioSIRGAS2000.addActionListener(this);
		radioWGS84.addActionListener(this);

	}

	/**
	 * Agrega las radiobases de sitio al sitio de esta ventana.
	 * 
	 * @param sitio
	 */
	public void setSitio(Sitio sitio) {
		ArrayList radiobases = sitio.radiobases;
		Iterator it = radiobases.iterator();
		while (it.hasNext()) {
			try {
				this.sitio.agregarRB((Radiobase) it.next());
			} catch (RadiobaseRepetidaException e) {
				// e.printStackTrace(); Aca entra solamente cuando el sitio es
				// él mismo. No queremos agregar nada en ese caso.
			}
		}
	}

	/**
	 * @return Returns the nombre.
	 */
	String getNombre() throws SitioMalIngresadoException {
		if (nombre.getText().equals(""))
			throw new SitioMalIngresadoException(
					"El nombre no puede ser vacío. ");
		return nombre.getText().replace(' ', '_');
	}

	double getXsitio() throws SitioMalIngresadoException {
		try {
			if(radioWGS84.isSelected()){
				double[] coord = sitio.cambioCoord(Double.parseDouble(posicionX.getText()), Double.parseDouble(posicionY.getText()));
				return coord[0];
			}else{
				return Double.parseDouble(posicionX.getText());
			}
		} catch (NumberFormatException e) {
			throw new SitioMalIngresadoException(
					"La posición debe tener un valor numérico. ");
		}
	}

	double getYsitio() throws SitioMalIngresadoException {
		try {
			if(radioWGS84.isSelected()){
				double[] coord = sitio.cambioCoord(Double.parseDouble(posicionX.getText()), Double.parseDouble(posicionY.getText()));
				return coord[1];
			}else{
				return Double.parseDouble(posicionY.getText());
			}
		} catch (NumberFormatException e) {
			throw new SitioMalIngresadoException(
					"La posición debe tener un valor numérico. ");
		}
	}

	public void setXsitio(double x) {
		posicionX.setText(String.valueOf(x));
	}

	public void setYsitio(double y) {
		posicionY.setText(String.valueOf(y));
	}

	public void agregarRB(String nombre) {
		// modeloListaRB.removeElement(SIN_RADIOBASES);
		modeloListaRB.addElement(nombre);
		editarRB.setEnabled(true);
		borrarRB.setEnabled(true);
	}

	/*
	 * 
	 * public String getRadiobaseSeleccionada(){ return
	 * (String)listaRB.getSelectedItem(); }
	 */

	public String getRadiobaseSeleccionada() {
		return (String) listaRB.getSelectedValue();
	}

	public void borrarRB(String nombre) {
		modeloListaRB.removeElement(nombre);
		if (modeloListaRB.isEmpty()) {
			// modeloListaRB.addElement(SIN_RADIOBASES);
			editarRB.setEnabled(false);
			borrarRB.setEnabled(false);
		}
	}

	/**
	 * 
	 * Crea una sitio con los datos ingresados.
	 * 
	 * @return
	 * @throws SitioMalIngresadoException
	 * 
	 */

	Sitio crearSitio() throws SitioMalIngresadoException {
		if (sitio == null)
			sitio = new Sitio();
		sitio.setNombre(this.getNombre());
		sitio.setPosicion(this.getXsitio(), this.getYsitio());
		return sitio;
	}

	/**
	 * Devuelve el sitio creado por esta ventana.
	 * 
	 * @return
	 */

	public Sitio getSitio() {
		return this.sitio;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(cancelar)) {
			this.setVisible(false);
			this.dispose();
		} else if (e.getSource().equals(aceptar)) {
			try {
				this.sitio = this.crearSitio();
				this.aceptarDefinitivo.doClick();
			} catch (SitioMalIngresadoException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage(), "Error",
						JOptionPane.WARNING_MESSAGE);
				e1.printStackTrace(System.out);
			}

		} else if (e.getSource().equals(this.borrarRB)) {
			if (listaRB.isSelectionEmpty()) {
				editarRB.setEnabled(false);
				borrarRB.setEnabled(false);
			}
		} else if (e.getSource().equals(this.radioSIRGAS2000)
				|| e.getSource().equals(this.radioWGS84)) {
			if (radioSIRGAS2000.isSelected()) {
				posx.setText(" Posición x: ");
				posy.setText(" Posición y: ");
			} else if (radioWGS84.isSelected()) {
				posx.setText(" Latitud: ");
				posy.setText(" Longitud: ");
			}

		}
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (listaRB.isSelectionEmpty()) {
			editarRB.setEnabled(false);
			borrarRB.setEnabled(false);
		} else {
			editarRB.setEnabled(true);
			borrarRB.setEnabled(true);
		}
	}
}