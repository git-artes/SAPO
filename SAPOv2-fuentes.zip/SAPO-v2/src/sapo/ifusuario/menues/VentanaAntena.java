package sapo.ifusuario.menues;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import sapo.predicciones.Modelo;
import sapo.principal.Comandos;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;
import sapo.red.CanalFrecuencias;
import sapo.red.TipoAntena;

/**
 * Esta clase define la ventana de creación/edición de una antena.
 * @author Grupo de proyecto SAPO
 */
public class VentanaAntena extends JDialog implements ActionListener,
		ItemListener {


	JTextField nombre;

	JTextField potencia;

	JTextField tilt;

	JTextField azimut;

	JTextField modelo;

	JComboBox listaAntenas;

	JComboBox listaModelos;

	JComboBox listaCanales;

	JButton aceptar = new JButton("Aceptar");

	JButton aceptarDefinitivo = new JButton();

	JButton cancelar = new JButton("Cancelar");

	Antena antena;

	public final static String SIN_ANTENAS_DISPONIBLES = "(ninguna)";

	public final static String SIN_CANALES_DISPONIBLES = "(ninguno)";

	public final static String SIN_MODELOS_DISPONIBLES = "(ninguno)";

	/**
	 * Construye una ventana para crear una antena nueva
	 * 
	 * @param proyecto
	 * @param a
	 * @param duenio
	 */
	public VentanaAntena(Proyecto proyecto, ActionListener a, JFrame duenio) {
		super(duenio, true);
		this.setTitle("Nueva Antena");
		this.setSize(new Dimension(255, 280));

		//		inicializacion de componentes
		nombre = new JTextField("Nueva Antena");
		potencia = new JTextField("8");
		tilt = new JTextField("0");
		azimut = new JTextField("0");
		this.inicializarListas(proyecto);

		//agregar campos
		this.agregarCampos();
		//this.pack();
		this.setLocationRelativeTo(duenio);

		//		listeners
		this.agregarListeners(a);
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_AGREGAR_ANTENA);
	}

	/**
	 * Construye una ventana para editar una antena ya existente
	 * 
	 * @param antena
	 * @param proyecto
	 * @param a
	 * @param duenio
	 */
	public VentanaAntena(Antena antena, Proyecto proyecto, ActionListener a,
			JFrame duenio) {
		super(duenio, true);
		this.setTitle("Editar Antena");
		this.setSize(new Dimension(255, 280));
		this.setLocationRelativeTo(duenio);

		//		inicializacion de componentes
		nombre = new JTextField(antena.getNombre());
		potencia = new JTextField(String.valueOf(antena.getPotencia()));
		tilt = new JTextField(String.valueOf(antena.getTilt()));
		azimut = new JTextField(String.valueOf(antena.getAzimut()));
		this.inicializarListas(proyecto);

		//agregar campos
		this.agregarCampos();
		//this.pack();
		this.setLocationRelativeTo(duenio);

		//estado inicial
		this.listaModelos.setSelectedItem(antena.getModelo().getNombre());
		this.listaAntenas.setSelectedItem(antena.getTipo().getNombre());
		this.listaCanales.setSelectedItem(antena.getCanal().getNombre());

		//		listeners
		this.agregarListeners(a);
		aceptarDefinitivo.setActionCommand(Comandos.CONFIRMAR_EDITAR_ANTENA);
	}

	private void inicializarListas(Proyecto proyecto) {
		ArrayList canales = proyecto.getCanales();
		String[] nombresCanales;
		if (canales.size() > 0) {
			nombresCanales = new String[canales.size()];
			for (int i = 0; i < canales.size(); i++) {
				CanalFrecuencias canal = (CanalFrecuencias) canales.get(i);
				nombresCanales[i] = canal.getNombre();
			}
		} else {
			nombresCanales = new String[] { SIN_CANALES_DISPONIBLES };

		}
		listaCanales = new JComboBox(nombresCanales);

		ArrayList antenas = proyecto.getTiposAntena();
		String[] nombresAntenas;
		if (antenas.size() > 0) {
			nombresAntenas = new String[antenas.size()];
			for (int i = 0; i < antenas.size(); i++) {
				TipoAntena tipoAntena = (TipoAntena) antenas.get(i);
				nombresAntenas[i] = tipoAntena.getNombre();
			}
		} else {
			nombresAntenas = new String[] { SIN_ANTENAS_DISPONIBLES };
		}
		listaAntenas = new JComboBox(nombresAntenas);

		ArrayList modelos = proyecto.getModelos();
		String[] nombresModelos;
		if (antenas.size() > 0) {
			nombresModelos = new String[modelos.size()];
			for (int i = 0; i < modelos.size(); i++) {
				Modelo modelo = (Modelo) modelos.get(i);
				nombresModelos[i] = modelo.getNombre();
			}
		} else {
			nombresModelos = new String[] { SIN_MODELOS_DISPONIBLES };
		}
		listaModelos = new JComboBox(nombresModelos);
	}

	private void agregarCampos() {
		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);

		c.weightx = 1;
		c.weighty = 1;

		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory
				.createTitledBorder("Características de la Antena"));

		panel.add(new JLabel(" Nombre: "), c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(nombre, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Tipo: "), c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(listaAntenas, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Potencia (dBm): "), c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(potencia, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Downtilt (grados): "), c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(tilt, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Azimut (grados): "), c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(azimut, c);

		/*
		 * c.gridwidth = GridBagConstraints.REMAINDER; getContentPane().add(new
		 * JLabel(""), c);
		 */

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(new JLabel(" Frecuencias: "), c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(listaCanales, c);

		getContentPane().add(panel, c);

		c.fill = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.RELATIVE;
		getContentPane().add(new JLabel(" Modelo: "), c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		getContentPane().add(listaModelos, c);

		c.fill = GridBagConstraints.NONE;
		JPanel panelBotones = new JPanel(new GridLayout(1, 2, 3, 3));
		panelBotones.add(aceptar);
		panelBotones.add(cancelar);
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);
	}

	private void agregarListeners(ActionListener a) {
		aceptar.addActionListener(this);
		aceptarDefinitivo.addActionListener(a);
		cancelar.addActionListener(this);
		listaCanales.addItemListener(this);
		listaModelos.addItemListener(this);
		listaAntenas.addItemListener(this);
	}

	/**
	 * 
	 * Crea una antena y le asigna los datos proporcionados por el usuario.
	 * 
	 * @return
	 * @throws AntenaMalIngresadaException -
	 *             cuando algún dato no es válido.
	 *  
	 */

	Antena crearAntena() throws AntenaMalIngresadaException {
		Antena antena = new Antena();
		antena.setNombre(this.getNombre());
		try {
			antena.setPotencia(Double.parseDouble(potencia.getText()));
			antena.setTilt(Double.parseDouble(tilt.getText()));
			antena.setAzimut(Double.parseDouble(azimut.getText()));
		} catch (NumberFormatException e) {
			throw new AntenaMalIngresadaException(
					"La antena únicamente acepta valores numéricos");
		}
		return antena;
	}

	/**
	 * Devuelve la antena que tiene esta ventana.
	 * 
	 * @return

	 */

	public Antena getAntena() {
		return this.antena;
	}

	/**
	 * @return Returns the nombre.

	 */
	String getNombre() throws AntenaMalIngresadaException {
		if (nombre.getText().equals("")) {
			throw new AntenaMalIngresadaException(
					"El nombre de la antena no puede ser vacío");
		}
		return nombre.getText().replace(' ', '_');
	}

	public String getTipoAntenaSeleccionada() {
		return (String) listaAntenas.getSelectedItem();
	}

	public String getModeloSeleccionado() {
		return (String) listaModelos.getSelectedItem();
	}

	public String getCanalSeleccionado() {
		return (String) listaCanales.getSelectedItem();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(this.cancelar)) {
			this.setVisible(false);
			this.dispose();
		} else if (e.getSource().equals(this.aceptar)) {
			try {
				this.antena = this.crearAntena();
				aceptarDefinitivo.doClick();
			} catch (AntenaMalIngresadaException ex) {
				ex.printStackTrace(System.out);
				JOptionPane.showMessageDialog(this, ex.getMessage(), "Error",
						JOptionPane.WARNING_MESSAGE);
			}
		}
	}

	//TODO no se usa
	@Override
	public void itemStateChanged(ItemEvent arg0) {

	}

}
