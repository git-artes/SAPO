package sapo.ifusuario.menues;

/**
 * 
 * Esta excepcion es lanzada al crear una antena, si el nombre es vacio o alguno de los 
 * parametros (potencia, tilt o azimut) no es un valor numerico.
 * 
 * @author Grupo de proyecto SAPO
 *  
 */

public class AntenaMalIngresadaException extends Exception {

	public AntenaMalIngresadaException(String mensaje) {
		super(mensaje);
	}

}
