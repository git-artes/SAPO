package sapo.ifusuario.menues;

/**
 * Esta excepción es lanzada al crear un sitio, si el nombre es vacío o las 
 * coordenadas no son valores numéricos.
 * 
 * @author Grupo de proyecto SAPO
 * 
 *  
 */

public class SitioMalIngresadoException extends Exception {

	public SitioMalIngresadoException(String mensaje) {
		super(mensaje);
	}

}
