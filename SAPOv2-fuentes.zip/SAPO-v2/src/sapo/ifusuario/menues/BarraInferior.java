package sapo.ifusuario.menues;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JToolBar;

/**
 * Esta clase define la barra inferior de la pantalla principal de SAPO.
 * @author Grupo de proyecto SAPO
 */

public class BarraInferior extends JToolBar {

	JLabel textoX;

	JLabel textoY;

	JLabel textoAltura;

	JLabel textoAtenuacion;

	public BarraInferior() {

		textoX = new JLabel("");
		textoY = new JLabel("");
		textoAltura = new JLabel(" ");
		textoAtenuacion = new JLabel("");

		add(new JLabel("  "));
		add(textoX);
		addSeparator();
		add(textoY);
		addSeparator();
		add(textoAltura);
		addSeparator();
		add(textoAtenuacion);

		//Color color = new Color(200, 240, 120);//verde manzana
		Color color = new Color(220, 240, 255);
		setBackground(color);

	}

	/**
	 * Devuelve el texto de la posicion x
	 */
	public JLabel getTextoX() {
		return textoX;
	}

	/**
	 *Devuelve el texto de la posicion y
	 */
	public JLabel getTextoY() {
		return textoY;
	}

	/**
	 * Devuelve el texto de la altura de terreno 
	 */
	public JLabel getTextoAltura() {
		return textoAltura;
	}

	/**
	 *  Devuelve el texto de potencia
	 */
	public JLabel getTextoAtenuacion() {
		return textoAtenuacion;
	}

}