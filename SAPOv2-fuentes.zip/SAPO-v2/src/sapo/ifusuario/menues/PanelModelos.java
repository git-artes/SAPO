package sapo.ifusuario.menues;

import javax.swing.JPanel;

import sapo.predicciones.Modelo;
import sapo.predicciones.ModeloMalDefinidoException;

/**
 * Esta clase constituye la interfaz de usuario para especificar los parámetros de los 
 * modelos existentes. Es un JPanel conteniendo todo lo necesario para especificar
 * parámetros del modelo. Cuenta con dos métodos abstractos para obtener los
 * parámetros del modelo de la interfaz. La idea es que cada modelo lo
 * implemente en una clase anidada y que devuelva su implementación en
 * particular en el método getPanelCreacion().
 * 
 * @author Grupo de proyecto SAPO
 */

public abstract class PanelModelos extends JPanel {

	/**
	 * Genera el PanelModelos con los paramétros especificados.

	 */
	public PanelModelos(double[] parametrosAjustables,
			Object[] parametrosNoAjustables) {
		super();
		this.agregarElementos();
		this.setParametrosAjustables(parametrosAjustables);
		this.setParametrosNoAjustables(parametrosNoAjustables);
	}

	/**
	 * Fija en los campos de este PanelModelos los parametrosAjustables
	 * especificados.
	 * 
	 * @param parametrosAjustables
	 * @throws ModeloMalDefinidoException 
	 *             cuando lo especificado no es válido.
	 */
	protected abstract void setParametrosAjustables(
			double[] parametrosAjustables);

	/**
	 * Fija en los campos de este PanelModelos los parametrosNoAjustables
	 * especificados.
	 * 
	 * @param parametrosAjustables
	 * @throws ModeloMalDefinidoException 
	 *             cuando lo especificado no es valido.
	 */
	protected abstract void setParametrosNoAjustables(
			Object[] parametrosNoAjustables);

	/**
	 * Dado lo que hay en el JPanel, devuelve los parámetros ajustables.
	 * 

	 * @throws ModeloMalDefinidoException 
	 *             en caso que haya alguna entrada ilegal en algún campo de la
	 *             gui.
	 */

	public abstract double[] getParametrosAjustables()
			throws ModeloMalDefinidoException;

	/**
	 * Dado lo que hay en el JPanel, devuelve los parámetros no ajustables.
	 * 

	 * @throws ModeloMalDefinidoException 
	 *             en caso que haya alguna entrada ilegal en algún campo de la
	 *             gui.
	 */

	public abstract Object[] getParametrosNoAjustables()
			throws ModeloMalDefinidoException;

	/**
	 * 
	 * Debe agregar los elementos de swing necesarios a la ventana. Será
	 * utilizado por el constructor.
	 * 
	 *  
	 */

	public abstract void agregarElementos();

	/**
	 * 
	 * Haciendo uso de los metodos getParametrosAjustables() y
	 * getParametrosNoAjustables(), y sabiendo a que modelo en particular esta
	 * asociado cada implementacion en particular, este metodo devuelve la
	 * instancia del modelo que indiquen sus campos.
	 * 
	 *  
	 */

	public abstract Modelo getModelo() throws ModeloMalDefinidoException;

}
