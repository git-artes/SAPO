package sapo.ifusuario.menues;

import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;


/**
 * Esta clase define los diferentes popups que aparecen en SAPO.
 * @author Grupo de proyecto SAPO
 */

public class Popup extends JPopupMenu {

	/**
	 * Consstruye un popup con los menues especificados
	 * @param a
	 * 			el ActionListener que atendera los eventos generados por el popup
	 * @param nombresMenu
	 */
	public Popup(ActionListener a, String[] nombresMenu) {

		for (int i = 0; i < nombresMenu.length; i++) {
			JMenuItem menu = new JMenuItem(nombresMenu[i]);
			add(menu);
			menu.addActionListener(a);
		}

	}

	public Popup() {
		super();
	}

}
