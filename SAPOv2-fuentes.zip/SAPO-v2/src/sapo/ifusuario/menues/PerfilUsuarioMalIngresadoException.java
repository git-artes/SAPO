
package sapo.ifusuario.menues;

/**
*  Esta excepción es lanzada al editar el perfil de usuario, si alguno de los parámetros 
* (altura, sensibilidad, C/I) no es un valor numérico.
* @author Grupo de proyecto SAPO
 */

public class PerfilUsuarioMalIngresadoException extends Exception {

	public PerfilUsuarioMalIngresadoException(String mensaje) {
		super(mensaje);
	}

}
