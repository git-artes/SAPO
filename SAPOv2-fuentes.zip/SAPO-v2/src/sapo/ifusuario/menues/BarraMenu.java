package sapo.ifusuario.menues;

//import gsmsoft.mapas.Demo2;

import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;

import sapo.principal.Comandos;

/**
 * Esta clase define la barra de menú desde la que se puede usar 
 * las diferentes herramientas de SAPO.
 * @author Grupo de proyecto SAPO
 */

public class BarraMenu extends JMenuBar {

	/*
	 * JMenuBar barraMenu; JMenu menuArchivo, menuVer; JMenuItem nuevoProy,
	 * abrirProy, salir; JCheckBox verExplorador;
	 * 
	 *  
	 */

	JMenu abrirDatos;

	JMenuItem abrirManzanas;

	JMenuItem abrirEdificios;

	JMenuItem abrirTerreno;

	JMenuItem guardarProyecto;

	JMenuItem nuevoProy;

	JMenuItem abrirProy;

	JMenuItem cerrarProyecto;

	JMenuItem editarProyecto;

	JMenuItem crearCanal;

	JMenuItem crearTipoAntena;

	JMenuItem crearSitio;

	JMenuItem salir;

	JMenuItem acercaDe;

	JMenuItem verDocu;

	JMenuItem verManual;

	JMenuItem crearModelo;

	JMenuItem estimarPrediccion;

	JMenuItem estimarLos;

	JMenuItem guardarPrediccion;

	JMenuItem quitarPrediccion;

	JMenuItem abrirPrediccion;

	JMenuItem infoPrediccion;

	JMenuItem abrirMedidas;
	
	JMenuItem moduloAdaptacion;

	JMenuItem cambiarPerfil;

	JMenuItem generadorEdif;

	JCheckBoxMenuItem verExplorador;

	JRadioButtonMenuItem verPotencia;

	JRadioButtonMenuItem verInterferencia;

	JRadioButtonMenuItem verCobertura;

	JCheckBoxMenuItem verAlturas;

	JCheckBoxMenuItem verEdificios;

	JCheckBoxMenuItem verManzanas;

	JCheckBoxMenuItem verPredicciones;

	//CONSTRUCTOR
	/**
	 * Construye la barra de menu
	 */
	public BarraMenu(ActionListener aL) {

		//MENU ARCHIVO
		JMenu menuArchivo = new JMenu("Archivo");

		//Sub-menu Abrir
		JMenu submenuAbrir = new JMenu("Abrir");

		abrirProy = new JMenuItem("Proyecto");
		abrirProy.setActionCommand(Comandos.ABRIR_PROYECTO);
		submenuAbrir.add(abrirProy);

		abrirDatos = new JMenu("Datos");
		abrirDatos.setEnabled(false);
		abrirTerreno = new JMenuItem("Alturas Terreno");
		abrirTerreno.setActionCommand(Comandos.ABRIR_ALTURAS);
		//abrirTerreno.setEnabled(false);
		abrirManzanas = new JMenuItem("Manzanas");
		abrirManzanas.setActionCommand(Comandos.ABRIR_MANZANAS);
		//abrirManzanas.setEnabled(false);
		abrirEdificios = new JMenuItem("Edificios");
		abrirEdificios.setActionCommand(Comandos.ABRIR_EDIFICIOS);
		//abrirEdificios.setEnabled(false);

		abrirDatos.add(abrirTerreno);
		abrirDatos.add(abrirManzanas);
		abrirDatos.add(abrirEdificios);
		submenuAbrir.add(abrirDatos);

		//Sub-menu Nuevo
		JMenu submenuNuevo = new JMenu("Nuevo");
		nuevoProy = new JMenuItem("Proyecto");
		nuevoProy.setActionCommand(Comandos.CREAR_PROYECTO);
		submenuNuevo.add(nuevoProy);

		//Sub-menu Guardar
		guardarProyecto = new JMenuItem("Guardar Proyecto");
		guardarProyecto.setActionCommand(Comandos.GUARDAR_PROYECTO);
		guardarProyecto.setEnabled(false);

		//Sub-menu Cerrar
		cerrarProyecto = new JMenuItem("Cerrar Proyecto");
		cerrarProyecto.setActionCommand(Comandos.CERRAR_PROYECTO);
		cerrarProyecto.setEnabled(false);

		//Sub-menu Salir
		salir = new JMenuItem("Salir");
		salir.setActionCommand(Comandos.SALIR);

		generadorEdif = new JMenuItem("Generador de Edificios");
		generadorEdif.setActionCommand(Comandos.GENERAR_EDIFICIOS);

		menuArchivo.add(submenuAbrir);
		menuArchivo.add(submenuNuevo);
		menuArchivo.add(guardarProyecto);
		menuArchivo.add(cerrarProyecto);
		menuArchivo.addSeparator();
		menuArchivo.add(generadorEdif);
		menuArchivo.addSeparator();
		menuArchivo.add(salir);
		this.add(menuArchivo);

		//		MENU PROYECTO
		JMenu menuProyecto = new JMenu("Proyecto");

		editarProyecto = new JMenuItem("Editar Datos del Proyecto");
		editarProyecto.setActionCommand(Comandos.EDITAR_PROYECTO);
		editarProyecto.setEnabled(false);
		cambiarPerfil = new JMenuItem("Editar Perfil de Usuario");
		cambiarPerfil.setActionCommand(Comandos.EDITAR_PERFIL);
		cambiarPerfil.setEnabled(false);
		crearModelo = new JMenuItem("Crear Modelo");
		crearModelo.setActionCommand(Comandos.AGREGAR_MODELO);
		crearModelo.setEnabled(false);
		crearTipoAntena = new JMenuItem("Crear Tipo de Antena");
		crearTipoAntena.setActionCommand(Comandos.AGREGAR_TIPO_ANTENA);
		crearTipoAntena.setEnabled(false);
		crearCanal = new JMenuItem("Crear Canal de Frecuencias");
		crearCanal.setActionCommand(Comandos.AGREGAR_CANAL);
		crearCanal.setEnabled(false);
		crearSitio = new JMenuItem("Crear Sitio");
		crearSitio.setActionCommand(Comandos.AGREGAR_SITIO);
		crearSitio.setEnabled(false);

		menuProyecto.add(editarProyecto);
		menuProyecto.add(cambiarPerfil);
		menuProyecto.addSeparator();
		menuProyecto.add(crearModelo);
		menuProyecto.add(crearTipoAntena);
		menuProyecto.add(crearCanal);
		menuProyecto.add(crearSitio);

		this.add(menuProyecto);

		//MENU PREDICCIONES
		JMenu menuPrediccion = new JMenu("Predicciones");
		estimarPrediccion = new JMenuItem("Realizar Predicción");
		estimarPrediccion.setActionCommand(Comandos.ESTIMAR_PREDICCION);
		estimarPrediccion.setEnabled(false);
		guardarPrediccion = new JMenuItem("Guardar Predicción");
		guardarPrediccion.setActionCommand(Comandos.GUARDAR_PREDICCION);
		guardarPrediccion.setEnabled(false);
		abrirPrediccion = new JMenuItem("Abrir Predicción");
		abrirPrediccion.setActionCommand(Comandos.ABRIR_PREDICCION);
		abrirPrediccion.setEnabled(false);
		quitarPrediccion = new JMenuItem("Quitar Predicción");
		quitarPrediccion.setActionCommand(Comandos.CERRAR_PREDICCION);
		quitarPrediccion.setEnabled(false);
		infoPrediccion = new JMenuItem("Ver Información de Predicción");
		infoPrediccion.setActionCommand(Comandos.INFO_PREDICCION);
		infoPrediccion.setEnabled(false);
		abrirMedidas = new JMenuItem("Análisis de error");
		abrirMedidas.setActionCommand(Comandos.ABRIR_MEDICIONES);
		abrirMedidas.setEnabled(false);
		estimarLos = new JMenuItem("Verificar LOS");
		estimarLos.setActionCommand(Comandos.ESTIMAR_LOS);
		estimarLos.setEnabled(false);
		
		moduloAdaptacion = new JMenuItem("Adaptación de modelos");
		moduloAdaptacion.setActionCommand(Comandos.ABRIR_MODULO_ADAPTACION);
		moduloAdaptacion.setEnabled(false);

		menuPrediccion.add(estimarPrediccion);
		menuPrediccion.add(estimarLos);
		menuPrediccion.add(abrirPrediccion);
		menuPrediccion.add(guardarPrediccion);
		menuPrediccion.add(quitarPrediccion);
		menuPrediccion.add(infoPrediccion);
		menuPrediccion.addSeparator();
		menuPrediccion.add(abrirMedidas);
		menuPrediccion.add(moduloAdaptacion);

		this.add(menuPrediccion);

		//		MENU VER
		JMenu menuVer = new JMenu("Ver");

		verExplorador = new JCheckBoxMenuItem("Ver Explorador", false);
		verExplorador.setActionCommand(Comandos.VER_EXPLORADOR);
		verExplorador.setEnabled(false);
		verPotencia = new JRadioButtonMenuItem("Ver Potencia");
		verPotencia.setActionCommand(Comandos.VER_POTENCIA);
		verPotencia.setEnabled(false);
		verInterferencia = new JRadioButtonMenuItem("Ver Interferencia");
		verInterferencia.setActionCommand(Comandos.VER_INTERFERENCIA);
		verInterferencia.setEnabled(false);
		verCobertura = new JRadioButtonMenuItem("Ver Cobertura");
		verCobertura.setActionCommand(Comandos.VER_COBERTURA);
		verCobertura.setEnabled(false);
		JMenu subMenuVerPrediccion = new JMenu("Predicción");
		subMenuVerPrediccion.add(verPotencia);
		subMenuVerPrediccion.add(verInterferencia);
		subMenuVerPrediccion.add(verCobertura);
		ButtonGroup bg = new ButtonGroup();
		bg.add(verPotencia);
		bg.add(verInterferencia);
		bg.add(verCobertura);

		verAlturas = new JCheckBoxMenuItem("Ver Capa Alturas");
		verAlturas.setActionCommand(Comandos.VER_ALTURAS);
		verAlturas.setEnabled(false);
		verEdificios = new JCheckBoxMenuItem("Ver Capa Edificios");
		verEdificios.setActionCommand(Comandos.VER_EDIFICIOS);
		verEdificios.setEnabled(false);
		verManzanas = new JCheckBoxMenuItem("Ver Capa Manzanas");
		verManzanas.setActionCommand(Comandos.VER_MANZANAS);
		verManzanas.setEnabled(false);
		verPredicciones = new JCheckBoxMenuItem("Ver Capa Predicciones");
		verPredicciones.setActionCommand(Comandos.VER_PREDICCIONES);
		verPredicciones.setEnabled(false);
		JMenu subMenuVerCapas = new JMenu("Capas");
		subMenuVerCapas.add(verAlturas);
		subMenuVerCapas.add(verEdificios);
		subMenuVerCapas.add(verManzanas);
		subMenuVerCapas.add(verPredicciones);

		menuVer.add(verExplorador);
		menuVer.add(subMenuVerPrediccion);
		menuVer.add(subMenuVerCapas);
		this.add(menuVer);

		//MENU AYUDA
		JMenu menuAyuda = new JMenu("Ayuda");

		acercaDe = new JMenuItem("Acerca de ...");
		acercaDe.setActionCommand(Comandos.ACERCA_DE);
		menuAyuda.add(acercaDe);
		verDocu = new JMenuItem("Ver documentacion ...");
		verDocu.setActionCommand(Comandos.DOCUMENTACION);
		menuAyuda.add(verDocu);
		verManual = new JMenuItem("Ver Manual ...");
		verManual.setActionCommand(Comandos.MANUAL);
		menuAyuda.add(verManual);
		this.add(menuAyuda);

		//agregamos los listeners a los items
		nuevoProy.addActionListener(aL);
		abrirProy.addActionListener(aL);
		abrirManzanas.addActionListener(aL);
		abrirEdificios.addActionListener(aL);
		abrirTerreno.addActionListener(aL);
		guardarProyecto.addActionListener(aL);
		cerrarProyecto.addActionListener(aL);
		salir.addActionListener(aL);
		crearModelo.addActionListener(aL);
		estimarPrediccion.addActionListener(aL);
		estimarLos.addActionListener(aL);
		guardarPrediccion.addActionListener(aL);
		quitarPrediccion.addActionListener(aL);
		abrirPrediccion.addActionListener(aL);
		infoPrediccion.addActionListener(aL);
		abrirMedidas.addActionListener(aL);
		moduloAdaptacion.addActionListener(aL);
		verExplorador.addActionListener(aL);
		verPotencia.addActionListener(aL);
		verInterferencia.addActionListener(aL);
		verCobertura.addActionListener(aL);
		verAlturas.addActionListener(aL);
		verEdificios.addActionListener(aL);
		verManzanas.addActionListener(aL);
		verPredicciones.addActionListener(aL);
		crearCanal.addActionListener(aL);
		crearTipoAntena.addActionListener(aL);
		cambiarPerfil.addActionListener(aL);
		editarProyecto.addActionListener(aL);
		acercaDe.addActionListener(aL);
		verDocu.addActionListener(aL);
		verManual.addActionListener(aL);
		generadorEdif.addActionListener(aL);

	}

	/**
	 * 
	 * Devuelve si está seleccionado verPotencia.
	 * 

	 *  
	 */

	public boolean verPotencia() {
		return this.verPotencia.isSelected();
	}

	/**
	 * 
	 * Devuelve si está seleccionado verInterferencia.
	 * 

	 *  
	 */

	public boolean verInterferencia() {
		return this.verInterferencia.isSelected();
	}

	/**
	 * 
	 * Devuelve si está seleccionado verCoberura.
	 * 

	 *  
	 */

	public boolean verCobertura() {
		return this.verCobertura.isSelected();
	}

	/**
	 * 
	 * Devuelve si está seleccionado ver la capa de alturas.
	 * 
	
	 *  
	 */

	public boolean verCapaAlturas() {
		return this.verAlturas.isSelected();
	}

	/**
	 * 
	 * Devuelve si está seleccionado ver la capa de edificios.
	 * 

	 *  
	 */

	public boolean verCapaEdificios() {
		return this.verEdificios.isSelected();
	}

	/**
	 * 
	 * Devuelve si está seleccionado ver la capa de manzanas.
	 * 

	 *  
	 */

	public boolean verCapaManzanas() {
		return this.verManzanas.isSelected();
	}

	/**
	 * 
	 * Devuelve si está seleccionado ver la capa de predicciones.
	 * 

	 *  
	 */

	public boolean verCapaPredicciones() {
		return this.verPredicciones.isSelected();
	}

	public boolean exploradorEsVisible() {
		return verExplorador.isSelected();
	}

	/**
	 * Pone los elementos del menu en el estado que corresponda segun haya o no
	 * un proyecto abierto
	 * 
	 * @param hay
	 */
	public void hayUnProyecto(boolean hay) {

		if (!hay) {
			this.hayUnaPrediccion(false);
		}
		if (!hay) {
			this.hayDatosAltura(hay);
			this.hayDatosManzanas(hay);
			this.hayDatosEdificios(hay);
		}

		abrirDatos.setEnabled(hay);
		abrirTerreno.setEnabled(hay);
		abrirManzanas.setEnabled(hay);
		abrirEdificios.setEnabled(hay);
		nuevoProy.setEnabled(!hay);
		abrirProy.setEnabled(!hay);
		guardarProyecto.setEnabled(hay);
		cerrarProyecto.setEnabled(hay);
		editarProyecto.setEnabled(hay);
		crearModelo.setEnabled(hay);
		estimarPrediccion.setEnabled(hay);
		estimarLos.setEnabled(hay);
		abrirPrediccion.setEnabled(hay);
		abrirMedidas.setEnabled(hay);
		moduloAdaptacion.setEnabled(hay);
		crearCanal.setEnabled(hay);
		crearTipoAntena.setEnabled(hay);
		verExplorador.setSelected(hay);
		verExplorador.setEnabled(hay);
		cambiarPerfil.setEnabled(hay);
		generadorEdif.setEnabled(hay);

	}

	/**
	 * Pone los elementos del menú en el estado que corresponda segun haya o no
	 * una predicción realizada.
	 */
	public void hayUnaPrediccion(boolean hay) {
		this.quitarPrediccion.setEnabled(hay);
		this.estimarPrediccion.setEnabled(!hay);
		this.estimarLos.setEnabled(!hay);
		this.abrirPrediccion.setEnabled(!hay);
		this.guardarPrediccion.setEnabled(hay);
		this.infoPrediccion.setEnabled(hay);
		this.verCobertura.setEnabled(hay);
		this.verPotencia.setEnabled(hay);
		this.verPotencia.setSelected(true);
		this.verInterferencia.setEnabled(hay);
		this.verPredicciones.setEnabled(hay);
		this.verPredicciones.setSelected(hay);
	}

	/**
	 * Pone los elementos del menú en el estado que corresponda segun haya o no
	 *datos de altura
	 */
	public void hayDatosAltura(boolean hay) {
		this.abrirTerreno.setEnabled(!hay);
		this.verAlturas.setEnabled(hay);
		this.verAlturas.setSelected(hay);
		this.crearSitio.setEnabled(hay);
	}

	/**
	 * Pone los elementos del menú en el estado que corresponda segun haya o no
	 *datos de edificios
	 */
	public void hayDatosEdificios(boolean hay) {
		this.abrirEdificios.setEnabled(!hay);
		this.verEdificios.setEnabled(hay);
		this.verEdificios.setSelected(hay);
	}

	/**
	 * Pone los elementos del menú en el estado que corresponda segun haya o no
	 *datos de manzanas
	 */
	public void hayDatosManzanas(boolean hay) {
		this.abrirManzanas.setEnabled(!hay);
		this.verManzanas.setEnabled(hay);
		this.verManzanas.setSelected(hay);
	}

}
