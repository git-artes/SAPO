
package sapo.ifusuario.menues;

/**
 *Esta excepción es lanzada al crear una radiobase, 
 *si el nombre es vacío o la altura no es un valor numérico.
 * 
 * @author Grupo de proyecto SAPO
 *  
 */

public class RadiobaseMalIngresadaException extends Exception {

	public RadiobaseMalIngresadaException(String mensaje) {
		super(mensaje);
	}

}
