package sapo.ifusuario.menues;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.Timer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.data.xy.XYSeriesCollection;

import sapo.archivos.Archivos;
import sapo.archivos.EscritorFeatures;
import sapo.archivos.LectorFeatures;
import sapo.ifusuario.Mapa;
import sapo.ifusuario.NuevoGraficador;
import sapo.predicciones.AnalisisModelo;
import sapo.predicciones.Modelo;
import sapo.predicciones.ModeloMalDefinidoException;
import sapo.predicciones.OkumuraHata;
import sapo.proyecto.ModeloRepetidoException;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase se utiliza como gui para el ajuste de medidas reales a curvas
 * conocidas.
 * 
 * @author Grupo de proyecto SAPO-TVDT
 */
public class VentanaModuloAdaptacion extends JDialog implements ActionListener,
		ListSelectionListener {

	JButton agregar;

	JButton calcular;

	JButton cerrar;

	JButton guardar;
	
	JButton guardarModelo;

	JButton graficar;

	JList listaDeAntenas;

	Proyecto proyecto;

	JLabel totalMedidas;

	JLabel sistCoord;

	JLabel datosParametrosAjustados;

	JProgressBar barraProgreso;

	AnalisisModelo am;

	Archivos archivo;

	Timer contador;

	Mapa mapa;

	JRadioButton WGS84Bot;

	JRadioButton SIRGAS2000Bot;

	ButtonGroup botonesCoord;

	JRadioButton okuBot;

	ButtonGroup botonesAprox;
	
	double[] parametros;
	
	VentanaCrearModelos ventanaOH;
	
	static Modelo OHAjustado;
	
	public VentanaModuloAdaptacion(JFrame duenio, Proyecto proyecto, Mapa mapa) {
		super(duenio, true);
		archivo = new Archivos();
		this.mapa = mapa;
		this.proyecto = proyecto;
		this.setTitle("Módulo de adaptación de modelos");
		ArrayList sitios = proyecto.sitios;
		ArrayList rbs, antenas;
		ArrayList nombreAntenas = new ArrayList();

		for (int i = 0; i < sitios.size(); i++) {
			rbs = ((Sitio) sitios.get(i)).radiobases;
			for (int j = 0; j < rbs.size(); j++) {
				antenas = ((Radiobase) rbs.get(j)).getAntenas();
				for (int k = 0; k < antenas.size(); k++) {
					Antena a = (Antena) antenas.get(k);
					nombreAntenas.add(a.getSitio() + "." + a.getRB() + "."
							+ a.getNombre());
				}
			}
		}
		listaDeAntenas = new JList(nombreAntenas.toArray());
		listaDeAntenas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listaDeAntenas.addListSelectionListener(this);

		// Se agrega elección de sistema de coordenadas
		this.sistCoord = new JLabel("Elija el sistema de coordenadas: ");
		this.botonesCoord = new ButtonGroup();
		this.WGS84Bot = new JRadioButton("WGS 84");
		this.SIRGAS2000Bot = new JRadioButton("SIRGAS 2000 / UTM 21S");
		this.botonesCoord.add(WGS84Bot);
		this.botonesCoord.add(SIRGAS2000Bot);
		this.WGS84Bot.setSelected(true);

		// Se agrega botón de elección de ajuste
		this.botonesAprox = new ButtonGroup();
		this.okuBot = new JRadioButton("Okumura-Hata");
		this.botonesAprox.add(okuBot);
		this.okuBot.setSelected(true);

		this.agregar = new JButton("Agregar Medidas");
		agregar.addActionListener(this);
		agregar.setEnabled(false);
		this.calcular = new JButton("Calcular");
		calcular.addActionListener(this);
		calcular.setEnabled(false);
		this.guardar = new JButton("Guardar Cálculos");
		guardar.addActionListener(this);
		guardar.setEnabled(false);
		this.guardarModelo = new JButton("Guardar Modelo");
		guardarModelo.addActionListener(this);
		guardarModelo.setEnabled(false);
		this.graficar = new JButton("Graficar");
		graficar.addActionListener(this);
		graficar.setEnabled(false);
		this.cerrar = new JButton("Cerrar");
		cerrar.addActionListener(this);
		this.totalMedidas = new JLabel("Total medidas: 0");
		this.datosParametrosAjustados = new JLabel(
				"<html><div align=left>A: -- <br> B: --</div></html>");
		this.barraProgreso = new JProgressBar(0, 100);
		this.barraProgreso.setStringPainted(true);

		// Hasta aca agrego todo lo que necesito, a continuación lo ordeno.

		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JScrollPane pa = new JScrollPane(listaDeAntenas);
		pa.setPreferredSize(new Dimension(300, 80));
		listaDeAntenas.setSize(new Dimension(290, 80));
		listaDeAntenas.setBackground(Color.WHITE);

		c.insets = new Insets(3, 3, 3, 3);
		c.gridy = 0;
		c.gridx = 0;
		c.gridheight = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(new JLabel("Elija la antena: "), c);

		c.gridy = 1;
		c.gridheight = 2;
		c.gridwidth = 2;
		c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.HORIZONTAL; // ****//
		this.getContentPane().add(pa, c);

		c.gridy = 3;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(
				new JLabel("Elija el sistema de coordenadas: "), c);

		c.gridy = 3;
		c.gridx = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(WGS84Bot, c);

		c.gridy = 4;
		c.gridx = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(SIRGAS2000Bot, c);

		c.gridy = 5;
		c.gridx = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(this.totalMedidas, c);

		c.gridy = 5;
		c.gridx = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_END;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(this.agregar, c);
		
		c.gridx = 0;
		c.gridy = 6;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(new JLabel("Aproximar por: "), c);

		c.gridy = 6;
		c.gridx = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(okuBot, c);

		JPanel panelAux = new JPanel(new GridBagLayout());
		GridBagConstraints c2 = new GridBagConstraints();
		c2.gridx = 0;
		c2.gridwidth = 1;
		c2.gridwidth = GridBagConstraints.RELATIVE;
		c2.anchor = GridBagConstraints.LINE_START;
		c2.fill = GridBagConstraints.HORIZONTAL;
		c2.weightx = 1;
		c2.insets = new Insets(3, 3, 3, 3);
		panelAux.add(this.barraProgreso, c2);

		c2.gridy = 0;
		c2.gridx = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.FIRST_LINE_END;
		c2.fill = GridBagConstraints.NONE;
		c2.weightx = 0;
		panelAux.add(this.calcular, c2);

		c2.gridy = 1;
		panelAux.add(this.graficar, c2);

		c2.gridx = 0;
		c2.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(this.datosParametrosAjustados, c);
		panelAux.add(this.datosParametrosAjustados, c2);

		c.gridy = 7;
		c.gridx = 0;
		c.gridwidth = 2;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.getContentPane().add(panelAux, c);

		panelAux = new JPanel();
		GridBagConstraints c3 = new GridBagConstraints();
		c3.insets = new Insets(3, 3, 3, 3);
		panelAux.add(this.guardar, c3);
		panelAux.add(this.guardarModelo, c3);
		panelAux.add(this.cerrar, c3);

		c.gridy = 9;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(panelAux, c);

		this.pack();
		this.setLocationRelativeTo(duenio);
		this.setVisible(true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Object fuente = arg0.getSource();
		try {
			if (fuente.equals(this.agregar)) {
				URL archivoAbierto = archivo.abrirArchivo("dat",
						"Archivo con datos (dat)").toURL();
				if (archivoAbierto != null) {
					this.listaDeAntenas.setEnabled(false);
					if (am == null) {
						String eleccion = (String) this.listaDeAntenas
								.getSelectedValue();
						String sitioElegido = eleccion.split("\\x2E")[0];
						String rbElegida = eleccion.split("\\x2E")[1];
						String antenaElegida = eleccion.split("\\x2E")[2];
						Antena antena = this.proyecto.getSitio(sitioElegido)
								.getRadiobase(rbElegida)
								.getAntena(antenaElegida);
						this.am = new AnalisisModelo(antena, this.proyecto);
					}
					LectorFeatures.agregarMedidas(am, archivoAbierto, WGS84Bot.isSelected());
					this.calcular.setEnabled(true);
					this.totalMedidas.setText("Total medidas: "
							+ am.cuantasMedidas());
				}
			} else if (fuente.equals(this.calcular)) {
				contador = new Timer(100, new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent evt) {
//						parametros = new double[2];
						try {
							parametros = am.ajusteModelo(mapa, false);
						} catch (IllegalAttributeException | SchemaException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						barraProgreso.setValue(100);
						if (am.termino()) {
							contador.stop();
							guardar.setEnabled(true);
							datosParametrosAjustados
									.setText("<html><div align=left><b>A: "
											+ parametros[0] + " <br> B: " + parametros[1]
											+ " </b></div></html>");
						}
					}
				});
				contador.start();
				this.graficar.setEnabled(true);
				this.guardarModelo.setEnabled(true);
			} else if (fuente.equals(this.guardar)) {
				File destino = this.archivo.guardarArchivo(
						"Ajuste_de_mediciones", "dat", "archivos con ajustes");
				EscritorFeatures.escribirAjuste(this.am, destino);
			} else if (fuente.equals(this.guardarModelo)) {
				double[] parametrosAjustables = new double[]{parametros[0], 0.0, 0.0, parametros[1]};
				ArrayList<Double> parametrosA = new ArrayList<Double>();
				ArrayList<Double> factoresCorrectivos = new ArrayList<Double>();
				for (int i = 0; i < 4; i++){
					parametrosA.add(0.0);
				}
				Object[] parametrosNoAj = new Object[] { new Double(0.0),
						new Integer(0), new Double(am.getAntena().getFrecuencia()), parametrosA,
						new Integer(2), factoresCorrectivos, new Boolean(false) };
				OHAjustado = new OkumuraHata(parametrosAjustables, parametrosNoAj);
				OHAjustado.setNombre("OH_Ajustado");
				JFrame crearModelo = new JFrame();
				ventanaOH = new VentanaCrearModelos(OHAjustado, crearModelo, new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent evt) {
						Object e = evt.getSource();
						if (e.equals(ventanaOH.aceptarDefinitivo)) {
							try {
								Modelo modeloNuevo = ventanaOH.crearModelo();
								proyecto.agregarModelo(modeloNuevo);
								ventanaOH.setVisible(false);
								ventanaOH.dispose();
							} catch (ModeloRepetidoException | ModeloMalDefinidoException e1) {
								JOptionPane.showMessageDialog(ventanaOH, e1.getMessage(),
										"Error", JOptionPane.WARNING_MESSAGE);
							} 
						} else if (e.equals(ventanaOH.cancelar)) {
							ventanaOH.setVisible(false);
							ventanaOH.dispose();
						}
					}
				});
				ventanaOH.setTitle("Nuevo modelo");
				ventanaOH.setVisible(true);
			} else if (fuente.equals(this.graficar)) {
				JDialog graficar = new JDialog(this, true);
				graficar.setSize(600, 400);
				graficar.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

				double[] perdidas = am.getPerdidas(); // eje y
				double[] distancias = am.getDistancias();
				double[] distanciasLog = new double[distancias.length]; // eje x

				for (int i = 0; i < distanciasLog.length; i++) {
					distanciasLog[i] = Math.log10(distancias[i]);
				}

				double[] paramAjuste = am.getParamAjuste();
				double[] ajuste = new double[distancias.length];

				for (int i = 0; i < distancias.length; i++) {
					ajuste[i] = paramAjuste[0] + paramAjuste[1]
							* distanciasLog[i];
				}

				NuevoGraficador ng = new NuevoGraficador("Ajuste de mediciones");
				XYSeriesCollection dataset = ng.getDataset("mediciones",
						"ajuste", distanciasLog, perdidas, distanciasLog,
						ajuste);
				JFreeChart grafica = ng.createChart("log(distancia)",
						"pérdida (dBm)", dataset, false, true, true, false);
				
				NumberAxis ejeY = (NumberAxis)(grafica.getXYPlot().getRangeAxis());
				ejeY.resizeRange(1.85);
				
				ChartPanel chartPanel = new ChartPanel(grafica);
				graficar.getContentPane().add(chartPanel);
				graficar.setLocationRelativeTo(this);
				graficar.setVisible(true);
			} else if (fuente.equals(this.cerrar)) {
				this.setVisible(false);
				this.dispose();
			}
		} catch (NullPointerException e) {

		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this,
					"Error: \n" + ex.getLocalizedMessage(), "Error",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event
	 * .ListSelectionEvent)
	 */
	@Override
	public void valueChanged(ListSelectionEvent e) {
		this.agregar.setEnabled(true);
	}
	
	public static Modelo getModelo(){
		return OHAjustado;
	}

}
