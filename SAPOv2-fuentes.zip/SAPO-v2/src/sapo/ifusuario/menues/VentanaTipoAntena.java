package sapo.ifusuario.menues;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.NumericShaper;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import sapo.ifusuario.FocusTraversalOnArray;

import sapo.principal.Comandos;
import sapo.red.TipoAntena;
import sapo.red.TipoAntenaMalDefinidoException;
import sapo.red.patronesEspeciales.PatronDipoloHorizontal;
import sapo.red.patronesEspeciales.PatronDipoloVertical;
import sapo.red.patronesEspeciales.PatronIsotropica;
import sapo.red.patronesEspeciales.PatronTNUHorizontal;
import sapo.red.patronesEspeciales.PatronTNUVertical;
import sapo.ifusuario.AppletPatron;

public class VentanaTipoAntena extends JDialog implements ActionListener {

	private JTextField nombre;
	private JPanel contentPane;
	private final ButtonGroup btngrpPatrones = new ButtonGroup();
	private GridBagLayout gblPanel;
	private GridBagConstraints gbcPanel;
	private GridBagLayout gblPanelBotones;
	private JToggleButton tglPatronIsotropica;
	private JToggleButton tglPatronDipolo;
	private JToggleButton tglPatronTNU;
	private JToggleButton tglPatronUsuario;
	private GridBagConstraints gbcTglPatron;
	private JPanel panelBotones;
	private JPanel panelTitulo;
	private JLabel labelTitulo;
	private JPanel panelDescripcion;
	private JLabel labelDescripcion;
	private AppletPatron appletPatronH;
	private AppletPatron appletPatronV;
	private JScrollPane scrollTablaV;
	private JScrollPane scrollTablaH;
	private JPanel panelAceptarCancelar;
	private JLabel imageLabel;
	private JLabel txtPatron;
	private ArrayList<Double> angulosH;
	private ArrayList<Double> gananciasH;
	private ArrayList<Double> angulosV;
	private ArrayList<Double> gananciasV;
	private JTable tablaPatronH;
	private JTable tablaPatronV;
	private DefaultTableModel modeloTablaH;
	private DefaultTableModel modeloTablaV;

	private String descDipolo = "<html><p>Dipolo de media longitud de onda.</p></html>";
	private String descIsotropica = "<html><p>Antena isotrópica. Ganancia 0 dB en todas las direcciones.</p></html>";
	private String descDirectiva = "<html><p>Antena creada o modificada por el usuario.</p></html>";
	private String descTNU = "<html><p align = 'center'>Diagrama de radiación de la antena utilizada por TNU para su transmisión de TVDT.<p align = 'center'>Kahtrein UHF ISDB-T Canal 30, código 75919516.</p></html>";

	private JButton aceptar;
	private JButton cancelar;
	private TipoAntena tipoAntena;
	private JButton aceptarDefinitivo = new JButton();
	private String patron = "";
	private JTextField txtPotencia;

	private TableModelListener listener;

	private final int anchoVentana = 780;
	private final int altoVentana = 600;

	/**
	 * Construye una ventana para crear o editar un nuevo tipo de antena
	 * existente
	 * 
	 * @throws TipoAntenaMalDefinidoException
	 * @throws PatronMalIngresadoException
	 * @throws NumberFormatException
	 */
	public VentanaTipoAntena(TipoAntena tipo, ActionListener a, JFrame duenio,
			Boolean editar) throws NumberFormatException,
			PatronMalIngresadoException, TipoAntenaMalDefinidoException {
		super(duenio, true);
		this.tipoAntena = tipo;
		this.setResizable(false);
		this.setTitle("Nuevo Tipo de Antena");
		this.setSize(new Dimension(anchoVentana, altoVentana));
		this.setLocationRelativeTo(duenio);
		agregarElementos(tipo);
		aceptarDefinitivo.addActionListener(a);

		if (editar) {
			nombre.setText(tipo.getNombre());
			patron = tipo.getPatronDeRadiacion();
			if (patron.equals(TipoAntena.DIPOLO)) {
				tglPatronDipolo.setSelected(true);
				labelTitulo.setText("<html><h1>" + TipoAntena.DIPOLO
						+ "</h1></html>");
				labelDescripcion.setText(descDipolo);
			} else if (patron.equals(TipoAntena.DIRECTIVA)) {
				tglPatronUsuario.setSelected(true);
				labelTitulo.setText("<html><h1>Definida por el usuario</h1></html>");
				labelDescripcion.setText(descDirectiva);
			} else if (patron.equals(TipoAntena.ISOTROPICA)) {
				tglPatronIsotropica.setSelected(true);
				labelTitulo.setText("<html><h1>Isotrópica</h1></html>");
				labelDescripcion.setText(descIsotropica);
			} else if (patron.equals(TipoAntena.TNU)) {
				tglPatronTNU.setSelected(true);
				labelTitulo.setText("<html><h1>" + TipoAntena.TNU + "</h1></html>");
				labelDescripcion.setText(descTNU);
			}

			Object[][] elementosH = elementosTabla(
					tipo.getPatronHorizontal().angulos,
					tipo.getPatronHorizontal().ganancias,
					tipo.getPatronHorizontal().ganancias.size());
			modeloTablaH = new DefaultTableModel(elementosH, new Object[] {
					"Ángulo", "Ganancia" });
			this.tablaPatronH.setModel(modeloTablaH);
			appletPatronH.ganancias = tipo.getPatronHorizontal().ganancias;
			appletPatronH.angulos = tipo.getPatronHorizontal().angulos;
			appletPatronH.repaint();

			Object[][] elementosV = elementosTabla(
					tipo.getPatronVertical().angulos,
					tipo.getPatronVertical().ganancias,
					tipo.getPatronVertical().ganancias.size());
			modeloTablaV = new DefaultTableModel(elementosV, new Object[] {
					"Ángulo", "Ganancia" });
			this.tablaPatronV.setModel(modeloTablaV);
			appletPatronV.ganancias = tipo.getPatronVertical().ganancias;
			appletPatronV.angulos = tipo.getPatronVertical().angulos;
			appletPatronV.repaint();

			aceptarDefinitivo
					.setActionCommand(Comandos.CONFIRMAR_EDITAR_TIPO_ANTENA);
			txtPotencia.setText(tipo.getGanancia() + "");
		} else {
			tglPatronIsotropica.setSelected(true);
			labelTitulo.setText("<html><h1>Isotrópica</html>");
			labelDescripcion.setText(descIsotropica);
			patron = TipoAntena.ISOTROPICA;
			String potencia = "0";
			txtPotencia.setText(potencia);
			tipoAntena = new TipoAntena("auxiliar", potencia, true,
					TipoAntena.ISOTROPICA, new PatronIsotropica(),
					new PatronIsotropica());
//			actualizarTablas();
			// TODO Agregar textos
		}
		// GM: Agrego actualizarTablas(), que es el que agrega al listener.
		actualizarTablas();
	}

	/**
	 * Agrega los elementos a la ventana.
	 */

	private void agregarElementos(TipoAntena tipo) {
		contentPane = new JPanel();
		gblPanel = new GridBagLayout();
		gbcPanel = new GridBagConstraints();
		contentPane.setLayout(gblPanel);
		setContentPane(contentPane);
		gbcPanel.insets = new Insets(0, 0, 0, 0);

		double alturaVentanaEfectiva = altoVentana - gbcPanel.insets.bottom
				- gbcPanel.insets.top;
		double anchoVentanaEfectivo = anchoVentana - gbcPanel.insets.bottom
				- gbcPanel.insets.top;
		gblPanel.rowHeights = new int[] {
				(int) Math.floor(alturaVentanaEfectiva * 0.06),
				(int) Math.floor(alturaVentanaEfectiva * 0.10),
				(int) Math.floor(alturaVentanaEfectiva * 0.36),
				(int) Math.floor(alturaVentanaEfectiva * 0.36),
				(int) Math.floor(alturaVentanaEfectiva * 0.06) };
		gblPanel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0 };
		gblPanel.columnWidths = new int[] {
				(int) Math.floor(anchoVentanaEfectivo * 0.2),
				(int) Math.floor(anchoVentanaEfectivo * 0.4),
				(int) Math.floor(anchoVentanaEfectivo * 0.4) };
		gblPanel.columnWeights = new double[] { 0.0, 0.0, 0.0 };

		aceptar = new JButton("Aceptar");
		aceptar.addActionListener(this);

		aceptarDefinitivo
				.setActionCommand(Comandos.CONFIRMAR_AGREGAR_TIPO_ANTENA);

		cancelar = new JButton("Cancelar");
		cancelar.addActionListener(this);

		nombre = new JTextField("Nuevo Tipo Antena");
		panelBotones = new JPanel();
		panelBotones.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null,
				null));

		gbcPanel.gridx = 0;
		gbcPanel.gridx = 0;
		gbcPanel.gridheight = 5;
		gbcPanel.gridwidth = 1;
		gbcPanel.anchor = GridBagConstraints.NORTH;
		gbcPanel.fill = GridBagConstraints.BOTH;
		gbcPanel.ipadx = 0;
		gbcPanel.ipady = 0;

		contentPane.add(panelBotones, gbcPanel);

		gblPanelBotones = new GridBagLayout();
		gblPanelBotones.columnWidths = new int[] { 150 };
		gblPanelBotones.rowHeights = new int[] { 25, 25, 25, 25, 25 };
		gblPanelBotones.columnWeights = new double[] { 0.0 };
		gblPanelBotones.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0 };
		panelBotones.setLayout(gblPanelBotones);

		tglPatronIsotropica = new JToggleButton("Isotrópica");
		nombre = new JTextField("Nombre de la Antena");

		tglPatronIsotropica.addActionListener(this);

		btngrpPatrones.add(tglPatronIsotropica);
		tglPatronIsotropica.setMnemonic('1');
		gbcTglPatron = new GridBagConstraints();
		gbcTglPatron.insets = new Insets(5, 5, 5, 5);
		gbcTglPatron.fill = GridBagConstraints.HORIZONTAL;
		gbcTglPatron.anchor = GridBagConstraints.NORTH;
		gbcTglPatron.gridx = 0;
		gbcTglPatron.gridy = 0;
		panelBotones.add(nombre, gbcTglPatron);
		gbcTglPatron.gridy = 1;
		panelBotones.add(tglPatronIsotropica, gbcTglPatron);

		tglPatronDipolo = new JToggleButton("Dipolo \u03BB/2");
		tglPatronDipolo.addActionListener(this);
		btngrpPatrones.add(tglPatronDipolo);
		gbcTglPatron.gridy = 2;
		panelBotones.add(tglPatronDipolo, gbcTglPatron);

		tglPatronUsuario = new JToggleButton("Customizada");
		tglPatronUsuario.addActionListener(this);
		btngrpPatrones.add(tglPatronUsuario);
		gbcTglPatron.gridy = 4;
		panelBotones.add(tglPatronUsuario, gbcTglPatron);
		panelBotones.setFocusTraversalPolicy(new FocusTraversalOnArray(
				new Component[] { tglPatronIsotropica }));

		tglPatronTNU = new JToggleButton("TNU");
		tglPatronTNU.addActionListener(this);
		btngrpPatrones.add(tglPatronTNU);
		gbcTglPatron.gridy = 3;
		panelBotones.add(tglPatronTNU, gbcTglPatron);
		panelBotones.setFocusTraversalPolicy(new FocusTraversalOnArray(
				new Component[] { tglPatronIsotropica }));

		gbcTglPatron.anchor = GridBagConstraints.SOUTH;
		gbcTglPatron.gridy = 5;
		JLabel potLabel = new JLabel("Ganancia (dBi)");

		panelBotones.add(potLabel, gbcTglPatron);
		gbcTglPatron.gridy = 6;
		txtPotencia = new JTextField("0");
		panelBotones.add(txtPotencia, gbcTglPatron);

		panelTitulo = new JPanel();
		labelTitulo = new JLabel();
		panelTitulo.add(labelTitulo);
		panelTitulo
				.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panelDescripcion = new JPanel();
		labelDescripcion = new JLabel();
		panelDescripcion.add(labelDescripcion);
		panelDescripcion.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null,
				null));
		angulosH = tipo.getPatronHorizontal().angulos;
		gananciasH = tipo.getPatronHorizontal().ganancias;
		angulosV = tipo.getPatronVertical().angulos;
		gananciasV = tipo.getPatronVertical().ganancias;

		appletPatronH = new AppletPatron(200, 200, angulosH, gananciasH, true);
		appletPatronH.init();

		appletPatronV = new AppletPatron(200, 200, angulosV, gananciasV, false);
		appletPatronV.init();

		Object[][] elementosH = elementosTabla(angulosH, gananciasH,
				gananciasH.size());
		modeloTablaH = new DefaultTableModel(elementosH, new Object[] {
				"Ángulo", "Ganancia" });

		listener = new TableModelListener() {
			@Override
			public void tableChanged(TableModelEvent arg0) {
				// tglPatronUsuario.doClick();
				patron = tipoAntena.DIRECTIVA;
				try {
					tipoAntena.setPatronDeRadiacion(patron);
				} catch (TipoAntenaMalDefinidoException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				DefaultTableModel modelo = (DefaultTableModel) arg0.getSource();
				double angulo;
				double anguloAux;
				double ganancia;
				double dob1;
				double dob2;
				Object obj1;
				Object obj2;
				boolean bool = true;
				int indice = arg0.getFirstRow();

				if (arg0.getColumn() == 0) {
					// No hago nada, la idea es que no modifiquen los ángulos.

//					obj1 = modelo.getValueAt(indice, 0);
//					obj2 = modelo.getValueAt(indice - 1, 0);
//					
//					dob1 = 0.0;
//					dob2 = 0.0;
//
//					try {
//						dob2 = (double) obj2;
//					} catch (NumberFormatException e) {
//						JOptionPane.showMessageDialog(contentPane, "El valor ingresado debe ser numérico.", "Error",
//								JOptionPane.ERROR_MESSAGE);
//						e.printStackTrace(System.out);
//					}
//					
////					if (obj2 instanceof Double)
////						dob2 = (double) obj2;
////					else
////						dob2 = (double) obj2;
//					
//					try {
//						dob1 = (double) obj1;
//					} catch (NumberFormatException e) {
//						JOptionPane.showMessageDialog(contentPane, "El valor ingresado debe ser numérico.", "Error",
//								JOptionPane.ERROR_MESSAGE);
//						e.printStackTrace(System.out);
//					}
//
////					if (obj1 instanceof Double) {
////						dob1 = (double) obj1;
////					} else {
////						// Es String
////						bool = esNumerico((String) obj1);
////						if (bool)
////							dob1 = Double.parseDouble((String) obj1);
////						else
////							dob1 = Double.MAX_VALUE;
////					}
//
//					if (!bool || dob1 != dob2 + 1) {
//						modelo.setValueAt(dob2 + 1, indice, 0);
//					}

				} else {
					obj1 = modelo.getValueAt(indice, 1);
					bool = esNumerico((String) obj1);
					
					ganancia = 0.0;
					try {
						ganancia = Double.parseDouble((String) obj1);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(contentPane, "El valor ingresado debe ser numérico.", "Error",
								JOptionPane.ERROR_MESSAGE);
						e.printStackTrace(System.out);
					}
					
					if(ganancia > 0.0){
						JOptionPane.showMessageDialog(contentPane, "La Ganancia está normalizada a 0 dBi.\nEl valor ingresado debe ser negativo.", "Error",
								JOptionPane.ERROR_MESSAGE);
						ganancia = 0.0;
					}
					
//					if (bool)
//						ganancia = Double.parseDouble((String) obj1);
//					else
//						ganancia = Double.MAX_VALUE;

					angulo = (double) modelo.getValueAt(indice, 0);

					if (modelo.equals(modeloTablaH)) {
						int indice2 = tipoAntena.getPatronHorizontal().angulos
								.indexOf(angulo);
						tipoAntena.getPatronHorizontal().ganancias.set(indice2,
								ganancia);
						appletPatronH.ganancias = tipoAntena
								.getPatronHorizontal().ganancias;
						appletPatronH.repaint();
					}
					if (modelo.equals(modeloTablaV)) {
						int indice2 = tipoAntena.getPatronVertical().angulos
								.indexOf(angulo);
						tipoAntena.getPatronVertical().ganancias.set(indice2,
								ganancia);
						appletPatronV.ganancias = tipoAntena
								.getPatronVertical().ganancias;
						appletPatronV.repaint();
					}
				}
				tglPatronUsuario.doClick();
			}
		};

		tablaPatronH = new JTable(modeloTablaH);

		Object[][] elementosV = elementosTabla(angulosV, gananciasV,
				gananciasV.size());
		modeloTablaV = new DefaultTableModel(elementosV, new Object[] {
				"Ángulo", "Ganancia" });

		tablaPatronV = new JTable(modeloTablaV);

		scrollTablaV = new JScrollPane(tablaPatronV);
		scrollTablaH = new JScrollPane(tablaPatronH);
		
//		scrollTablaV.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null,
//				null));
//		scrollTablaH.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null,
//				null));
		scrollTablaV.setBorder(BorderFactory.createTitledBorder (BorderFactory.createEtchedBorder (),
	              "Patrón vertical",
	              TitledBorder.CENTER,
	              TitledBorder.TOP));
		scrollTablaH.setBorder(BorderFactory.createTitledBorder (BorderFactory.createEtchedBorder (),
	              "Patrón horizontal",
	              TitledBorder.CENTER,
	              TitledBorder.TOP));
		
		panelAceptarCancelar = new JPanel();
		panelAceptarCancelar.add(aceptar, BorderLayout.CENTER);
		panelAceptarCancelar.add(cancelar, BorderLayout.CENTER);
		panelAceptarCancelar.setBorder(new EtchedBorder(EtchedBorder.LOWERED,
				null, null));

		gbcPanel.gridx = 1;
		gbcPanel.gridwidth = 2;
		gbcPanel.gridy = 0;
		gbcPanel.gridheight = 1;
		contentPane.add(panelTitulo, gbcPanel);

		gbcPanel.gridx = 1;
		gbcPanel.gridwidth = 2;
		gbcPanel.gridy = 1;
		gbcPanel.gridheight = 1;
		contentPane.add(panelDescripcion, gbcPanel);

		gbcPanel.gridx = 1;
		gbcPanel.gridwidth = 1;
		gbcPanel.gridy = 2;
		gbcPanel.gridheight = 1;
		contentPane.add(appletPatronH, gbcPanel);
		appletPatronH.setAltoApp(gblPanel.rowHeights[2]);
		appletPatronH.setAnchoApp(gblPanel.columnWidths[1]);

		gbcPanel.gridx = 2;
		contentPane.add(appletPatronV, gbcPanel);
		appletPatronV.setAltoApp(gblPanel.rowHeights[2]);
		appletPatronV.setAnchoApp(gblPanel.columnWidths[2]);

		gbcPanel.gridx = 1;
		gbcPanel.gridy = 3;
		contentPane.add(scrollTablaH, gbcPanel);

		gbcPanel.gridx = 2;
		gbcPanel.gridy = 3;
		contentPane.add(scrollTablaV, gbcPanel);

		gbcPanel.gridx = 1;
		gbcPanel.gridy = 4;
		gbcPanel.gridwidth = 2;
		contentPane.add(panelAceptarCancelar, gbcPanel);

		imageLabel = new JLabel("");
		imageLabel.setSize(200, 200);
		imageLabel.setAlignmentX(LEFT_ALIGNMENT);
		imageLabel.setAlignmentY(TOP_ALIGNMENT);

		txtPatron = new JLabel("");
		txtPatron.setSize(200, 200);
		txtPatron.setAlignmentX(RIGHT_ALIGNMENT);
		txtPatron.setAlignmentY(TOP_ALIGNMENT);
		txtPatron.setVerticalAlignment(SwingConstants.TOP);
		// GM: Saco esto que para mi no va.
		// this.tglPatronIsotropica.doClick();
	}

	/**
	 * Construye una ventana para crear o editar un nuevo tipo de antena
	 * existente
	 * 
	 * @throws TipoAntenaMalDefinidoException
	 * @throws PatronMalIngresadoException
	 * @throws NumberFormatException
	 */
	public VentanaTipoAntena(TipoAntena tipo, ActionListener a, JFrame duenio)
			throws NumberFormatException, PatronMalIngresadoException,
			TipoAntenaMalDefinidoException {
		this(tipo, a, duenio, true);
	}

	/**
	 * Construye una ventana para crear o editar un nuevo tipo de antena
	 * existente
	 * 
	 * @throws PatronMalIngresadoException
	 * @throws NumberFormatException
	 */
	public VentanaTipoAntena(ActionListener a, JFrame duenio)
			throws TipoAntenaMalDefinidoException, NumberFormatException,
			PatronMalIngresadoException {
		this(new TipoAntena("Nombre de Antena"), a, duenio, false);

	}

	private Image getScaledImage(Image srcImg, int w, int h) {
		BufferedImage resizedImg = new BufferedImage(w, h,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = resizedImg.createGraphics();
		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(srcImg, 0, 0, w, h, null);
		g2.dispose();
		return resizedImg;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String potencia;
		try {
			if (e.getSource().equals(tglPatronIsotropica)) {
				labelTitulo.setText("<html><h1>Isotrópica</html>");
				labelDescripcion.setText(descIsotropica);
				patron = TipoAntena.ISOTROPICA;
				potencia = "0";
				txtPotencia.setText(potencia);
				tipoAntena = new TipoAntena("auxiliar", potencia, true,
						TipoAntena.ISOTROPICA, new PatronIsotropica(),
						new PatronIsotropica());
				actualizarTablas();

			} else if (e.getSource().equals(tglPatronDipolo)) {
				labelTitulo.setText("<html><h1>" + TipoAntena.DIPOLO
						+ "</html>");
				labelDescripcion.setText(descDipolo);
				patron = TipoAntena.DIPOLO;
				potencia = "2.1";
				txtPotencia.setText(potencia);
				tipoAntena = new TipoAntena("auxiliar", potencia, false,
						TipoAntena.DIPOLO, new PatronDipoloHorizontal(),
						new PatronDipoloVertical());
				actualizarTablas();
			} else if (e.getSource().equals(tglPatronUsuario)) {
				labelTitulo.setText("<html><h1>Definida por usuario</html>");
				labelDescripcion.setText(descDirectiva);
				patron = TipoAntena.DIRECTIVA;
				// Object[] patronH = new Object[]{
				// tipoAntena.getPatronHorizontal().angulos,
				// tipoAntena.getPatronHorizontal().ganancias};
				// Object[] patronV = new Object[]{
				// tipoAntena.getPatronVertical().angulos,
				// tipoAntena.getPatronVertical().ganancias};
				// tipoAntena = new TipoAntena("auxiliar",
				// this.txtPotencia.getText(), true, patron,
				// new PatronRadiacion(patronH), new PatronRadiacion(patronV));
				actualizarTablas();

			} else if (e.getSource().equals(tglPatronTNU)) {
				labelTitulo.setText("<html><h1>" + TipoAntena.TNU + "</html>");
				labelDescripcion.setText(descTNU);
				patron = TipoAntena.TNU;
				potencia = "15.1";
				txtPotencia.setText(potencia);
				tipoAntena = new TipoAntena("auxiliar", potencia, true,
						TipoAntena.TNU, new PatronTNUHorizontal(),
						new PatronTNUVertical());
				actualizarTablas();
			} else if (e.getSource().equals(cancelar)) {
				this.setVisible(false);
				this.dispose();
			} else if (e.getSource().equals(aceptar)) {
				if (esNumerico(txtPotencia.getText())) {
					this.tipoAntena = this.crearTipoAntena(tipoAntena);
					aceptarDefinitivo.doClick();
				}
			}
			this.repaint();
			this.validate();
		} catch (Exception ex) {
			ex.printStackTrace(System.out);
			JOptionPane.showMessageDialog(this, ex.getMessage(), "Error",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	private void actualizarTablas() {
		Object[][] elementosH = elementosTabla(
				tipoAntena.getPatronHorizontal().angulos,
				tipoAntena.getPatronHorizontal().ganancias,
				tipoAntena.getPatronHorizontal().ganancias.size());
		modeloTablaH = new DefaultTableModel(elementosH, new Object[] {
				"Ángulo", "Ganancia" });
		modeloTablaH.addTableModelListener(listener);
		tablaPatronH.setModel(modeloTablaH);
		Object[][] elementosV = elementosTabla(
				tipoAntena.getPatronVertical().angulos,
				tipoAntena.getPatronVertical().ganancias,
				tipoAntena.getPatronVertical().ganancias.size());
		modeloTablaV = new DefaultTableModel(elementosV, new Object[] {
				"Ángulo", "Ganancia" });
		modeloTablaV.addTableModelListener(listener);
		tablaPatronV.setModel(modeloTablaV);
		appletPatronH.angulos = tipoAntena.getPatronHorizontal().angulos;
		appletPatronH.ganancias = tipoAntena.getPatronHorizontal().ganancias;
		appletPatronV.angulos = tipoAntena.getPatronVertical().angulos;
		appletPatronV.ganancias = tipoAntena.getPatronVertical().ganancias;
		appletPatronH.repaint();
		appletPatronV.repaint();
	}

	/**
	 * 
	 * Intenta crear un nuevo tipo de antena
	 * 
	 * @return
	 * @throws PatronMalIngresadoException
	 * @throws TipoAntenaMalDefinidoException
	 * 
	 */

	TipoAntena crearTipoAntena(TipoAntena tipo)
			throws PatronMalIngresadoException, TipoAntenaMalDefinidoException {
		tipo.setNombre(this.nombre.getText());
		tipo.setGanancia(Double.parseDouble(this.txtPotencia.getText()));
		return tipo;
	}

	public TipoAntena getTipoAntena() {
		return this.tipoAntena;
	}

	private boolean esNumerico(String s) {
		try {
			Double.parseDouble(s);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	private Object[][] elementosTabla(ArrayList angulos, ArrayList ganancias,
			int max) {

		Object[][] aux = new Object[2][max];
		aux[0] = angulos.toArray();
		aux[1] = ganancias.toArray();
		Object[][] aux2 = transponer(aux, max);
		return aux2;
	}

	private Object[][] transponer(Object[][] elementosVAux, int max) {
		int ancho = 2;
		int alto = max;
		Object[][] salida = new Object[max][2];
		for (int i = 0; i < ancho; i++) {
			for (int j = 0; j < alto; j++) {
				salida[j][i] = elementosVAux[i][j];
			}
		}
		return salida;
	}
}