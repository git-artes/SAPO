package sapo.ifusuario.menues;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;

import sapo.principal.Comandos;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase define la ventana para realizar las predicciones.
 * 
 * @author Grupo de proyecto SAPO
 */

public class VentanaPrediccion extends JDialog implements ActionListener, ItemListener {
	
	ArrayList antenasElegidas;
	ArrayList checks;
	JPanel panelAntenas;


	JTextField precision;


	JTextField radio;
	JCheckBox usarIterpolacion = new JCheckBox("Utilizar Interpolación");
	JButton aceptar = new JButton("Aceptar");
	JButton aceptarDefinitivo = new JButton();
	JButton cancelar = new JButton("Cancelar");
	JButton cancelarPrediccion = new JButton("Cancelar Predicción");
	JButton seleccionarTodas = new JButton("Seleccionar todas");
	JLabel antenaActual;
	JProgressBar barraDeProgreso;
	public boolean cancelo = false;
	
	/**
	 * Inicializa la ventana de predicción. Le asigna el actionListener especificado (que deberá tomar los 
	 * datos ingresados por el usuario) y los sitios disponibles para asignarlos en la lista.  
	 * 
	 * @param aL
	 * @param duenio
	 * @param sitios 
	 *  los sitios que obviamente incluyen las antenas. 
	 */
	public VentanaPrediccion(ActionListener aL, JFrame duenio, ArrayList sitios) {
		super(duenio, true);
		this.setTitle("Calculo Atenuacion");
		this.setSize(new Dimension(370, 350));
		
		//inicializacion
		this.checks = new ArrayList();
		this.antenasElegidas = new ArrayList();
		this.precision = new JTextField("");
		this.radio = new JTextField("");
		this.antenaActual = new JLabel("");
		this.barraDeProgreso = new JProgressBar(0, 100);
		this.barraDeProgreso.setStringPainted(true);
		ArrayList listaRB, listaAntenas;
		ArrayList listaAntenasAux = new ArrayList();
		if (!sitios.isEmpty()) {
			for (int i = 0; i < sitios.size(); i++) {
				listaRB = ((Sitio) sitios.get(i)).getRadiobases();
				for (int j = 0; j < listaRB.size(); j++) {
					listaAntenas = ((Radiobase) listaRB.get(j)).getAntenas();
					listaAntenasAux.addAll(listaAntenas);
				}
			}
		}
		
		Antena antenaAux;
		panelAntenas = new JPanel();
		int i = 4;
		if (listaAntenasAux.size() > i)
			i = listaAntenasAux.size();
		panelAntenas.setLayout(new GridLayout(i, 1));
		for (int j = 0; j < listaAntenasAux.size(); j++) {
			antenaAux = (Antena) listaAntenasAux.get(j);
			String nombreAntena = antenaAux.getSitio()
			+ "."
			+ antenaAux.getRB()
			+ "."
			+ antenaAux.getNombre();
			JCheckBox check = new JCheckBox(nombreAntena);
			check.setBackground(Color.WHITE);
			check.addItemListener(this);
			panelAntenas.add(check);
			checks.add(check);
			
			if(listaAntenasAux.size() == 1){
				check.setSelected(true); 
			}
		}
		
		//estado inicial
		aceptar.setEnabled(false);
		if(listaAntenasAux.size() == 1){
			aceptar.setEnabled(true); 
		}
		cancelarPrediccion.setEnabled(false);
		
		//listeners		
		aceptar.addActionListener(this);
		aceptarDefinitivo.addActionListener(aL);
		aceptarDefinitivo
		.setActionCommand(Comandos.CONFIRMAR_ESTIMAR_PREDICCION);
		cancelarPrediccion.addActionListener(this);
		cancelar.addActionListener(this);
		seleccionarTodas.addActionListener(this);
		
		//layout
		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(3, 3, 3, 3);
		
		JScrollPane pa = new JScrollPane(panelAntenas);
		pa.setPreferredSize(new Dimension(300, 80));
		panelAntenas.setSize(new Dimension(290, 80));
		panelAntenas.setBackground(Color.WHITE);
		
		c.gridy = 0;
		c.gridx = 0;
		c.gridheight = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(new JLabel("Elija la/s antena/s: "), c);
		
		c.gridy = 1;
		c.gridheight = 2;
		c.gridwidth = 2;
		c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.HORIZONTAL; //****//
		this.getContentPane().add(pa, c);
		
		c.gridy = 3;
		c.gridx = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.LINE_START;
		this.getContentPane().add(seleccionarTodas, c);
		
		c.gridy = 4;
		this.getContentPane().add(new JLabel(""), c);
		
		c.gridy = 5;
		
		c.gridx = 0;
		c.weightx = 0;
		c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.NONE; //****//
		this.getContentPane().add(new JLabel("Precisión (m): "), c);
		
		c.gridx = 1;
		c.weightx = 1;
		c.fill = GridBagConstraints.HORIZONTAL; //****//
		this.getContentPane().add(this.precision, c);
		
		c.gridy = 6;
		c.gridx = 0;
		c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(new JLabel("Radio Máximo (m): "), c);
		
		c.gridx = 1;
		c.weightx = 1;
		c.fill = GridBagConstraints.HORIZONTAL; //****//
		this.getContentPane().add(this.radio, c);
		
		c.gridx = 0;
		c.gridy = 7;
		this.getContentPane().add(this.usarIterpolacion, c);
		
		c.gridx = 0;
		c.gridy = 8;
		c.gridwidth = GridBagConstraints.REMAINDER;
		this.getContentPane().add(this.antenaActual, c);
		
		c.gridy = 9;
		barraDeProgreso.setPreferredSize(new Dimension(340, 20));
		c.gridwidth = 2;
		this.getContentPane().add(this.barraDeProgreso, c);
		
		c.gridwidth = GridBagConstraints.REMAINDER;
		this.getContentPane().add(new JLabel(""), c);
		
		JPanel panelBotones = new JPanel(new GridBagLayout());
		GridBagConstraints g = new GridBagConstraints();
		g.insets = new Insets(2, 2, 2, 2);
		panelBotones.add(aceptar, g);
		panelBotones.add(cancelarPrediccion, g);
		panelBotones.add(cancelar, g);
		c.gridy = 11;
		c.weightx = 1;
		c.fill = GridBagConstraints.NONE;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.anchor = GridBagConstraints.LAST_LINE_END;
		this.getContentPane().add(panelBotones, c);
		
		this.pack();
		this.setLocationRelativeTo(duenio);
	}
	
	public VentanaPrediccion(boolean los, ActionListener aL, JFrame duenio, ArrayList sitios) {
		this(aL, duenio, sitios);
		if (los){
			this.setTitle("Verificacion de LOS"); 
			aceptarDefinitivo
				.setActionCommand(Comandos.CONFIRMAR_ESTIMAR_LOS);
		}
	}
	
	
	
	
	/**
	 *
	 * Devuelve un ArrayList conteniendo los Strings simbolizando las antenas 
	 * seleccinonadas por el usuario. 
	 *  @return
	 * 
	 */
	
	public ArrayList getElegido() {
		return this.antenasElegidas;
	}
	
	/**
	 * Deja aceptar en estado habilitado. 
	 * @param e
	 */
	public void valueChanged(ListSelectionEvent e) {
		this.aceptar.setEnabled(true);
		
	}
	
	/**
	 * Devuelve el valor que ingresó el usuario para la precisión.  
	 * @return
	 * @uml.property  name="precision"
	 */
	
	public double getPrecision() {
		return Double.parseDouble(this.precision.getText());
	}
	
	/**
	 * Devuelve el valor que ingresó el usuario para el radio.  
	 * @return
	 * @uml.property  name="radio"
	 */
	
	public double getRadio() {
		return Double.parseDouble(this.radio.getText());
	}
	
	/**
	 *
	 *  Devuelve si el usuario eligió utilizar interpolación o no. 
	 *  @return
	 * 
	 */
	
	public boolean getUsarInterpolacion() {
		return this.usarIterpolacion.isSelected();
	}
	
	/**
	 * Le asigna el progreso especificado a la barra de progreso. 
	 * @param progreso
	 */
	public void setAvance(int progreso) {
		this.barraDeProgreso.setValue(progreso);
	}
	
	/**
	 * Le asigna el texto de status. 
	 * @param antena
	 */
	public void setAntenaActual(String antena) {
		this.antenaActual.setText("Procesando antena " + antena);
		this.pack();
	}
	
	
	
	/**
	 * Pone los componentes en los estados correspondientes a cuando esta realizando alguna predicción. 
	 * @param estado
	 */
	public void estaProcesando(boolean estado) {
		this.cancelarPrediccion.setEnabled(estado);
		this.aceptar.setEnabled(!estado);
		this.cancelar.setEnabled(!estado);
		this.precision.setEnabled(!estado);
		this.radio.setEnabled(!estado);
		this.usarIterpolacion.setEnabled(!estado);
		this.seleccionarTodas.setEnabled(!estado);
		this.panelAntenas.setEnabled(!estado);
	}
	
	/**
	 * Agrega o desagrega a la lista de antenas a realizarle el calculo de la atenuación la antena seleccinonada. 
	 * Si ésta queda vacía se pone en estado deshabilitado el botón de aceptar.   
	 */
	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			this.aceptar.setEnabled(true);
			antenasElegidas.add(((JCheckBox) e.getItemSelectable()).getText());
		} else if (e.getStateChange() == ItemEvent.DESELECTED) {
			antenasElegidas.remove(((JCheckBox) e.getItemSelectable())
					.getText());
			if (antenasElegidas.isEmpty()) {
				this.aceptar.setEnabled(false);
			}
		}
		
	}
	
	/**
	 * Realiza las acciones dependiendo de lo que se haya presionado. En caso que sea cancelarPrediccion, se pone 
	 * la bandera de cancelo en true. En caso que sea cancelar, se cierra esta ventana. En caso que sea seleccionarTodas, 
	 * se seleccionan todas las antenas. En caso que sea aceptar, primero se verifica que los datos ingresados sean 
	 * correctos y luego se hace un click por software a aceptarDefinitivo que estará escuchando aL.  
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(cancelarPrediccion)) {
			this.cancelo = true;
		} else if (e.getSource().equals(cancelar)) {
			this.setVisible(false);
			this.dispose();
		} else if (e.getSource().equals(seleccionarTodas)) {
			Iterator i = checks.iterator();
			while (i.hasNext()) {
				JCheckBox check = ((JCheckBox) i.next());
				check.setSelected(true);
			}
		} else if (e.getSource().equals(aceptar)) {
			try {
				this.getRadio();
				this.getPrecision();
				if (this.getRadio() <= 0 || this.getPrecision() <= 0) {
					JOptionPane.showMessageDialog(
							this,
							"Los valores deben ser ambos mayores que cero",
							"Error",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				this.aceptarDefinitivo.doClick();
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(
						this,
						"Los valores deben ser numéricos",
						"Error",
						JOptionPane.WARNING_MESSAGE);
			}
		}
	}
}