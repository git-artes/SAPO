package sapo.ifusuario.menues;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.Timer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYSeriesCollection;

import sapo.archivos.Archivos;
import sapo.archivos.EscritorFeatures;
import sapo.archivos.LectorFeatures;
import sapo.ifusuario.Mapa;
import sapo.ifusuario.NuevoGraficador;
import sapo.predicciones.AnalisisModelo;
import sapo.predicciones.PrediccionMalRealizadaException;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase se utiliza como gui para la comparación de medidas reales con las
 * predicciones de SAPO.
 * 
 * @author Grupo de proyecto SAPO
 */
public class VentanaAnalisisError extends JDialog implements ActionListener,
		ListSelectionListener {

	JButton agregar;

	JButton calcular;

	JButton cerrar;

	JButton guardar;

	JButton abrir;

	JButton graficar;

	JList listaDeAntenas;

	Proyecto proyecto;

	JLabel totalMedidas;

	JLabel datosError;

	JProgressBar barraProgreso;

	AnalisisModelo am;

	Archivos archivo;

	Timer contador;

	Mapa mapa;

	JLabel sistCoord;

	JRadioButton WGS84Bot;

	JRadioButton SIRGAS2000Bot;

	ButtonGroup botonesCoord;

	public VentanaAnalisisError(JFrame duenio, Proyecto proyecto, Mapa mapa) {
		super(duenio, true);
		archivo = new Archivos();
		this.mapa = mapa;
		this.proyecto = proyecto;
		this.setTitle("Análisis de error");
		ArrayList sitios = proyecto.sitios;
		ArrayList rbs, antenas;
		ArrayList nombreAntenas = new ArrayList();

		for (int i = 0; i < sitios.size(); i++) {
			rbs = ((Sitio) sitios.get(i)).radiobases;
			for (int j = 0; j < rbs.size(); j++) {
				antenas = ((Radiobase) rbs.get(j)).getAntenas();
				for (int k = 0; k < antenas.size(); k++) {
					Antena a = (Antena) antenas.get(k);
					nombreAntenas.add(a.getSitio() + "." + a.getRB() + "."
							+ a.getNombre());
				}
			}
		}
		listaDeAntenas = new JList(nombreAntenas.toArray());
		listaDeAntenas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listaDeAntenas.addListSelectionListener(this);

		this.sistCoord = new JLabel("Elija el sistema de coordenadas: ");
		this.botonesCoord = new ButtonGroup();
		this.WGS84Bot = new JRadioButton("WGS 84");
		this.SIRGAS2000Bot = new JRadioButton("SIRGAS 2000 / UTM 21S");
		this.botonesCoord.add(WGS84Bot);
		this.botonesCoord.add(SIRGAS2000Bot);
		this.WGS84Bot.setSelected(true);

		this.agregar = new JButton("Agregar Medidas");
		agregar.addActionListener(this);
		agregar.setEnabled(false);
		this.calcular = new JButton("Calcular");
		calcular.addActionListener(this);
		calcular.setEnabled(false);
		this.guardar = new JButton("Guardar Cálculos");
		guardar.addActionListener(this);
		guardar.setEnabled(false);
		this.abrir = new JButton("Abrir Cálculos");
		abrir.addActionListener(this);
		abrir.setEnabled(false);
		this.graficar = new JButton("Graficar");
		graficar.addActionListener(this);
		graficar.setEnabled(false);
		this.cerrar = new JButton("Cerrar");
		cerrar.addActionListener(this);
		this.totalMedidas = new JLabel("Total medidas: 0");
		this.datosError = new JLabel(
				"<html><div align=center>Error Medio: -- <br> Varianza Error: --</div></html>");
		this.barraProgreso = new JProgressBar(0, 100);
		this.barraProgreso.setStringPainted(true);

		this.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JScrollPane pa = new JScrollPane(listaDeAntenas);
		pa.setPreferredSize(new Dimension(300, 80));
		listaDeAntenas.setSize(new Dimension(290, 80));
		listaDeAntenas.setBackground(Color.WHITE);

		// c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(3, 3, 3, 3);
		;
		c.gridy = 0;
		c.gridx = 0;
		c.gridheight = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(new JLabel("Elija la antena: "), c);

		c.gridy = 1;
		c.gridheight = 2;
		c.gridwidth = 2;
		c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.HORIZONTAL; // ****//
		this.getContentPane().add(pa, c);

		c.gridy = 3;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(
				new JLabel("Elija el sistema de coordenadas: "), c);

		c.gridy = 3;
		c.gridx = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(WGS84Bot, c);

		c.gridy = 4;
		c.gridx = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(SIRGAS2000Bot, c);

		c.gridy = 5;
		c.gridx = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(this.totalMedidas, c);

		c.gridy = 5;
		c.gridx = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.anchor = GridBagConstraints.FIRST_LINE_END;
		c.fill = GridBagConstraints.NONE;
		this.getContentPane().add(this.agregar, c);

		JPanel panelAux = new JPanel(new GridBagLayout());
		GridBagConstraints c2 = new GridBagConstraints();
		c2.gridx = 0;
		c2.gridwidth = 1;
		c2.gridwidth = GridBagConstraints.RELATIVE;
		c2.anchor = GridBagConstraints.LINE_START;
		c2.fill = GridBagConstraints.HORIZONTAL;
		c2.weightx = 1;
		c2.insets = new Insets(3, 3, 3, 3);
		panelAux.add(this.barraProgreso, c2);

		c2.gridy = 0;
		c2.gridx = 1;
		c2.gridwidth = 1;
		c2.anchor = GridBagConstraints.FIRST_LINE_END;
		c2.fill = GridBagConstraints.NONE;
		c2.weightx = 0;
		panelAux.add(this.calcular, c2);

		c2.gridy = 1;
		panelAux.add(this.graficar, c2);

		c2.gridx = 0;
		c2.anchor = GridBagConstraints.FIRST_LINE_START;
		this.getContentPane().add(this.datosError, c);
		panelAux.add(this.datosError, c2);

		c.gridy = 6;
		c.gridx = 0;
		c.gridwidth = 2;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.getContentPane().add(panelAux, c);

		c.gridy = 8;
		c.gridx = 0;
		c.gridheight = 2;
		// c.gridwidth = 2;
		c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.HORIZONTAL;
		// this.getContentPane().add(this.datosError, c);

		panelAux = new JPanel();
		GridBagConstraints c3 = new GridBagConstraints();
		c3.insets = new Insets(3, 3, 3, 3);
		panelAux.add(this.abrir, c3);
		panelAux.add(this.guardar, c3);

		panelAux.add(this.cerrar, c3);

		c.gridy = 7;
		this.getContentPane().add(new JLabel(""), c);
		c.gridy = 8;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.getContentPane().add(panelAux, c);

		this.pack();
		this.setLocationRelativeTo(duenio);
		this.setVisible(true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Object fuente = arg0.getSource();
		try {
			if (fuente.equals(this.agregar)) {
				URL archivoAbierto = archivo.abrirArchivo("dat",
						"Archivo con datos (dat)").toURL();
				if (archivoAbierto != null) {
					this.listaDeAntenas.setEnabled(false);
					if (am == null) {
						String eleccion = (String) this.listaDeAntenas
								.getSelectedValue();
						String sitioElegido = eleccion.split("\\x2E")[0]; // 2E
																			// es
																			// el
																			// ASCII
																			// del
																			// punto
						String rbElegida = eleccion.split("\\x2E")[1]; // 2E es
																		// el
																		// ASCII
																		// del
																		// punto
						String antenaElegida = eleccion.split("\\x2E")[2]; // 2E
																			// es
																			// el
																			// ASCII
																			// del
																			// punto
						Antena antena = this.proyecto.getSitio(sitioElegido)
								.getRadiobase(rbElegida)
								.getAntena(antenaElegida);
						this.am = new AnalisisModelo(antena, this.proyecto);
					}
					boolean wgs = false;
					if (WGS84Bot.isSelected()) {
						wgs = true;
					}
					LectorFeatures.agregarMedidas(am, archivoAbierto, wgs);
					this.calcular.setEnabled(true);
					this.graficar.setEnabled(true);
					this.abrir.setEnabled(true);
					this.totalMedidas.setText("Total medidas: "
							+ am.cuantasMedidas());
				}
			} else if (fuente.equals(this.calcular)) {
				am.hacerPredicciones(mapa, false);
				contador = new Timer(100, new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent evt) {
						barraProgreso.setValue(am.cuantoVa());
						if (am.termino()) {
							contador.stop();
							guardar.setEnabled(true);
							try {
								datosError
										.setText("<html><div align=left><b>Error Medio: "
												+ ((int) (am.mediaError() * 100))
												/ 100.0
												+ " <br> Varianza Error: "
												+ ((int) (am.desviacionError() * 100))
												/ 100.0 + " </b></div></html>");
							} catch (PrediccionMalRealizadaException ex) {
								JOptionPane.showMessageDialog(listaDeAntenas,
										"Error: \n" + ex.getLocalizedMessage(),
										"Error", JOptionPane.WARNING_MESSAGE);
							}
						}
					}
				});
				contador.start();
				this.abrir.setEnabled(false);
			} else if (fuente.equals(this.guardar)) {
				File destino = this.archivo.guardarArchivo(this.am.getModelo()
						+ "_prediccion_" + this.archivo.getUltimoNombre(),
						"dat", "archivos con predicciones");
				EscritorFeatures.escribirPredicciones(this.am, destino);
			} else if (fuente.equals(this.abrir)) {
				URL archivoAbierto = archivo.abrirArchivo("dat",
						"Archivo con datos (dat)").toURL();
				if (archivoAbierto != null) {
					LectorFeatures.agregarPredicciones(am, archivoAbierto);
					datosError
							.setText("<html><div align=center><b>Error Medio: "
									+ ((int) (am.mediaError() * 100)) / 100.0
									+ " <br> Varianza Error: "
									+ ((int) (am.desviacionError() * 100))
									/ 100.0 + " </b></div></html>");
					this.calcular.setEnabled(false);
				}
			} else if (fuente.equals(this.graficar)) {
				JDialog graficar = new JDialog(this, true);
				graficar.setSize(600, 400);
				graficar.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

				int contador = 0;
				double[] medidas = new double[this.am.cuantasMedidas()];
				double[] xMedidas = new double[am.cuantasMedidas()];
				while (contador < medidas.length) {
					medidas[contador] = this.am.getPotencia(contador);
					xMedidas[contador] = contador + 1.0;
					contador++;
				}
				contador = 0;
				double[] predicciones = new double[this.am
						.cuantasPredicciones()];
				double[] xPredicciones = new double[this.am
						.cuantasPredicciones()];
				while (contador < predicciones.length) {
					predicciones[contador] = this.am.getPrediccion(contador);
					xPredicciones[contador] = contador + 1.0;
					contador++;
				}
				
				//TODO: Ver de ordenar los puntos por distancia como hace VentanaModuloAdaptacion
//				double[] distancias = am.getDistancias(); // eje x

				NuevoGraficador ng = new NuevoGraficador("Análisis de error");
				XYSeriesCollection dataset = ng.getDataset("predicciones",
						"medidas", xPredicciones, predicciones, xMedidas,
						medidas);
				JFreeChart grafica = ng.createChart("número de medida",
						"potencia (dBm)", dataset, true, true, true, true);
				
				NumberAxis ejeX = (NumberAxis)(grafica.getXYPlot().getDomainAxis());
				ejeX.setTickUnit(new NumberTickUnit(1.0));

				TextTitle subtitulo = new TextTitle("Comparación entre medidas y predicciones");
				grafica.addSubtitle(subtitulo);

				ChartPanel chartPanel = new ChartPanel(grafica);
				graficar.getContentPane().add(chartPanel);
				graficar.setLocationRelativeTo(this);
				graficar.setVisible(true);
				
//				if (!(xPredicciones.length == 0))
//					gs.agregarDataLinea(xPredicciones, predicciones,
//							this.am.getModelo(), Color.RED);
			} else if (fuente.equals(this.cerrar)) {
				this.setVisible(false);
				this.dispose();
			}
		} catch (NullPointerException e) {

		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this,
					"Error: \n" + ex.getLocalizedMessage(), "Error",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event
	 * .ListSelectionEvent)
	 */
	@Override
	public void valueChanged(ListSelectionEvent e) {
		this.agregar.setEnabled(true);
	}

}
