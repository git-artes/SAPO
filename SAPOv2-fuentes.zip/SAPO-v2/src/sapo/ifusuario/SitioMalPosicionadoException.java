package sapo.ifusuario;

/**
 * 
 * Esta excepcion es lanzada al agregar un sitio al mapa, si 
 * las coordenadas del mismo estan fuera de los limites del mapa de alturas.
 * 
 * @author Grupo de proyecto SAPO
 *  
 */

public class SitioMalPosicionadoException extends Exception {

	public SitioMalPosicionadoException(String mensaje) {
		super(mensaje);
	}

}
