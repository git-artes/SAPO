package sapo.ifusuario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

import org.geotools.gui.swing.StyledMapPane;
import org.geotools.cs.CoordinateSystem;
import org.geotools.renderer.j2d.RenderedMapScale;
import org.geotools.resources.gui.Resources;
import org.geotools.units.Unit;

import com.jgoodies.looks.plastic.PlasticXPLookAndFeel;

/**
 * Esta clase constituye la base para la creación de un ContenedorMapa. 
 * Incluye lo relativo al zoom y a la barra de escala.
 * @author Grupo de proyecto SAPO
 */

public class ContenedorMapaGeneral extends StyledMapPane implements
		MouseListener {

	/**
	 * La barra que indica la escala del mapa
	 */
	RenderedMapScale barraEscala;

	/**
	 * Los popups que se despliegan al clickear sobre el mapa
	 */
	JPopupMenu popupMapa;

	/**
	 * Los popups que se despliegan al clickear sobre el mapa
	 */
	JPopupMenu popupOcultarLupa;

	/**
	 * La coordenada x del punto donde está el ratón
	 */
	private double x;

	/**
	 * La coordenada y del punto donde está el ratón
	 */
	private double y;

	/**
	 * Construye un ContenedorMapa vacío. Inicializa los popups.
	 * 
	 * @param eL -
	 *            quien escucha los eventos que s egeneran en el ContenedorMapa
	 */
	public ContenedorMapaGeneral(){

		this.setLayout(new BorderLayout());

		//listeners
		this.addMouseListener(this);

		this.setMagnifierBorder(new Color(200, 240, 120));
		this.setMagnifierGlass(Color.ORANGE);

		////// creo los popups

		popupMapa = new JPopupMenu();

		String[] ACTION_ID = {
		/* [0] Left */"Left",
		/* [1] Right */"Right",
		/* [2] Up */"Up",
		/* [3] Down */"Down",
		/* [4] ZoomIn */"ZoomIn",
		/* [5] ZoomOut */"ZoomOut",
		/* [6] ZoomMax */"ZoomMax",
		/* [7] Reset */"Reset",
		/* [8] RotateLeft */"RotateLeft",
		/* [9] RotateRight */"RotateRight" };

		String[] ACTION_ID_ES = {
		/* [0] Left */"Izquierda",
		/* [1] Right */"Derecha",
		/* [2] Up */"Arriba",
		/* [3] Down */"Abajo",
		/* [4] ZoomIn */"Acercar",
		/* [5] ZoomOut */"Alejar",
		/* [6] ZoomMax */"Máximo",
		/* [7] Reset */"Resetear",
		/* [8] RotateLeft */"Izquierda",
		/* [9] RotateRight */"Derecha" };

		final ActionMap actionMap = getActionMap();
		final Resources resources = Resources.getResources(getLocale());
		final JMenuItem itemLupa = new JMenuItem("Mostrar lupa");
		itemLupa.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(final ActionEvent event) {
				setMagnifierVisible(true);
			}
		});
		popupMapa.add(itemLupa);
		popupMapa.addSeparator();

		JMenu menu = new JMenu("Zoom");

		for (int i = 4; i < 7; i++) {
			final Action accion = actionMap.get(ACTION_ID[i]);
			if (accion != null && accion.getValue(Action.NAME) != null) {
				JMenuItem item = new JMenuItem(accion);
				item.setAccelerator((KeyStroke) accion
						.getValue(Action.ACCELERATOR_KEY));
				item.setText(ACTION_ID_ES[i]);
				menu.add(item);
			}
		}
		popupMapa.add(menu);

		menu = new JMenu("Mover");

		for (int i = 0; i < 4; i++) {
			final Action accion = actionMap.get(ACTION_ID[i]);
			if (accion != null && accion.getValue(Action.NAME) != null) {
				JMenuItem item = new JMenuItem(accion);
				item.setAccelerator((KeyStroke) accion
						.getValue(Action.ACCELERATOR_KEY));
				item.setText(ACTION_ID_ES[i]);
				menu.add(item);
			}
		}
		popupMapa.add(menu);

		menu = new JMenu("Rotar");

		for (int i = 8; i < 10; i++) {
			final Action accion = actionMap.get(ACTION_ID[i]);
			if (accion != null && accion.getValue(Action.NAME) != null) {
				JMenuItem item = new JMenuItem(accion);
				item.setAccelerator((KeyStroke) accion
						.getValue(Action.ACCELERATOR_KEY));
				item.setText(ACTION_ID_ES[i]);
				menu.add(item);
			}
		}
		popupMapa.add(menu);
		popupMapa.addSeparator();

		final Action accion = actionMap.get(ACTION_ID[7]);
		if (accion != null && accion.getValue(Action.NAME) != null) {
			JMenuItem item = new JMenuItem(accion);
			item.setAccelerator((KeyStroke) accion
					.getValue(Action.ACCELERATOR_KEY));
			item.setText(ACTION_ID_ES[7]);
			popupMapa.add(item);
		}

		//se crea el popup a aparecer cuando esta la lupa

		popupOcultarLupa = new JPopupMenu();
		JMenuItem item = new JMenuItem("Ocultar lupa");
		item.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(final ActionEvent event) {
				setMagnifierVisible(false);
			}
		});
		popupOcultarLupa.add(item);

		///////

		try {
			UIManager.setLookAndFeel(new PlasticXPLookAndFeel());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Agrega la barra de escala en metros
	 *  
	 */
	public void agregarBarraEscala() {
		barraEscala = new RenderedMapScale();
		barraEscala.setText("escala");
		//barraEscala.setForeground(Color.BLACK);
		barraEscala.setMaximumLength(160);
		barraEscala.setUnits(Unit.METRE);
		//
		CoordinateSystem coordsys = barraEscala.getCoordinateSystem();
//		System.out.println(coordsys);
		this.getRenderer().addLayer(barraEscala);
	}

	// METODOS PPALES PARA MANIPULAR CAPAS

	@Override
	public void mouseClicked(MouseEvent e) {
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
 */
	@Override
	public void mouseEntered(MouseEvent e) {
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
 */
	@Override
	public void mouseExited(MouseEvent e) {
	}
/*
 *  (non-Javadoc)
 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
 */
	@Override
	public void mousePressed(MouseEvent e) {
		if (e.isPopupTrigger()) {
			//if (!this.mapa.getCapaAlturas().esVacia()){
			mostrarPopup(e);
			//}else {}
		}
	}
	/*
	 *  (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */

	@Override
	public void mouseReleased(MouseEvent e) {
		if (e.isPopupTrigger()) {
			//if (!this.mapa.getCapaAlturas().esVacia()){
			mostrarPopup(e);
			//}else {}
		}
	}

	/**
	 * Mustra el popup para el zoom o para ocultar la lupa
	 */
	private void mostrarPopup(MouseEvent e) {
		if (!isMagnifierVisible()) {
			popupMapa.show(e.getComponent(), e.getX(), e.getY());
		} else {
			popupOcultarLupa.show(e.getComponent(), e.getX(), e.getY());
		}

	}
}
