package sapo.ifusuario;

import java.util.ArrayList;
import java.util.EventListener;

import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

import sapo.predicciones.Modelo;
import sapo.proyecto.Proyecto;
import sapo.red.CanalFrecuencias;
import sapo.red.Radiobase;
import sapo.red.Sitio;
import sapo.red.TipoAntena;

/**
 * Esta clase representa el panel que constituye el explorador, formado a su vez
 * por tres solapas de exploradores.
 * @author Grupo de proyecto SAPO
 */

public class TabsExplorador extends JTabbedPane {

	/**
	 * Índice del tab de sitios
	 */
	public static int TAB_SITIOS = -1;

	/**
	 * Índice del tab de tipos de antenas y canales
	 */
	public static int TAB_ANTENAS = 0;

	/**
	 * Índice del tab de modelos
	 */
	public static int TAB_MODELOS = 1;

	/**
	 * El explorador de sitios, radiobases y antenas
	 */
	ExploradorSitios exploradorSitios;

	/**
	 * El explorador de tipos de antena
	 */
	ExploradorAntenas exploradorAntenas;

	/**
	 * El explorador de canales
	 */
	ExploradorCanales exploradorCanales;

	/**
	 * El explorador de modelos
	 */
	ExploradorModelos exploradorModelos;

	/**
	 * El panel que contiene los exploradores de tipos de antenas y canales
	 */
	JSplitPane tabAntenas;

	/**
	 * construye un TabsExplorador con dos tabs vacios
	 * 
	 * @param eL 
	 *            Quien va a escuchar los eventos que ocurran en el explorador
	 */
	public TabsExplorador(EventListener eL) {
		super();

		exploradorSitios = new ExploradorSitios(eL);
		exploradorAntenas = new ExploradorAntenas(eL);
		exploradorCanales = new ExploradorCanales(eL);
		exploradorModelos = new ExploradorModelos(eL);

		tabAntenas = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				exploradorAntenas, exploradorCanales);
		tabAntenas.setDividerSize(2);
		tabAntenas.setDividerLocation(240);

		//this.addTab("sitios", exploradorSitios);
		this.addTab("antenas", tabAntenas);
		this.addTab("modelos", exploradorModelos);
	}

	/**
	 * construye un explorador a partir de un proyecto existente eL - Quien va a
	 * escuchar los eventos que ocurran en el explorador
	 * 
	 * @param proyecto 
	 *            el proyecto del cual se tomarán todos los datos para construir
	 *            los exploradores
	 */
	public TabsExplorador(EventListener eL, Proyecto proyecto) {
		this(eL);

		if (proyecto.getLinkCapaAlturas() != null) {
			this.agregarTabSitios();
		}

		//explorador sitios
		ArrayList sitios = proyecto.getSitios();
		for (int i = 0; i < sitios.size(); i++) {
			this.agregarSitio((Sitio) sitios.get(i));
		}

		//explorador antenas
		ArrayList antenas = proyecto.getTiposAntena();
		for (int i = 0; i < antenas.size(); i++) {
			this.agregarTipoAntena((((TipoAntena) antenas.get(i))).getNombre());
		}

		//explorador canales
		ArrayList canales = proyecto.getCanales();
		for (int i = 0; i < canales.size(); i++) {
			this
					.agregarCanal((((CanalFrecuencias) canales.get(i)))
							.getNombre());
		}

		//explorador modelos
		ArrayList modelos = proyecto.getModelos();
		for (int i = 0; i < modelos.size(); i++) {
			this.agregarModelo((((Modelo) modelos.get(i))).getNombre());
		}
	}

	/**
	 * Agrega el tab de sitios
	 */
	public void agregarTabSitios() {
		this.removeAll();
		this.addTab("sitios", exploradorSitios);
		this.addTab("antenas", tabAntenas);
		this.addTab("modelos", exploradorModelos);
		TabsExplorador.TAB_SITIOS = 0;
		TabsExplorador.TAB_ANTENAS = 1;
		TabsExplorador.TAB_MODELOS = 2;
	}

	/*
	 * public void agregarListener(EventListener a){
	 * exploradorSitios.agregarListener(a);
	 * exploradorAntenas.agregarListener(a);
	 * exploradorCanales.agregarListener(a);
	 * exploradorModelos.agregarListener(a); }
	 */

	//solapa sitios
	/**
	 * Agrega un sitio al explorador de sitios
	 * 
	 * @param sitio 
	 *            el sitio a agregar
	 */
	public void agregarSitio(Sitio sitio) {
		exploradorSitios.agregarSitio(sitio);
	}

	/**
	 * Borra el sitio seleccionado del explorador de sitios
	 *  
	 */
	public void borrarSitio() {
		exploradorSitios.borrarNodo();
	}

	/**
	 * Borra la radiobase seleccionada del explorador de sitios
	 *  
	 */
	public void borrarRB() {
		exploradorSitios.borrarNodo();
	}

	/**
	 * Borra la antena seleccionada del explorador de sitios
	 *  
	 */
	public void borrarAntena() {
		exploradorSitios.borrarNodo();
	}

	/**
	 * Renombra la antena seleccionada del explorador de sitios
	 * 
	 * @param nombre 
	 *            el nuevo nombre
	 */
	public void renombrarAntena(String nombre) {
		if (exploradorSitios.getNivelSeleccionado() == ExploradorSitios.NIVEL_ANTENAS) {
			exploradorSitios.renombrarNodo(nombre);
		}
	}

	/**
	 * Reemplaza un sitio del explorador de sitios
	 * 
	 * @param sitioNuevo 
	 *            el nuevo sitio
	 */
	public void editarSitio(Sitio sitioNuevo) {
		exploradorSitios.editarSitio(sitioNuevo);
	}

	/**
	 * Reemplaza una radiobase del explorador de sitios
	 * 
	 * @param rbNueva 
	 *            la nueva radiobase
	 */
	public void editarRB(Radiobase rbNueva) {
		exploradorSitios.editarRB(rbNueva);
	}

	/**
	 * Selecciona un sitio del explorador de sitios
	 * 
	 * @param nombreSitio 
	 *            el nombre del sitio a seleccionar
	 */
	public void seleccionarSitio(String nombreSitio) {
		exploradorSitios.seleccionarSitio(nombreSitio);
	}

	/**
	 * Devuelve, de acuerdo a que nodo se haya seleccionado, los nombres del
	 * sitio, la radiobse y la antena seleccionados en el explorador de sitios
	 * 
	 * @return el nombre del sitio, la radiobase y la antena. Alguno de ellos
	 *         puede ser null
	 */
	public String[] getSeleccionesSitio() {
		return exploradorSitios.getSelecciones();
	}

	/*
	 * public void seleccionar(DefaultMutableTreeNode nodo){
	 * exploradorSitios.seleccionar(nodo); }
	 */

	//solapa antenas
	/**
	 * Agrega un tipo de antena del explorador de antenas
	 * 
	 * @param nombre 
	 *            el nombre del tipo de antena
	 */
	public void agregarTipoAntena(String nombre) {
		exploradorAntenas.agregarNodo(exploradorAntenas.nodoRaiz, nombre);
	}

	/**
	 * Borra el tipo de antnea seleccionado del explorador de antenas
	 *  
	 */
	public void borrarTipoAntena() {
		exploradorAntenas.borrarNodo();
	}

	/**
	 * Renombra el tipo de antena seleccionado del explorador de antenas
	 * 
	 * @param nombre 
	 *            el nuevo nombre
	 */
	public void renombrarTipoAntena(String nombre) {
		exploradorAntenas.renombrarNodo(nombre);
	}

	/**
	 * Borra el canal seleccionado del explorador de canales
	 *  
	 */
	public void borrarCanal() {
		exploradorCanales.borrarNodo();
	}

	/**
	 * Agrega un canal al explorador de canales
	 * 
	 * @param nombre 
	 *            el nombre del nuevo canal
	 */
	public void agregarCanal(String nombre) {
		exploradorCanales.agregarNodo(exploradorCanales.nodoRaiz, nombre);
	}

	/**
	 * Renombra un canal del explorador de canales
	 * 
	 * @param nombre 
	 *            el nuevo nombre
	 */
	public void renombrarCanal(String nombre) {
		exploradorCanales.renombrarNodo(nombre);
	}

	/**
	 * Devuelve el nombre del tipo de antena seleccionado del explorador de
	 * antenas
	 * 
	 * @return el nombre del tipo de antena
	 */
	public String getTipoAntenaSeleccionado() {
		return exploradorAntenas.getSeleccion();
	}

	/**
	 * Devuelve el nombre del canal seleccionado del explorador de antenas
	 * 
	 * @return el nombre del canal
	 */
	public String getCanalSeleccionado() {
		return exploradorCanales.getSeleccion();
	}

	//solapa modelos
	/**
	 * Agrega un modelo al explorador de modelos
	 * 
	 * @param nombre 
	 *            el nombre del modelo
	 */
	public void agregarModelo(String nombre) {
		exploradorModelos.agregarNodo(exploradorModelos.nodoRaiz, nombre);
	}

	/**
	 * Borra un modelo al explorador de modelos
	 * 
	 * @param nombre 
	 *            el nombre del modelo a borrar
	 */
	public void borrarModelo() {
		exploradorModelos.borrarNodo();
	}

	/**
	 * Renombra un modelo al explorador de modelos
	 * 
	 * @param nombre 
	 *            el nuevo nombre
	 */
	public void renombrarModelo(String nombre) {
		exploradorModelos.renombrarNodo(nombre);
	}

	/**
	 * DEvuelve el modelo seleccionado del explorador de modelos
	 * 
	 * @return el nombre del modelo
	 */
	public String getModeloSeleccionado() {
		return exploradorModelos.getSeleccion();
	}

	/*
	 * 
	 * public String getSeleccion(){ Explorador exploradorSeleccionado =
	 * (Explorador)this.getSelectedComponent(); return
	 * exploradorSeleccionado.getSeleccion(); }
	 */

	/**
	 * Vacía los exploradores
	 */
	public void vaciar() {
		exploradorSitios.vaciar();
		exploradorAntenas.vaciar();
		exploradorCanales.vaciar();
		exploradorModelos.vaciar();
	}

	/*
	 * 
	 * public void borrarNodo() { Explorador exploradorSeleccionado =
	 * (Explorador)this.getSelectedComponent();
	 * exploradorSeleccionado.borrarNodo(); }
	 */

	/**
	 * Devuelve el nivel en el arbol de la seleccion
	 * 
	 * @return el índice del nivel de la seleccion
	 */
	public int getNivelSeleccionado() {
		Explorador exploradorSeleccionado = (Explorador) this
				.getSelectedComponent();
		return exploradorSeleccionado.getNivelSeleccionado();
	}

	/**
	 * Devuelve el tab seleccionado
	 * 
	 * @return el índice del tab seleccionado
	 */
	public int getTabSeleccionado() {
		return this.getSelectedIndex();
	}

}
