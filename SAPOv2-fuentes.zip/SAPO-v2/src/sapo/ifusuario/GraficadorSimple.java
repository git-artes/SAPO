package sapo.ifusuario;

import gov.noaa.pmel.sgt.LineAttribute;
import gov.noaa.pmel.sgt.LogAxis;
import gov.noaa.pmel.sgt.dm.PointCollection;
import gov.noaa.pmel.sgt.dm.SGTMetaData;
import gov.noaa.pmel.sgt.dm.SimpleLine;
import gov.noaa.pmel.sgt.dm.SimplePoint;
import gov.noaa.pmel.sgt.swing.JPlotLayout;

/**
 * Esta clase, basada en la biblioteca sgt, utiliza algunas clases de dicha biblioteca
 * y hace un front-end para su uso más simplificado. Sirve para realizar
 * graficas sencillas. El orden adecuado para el uso de los métodos es el
 * siguiente: <br>
 * <code>
 * GraficadorSimple gp = new GraficadorSimple("Titulo","SubTitulo","SubSubTitulo");<br>
 gp.setTituloX("medidaX","unidadesX");<br>
 gp.setTituloY("medidaY","unidadesY");<br>
 gp.setDataLinea(x,y); <br>
 * </code>
 * 
 * 
 * @author Grupo de proyecto SAPO
 */
public class GraficadorSimple {

	JPlotLayout layout;

	SGTMetaData xMetaData = new SGTMetaData("", "", false, false);

	SGTMetaData yMetaData = new SGTMetaData("", "", false, false);

	String titulo;

	String subTitulo;

	String subSubTitulo;

	public JPlotLayout getJPlotLayout() {
		this.layout.setBatch(false);
		return layout;
	}

	/**
	 * El constructor. Se le indica los títulos que deben mostrar en el gráfico.

	 */
	public GraficadorSimple(String titulo, String subTitulo, String subSubTitulo) {
		layout = new JPlotLayout(false, false, false, "Grafica", null, false);
		layout.setTitles(titulo, subTitulo, subSubTitulo);
		this.titulo = titulo;
		this.subTitulo = subTitulo;
		this.subSubTitulo = subSubTitulo;
	}

	/**
	 * Indica la leyenda que debe aparecer en el eje de las x, junto con sus
	 * unidades.

	 */
	public void setTituloX(String titulo, String unidades) {
		this.xMetaData = new SGTMetaData(titulo, unidades, false, false);
	}

	/**
	 * Indica la leyenda que debe aparecer en el eje de las y, junto con sus
	 * unidades.

	 */
	public void setTituloY(String titulo, String unidades) {
		this.yMetaData = new SGTMetaData(titulo, unidades, false, false);
	}
	
	public void setTituloXLog(String titulo) {
		this.xMetaData = new SGTMetaData();
		this.xMetaData.setName(titulo);
	}


	/**
	 * Se le indica los datos que debe graficar. No se hace ningún tipo de
	 * verificación en cuanto a tamaño de los arrays, etc. Eso es
	 * responsabilidad del usuario. Este método le indica al graficador que debe
	 * hacer un representación con una línea uniendo los sucesivos puntos.
	 * 

	 */
	public void agregarDataLinea(double[] x, double[] y, String descripcion,
			java.awt.Color color) {
		SimpleLine datos = new SimpleLine(x, y, "grafica");
		datos.setXMetaData(xMetaData);
		datos.setYMetaData(yMetaData);
		layout.setBatch(true);
		layout.addData(datos, new LineAttribute(LineAttribute.SOLID, color),
				descripcion);
	}

	/**
	 * Se le indica los datos que debe graficar. No se hace ningún tipo de
	 * verificación en cuanto a tamaño de los arrays, etc. Eso es
	 * responsabilidad del usuario. Este método le indica al graficador que debe
	 * hacer un representación con una cruz por cada punto.

	 */

	public void setDataPuntos(double[] x, double[] y) {
		PointCollection coleccionPuntos = new PointCollection(
				"Coleccion de puntos", x.length);
		for (int i = 0; i < x.length; i++) {
			SimplePoint sp = new SimplePoint();
			sp.setX(x[i]);
			sp.setY(y[i]);
			coleccionPuntos.add(sp);
		}
		coleccionPuntos.setXMetaData(xMetaData);
		coleccionPuntos.setYMetaData(yMetaData);
		this.layout = new JPlotLayout(false, true, false, false, "Grafica",
				null, false);
		this.layout.setTitles(this.titulo, this.subTitulo, this.subSubTitulo);
		layout.setBatch(true);
		layout.addData(coleccionPuntos, "Grafica");
	}
	
	public void setPuntosLineas(double[] x1, double[] y1, double[] y2, java.awt.Color color1, java.awt.Color color2, String descripcion) {
		PointCollection coleccionMediciones = new PointCollection(
				"Coleccion de puntos", x1.length);
		for (int i = 0; i < x1.length; i++) {
			SimplePoint sp = new SimplePoint();
			sp.setX(x1[i]);
			sp.setY(y1[i]);
			coleccionMediciones.add(sp);
		}
		coleccionMediciones.setXMetaData(xMetaData);
		coleccionMediciones.setYMetaData(yMetaData);
		
		LogAxis ejeX = new LogAxis("ejeX"); // ver como usar esto.

		this.layout = new JPlotLayout(false, true, false, false, "Grafica",
				null, false);
		
		this.layout.setTitles(this.titulo, this.subTitulo, this.subSubTitulo);
		layout.setBatch(true);
		layout.addData(coleccionMediciones, "Mediciones");
		
		PointCollection coleccionAjuste = new PointCollection(
				"Coleccion de puntos", x1.length);
		
		for (int i = 0; i < x1.length; i++) {
			SimplePoint sp = new SimplePoint();
			sp.setX(x1[i]);
			sp.setY(y2[i]);
			coleccionAjuste.add(sp);
		}
		coleccionAjuste.setXMetaData(xMetaData);
		coleccionAjuste.setYMetaData(yMetaData);
		
		layout.addData(coleccionAjuste, "Ajuste");
	
//		SimpleLine datos = new SimpleLine(x2, y2, "grafica");
//		datos.setXMetaData(xMetaData);
//		datos.setYMetaData(yMetaData);
//		layout.setBatch(true);
//		layout.addData(datos, new LineAttribute(LineAttribute.SOLID, color2),
//				descripcion);
		
		
	}
	

}
