package sapo.ifusuario;

import java.io.IOException;
import java.util.ArrayList;

import org.geotools.cs.CoordinateSystem;
import org.geotools.cs.CoordinateSystemFactory;
import org.geotools.cs.FactoryException;
import org.geotools.map.DefaultMapContext;
import org.geotools.pt.CoordinatePoint;
import org.geotools.util.UnsupportedImplementationException;
import org.opengis.referencing.crs.CoordinateReferenceSystem;

import sapo.capas.CapaRaster;
import sapo.capas.CapaVectorial;
import sapo.capas.ElementoCapa;
import sapo.capas.estilos.EstiloAlturas;
import sapo.capas.estilos.EstiloEdificios;
import sapo.capas.estilos.EstiloManzanas;
import sapo.capas.estilos.EstiloResultados;
import sapo.capas.estilos.EstiloSitios;
import sapo.proyecto.Proyecto;
import sapo.red.Sitio;

/**
 * Esta clase define la agrupación de capas (mapa).
 * @author Grupo de proyecto SAPO
 */

public class Mapa extends DefaultMapContext {

	/**
	 * La capa de alturas
	 */
	CapaRaster capaAlturas;

	/**
	 * El índice de la capa de alturas
	 */
	final static int INDICE_ALTURAS = 0;

	/**
	 * La capa de manzanas
	 */
	public CapaVectorial capaManzanas;

	/**
	 * El índice de la capa de manzanas
	 */
	final static int INDICE_MANZANAS = 2;

	/**
	 * La capa de edificios
	 */
	CapaVectorial capaEdificios;

	/**
	 * El índice de la capa de edificios
	 */
	final static int INDICE_EDIFICIOS = 3;

	/**
	 * La capa de resultados
	 */
	CapaRaster capaResultados;

	/**
	 * El índice de la capa de resultados
	 */
	final static int INDICE_RESULTADOS = 1;

	/**
	 * La capa de sitios
	 */
	CapaVectorial capaSitios;

	/**
	 * El índice de la capa de sitios
	 */
	final static int INDICE_SITIOS = 4;

	/**
	 * La capa de sitios seleccionados
	 */
	public CapaVectorial capaSitiosSeleccionados;

	/**
	 * El índice de la capa de sitios seleccionados
	 */
	final static int INDICE_SITIOS_SELECCIONADOS = 5;

	/**
	 * Indica si hay algún sitio seleccionado
	 */
	public boolean seleccionado;

	//double x, y, absx, absy;

	/**
	 * Cnstruye un mapa vacío
	 * @throws IOException 
	 */
	public Mapa() throws IOException {

		capaAlturas = new CapaRaster();
		capaAlturas.setStyle(new EstiloAlturas());
		capaManzanas = new CapaVectorial();
		capaManzanas.setStyle(new EstiloManzanas());
		capaEdificios = new CapaVectorial();
		capaEdificios.setStyle(new EstiloEdificios());
		capaSitios = new CapaVectorial();
		capaSitios.setStyle(new EstiloSitios());
		capaSitiosSeleccionados = new CapaVectorial();
		capaSitiosSeleccionados.setStyle(new EstiloSitios(true));
		capaResultados = new CapaRaster();
		capaResultados.setStyle(new EstiloResultados());
		seleccionado = false;

		agregarCapas();
		
	}

	/**
	 * Construye un Mapa a partir de un proyecto existente
	 * 
	 * @param proyecto 
	 *            el proyecto del cual tomar los sitios
	 * @throws Exception 
	 * @throws SitioMalPosicionadoException 
	 */
	public Mapa(Proyecto proyecto) throws SitioMalPosicionadoException, Exception {
		
		this();

		ArrayList sitios = proyecto.getSitios();
		for (int i = 0; i < sitios.size(); i++) {
			this.agregarSitio((Sitio) sitios.get(i));
		}
		capaSitios.setStyle(new EstiloSitios());
		capaSitiosSeleccionados.setStyle(new EstiloSitios(true));

	}

	/**
	 * Devuelve el sistema de coordenadas

	 */
	public CoordinateSystem getCoordinateSystem() throws FactoryException {
		CoordinateReferenceSystem crs = getCoordinateReferenceSystem();
		String wkt = "";
		try {
			wkt = crs.toWKT();
		} catch (UnsupportedImplementationException e) {
			e.printStackTrace(); 
			System.out.println("De todas formas se buscará encontrar el sistema de coordenadas de una manera alternativa. "); 
			wkt = crs.toString();
		}
		CoordinateSystem cs = CoordinateSystemFactory.getDefault()
				.createFromWKT(wkt);
		return cs;
	}

	/**
	 * Devuelve la capa de alturas

	 */
	public CapaRaster getCapaAlturas() {
		return capaAlturas;
	}

	/**
	 * Devuelve la capa de manzanas

	 */
	public CapaVectorial getCapaManzanas() {
		return capaManzanas;
	}

	/**
	 * Devuelve la capa de edificios

	 */
	public CapaVectorial getCapaEdificios() {
		return capaEdificios;
	}

	/**
	 * Devuelve la capa de sitios

	 */
	public CapaVectorial getCapaSitio() {
		return capaSitios;
	}

	/**
	 * Devuelve la capa de sitio seleccionado

	 */
	public CapaVectorial getCapaSitioElegido() {
		return capaSitiosSeleccionados;
	}

	/**
	 * Devuelve la capa de resultados

	 */
	public CapaRaster getCapaResultados() {
		return capaResultados;
	}

	/**
	 * Agrega las capas al mapa
	 *  
	 */
	private void agregarCapas() {
		addLayer(Mapa.INDICE_ALTURAS, capaAlturas);
		addLayer(Mapa.INDICE_RESULTADOS, capaResultados);
		addLayer(Mapa.INDICE_MANZANAS, capaManzanas);
		addLayer(Mapa.INDICE_EDIFICIOS, capaEdificios);
		//		addLayer(Mapa.INDICE_RESULTADOS, capaResultados);
		addLayer(Mapa.INDICE_SITIOS, capaSitios);
		addLayer(Mapa.INDICE_SITIOS_SELECCIONADOS, capaSitiosSeleccionados);
	}

	/**
	 * Selecciona un sitio en el mapa a partir de sus coordenadas
	 */
	public boolean seleccionarSitio(double x, double y) {
		//boolean seleccionado = false;
		seleccionado = false;
		capaSitiosSeleccionados.vaciar();

		//x = Math.round(x);
		//y = Math.round(y);
		Sitio sitioAux = new Sitio(x, y);

		try {

			//Si el sitio siendo seleccionado pertenece a la coleccion de
			// sitios
			//entonces lo agrego a la coleccion de sitios seleccionados

			if (capaSitios.contiene((ElementoCapa) sitioAux)) {
				capaSitiosSeleccionados.agregar((ElementoCapa) sitioAux);
				seleccionado = true;
			}
			capaSitiosSeleccionados.recargarEstilo();

		} catch (Exception z) {
			z.printStackTrace();
		}
		if (!capaSitiosSeleccionados.esVacia()) {
			seleccionado = true;
		} else {
			seleccionado = false;

		}
		capaSitios.recargarEstilo();
		return seleccionado;
	}

	/**
	 * Si hay algun sitio seleccionado, lo deselecciona
	 * 
	 * @return si quedo algun sitio seleccionado

	 */
	public boolean deseleccionarSitios(){
		seleccionado = true;
		try {

			//Borro los sitios anteriormente seleccionados de la colección

			capaSitiosSeleccionados.vaciar();
			capaSitiosSeleccionados.recargarEstilo();
			capaSitios.recargarEstilo();

		} catch (Exception z) {
			z.printStackTrace(System.out);
		}
		return seleccionado;
	}

	/**
	 * Agrega el sitio a la capa de sitios.
	 * 
	 * @param sitio 
	 *            el sitio a agregar
	 * @throws SitioMalPosicionadoException 
	 *             si el sitio está por fuera del mapa de alturas.
	 */
	public void agregarSitio(Sitio sitio) throws SitioMalPosicionadoException,
			Exception {
		if (!capaAlturas.getGridCoverage().getEnvelope().contains(
				new CoordinatePoint(sitio.getX(), sitio.getY()))) {
			throw new SitioMalPosicionadoException(
					"El sitio está por fuera del mapa de alturas. ");
		}
		try {
			capaSitios.agregar((ElementoCapa) sitio);
		} catch (Exception e) {
			e.printStackTrace();
		}
		capaSitios.recargarEstilo();

	}

	/**
	 * Borra un sitio de la capa de sitios
	 * 
	 * @param sitio 
	 *            sitio a borrar
	 */
	public void borrarSitio(Sitio sitio) {
		if (capaSitios.contiene((ElementoCapa) sitio)) {
			capaSitios.quitar((ElementoCapa) sitio);
			capaSitios.recargarEstilo();
		}
	}

	/**
	 * Reemplaza un sitio en la capa de sitios
	 * 
	 * @param sitioViejo 
	 *            el sitio a sustituir
	 * @param sitioNuevo 
	 *            el nuevo sitio
	 * @throws IOException 
	 */
	public void editarSitio(Sitio sitioViejo, Sitio sitioNuevo) throws IOException {
		if (capaSitios.contiene((ElementoCapa) sitioViejo)) {
			capaSitios.quitar((ElementoCapa) sitioViejo);
			capaSitios.agregar((ElementoCapa) sitioNuevo);
			capaSitios.recargarEstilo();
		}

	}

}
