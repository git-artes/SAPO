package sapo.ifusuario;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Document;

/**
 * Esta clase define la ventana de ayuda de SAPO.
 * @author Grupo de proyecto SAPO
 */

public class VentanaAyuda extends JDialog {


	public VentanaAyuda(JFrame duenio, String dir) throws MalformedURLException {
		super(duenio, true);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setSize(new Dimension(640, 480));
		this.setLocationRelativeTo(duenio);
		this.setLocation(this.getLocation().x + 30, this.getLocation().y + 30);
		this.setLayout(new GridLayout(1, 1));
		final JEditorPane jt = new JEditorPane();
		jt.setEditable(false);

		jt.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(final HyperlinkEvent e) {
				if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							// Save original
							Document doc = jt.getDocument();
							try {
								URL url = e.getURL();
								jt.setPage(url);
								//input.setText (url.toString());
							} catch (IOException io) {
								JOptionPane.showMessageDialog(
										VentanaAyuda.this, "Can't follow link",
										"Invalid Input",
										JOptionPane.ERROR_MESSAGE);
								jt.setDocument(doc);
							}
						}
					});
				}
			}
		});

		java.net.URL helpURL = new File(dir).toURL();
		if (helpURL != null) {
			try {
				jt.setPage(helpURL);
			} catch (IOException e) {
				System.err.println("Attempted to read a bad URL: " + helpURL);
			}
		} else {
			System.err.println("Couldn't find file: TextSampleDemoHelp.html");
		}

		JScrollPane editorScrollPane = new JScrollPane(jt);
		editorScrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		add(editorScrollPane);

	}

}
