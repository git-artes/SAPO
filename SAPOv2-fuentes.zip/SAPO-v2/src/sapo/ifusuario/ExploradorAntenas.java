package sapo.ifusuario;

import java.awt.event.ActionListener;
import java.util.EventListener;

import sapo.ifusuario.menues.Popup;
import sapo.principal.Comandos;

/**
 * Esta clase define el explorador que contiene los tipos de antenas.
 * @author Grupo de proyecto SAPO
 */

public class ExploradorAntenas extends Explorador {

	/**
	 * El nivel del nodo raíz
	 */
	public final static int NIVEL_RAIZ = 0;

	/**
	 * El nivel de los nodos que representan los tipos de antenas
	 */
	public final static int NIVEL_ANTENAS = 1;

	/**
	 * Construye un explorador para los tipos de antenas
	 * 
	 * @param eL 
	 *            Quien va a escuchar los eventos que ocurran en el explorador
	 */
	protected ExploradorAntenas(EventListener eL) {
		super(eL, "ANTENAS disponibles");
		popupNivel0 = new Popup((ActionListener) eL,
				new String[] { Comandos.AGREGAR_TIPO_ANTENA });
		popupNivel1 = new Popup((ActionListener) eL, new String[] {
				Comandos.EDITAR_TIPO_ANTENA, Comandos.BORRAR_TIPO_ANTENA });

	}

}
