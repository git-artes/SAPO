package sapo.raster;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.DataBuffer;
import java.awt.image.WritableRaster;

import javax.media.jai.RasterFactory;

import org.geotools.cs.CoordinateSystem;
import org.geotools.cs.GeographicCoordinateSystem;
import org.geotools.ct.MathTransform2D;
import org.geotools.feature.AttributeType;
import org.geotools.feature.AttributeTypeFactory;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureType;
import org.geotools.feature.FeatureTypeFactory;
import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.Envelope;
import org.opengis.referencing.operation.TransformException;

import sapo.capas.ElementoCapa;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LinearRing;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.geom.PrecisionModel;

/**
 * Esta clase sirve como base para la creación de datos del tipo raster.
 * @author Grupo de proyecto SAPO
 */
public class Grilla implements ElementoCapa {

	WritableRaster raster;

	public int ancho; //en cantidad de pixels

	public int alto; //en cantidad de pixels

	public double anchoReal; //ancho en coordenadas reales de la grilla

	public double altoReal; //alto en coordenadas reales de la grilla

	GridCoverage gc;

	/**
	 * La transformada de matriz a coordenadas reales
	 */
	MathTransform2D mtgAc;

	/**
	 * La transformada de coordenadas reales a matriz
	 */
	MathTransform2D mtcAg;

	Feature fGrilla;

	/**
	 * El máximo valor que toma la grilla (es responsabilidad del usuario o de
	 * los métodos que utilicen Grilla asignar este valor correctamente).
	 * 
	 */
	double max = -Double.MAX_VALUE;

	/**
	 * El mínimo valor que toma la grilla (es responsabilidad del usuario o de
	 * los métodos que utilicen Grilla asignar este valor correctamente).
	 * 
	 */
	double min = Double.MAX_VALUE;

	/**
	 * El constructor histórico. Genera algunos datos de altura. Utiliza la cs
	 * que se le pase.
	 * 
	 * @param cs
	 * @throws SchemaException
	 * @throws IllegalAttributeException
	 */
	//TODO borrarlo
	public Grilla(CoordinateSystem cs) throws IllegalAttributeException,
			SchemaException { //, double[] datos, int ancho, int largo) throws
							  // Exception{
		double[] datos = new double[] { 10, 10, 10, 12, 12, 14, 16, 18, 18, 10,
				10, 10, 12, 12, 14, 16, 18, 18, 10, 12, 14, 18, 20, 30, 30, 22,
				18, 25, 22, 22, 20, 20, 18, 15, 15, 15, 28, 28, 28, 28, 25, 25,
				25, 25, 28, 12, 10, 10, 10, 15, 15, 22, 20, 18, 30, 30, 30, 29,
				28, 28, 28, 27, 26, 10, 12, 14, 18, 20, 30, 30, 22, 18, };
		ancho = 18;
		alto = 4;
		raster = RasterFactory.createBandedRaster(DataBuffer.TYPE_FLOAT, ancho,
				alto, 1, null);
		raster.setSamples(0, 0, ancho, alto, 0, datos);
		Envelope contorno = new Envelope(new Rectangle2D.Float(2, 2,
				2 + ancho / 2, 2 + alto / 2));
		gc = new GridCoverage("", raster, cs, contorno, null, null, null, null,
				null);
		generarFeature();
		mtgAc = gc.getGridGeometry().getGridToCoordinateSystem2D();
		try {
			mtcAg = (MathTransform2D) (mtgAc.inverse());
		} catch (Exception e) {
			e.printStackTrace(System.out); //igual acá no va entrar.
		}

	}

	public Grilla() throws IllegalAttributeException, SchemaException {
		this(GeographicCoordinateSystem.WGS84);
	}

	/**
	 * Construye una Grilla a partir de los parametros especificados
	 * 

	 */
	public Grilla(String nombre, CoordinateSystem cs, WritableRaster raster,
			double xMin, double yMin, double pasoX, double pasoY)
			throws IllegalAttributeException, SchemaException {
		this.raster = raster;
		this.ancho = raster.getWidth();
		this.alto = raster.getHeight();
		this.anchoReal = ancho * pasoX;
		this.altoReal = alto * pasoY;
		Envelope contorno = new Envelope(new Rectangle2D.Double(xMin, yMin,
				anchoReal, altoReal));
		this.gc = new GridCoverage(nombre, raster, cs, contorno, null, null,
				null, null, null);
		mtgAc = gc.getGridGeometry().getGridToCoordinateSystem2D();
		try {
			mtcAg = (MathTransform2D) (mtgAc.inverse());
		} catch (Exception e) {
			e.printStackTrace(System.out); //igual acá no va entrar.
		}
		this.generarFeature();

	}

	/**
	 * Crea una nueva Grilla a partir de otra instancia. Los throws son
	 * innecesarios pues jamás se arrojan, al construirse la grilla a partir de
	 * una ya existente, pero por como se implementó, formalmente deben estar.
	 * 
	 * @param grilla
	 * @throws SchemaException
	 * @throws IllegalAttributeException
	 */
	public Grilla(Grilla grilla) throws IllegalAttributeException,
			SchemaException {
		this(grilla.getGridCoverage().getCoordinateSystem());
		double[] datos = new double[grilla.ancho * grilla.alto];
		datos = grilla.getRaster().getPixels(grilla.getRaster().getMinX(),
				grilla.getRaster().getMinY(), grilla.ancho, grilla.alto, datos);
		this.setDatos(grilla.getGridCoverage().getCoordinateSystem(), datos,
				grilla.alto, grilla.ancho, grilla.getGridCoverage()
						.getEnvelope());
	}


	public GridCoverage getGridCoverage() {
		return gc;
	}

	public WritableRaster getRaster() {
		return raster;
	}

	/**
	 * Genera la feature conteniendo el GridCoverage
	 * 
	 * @throws IllegalAttributeException
	 * @throws SchemaException
	 */
	private void generarFeature() throws IllegalAttributeException,
			SchemaException {
		PrecisionModel pm = new PrecisionModel();

		//se crea el rectangulo (poligono)
		Rectangle2D rect = gc.getEnvelope().toRectangle2D();
		Coordinate[] coord = new Coordinate[5];
		coord[0] = new Coordinate(rect.getMinX(), rect.getMinY());
		coord[1] = new Coordinate(rect.getMaxX(), rect.getMinY());
		coord[2] = new Coordinate(rect.getMaxX(), rect.getMaxY());
		coord[3] = new Coordinate(rect.getMinX(), rect.getMaxY());
		coord[4] = new Coordinate(rect.getMinX(), rect.getMinY());

		GeometryFactory fabricaGeometria = new GeometryFactory(pm);
		LinearRing ring = fabricaGeometria.createLinearRing(coord);
		Polygon bounds = fabricaGeometria.createPolygon(ring, null);

		//atributos
		AttributeType geom = AttributeTypeFactory.newAttributeType("geom",
				Polygon.class);
		AttributeType grid = AttributeTypeFactory.newAttributeType("grid",
				GridCoverage.class);

		FeatureType schema = null;
		AttributeType[] attTypes = { geom, grid };

		schema = FeatureTypeFactory.newFeatureType(attTypes, "Grilla");

		//se crea el feature, con el rectangulo y el gc
		fGrilla = schema.create(new Object[] { bounds, gc });

	}

	/**
	 * Pone los datos en un WritableRaster y a su vez luego pone éste en el
	 * GridCoverage. El WritableRaster generado es devuelto. Para el
	 * GridCoverage se utilizan valores por defecto muy simples. Si se quiere
	 * más control debe utilizarse el setGridCoverage(GridCoverage gc).
	 * 
	 * @param cs 
	 *            El sistema de coordenadas utilizado.
	 * @param datos 
	 *            Los datos para rellenar el writableRaster.
	 * @param largo 
	 *            El largo en pixels del writableRaster.
	 * @param ancho 
	 *            El ancho en pixels del writableRaster.
	 * @param contorno 
	 *            El rectángulo del mapa real donde irán los datos.
	 * @throws SchemaException
	 * @throws IllegalAttributeException
	 */

	public WritableRaster setDatos(CoordinateSystem cs, double[] datos,
			int alto, int ancho, Envelope contorno)
			throws IllegalAttributeException, SchemaException {
		this.alto = alto;
		this.ancho = ancho;
		this.altoReal = contorno.toRectangle2D().getHeight();
		this.anchoReal = contorno.toRectangle2D().getWidth();
		raster = RasterFactory.createBandedRaster(DataBuffer.TYPE_FLOAT, ancho,
				alto, 1, null);
		raster.setSamples(0, 0, ancho, alto, 0, datos);
		gc = new GridCoverage("", raster, cs, contorno, null, null, null, null,
				null);
		mtgAc = gc.getGridGeometry().getGridToCoordinateSystem2D();
		try {
			mtcAg = (MathTransform2D) (mtgAc.inverse());
		} catch (Exception e) {
			e.printStackTrace(System.out); //igual acá no va entrar.
		}
		this.generarFeature();
		return raster;
	}

	/**
	 * Cambia los valores de la grilla desde la posición (x,y) hasta (x+ancho,
	 * y+alto) por los valores en datos. No se verifica que el tamaño del array
	 * sea ancho*alto.
	 * 

	 */
	public void setDatos(double[] datos, int x, int y, int alto, int ancho)
			throws IllegalAttributeException, SchemaException {
		raster.setSamples(x, y, ancho, alto, 0, datos);
		CoordinateSystem cs = gc.getCoordinateSystem();
		Envelope contorno = gc.getEnvelope();
		gc = new GridCoverage("", raster, cs, contorno, null, null, null, null,
				null);
		this.generarFeature();
	}

	/**
	 * asigna un valor en la coordenada (en coordenadas reales) especificada.
	 * Debe ser usado cuando no se quieren cambiar varios puntos seguidos. En
	 * ese caso utilizar
	 * 
	 * @param dato
	 * @param coordX
	 * @param coordY
	 * @return verdadero si se realizó con éxito, falso en caso contrario.
	 */
	public boolean setDato(double dato, double coordX, double coordY) {
		try {
			Point2D puntoEnGrilla = mtcAg.transform(new Point2D.Double(coordX,
					coordY), null);
			this.setDatos(new double[] { dato }, Math.round(Math
					.round(puntoEnGrilla.getX())), Math.round(Math
					.round(puntoEnGrilla.getY())), 1, 1);
			return true;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return false;
		}
	}

	/**
	 * Cuando se deben cambiar varios valores seguidos, conviene utilizar este
	 * método seguido de cambiarCG().
	
	 */
	public void setDatosSinCambiarGC(double[] datos, int x, int y, int alto,
			int ancho) {
		raster.setSamples(x, y, ancho, alto, 0, datos);
	}

	/**
	 * Cuando se deben cambiar varios valores seguidos, conviene utilizar este
	 * método seguido de cambiarCG()
	 * 
	
	 */
	public boolean setDatoSinCambiarGC(double dato, double coordX, double coordY) {
		try {
			Point2D puntoEnGrilla = mtcAg.transform(new Point2D.Double(coordX,
					coordY), null);
			this.setDatos(new double[] { dato }, Math.round(Math
					.round(puntoEnGrilla.getX())), Math.round(Math
					.round(puntoEnGrilla.getY())), 1, 1);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Si se cambió el WritableRaster de esta grilla utilizando los métodos
	 * *SinCambiarGC(), para que funcione correctamente se debe ejecutar este
	 * método luego de finalizado todos los cambios.
	 *  
	 */
	public void cambiarCG() {
		try {
			CoordinateSystem cs = gc.getCoordinateSystem();
			Envelope contorno = gc.getEnvelope();
			gc = new GridCoverage("", raster, cs, contorno, null, null, null,
					null, null);
			this.generarFeature();
		} catch (IllegalAttributeException e) {
			e.printStackTrace();
		} catch (SchemaException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Devuelve el valor en la posición (x y) en coordenadas de la matriz
	 * (Cuidado que x son las columnas e y son las filas).
	 * 

	 */
	public double evaluarEn(int x, int y) {
		return this.raster.getSampleDouble(x, y, 0);
	}

	/**
	 * transforma el punto puntoCoordenadas en su correspondiente a la matriz y
	 * devuelve esas coordenadas en un array de enteros (la posición 0 es la i y
	 * la 1 es la j).

	 */
	public int[] puntoMatriz(Point2D.Double puntoCoordenadas) {
		try {
			Point2D puntoMatriz = mtcAg.transform(puntoCoordenadas, null);
			return new int[] { Math.round(Math.round(puntoMatriz.getY())),
					Math.round(Math.round(puntoMatriz.getX())) };
		} catch (TransformException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * transforma el punto puntoMatriz en coordenadas de la matriz en un punto
	 * en coordenadas reales.
	 * 
	 * @param puntoMatriz 
	 *            un array de int cuya posición 0 es la fila y la 1 es la
	 *            columna.

	 */
	public Point2D puntoReal(int[] puntoMatriz) {
		try {
			Point2D.Double punto = new Point2D.Double(puntoMatriz[1],
					puntoMatriz[0]);
			Point2D puntoReal = mtgAc.transform(punto, null);
			return puntoReal;
		} catch (TransformException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Devuelve en un feature el GridCoverage generado.
	 */
	public Feature getFeature() {
		return fGrilla;
	}

	/**
	 * Asigna el máximo de esta grilla.
	 * 


	 */
	public void setMax(double max) {
		this.max = max;
	}

	/**
	 * Asigna el mínimo de esta grilla.


	 */
	public void setMin(double min) {
		this.min = min;
	}

	/**
	 * Devuelve el máximo de la grilla. Este método hay que usarlo con
	 * precaución, pues no se asegura que lo que devuelva sea el verdadero
	 * máximo de la grilla.
	 * 


	 */
	public double getMax() {
		return this.max;
	}

	/**
	 * Devuelve el mínimo de la grilla. Este método hay que usarlo con
	 * precaución, pues no se asegura que lo que devuelva sea el verdadero
	 * mínimo de la grilla.
	 * 


	 */
	public double getMin() {
		return this.min;
	}
}
