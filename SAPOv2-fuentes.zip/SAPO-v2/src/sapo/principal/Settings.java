/**
 * Copyright (c) 2001-2005 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 * o Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer. 
 * 
 * o Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution. 
 * 
 * o Neither the name of JGoodies Karsten Lentzsch nor the names of 
 * its contributors may be used to endorse or promote products derived 
 * from this software without specific prior written permission. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package sapo.principal;

import javax.swing.LookAndFeel;

import com.jgoodies.looks.BorderStyle;
import com.jgoodies.looks.FontSizeHints;
import com.jgoodies.looks.HeaderStyle;
import com.jgoodies.looks.plastic.PlasticLookAndFeel;
import com.jgoodies.looks.plastic.PlasticTheme;
import com.jgoodies.looks.plastic.PlasticXPLookAndFeel;

/**
 * Describes most of the optional settings of the JGoodies Looks. Used by the
 * <code>DemoFrame</code> to configure the UI.
 * 
 * @author Karsten Lentzsch
 * @version $Revision: 1.7 $
 * @see com.jgoodies.looks.BorderStyle
 * @see com.jgoodies.looks.FontSizeHints
 * @see com.jgoodies.looks.HeaderStyle
 * @see com.jgoodies.looks.Options
 */
public final class Settings {

	private LookAndFeel selectedLookAndFeel;

	private PlasticTheme selectedTheme;

	private Boolean useSystemFonts;

	private FontSizeHints fontSizeHints;

	private boolean useNarrowButtons;

	private boolean tabIconsEnabled;

	private Boolean popupDropShadowEnabled;

	private String plasticTabStyle;

	private boolean plasticHighContrastFocusEnabled;

	private HeaderStyle menuBarHeaderStyle;

	private BorderStyle menuBarPlasticBorderStyle;

	private BorderStyle menuBarWindowsBorderStyle;

	private Boolean menuBar3DHint;


	private HeaderStyle toolBarHeaderStyle;


	private BorderStyle toolBarPlasticBorderStyle;


	private BorderStyle toolBarWindowsBorderStyle;


	private Boolean toolBar3DHint;

	// Instance Creation ******************************************************

	private Settings() {
		// Override default constructor; prevents instantiability.
	}

	public static Settings createDefault() {
		Settings settings = new Settings();
		settings.setSelectedLookAndFeel(new PlasticXPLookAndFeel());
		settings.setSelectedTheme(PlasticLookAndFeel.createMyDefaultTheme());
		settings.setUseSystemFonts(Boolean.TRUE);
		settings.setFontSizeHints(FontSizeHints.MIXED);
		settings.setUseNarrowButtons(false);
		settings.setTabIconsEnabled(true);
		settings.setPlasticTabStyle(PlasticLookAndFeel.TAB_STYLE_DEFAULT_VALUE);
		settings.setPlasticHighContrastFocusEnabled(false);
		settings.setMenuBarHeaderStyle(null);
		settings.setMenuBarPlasticBorderStyle(null);
		settings.setMenuBarWindowsBorderStyle(null);
		settings.setMenuBar3DHint(null);
		settings.setToolBarHeaderStyle(null);
		settings.setToolBarPlasticBorderStyle(null);
		settings.setToolBarWindowsBorderStyle(null);
		settings.setToolBar3DHint(null);
		return settings;
	}

	// Accessors **************************************************************

	/**
	 * @return Returns the fontSizeHints.

	 */
	public FontSizeHints getFontSizeHints() {
		return fontSizeHints;
	}

	/**
	 * @param fontSizeHints
	 *            The fontSizeHints to set.

	 */
	public void setFontSizeHints(FontSizeHints fontSizeHints) {
		this.fontSizeHints = fontSizeHints;
	}

	/**
	 * @return Returns the menuBar3DHint.

	 */
	public Boolean getMenuBar3DHint() {
		return menuBar3DHint;
	}

	/**
	 * @param menuBar3DHint
	 *            The menuBar3DHint to set.

	 */
	public void setMenuBar3DHint(Boolean menuBar3DHint) {
		this.menuBar3DHint = menuBar3DHint;
	}

	/**
	 * @return Returns the menuBarHeaderStyle.

	 */
	public HeaderStyle getMenuBarHeaderStyle() {
		return menuBarHeaderStyle;
	}

	/**
	 * @param menuBarHeaderStyle
	 *            The menuBarHeaderStyle to set.

	 */
	public void setMenuBarHeaderStyle(HeaderStyle menuBarHeaderStyle) {
		this.menuBarHeaderStyle = menuBarHeaderStyle;
	}

	/**
	 * @return Returns the menuBarPlasticBorderStyle.

	 */
	public BorderStyle getMenuBarPlasticBorderStyle() {
		return menuBarPlasticBorderStyle;
	}

	/**
	 * @param menuBarPlasticBorderStyle
	 *            The menuBarPlasticBorderStyle to set.

	 */
	public void setMenuBarPlasticBorderStyle(
			BorderStyle menuBarPlasticBorderStyle) {
		this.menuBarPlasticBorderStyle = menuBarPlasticBorderStyle;
	}

	/**
	 * @return Returns the menuBarWindowsBorderStyle.
	
	 */
	public BorderStyle getMenuBarWindowsBorderStyle() {
		return menuBarWindowsBorderStyle;
	}

	/**
	 * @param menuBarWindowsBorderStyle
	 *            The menuBarWindowsBorderStyle to set.

	 */
	public void setMenuBarWindowsBorderStyle(
			BorderStyle menuBarWindowsBorderStyle) {
		this.menuBarWindowsBorderStyle = menuBarWindowsBorderStyle;
	}

	public Boolean isPopupDropShadowEnabled() {
		return popupDropShadowEnabled;
	}

	/**
	 * @param popupDropShadowEnabled
	 *            The popupDropShadowEnabled to set.

	 */
	public void setPopupDropShadowEnabled(Boolean popupDropShadowEnabled) {
		this.popupDropShadowEnabled = popupDropShadowEnabled;
	}

	/**
	 * @return Returns the plasticHighContrastFocusEnabled.

	 */
	public boolean isPlasticHighContrastFocusEnabled() {
		return plasticHighContrastFocusEnabled;
	}

	/**
	 * @param plasticHighContrastFocusEnabled
	 *            The plasticHighContrastFocusEnabled to set.

	 */
	public void setPlasticHighContrastFocusEnabled(
			boolean plasticHighContrastFocusEnabled) {
		this.plasticHighContrastFocusEnabled = plasticHighContrastFocusEnabled;
	}

	/**
	 * @return Returns the plasticTabStyle.

	 */
	public String getPlasticTabStyle() {
		return plasticTabStyle;
	}

	/**
	 * @param plasticTabStyle
	 *            The plasticTabStyle to set.

	 */
	public void setPlasticTabStyle(String plasticTabStyle) {
		this.plasticTabStyle = plasticTabStyle;
	}

	/**
	 * @return Returns the selectedLookAndFeel.

	 */
	public LookAndFeel getSelectedLookAndFeel() {
		return selectedLookAndFeel;
	}

	/**
	 * @param selectedLookAndFeel
	 *            The selectedLookAndFeel to set.

	 */
	public void setSelectedLookAndFeel(LookAndFeel selectedLookAndFeel) {
		this.selectedLookAndFeel = selectedLookAndFeel;
	}

	/**
	 * @return Returns the selectedTheme.

	 */
	public PlasticTheme getSelectedTheme() {
		return selectedTheme;
	}

	/**
	 * @param selectedTheme
	 *            The selectedTheme to set.

	 */
	public void setSelectedTheme(PlasticTheme selectedTheme) {
		this.selectedTheme = selectedTheme;
	}

	/**
	 * @return Returns the tabIconsEnabled.

	 */
	public boolean isTabIconsEnabled() {
		return tabIconsEnabled;
	}

	/**
	 * @param tabIconsEnabled
	 *            The tabIconsEnabled to set.

	 */
	public void setTabIconsEnabled(boolean tabIconsEnabled) {
		this.tabIconsEnabled = tabIconsEnabled;
	}

	/**
	 * @return Returns the toolBar3DHint.

	 */
	public Boolean getToolBar3DHint() {
		return toolBar3DHint;
	}

	/**
	 * @param toolBar3DHint
	 *            The toolBar3DHint to set.

	 */
	public void setToolBar3DHint(Boolean toolBar3DHint) {
		this.toolBar3DHint = toolBar3DHint;
	}

	/**
	 * @return Returns the toolBarHeaderStyle.
	
	 */
	public HeaderStyle getToolBarHeaderStyle() {
		return toolBarHeaderStyle;
	}

	/**
	 * @param toolBarHeaderStyle
	 *            The toolBarHeaderStyle to set.
	
	 */
	public void setToolBarHeaderStyle(HeaderStyle toolBarHeaderStyle) {
		this.toolBarHeaderStyle = toolBarHeaderStyle;
	}

	/**
	 * @return Returns the toolBarPlasticBorderStyle.
	 
	 */
	public BorderStyle getToolBarPlasticBorderStyle() {
		return toolBarPlasticBorderStyle;
	}

	/**
	 * @param toolBarPlasticBorderStyle
	 *            The toolBarPlasticBorderStyle to set.

	 */
	public void setToolBarPlasticBorderStyle(
			BorderStyle toolBarPlasticBorderStyle) {
		this.toolBarPlasticBorderStyle = toolBarPlasticBorderStyle;
	}

	/**
	 * @return Returns the toolBarWindowsBorderStyle.

	 */
	public BorderStyle getToolBarWindowsBorderStyle() {
		return toolBarWindowsBorderStyle;
	}

	/**
	 * @param toolBarWindowsBorderStyle
	 *            The toolBarWindowsBorderStyle to set.

	 */
	public void setToolBarWindowsBorderStyle(
			BorderStyle toolBarWindowsBorderStyle) {
		this.toolBarWindowsBorderStyle = toolBarWindowsBorderStyle;
	}

	/**
	 * @return Returns the useNarrowButtons.

	 */
	public boolean isUseNarrowButtons() {
		return useNarrowButtons;
	}

	/**
	 * @param useNarrowButtons
	 *            The useNarrowButtons to set.

	 */
	public void setUseNarrowButtons(boolean useNarrowButtons) {
		this.useNarrowButtons = useNarrowButtons;
	}

	public Boolean isUseSystemFonts() {
		return useSystemFonts;
	}

	/**
	 * @param useSystemFonts
	 *            The useSystemFonts to set.

	 */
	public void setUseSystemFonts(Boolean useSystemFonts) {
		this.useSystemFonts = useSystemFonts;
	}

}