package sapo.principal;


/**
 * Esta clase constituye el main del SAPO, crea una instancia de Principal.
 * @author Grupo de proyecto SAPO
 */
public class Main {

		
	public static void main(String[] args) throws Exception {
		
		Principal p = new Principal();
		
	}
	
}
