package sapo.principal;

/**
 * Esta clase define los Strings que representan los diferentes comandos que debe 
 * interpretar la clase Principal.
 * @author Grupo de proyecto SAPO
 */
public class Comandos {

	private static final String CONFIRMAR = "(aceptar)";

	//	COMANDOS GENERALES

	public static final String SALIR = "Salir";

	public static final String ACERCA_DE = "Acerca De";

	public static final String DOCUMENTACION = "ver docu";

	public static final String MANUAL = "ver manual";

	//	COMANDOS PARA MANEJAR PROYECTOS

	public static final String CREAR_PROYECTO = "Nuevo Proyecto";

	public static final String CONFIRMAR_CREAR_PROYECTO = CREAR_PROYECTO
			+ CONFIRMAR;

	public static final String EDITAR_PROYECTO = "Editar Proyecto";

	public static final String CONFIRMAR_EDITAR_PROYECTO = "Editar Proyecto"
			+ CONFIRMAR;

	public static final String ABRIR_PROYECTO = "Abrir Proyecto";

	public static final String GUARDAR_PROYECTO = "Guardar Proyecto";

	public static final String CERRAR_PROYECTO = "Cerrar Proyecto";

	//	COMANDOS PARA ABRIR DATOS

	public static final String ABRIR_ALTURAS = "Abrir Alturas";

	public static final String ABRIR_MANZANAS = "Abrir Manzanas";

	public static final String ABRIR_EDIFICIOS = "Abrir Edificios";

	public static final String GENERAR_EDIFICIOS = "Generar Edificios";

	//	COMANDOS PARA VISUALIZACION EN PANTALLA

	public static final String VER_EXPLORADOR = "Ver Explorador";

	public static final String VER_POTENCIA = "Ver Potencia";

	public static final String VER_INTERFERENCIA = "Ver Interferencia";

	public static final String VER_COBERTURA = "Ver Cobertura";

	public static final String VER_ALTURAS = "Ver Alturas";

	public static final String VER_EDIFICIOS = "Ver Edificios";

	public static final String VER_MANZANAS = "Ver manzanas";

	public static final String VER_PREDICCIONES = "Ver Predicciones";

	//COMANDOS PARA MANEJAR SITIOS

	public static final String AGREGAR_SITIO = "Agregar Sitio";

	public static final String CONFIRMAR_AGREGAR_SITIO = AGREGAR_SITIO
			+ CONFIRMAR;

	public static final String EDITAR_SITIO = "Editar Sitio";

	public static final String CONFIRMAR_EDITAR_SITIO = EDITAR_SITIO
			+ CONFIRMAR;

	public static final String BORRAR_SITIO = "Borrar Sitio";

	//	COMANDOS PARA MANEJAR RADIOBASES

	public static final String AGREGAR_RADIOBASE = "Agregar Radiobase";

	public static final String CONFIRMAR_AGREGAR_RADIOBASE = AGREGAR_RADIOBASE
			+ CONFIRMAR;

	public static final String EDITAR_RADIOBASE = "Editar Radiobase";

	public static final String CONFIRMAR_EDITAR_RADIOBASE = EDITAR_RADIOBASE
			+ CONFIRMAR;

	public static final String BORRAR_RADIOBASE = "Borrar Radiobase";

	//	COMANDOS PARA MANEJAR ANTENAS

	public static final String AGREGAR_ANTENA = "Agregar Antena";

	public static final String CONFIRMAR_AGREGAR_ANTENA = AGREGAR_ANTENA
			+ CONFIRMAR;

	public static final String EDITAR_ANTENA = "Editar Antena";

	public static final String CONFIRMAR_EDITAR_ANTENA = EDITAR_ANTENA
			+ CONFIRMAR;

	public static final String BORRAR_ANTENA = "Borrar Antena";

	//COMANDOS PARA MANEJAR MODELOS

	public static final String AGREGAR_MODELO = "Agregar Modelo de Propagación";

	public static final String CONFIRMAR_AGREGAR_MODELO = AGREGAR_MODELO
			+ CONFIRMAR;

	public static final String EDITAR_MODELO = "Editar Modelo de Propagación";

	public static final String CONFIRMAR_EDITAR_MODELO = EDITAR_MODELO
			+ CONFIRMAR;

	public static final String BORRAR_MODELO = "Borrar Modelo de Propagación";

	//	COMANDOS PARA MANEJAR PREDICCIONES

	public static final String ESTIMAR_PREDICCION = "Estimar predicción";

	public static final String CONFIRMAR_ESTIMAR_PREDICCION = ESTIMAR_PREDICCION
			+ CONFIRMAR;

	public static final String GUARDAR_PREDICCION = "Guardar Predicción";

	public static final String CERRAR_PREDICCION = "Cerrar Predicción";

	public static final String ABRIR_PREDICCION = "Abrir Predicción";

	public static final String INFO_PREDICCION = "Información de Predicción";

	public static final String ABRIR_MEDICIONES = "Abrir Medicion";

	public static final String CONFIRMAR_ABRIR_MEDICIONES = ABRIR_MEDICIONES
			+ CONFIRMAR;
	
	public static final String ABRIR_MODULO_ADAPTACION = "Abrir Módulo de Adaptación";

	public static final String CONFIRMAR_ABRIR_MODULO_ADAPTACION = ABRIR_MODULO_ADAPTACION + CONFIRMAR;

	public static final String ESTIMAR_LOS = "Verificar LOS";

	public static final String CONFIRMAR_ESTIMAR_LOS = ESTIMAR_LOS + CONFIRMAR;

	public static final String CERRAR_LOS = "Cerrar LOS";

	//	COMANDOS PARA MANEJAR TIPOS DE ANTENAS

	public static final String AGREGAR_TIPO_ANTENA = "Agregar Tipo de Antena";

	public static final String CONFIRMAR_AGREGAR_TIPO_ANTENA = AGREGAR_TIPO_ANTENA
			+ CONFIRMAR;

	public static final String EDITAR_TIPO_ANTENA = "Editar Tipo de Antena";

	public static final String CONFIRMAR_EDITAR_TIPO_ANTENA = EDITAR_TIPO_ANTENA
			+ CONFIRMAR;

	public static final String BORRAR_TIPO_ANTENA = "Borrar Tipo de Antena";

	//	COMANDOS PARA MANEJAR CANALES

	public static final String AGREGAR_CANAL = "Agregar Canal de Frecuencias";

	public static final String CONFIRMAR_AGREGAR_CANAL = AGREGAR_CANAL
			+ CONFIRMAR;

	public static final String EDITAR_CANAL = "Editar Canal de Frecuencias";

	public static final String CONFIRMAR_EDITAR_CANAL = EDITAR_CANAL
			+ CONFIRMAR;

	public static final String BORRAR_CANAL = "Borrar Canal de Frecuencias";

	//	COMANDOS PARA MANEJAR PERFILES DE USUARIO

	public static final String EDITAR_PERFIL = "Editar Perfil de Usuario";

	public static final String CONFIRMAR_EDITAR_PERFIL = EDITAR_PERFIL
			+ CONFIRMAR;

	//  AUNQUE NO ESTRICTAMENTE COMANDOS SON LAS TERMINACIONES DE ARCHIVO
	// ADMITIDAS HASTA AHORA
	public static final String[] EXTENSIONES_ALTURAS = new String[] { "asc",
			"arc", "grd", "arx", "gz" };

	public static final String[] FORMATOS_GRIDS = { "ArcInfo ASCII grid",
			"ArcInfo ASCII grid comprimido con gzip", "GRASS ASCII grid",
			"GRASS ASCII grid comprimido con gzip" };

}
