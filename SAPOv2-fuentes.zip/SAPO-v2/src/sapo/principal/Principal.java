package sapo.principal;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Frame;
import java.awt.Image;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSplitPane;
import javax.swing.KeyStroke;
import javax.swing.Timer;

import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.renderer.j2d.GeoMouseEvent;

import sapo.archivos.Archivos;
import sapo.archivos.ArchivosXML;
import sapo.archivos.EscritorFeatures;
import sapo.archivos.GeneradorEdificios;
import sapo.archivos.LectorFeatures;
import sapo.ifusuario.ContenedorMapa;
import sapo.ifusuario.ContenedorMapaException;
import sapo.ifusuario.DatosNoDisponiblesException;
import sapo.ifusuario.PanelLateral;
import sapo.ifusuario.SitioMalPosicionadoException;
import sapo.ifusuario.TabsExplorador;
import sapo.ifusuario.Toolbar;
import sapo.ifusuario.VentanaAcercaDe;
import sapo.ifusuario.VentanaAyuda;
import sapo.ifusuario.VentanaInfoPrediccion;
import sapo.ifusuario.VentanaInicial;
import sapo.ifusuario.menues.BarraInferior;
import sapo.ifusuario.menues.BarraMenu;
import sapo.ifusuario.menues.VentanaAnalisisError;
import sapo.ifusuario.menues.VentanaAntena;
import sapo.ifusuario.menues.VentanaCanalFrecuencias;
import sapo.ifusuario.menues.VentanaCrearModelos;
import sapo.ifusuario.menues.VentanaModuloAdaptacion;
import sapo.ifusuario.menues.VentanaPerfilUsuario;
import sapo.ifusuario.menues.VentanaPrediccion;
import sapo.ifusuario.menues.VentanaProyecto;
import sapo.ifusuario.menues.VentanaRB;
import sapo.ifusuario.menues.VentanaSitio;
import sapo.ifusuario.menues.VentanaTipoAntena;
import sapo.predicciones.Modelo;
import sapo.predicciones.PrediccionMalRealizadaException;
import sapo.predicciones.PrediccionMultiAntena;
import sapo.predicciones.PrediccionUniAntena;
import sapo.predicciones.ThreadCalculaAtenuacion;
import sapo.proyecto.CanalRepetidoException;
import sapo.proyecto.ModeloRepetidoException;
import sapo.proyecto.Proyecto;
import sapo.proyecto.SitioRepetidoException;
import sapo.proyecto.TipoAntenaRepetidaException;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.AntenaRepetidaException;
import sapo.red.CanalFrecuencias;
import sapo.red.CanalMalDefinidoException;
import sapo.red.Radiobase;
import sapo.red.RadiobaseRepetidaException;
import sapo.red.Sitio;
import sapo.red.TipoAntena;
import sapo.red.TipoAntenaMalDefinidoException;

/**
 * Esta clase es la que controla el flujo de ejecución del programa.
 * 
 * @author Grupo de proyecto SAPO
 */
public class Principal implements ActionListener, MouseListener,
		MouseMotionListener, KeyListener {

	/**
	 * El marco que contiene todos los elementos de la ventana
	 */
	JFrame contenedorPrincipal;

	/**
	 * El panel que contiene el explorador y el mapa
	 */
	JSplitPane contenedor;

	/**
	 * El explorador que contiene tres tabs
	 */
	TabsExplorador explorador;

	/**
	 * El panel que contiene el mapa
	 */
	ContenedorMapa contenedorMapa;

	/**
	 * La barra de menu superior
	 */
	BarraMenu barraMenu;

	/**
	 * La barra de comandos más usuales
	 */
	Toolbar toolbar;

	/**
	 * La barra de menu inferior
	 */
	BarraInferior barraInferior;

	/**
	 * El proyecto actual
	 */
	Proyecto proyecto;

	/**
	 * Las coordenadas en donde se encuentra el mouse
	 */
	private double x;

	/**
	 * Las coordenadas en donde se encuentra el mouse
	 */
	private double y;

	/**
	 * Las coordenadas en donde se encuentra el mouse
	 */
	PanelLateral panelLateral;

	JComponent scrollMapa;

	VentanaSitio ventanaSitio;

	VentanaRB ventanaRB;

	VentanaAntena ventanaAntena;

	VentanaTipoAntena ventanaTipoAntena;

	VentanaProyecto ventanaProyecto;

	VentanaCrearModelos ventanaCrearModelo;

	VentanaPrediccion ventanaPrediccion;

	VentanaCanalFrecuencias ventanaCanal;

	VentanaPerfilUsuario ventanaPerfil;

	Archivos archivos;

	Sitio sitioSeleccionado;

	Radiobase rbSeleccionada;

	Antena antenaSeleccionada;

	CanalFrecuencias canalSeleccionado;

	Modelo modeloSeleccionado;

	TipoAntena tipoSeleccionado;

	PrediccionMultiAntena prediccionActual;

	ThreadCalculaAtenuacion tca;

	Timer contador;

	static final String imgSrc = "res/";

	static final String icoOpen = "open_file.png";

	static final String icoNew = "new_file.png";

	/**
	 * Indica si se hizo una predicción de línea de vista
	 */
	boolean hayLineaDeVista = false;

	URL fondoURL = (new File("res/sapo_mich_fondo.png")).toURL();

	ImageIcon icono = new ImageIcon("res/icon_mich.png");
	// URL iconoURL = (new File("res/icon_mich.png")).toURL();
	// URL iconoURL = this.getClass().getResource("res/icon_mich.png");

	public static String TITULO = "SAPO v2.0 'Michigan' - Análisis de Propagación Outdoor";

	VentanaInicial ventanaInicial;

	JList listaMouse;
	TipoAntena tipoAntenaMouse;
	Component lastEntered;
	JButton botSi;
	JButton botNo;
	JDialog dialogCanales;

	/**
	 * Parámetros de tamaños
	 * 
	 */
	public static final int tamanoPanelIzquiera = 170;

	/**
	 * Botones para acciones particulares
	 * 
	 */

	private JButton botonEditarTipoAntena;
	private JButton botonEditarSitio;
	private JButton botonEditarCanales;
	private JButton botonEditarModelo;

	/**
	 * Crea una instancia del programa principal
	 * 
	 * @throws Exception
	 */
	public Principal() throws Exception {

		// TODO: elementos para trucos
		KeyboardFocusManager manager = KeyboardFocusManager
				.getCurrentKeyboardFocusManager();
		manager.addKeyEventDispatcher(new MyDispatcher());

		JFrame bienvenido = frogDeBienvenida();
		bienvenido.setLocationRelativeTo(null);
		bienvenido.setVisible(true);

		// inicializacion contenedor mapa y explorador
		contenedorMapa = new ContenedorMapa(this);
		explorador = new TabsExplorador(this);

		// inicializacion barras
		barraMenu = new BarraMenu(this);
		barraInferior = new BarraInferior();
		toolbar = new Toolbar(this);

		archivos = new Archivos();

		// inicializacion panel principal
		contenedorPrincipal = new JFrame();

		// contenedorPrincipal.addKeyListener(this);

		contenedorPrincipal.setLayout(new BorderLayout());
		contenedorPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// GM: esto no está caminando :/
		contenedorPrincipal.setIconImage(icono.getImage());

		contenedorPrincipal.add(toolbar, BorderLayout.NORTH);
		contenedorPrincipal.setJMenuBar(barraMenu);
		panelLateral = new PanelLateral(this);
		scrollMapa = contenedorMapa.createScrollPane();
		contenedor = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelLateral,
				scrollMapa);
		contenedor.setDividerSize(2);
		contenedorPrincipal.getContentPane().add(contenedor);

		// inicializacion ventanas
		ventanaSitio = new VentanaSitio(this, contenedorPrincipal);
		ventanaRB = new VentanaRB(this, contenedorPrincipal, false);
		ventanaInicial = new VentanaInicial(this);

		// inicializar botones de acciones
		botonEditarTipoAntena = new JButton();
		botonEditarTipoAntena.addActionListener(this);
		botonEditarTipoAntena.setActionCommand(Comandos.EDITAR_TIPO_ANTENA);
		botonEditarSitio = new JButton();
		botonEditarSitio.addActionListener(this);
		botonEditarSitio.setActionCommand(Comandos.EDITAR_SITIO);
		botonEditarCanales = new JButton();
		botonEditarCanales.addActionListener(this);
		botonEditarCanales.setActionCommand(Comandos.EDITAR_CANAL);
		botonEditarModelo = new JButton();
		botonEditarModelo.addActionListener(this);
		botonEditarModelo.setActionCommand(Comandos.EDITAR_MODELO);

		contenedor.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
				KeyStroke.getKeyStroke(KeyEvent.VK_A, Event.CTRL_MASK), "frog");
		contenedor.getActionMap().put("frog", new mostrarFrog());
		contenedor.addKeyListener(this);
		contenedor.requestFocus();
		bienvenido.setVisible(false);
		ventanaInicial.setVisible(true);
	}

	/**
	 * Metodo que se llama cuando el usuario hace un click con el boton
	 * izquierdo del mouse tanto en el mapa como en el explorador. De acuerdo a
	 * la seleccion del usuario, setea sitioSeleccionado, radiobaseSeleccionada
	 * y antenaSeleccionada
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		if (!contenedorMapa.getMapa().getCapaAlturas().esVacia()) {
			try {

				// caso en que el click es en el mapa
				if (e.getClass().equals(GeoMouseEvent.class)) {

					if (e.getClickCount() == 2) {
						sitioSeleccionado = new Sitio();
						ventanaSitio = new VentanaSitio(this,
								contenedorPrincipal);
						ventanaSitio.setXsitio(x);
						ventanaSitio.setYsitio(y);
						ventanaSitio.setVisible(true);
					}

					boolean seleccionado = contenedorMapa.getMapa()
							.seleccionarSitio(x, y);
					if (seleccionado) {
						sitioSeleccionado = proyecto.getSitio(x, // Math.round(x),
								y); // Math.round(y));
						explorador.seleccionarSitio(sitioSeleccionado
								.getNombre());
					}
				}
			} catch (Exception ex) {
				ex.printStackTrace(System.out);
			}

		}
		// caso en que el click es en el las listas del panel lateral
		if (e.getSource().equals(panelLateral.listaAntenas)) {
			if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
				if (panelLateral.hayTipoAntenaSeleccionada()) {
					botonEditarTipoAntena.doClick();
				}
			} else if (e.getButton() == MouseEvent.BUTTON3) {

				JPopupMenu popup = new JPopupMenu();
				JMenuItem editar = new JMenuItem("Editar");
				editar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						if (panelLateral.hayTipoAntenaSeleccionada()) {
							botonEditarTipoAntena.doClick();
						}
					}

				});
				JMenuItem eliminar = new JMenuItem("Eliminar");
				eliminar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						if (panelLateral.hayTipoAntenaSeleccionada()) {

							TipoAntena tipo = (TipoAntena) panelLateral.listaAntenas
									.getSelectedValue();
							tipoSeleccionado = tipo;
							if (proyecto.tipoEstaAsignado(tipoSeleccionado
									.getNombre())) {
								JOptionPane
										.showMessageDialog(
												contenedorPrincipal,
												"No se puede borrar el tipo\n"
														+ tipo
														+ "porque existen antenas que lo tienen asignado",
												"Eliminar",
												JOptionPane.WARNING_MESSAGE);
							} else {
								int opcionElegida = JOptionPane
										.showConfirmDialog(contenedorPrincipal,
												"¿Seguro que desea eliminar el tipo de antena\n"
														+ tipo + "?",
												"Eliminar",
												JOptionPane.OK_CANCEL_OPTION,
												JOptionPane.WARNING_MESSAGE);
								if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
									proyecto.borrarTipoAntena(tipoSeleccionado);
								}
							}
							try {
								panelLateral.refrescarElementos(new TipoAntena(
										"hola"), proyecto.getTiposAntena());
							} catch (TipoAntenaMalDefinidoException e) {
								e.printStackTrace();
							}

						}
					}

				});

				popup.add(editar);
				popup.add(eliminar);
				panelLateral.listaAntenas
						.setSelectedIndex(panelLateral.listaAntenas
								.locationToIndex(e.getPoint()));
				popup.show((Component) e.getSource(), e.getX(), e.getY());
			}

		} else if (e.getSource().equals(panelLateral.listaCanales)) {
			if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
				if (panelLateral.hayCanalSeleccionado())
					botonEditarCanales.doClick();
			}

			// TODO

			else if (e.getButton() == MouseEvent.BUTTON3) {

				JPopupMenu popup = new JPopupMenu();
				JMenuItem editar = new JMenuItem("Editar");
				editar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						{
							if (panelLateral.hayCanalSeleccionado()) {
								botonEditarCanales.doClick();
							}
						}
					}

				});
				JMenuItem eliminar = new JMenuItem("Eliminar");
				eliminar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						{
							if (panelLateral.hayCanalSeleccionado()) {

								CanalFrecuencias canal = (CanalFrecuencias) panelLateral.listaCanales
										.getSelectedValue();
								canalSeleccionado = canal;
								if (proyecto
										.canalEstaAsignado(canalSeleccionado
												.getNombre())) {
									JOptionPane
											.showMessageDialog(
													contenedorPrincipal,
													"No se puede borrar el canal\n"
															+ canal
															+ "porque existen antenas que lo tienen asignado",
													"Eliminar",
													JOptionPane.WARNING_MESSAGE);
								} else {
									int opcionElegida = JOptionPane
											.showConfirmDialog(
													contenedorPrincipal,
													"¿Seguro que desea eliminar el canal\n"
															+ canal + "?",
													"Eliminar",
													JOptionPane.OK_CANCEL_OPTION,
													JOptionPane.WARNING_MESSAGE);
									if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
										proyecto.borrarCanal(canal);
									}
								}
								try {
									panelLateral.refrescarElementos(
											new CanalFrecuencias("hola"),
											proyecto.getCanales());
								} catch (CanalMalDefinidoException e) {
									e.printStackTrace();
								}

							}
						}
					}

				});

				popup.add(editar);
				popup.add(eliminar);
				panelLateral.listaCanales
						.setSelectedIndex(panelLateral.listaCanales
								.locationToIndex(e.getPoint()));
				popup.show((Component) e.getSource(), e.getX(), e.getY());
			}

		} else if (e.getSource().equals(panelLateral.listaSitios)) {
			
			if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 1) {
				if (panelLateral.haySitioSeleccionado())
					sitioSeleccionado = panelLateral.listaSitios
							.getSelectedValue();
				contenedorMapa.getMapa().seleccionarSitio(sitioSeleccionado.getX(), sitioSeleccionado.getY());
			}
			if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
				if (panelLateral.haySitioSeleccionado())
					sitioSeleccionado = panelLateral.listaSitios
							.getSelectedValue();
				botonEditarSitio.doClick();
			} else if (e.getButton() == MouseEvent.BUTTON3) {
				JPopupMenu popup = new JPopupMenu();
				JMenuItem editar = new JMenuItem("Editar");
				editar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						{
							if (panelLateral.haySitioSeleccionado()) {
								sitioSeleccionado = panelLateral.listaSitios
										.getSelectedValue();
								botonEditarSitio.doClick();
							}
						}
					}
				});
				JMenuItem eliminar = new JMenuItem("Eliminar");
				eliminar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						{
							if (panelLateral.haySitioSeleccionado()) {

								Sitio sitio = (Sitio) panelLateral.listaSitios
										.getSelectedValue();
								sitioSeleccionado = sitio;
								int opcionElegida = JOptionPane
										.showConfirmDialog(contenedorPrincipal,
												"¿Seguro que desea eliminar el sitio\n"
														+ sitio + "?",
												"Eliminar",
												JOptionPane.OK_CANCEL_OPTION,
												JOptionPane.WARNING_MESSAGE);
								if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
									proyecto.borrarSitio(sitio);
									contenedorMapa.getMapa().borrarSitio(
											sitioSeleccionado);
									panelLateral.refrescarElementos(new Sitio(
											"Aux"), proyecto.getSitios());
								}
							}
						}
					}
				});
				popup.add(editar);
				popup.add(eliminar);
				panelLateral.listaSitios
						.setSelectedIndex(panelLateral.listaSitios
								.locationToIndex(e.getPoint()));
				popup.show((Component) e.getSource(), e.getX(), e.getY());
			}
		} else if (e.getSource().equals(panelLateral.listaModelos)) {
			if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
				if (panelLateral.hayModeloSeleccionado()) {
					modeloSeleccionado = panelLateral.listaModelos
							.getSelectedValue();
					botonEditarModelo.doClick();
				}

			} else if (e.getButton() == MouseEvent.BUTTON3) {
				JPopupMenu popup = new JPopupMenu();
				JMenuItem editar = new JMenuItem("Editar");
				editar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						{
							if (panelLateral.hayModeloSeleccionado()) {
								botonEditarModelo.doClick();
							}
						}
					}

				});
				JMenuItem eliminar = new JMenuItem("Eliminar");
				eliminar.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(final ActionEvent event) {
						{
							if (panelLateral.hayModeloSeleccionado()) {

								Modelo modelo = (Modelo) panelLateral.listaModelos
										.getSelectedValue();
								modeloSeleccionado = modelo;
								if (proyecto
										.modeloEstaAsignado(modeloSeleccionado
												.getNombre())) {
									JOptionPane
											.showMessageDialog(
													contenedorPrincipal,
													"No se puede borrar el modelo\n"
															+ modelo
															+ "porque existen antenas que lo tienen asignado",
													"Eliminar",
													JOptionPane.WARNING_MESSAGE);
								} else {
									int opcionElegida = JOptionPane
											.showConfirmDialog(
													contenedorPrincipal,
													"¿Seguro que desea eliminar el modelo\n"
															+ modelo + "?",
													"Eliminar",
													JOptionPane.OK_CANCEL_OPTION,
													JOptionPane.WARNING_MESSAGE);
									if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
										proyecto.borrarModelo(modelo);
									}
								}
								panelLateral.refrescarElementos(modelo,
										proyecto.getModelos());
							}
						}
					}

				});

				popup.add(editar);
				popup.add(eliminar);
				panelLateral.listaModelos
						.setSelectedIndex(panelLateral.listaModelos
								.locationToIndex(e.getPoint()));
				popup.show((Component) e.getSource(), e.getX(), e.getY());
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		lastEntered = e.getComponent();
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		JComponent comp = (JComponent) e.getComponent();
		Component child = comp.findComponentAt(e.getPoint());

		if (child instanceof JList) {
			if (((JList) child).getSelectedValue() instanceof TipoAntena) {
				listaMouse = (JList) child;
				tipoAntenaMouse = (TipoAntena) ((JList) child)
						.getSelectedValue();

				// Crea cursor para arrastrar antena
				Toolkit toolkit = Toolkit.getDefaultToolkit();
				Image image = toolkit.getImage("res/antenaDrag.png");
				Point hotSpot = new Point(0, 0);
				Cursor cursor = toolkit.createCustomCursor(image, hotSpot,
						"Pencil");

				contenedor.setCursor(cursor);
				scrollMapa.setCursor(cursor);
			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {

		Cursor cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		contenedor.setCursor(cursor);

		if (tipoAntenaMouse != null && lastEntered.equals(contenedorMapa)) {

			contenedor.setCursor(cursor);
			scrollMapa.setCursor(cursor);

			int x = e.getX();
			int y = e.getY();

			if (!contenedorMapa.getMapa().getCapaAlturas().esVacia()) {

				contenedorMapa.dispatchEvent(new MouseEvent(contenedorMapa,
						MouseEvent.MOUSE_CLICKED, System.currentTimeMillis(),
						InputEvent.BUTTON1_MASK, x, y, 2, false));
			}
			listaMouse = null;
			tipoAntenaMouse = null;
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (tipoAntenaMouse != null) {
//			Cursor cursor = new Cursor(Cursor.MOVE_CURSOR);
//			panelLateral.setCursor(cursor);
		}

	}

	/**
	 * Método que se llama cuando el usuario mueve el mouse en el mapa. Setea
	 * las variables x e y con la coordenadas del punto correspondiente a la
	 * posicion del mouse y las despliega en la barra inferior, junto con la
	 * altura y la potencia en dicho punto, si corresponde.
	 */
	@Override
	public void mouseMoved(MouseEvent e) {
		Point2D punto = ((GeoMouseEvent) e).getMapCoordinate(null);
		x = punto.getX();
		y = punto.getY();
		barraInferior.getTextoX().setText("X: " + ((int) (x * 100)) / 100.0);
		barraInferior.getTextoY().setText("Y: " + ((int) (y * 100)) / 100.0);
		CoordinatePoint coord = new CoordinatePoint(punto);
		try {
			GridCoverage gcAlturas = (GridCoverage) this.contenedorMapa
					.getMapa().getCapaAlturas().getFeatureCollection()
					.features().next().getAttribute("grid");
			double[] altura = new double[1];
			altura = gcAlturas.evaluate(coord, altura);
			barraInferior.getTextoAltura().setText(
					"Altura: " + altura[0] + " m");
		} catch (Exception ex) {
			barraInferior.getTextoAltura().setText(" ");
		}
		try {
			FeatureIterator fi = this.contenedorMapa.getMapa()
					.getCapaResultados().getFeatureCollection().features();
			double[] atenuacion = new double[] { Double.NaN };
			while (new Double(atenuacion[0]).isNaN()) {
				GridCoverage gcResultados = (GridCoverage) fi.next()
						.getAttribute("grid");
				try {
					atenuacion = gcResultados.evaluate(coord, atenuacion);
				} catch (org.geotools.cv.PointOutsideCoverageException z) {
				}
			}
			if (this.hayLineaDeVista) {
				barraInferior.getTextoAtenuacion()
						.setText("Hay línea de vista");
			} else {
				if (barraMenu.verPotencia())
					barraInferior.getTextoAtenuacion().setText(
							"Potencia: " + ((int) (atenuacion[0] * 100))
									/ 100.0 + " dBm");
				else if (barraMenu.verInterferencia())
					barraInferior.getTextoAtenuacion().setText(
							"C/I: " + ((int) (atenuacion[0] * 100)) / 100.0
									+ " dB");
				else if (barraMenu.verCobertura()) {
					String cobertura = "no";
					if (Math.round(atenuacion[0]) == Math
							.round(PrediccionMultiAntena.HAY_COBERTURA))
						cobertura = "sí";
					barraInferior.getTextoAtenuacion().setText(
							"¿Hay cobertura? " + cobertura);
				}
			}
		} catch (Exception ex) {
			barraInferior.getTextoAtenuacion().setText("");
			// ex.printStackTrace(System.out);
		}
		// ventanaSitio.setXsitio(Math.round(x));
		// ventanaSitio.setYsitio(Math.round(y));

		// ventanaEditarSitio.setEtiquetaX(String.valueOf(Math.round(x)));
		// ventanaEditarSitio.setEtiquetaY(String.valueOf(Math.round(y)));
	}

	/**
	 * Método que centraliza todos los comandos principales que puede generar el
	 * usuario
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			String comando = e.getActionCommand();
			System.out.println(comando);

			// COMANDOS GENERALES

			if (comando.equals(Comandos.SALIR)) {
				if (this.proyecto.getCambiosSinGuardar()) {
					int opcionElegida = JOptionPane
							.showConfirmDialog(
									contenedorPrincipal,
									"¿Seguro que desea salir?\n"
											+ "Se perderán todos los cambios que no hayan sido guardados.",
									"Salir", JOptionPane.OK_CANCEL_OPTION,
									JOptionPane.QUESTION_MESSAGE);
					if (opcionElegida == JOptionPane.OK_OPTION) {
						this.salir();
					}
				} else {
					int opcionElegida = JOptionPane.showConfirmDialog(
							contenedorPrincipal, "¿Seguro que desea salir?\n",
							"Salir", JOptionPane.OK_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE);
					if (opcionElegida == JOptionPane.OK_OPTION) {
						this.salir();
					}
				}
			}

			// COMANDOS PARA MANEJAR PROYECTOS

			else if (comando.equals(Comandos.CREAR_PROYECTO)) {
				ventanaProyecto = new VentanaProyecto(this, ventanaInicial);
				ventanaProyecto.setVisible(true);

			} else if (comando.equals(Comandos.CONFIRMAR_CREAR_PROYECTO)) {
				contenedorPrincipal.setLayout(new BorderLayout());
				contenedorPrincipal
						.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				contenedorPrincipal.setSize(new Dimension(500, 500));
				barraMenu = new BarraMenu(this);

				barraInferior = new BarraInferior();
				// contenedorPrincipal.getContentPane().removeAll();
				contenedorPrincipal.setExtendedState(Frame.MAXIMIZED_BOTH);
				toolbar = new Toolbar(this);
				contenedorPrincipal.add(toolbar, BorderLayout.NORTH);
				archivos = new Archivos();
				contenedorPrincipal.setJMenuBar(barraMenu);
				this.crearProyecto();

				contenedorMapa = new ContenedorMapa(this);

				this.barraMenu.hayUnProyecto(true);
				contenedorPrincipal.setTitle(Principal.TITULO + " - ["
						+ proyecto.getNombre() + "]");
				dialogCanales = new JDialog();
				JPanel panelDialog = new JPanel();
				JLabel label = new JLabel("¿Agregar canales TVDT por defecto?");
				botSi = new JButton("Sí");
				botSi.addActionListener(this);
				botNo = new JButton("No");
				botNo.addActionListener(this);
				panelDialog.add(label);
				panelDialog.add(botSi);
				panelDialog.add(botNo);
				dialogCanales.add(panelDialog);
				dialogCanales.pack();
				dialogCanales.setLocationRelativeTo(null);

				contenedorPrincipal.setVisible(true);
				dialogCanales.setVisible(true);
				contenedorPrincipal.validate();
				contenedorPrincipal.repaint();
				panelLateral = new PanelLateral(this);
				scrollMapa = contenedorMapa.createScrollPane();
				// scrollMapa.setTransferHandler(new
				// TransferHandlerAntenas(TransferHandler.COPY));
				contenedor = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
						panelLateral, contenedorMapa.createScrollPane());

				contenedor.setContinuousLayout(true);
				contenedor.setDividerSize(2);
				contenedor.setDividerLocation(tamanoPanelIzquiera);
				contenedorPrincipal.getContentPane().add(contenedor);

				ventanaInicial.setVisible(false);
				panelLateral.refrescarElementos(new CanalFrecuencias("Canal"),
						proyecto.getCanales());
				contenedorPrincipal.getContentPane().add(barraInferior,
						BorderLayout.PAGE_END);
			} else if (comando.equals(Comandos.EDITAR_PROYECTO)) {
				ventanaProyecto = new VentanaProyecto(proyecto, this,
						this.contenedorPrincipal);
				ventanaProyecto.setVisible(true);

			} else if (comando.equals(Comandos.CONFIRMAR_EDITAR_PROYECTO)) {
				proyecto = ventanaProyecto.getProyecto(proyecto);
				ventanaProyecto.setVisible(false);
				ventanaProyecto.dispose();
				contenedorPrincipal.setTitle(Principal.TITULO + " - ["
						+ proyecto.getNombre() + "]");

			} else if (comando.equals(Comandos.ABRIR_PROYECTO)) {
				this.leerProyecto();
				if (proyecto != null) {
					contenedorPrincipal.getContentPane().removeAll();
					contenedorPrincipal.validate();
					contenedorMapa = new ContenedorMapa(this);
					toolbar = new Toolbar(this);
					if (proyecto.getLinkCapaAlturas() != null) {
						Grilla grilla = LectorFeatures.leerAlturas(
								proyecto.getLinkCapaAlturas(),
								this.contenedorMapa.getCoordinateSystem());
						contenedorMapa.crearCapaAlturas(grilla);
						this.barraMenu.hayDatosAltura(true);
						toolbar.disableAlturas();
						toolbar.enableSitio();
						toolbar.enableManzanas();
						toolbar.enableEdificios();
					}
					if (proyecto.getLinkCapaEdificios() != null) {
						FeatureCollection fcEdificios = LectorFeatures
								.leerShp(proyecto.getLinkCapaEdificios());
						contenedorMapa.crearCapaEdificios(fcEdificios);
						this.barraMenu.hayDatosEdificios(true);
						toolbar.disableEdificios();
					}
					if (proyecto.getLinkCapaManzanas() != null) {
						FeatureCollection fcManzanas = LectorFeatures
								.leerShp(proyecto.getLinkCapaManzanas());
						contenedorMapa.crearCapaManzanas(fcManzanas);
						this.barraMenu.hayDatosManzanas(true);
						toolbar.disableManzanas();
					}

					contenedorMapa.crearCapaSitios(proyecto.getSitios());

					contenedor = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
							panelLateral, contenedorMapa.createScrollPane());
					contenedor.setContinuousLayout(true);
					contenedor.setDividerSize(2);
					contenedor.setDividerLocation(tamanoPanelIzquiera);
	
					contenedorPrincipal.getContentPane().add(barraInferior,
							BorderLayout.PAGE_END);
					contenedorPrincipal.getContentPane().add(contenedor);
					contenedorPrincipal.setTitle(Principal.TITULO + " - ["
							+ proyecto.getNombre() + "]");

					// barraMenu = new BarraMenu(this);//prueba
					// barraInferior = new BarraInferior();//prueba
					contenedorPrincipal.setSize(700, 700);
					contenedorPrincipal.setExtendedState(Frame.MAXIMIZED_BOTH);
					contenedorPrincipal
							.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					contenedorPrincipal.setJMenuBar(barraMenu);
					contenedorPrincipal.add(toolbar, BorderLayout.NORTH);
					contenedorPrincipal.setVisible(true);
					
					contenedorMapa.repaint();
					
					this.barraMenu.hayUnProyecto(true);
					this.proyecto.fueGuardado();

					ventanaInicial.setVisible(false);
					panelLateral.refrescarElementos(new TipoAntena("Antenas"),
							proyecto.getTiposAntena());
					panelLateral.refrescarElementos(new Sitio("Sitios"),
							proyecto.getSitios());

					if (!proyecto.getModelos().isEmpty()) {
						panelLateral.refrescarElementos(proyecto.getModelos()
								.get(0), proyecto.getModelos());
					}
					panelLateral.refrescarElementos(new CanalFrecuencias(
							"Canal"), proyecto.getCanales());
				}
			}

			else if (comando.equals(Comandos.GUARDAR_PROYECTO)) {
				this.guardarProyectoaXML();

			} else if (comando.equals(Comandos.CERRAR_PROYECTO)) {
				if (proyecto.getCambiosSinGuardar()) {
					int opcionElegida = JOptionPane.showConfirmDialog(
							contenedorPrincipal,
							"¿Desea guardar los cambios efectuados en "
									+ proyecto.getNombre() + "?", "Guardar",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.WARNING_MESSAGE);
					if (opcionElegida == JOptionPane.YES_OPTION) {
						this.guardarProyectoaXML();
					}
				}
				contenedorPrincipal.remove(contenedor);
				contenedorPrincipal.setJMenuBar(null);
				contenedorPrincipal.remove(toolbar);
				contenedorPrincipal.getContentPane().remove(barraInferior);
				contenedorPrincipal.setTitle(Principal.TITULO);
				contenedorPrincipal.repaint();
				// contenedorPrincipal
				// .add(new JLabel(new ImageIcon(this.fondoURL)));
				this.barraMenu.hayUnProyecto(false);
				contenedorPrincipal.validate();
				contenedorPrincipal.setLocationRelativeTo(null);
				contenedorPrincipal.dispose();
				this.ventanaInicial.setVisible(true);
			}

			// COMANDOS PARA ABRIR DATOS

			else if (comando.equals(Comandos.ABRIR_ALTURAS)) {
				try {
					URL dirCapaAlturas = archivos.abrirArchivo(
							Comandos.EXTENSIONES_ALTURAS,
							"ArcInfo ASCII o GRASS ASCII").toURL();
					Grilla grilla = LectorFeatures.leerAlturas(dirCapaAlturas,
							this.contenedorMapa.getCoordinateSystem());

					contenedorMapa.crearCapaAlturas(grilla);
					contenedorPrincipal.getContentPane().add(barraInferior,
							BorderLayout.PAGE_END);
					proyecto.setLinkCapaAlturas(dirCapaAlturas);
					// explorador.agregarTabSitios();
					barraMenu.hayDatosAltura(true);
					toolbar.disableAlturas();
					toolbar.enableSitio();
					toolbar.enableManzanas();
					toolbar.enableEdificios();

				} catch (NullPointerException ex) {

				}
			}

			else if (comando.equals(Comandos.ABRIR_MANZANAS)) {
				try {
					URL dirCapaCuadras = archivos.abrirArchivo("shp",
							"Archivo shp").toURL();
					FeatureCollection fc = LectorFeatures
							.leerShp(dirCapaCuadras);
					contenedorMapa.crearCapaManzanas(fc);
					proyecto.setLinkCapaManzanas(dirCapaCuadras);
					this.barraMenu.hayDatosManzanas(true);
					toolbar.disableManzanas();

				} catch (NullPointerException ex) {

				}
			}

			else if (comando.equals(Comandos.ABRIR_EDIFICIOS)) {
				try {
					URL dirCapaEdificios = archivos.abrirArchivo("shp",
							"Archivo shp").toURL();
					FeatureCollection fc = LectorFeatures
							.leerShp(dirCapaEdificios);
					contenedorMapa.crearCapaEdificios(fc);
					proyecto.setLinkCapaEdificios(dirCapaEdificios);
					this.barraMenu.hayDatosEdificios(true);
					toolbar.disableEdificios();
				} catch (NullPointerException ex) {

				}
			}
			// ******eli
			else if (comando.equals(Comandos.GENERAR_EDIFICIOS)) {
				GeneradorEdificios ge = new GeneradorEdificios(
						contenedorPrincipal, contenedorMapa.getMapa()
								.getCapaManzanas(), contenedorMapa.getMapa()
								.getCapaEdificios());
				if (ge.getLinkManzanas() != null) {
					contenedorMapa.crearCapaManzanas(ge.getManzanas());
					proyecto.setLinkCapaManzanas(ge.getLinkManzanas());
					barraMenu.hayDatosManzanas(true);
				}
				if (ge.getLinkEdificios() != null) {
					contenedorMapa.getMapa().getCapaEdificios().vaciar();
					contenedorMapa.crearCapaEdificios(ge.getEdificios());
					proyecto.setLinkCapaEdificios(ge.getLinkEdificios());
					barraMenu.hayDatosEdificios(true);
				}
			}

			// *************

			// COMANDOS PARA VISUALIZACION EN PANTALLA

			else if (comando.equals(Comandos.VER_EXPLORADOR)) {
				if (!barraMenu.exploradorEsVisible()) {
					contenedor.remove(panelLateral);
				} else {
					contenedor.add(panelLateral);
					contenedor.setDividerLocation(tamanoPanelIzquiera);
				}
			}

			else if (comando.equals(Comandos.VER_POTENCIA)) {
				contenedorMapa.quitarCapaResultados();
				contenedorMapa.crearCapaResultados(prediccionActual,
						this.proyecto);
			}

			else if (comando.equals(Comandos.VER_INTERFERENCIA)) {
				contenedorMapa.quitarCapaResultados();
				contenedorMapa.crearCapaInterferencia(prediccionActual);
			}

			else if (comando.equals(Comandos.VER_COBERTURA)) {
				contenedorMapa.quitarCapaResultados();
				contenedorMapa.crearCapaCobertura(prediccionActual,
						this.proyecto.getPerfilUsuario());
			}

			else if (comando.equals(Comandos.VER_ALTURAS)) {
				contenedorMapa.mostrarCapaAlturas(this.barraMenu
						.verCapaAlturas());
			}

			else if (comando.equals(Comandos.VER_EDIFICIOS)) {
				contenedorMapa.mostrarCapaEdificios(this.barraMenu
						.verCapaEdificios());
			}

			else if (comando.equals(Comandos.VER_MANZANAS)) {
				contenedorMapa.mostrarCapaManzanas(this.barraMenu
						.verCapaManzanas());
			}

			else if (comando.equals(Comandos.VER_PREDICCIONES)) {
				contenedorMapa.mostrarCapaPredicciones(this.barraMenu
						.verCapaPredicciones());
			}

			else if (comando.equals(Comandos.ACERCA_DE)) {
				VentanaAcercaDe vad = new VentanaAcercaDe(
						this.contenedorPrincipal);
				vad.setVisible(true);
				vad.pack();
			}

			else if (comando.equals(Comandos.DOCUMENTACION)) {
				if (Desktop.isDesktopSupported()) {
                    try {
                        File myFile = new File("res/documentacion.pdf");
                        Desktop.getDesktop().open(myFile);
                    } catch (IOException ex) {
                        // no application registered for PDFs
                    }
				}
			}

			else if (comando.equals(Comandos.MANUAL)) {
				if (Desktop.isDesktopSupported()) {
                    try {
                        File myFile = new File("res/manual.pdf");
                        Desktop.getDesktop().open(myFile);
                    } catch (IOException ex) {
                        // no application registered for PDFs
                    }
				}
			}
			// COMANDOS PARA MANEJAR SITIOS

			else if (comando.equals(Comandos.AGREGAR_SITIO)) {
				sitioSeleccionado = new Sitio();
				ventanaSitio = new VentanaSitio(this, contenedorPrincipal);
				ventanaSitio.setVisible(true);
			} else if (comando.equals(Comandos.CONFIRMAR_AGREGAR_SITIO)) {
				this.agregarSitio(true);
			}

			else if (comando.equals(Comandos.EDITAR_SITIO)) {
				ventanaSitio = new VentanaSitio(sitioSeleccionado, this,
						contenedorPrincipal);
				ventanaSitio.setVisible(true);
			}

			else if (comando.equals(Comandos.CONFIRMAR_EDITAR_SITIO)) {
				proyecto.borrarSitio(sitioSeleccionado);
				contenedorMapa.getMapa().borrarSitio(sitioSeleccionado);
				this.agregarSitio(false);
			}

			else if (comando.equals(Comandos.BORRAR_SITIO)) {
				int opcionElegida = JOptionPane.showConfirmDialog(
						contenedorPrincipal,
						"¿Seguro que desea eliminar el sitio "
								+ sitioSeleccionado.getNombre() + "?",
						"Eliminar", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.WARNING_MESSAGE);
				if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
					proyecto.borrarSitio(sitioSeleccionado);
					contenedorMapa.getMapa().borrarSitio(sitioSeleccionado);
					explorador.borrarSitio();
				}
			}

			// COMANDOS PARA MANEJAR RADIOBASES

			else if (comando.equals(Comandos.AGREGAR_RADIOBASE)) {
				rbSeleccionada = new Radiobase();
				ventanaRB = new VentanaRB(this, this.contenedorPrincipal,
						this.proyecto.sePuedeCrearAntenas());
				ventanaRB.setVisible(true);
			}

			else if (comando.equals(Comandos.CONFIRMAR_AGREGAR_RADIOBASE)) {
				this.agregarRB(true);
			}

			else if (comando.equals(Comandos.EDITAR_RADIOBASE)) {
				if (ventanaSitio.isVisible()) {
					rbSeleccionada = sitioSeleccionado
							.getRadiobase(ventanaSitio
									.getRadiobaseSeleccionada());
				}
				ventanaRB = new VentanaRB(rbSeleccionada, this,
						contenedorPrincipal,
						this.proyecto.sePuedeCrearAntenas());
				ventanaRB.setVisible(true);
			}

			else if (comando.equals(Comandos.CONFIRMAR_EDITAR_RADIOBASE)) {
				if (ventanaSitio.isVisible()) {// la borro de la lista
					ventanaSitio.borrarRB(rbSeleccionada.getNombre());
				}
				sitioSeleccionado.borrarRB(rbSeleccionada);
				this.agregarRB(false);
			}

			else if (comando.equals(Comandos.BORRAR_RADIOBASE)) {
				if (ventanaSitio.isVisible()) {
					rbSeleccionada = sitioSeleccionado
							.getRadiobase(ventanaSitio
									.getRadiobaseSeleccionada());
				}
				int opcionElegida = JOptionPane.showConfirmDialog(
						contenedorPrincipal,
						"¿ seguro que desea eliminar la radiobase "
								+ rbSeleccionada.getNombre() + "?", "Eliminar",
						JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.WARNING_MESSAGE);
				if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
					if (ventanaSitio.isVisible()) {// la borro de la lista
						ventanaSitio.borrarRB(rbSeleccionada.getNombre());
					} else {
						explorador.borrarRB();
					}
					// la borro del sitio
					rbSeleccionada.setSitio(sitioSeleccionado.getNombre());
					sitioSeleccionado.borrarRB(rbSeleccionada);
				}
			}

			// COMANDOS PARA MANEJAR ANTENAS

			else if (comando.equals(Comandos.AGREGAR_ANTENA)) {
				antenaSeleccionada = new Antena();
				ventanaAntena = new VentanaAntena(proyecto, this,
						this.contenedorPrincipal);
				ventanaAntena.setVisible(true);
			}

			else if (comando.equals(Comandos.CONFIRMAR_AGREGAR_ANTENA)) {
				this.agregarAntena(true);
			}

			else if (comando.equals(Comandos.EDITAR_ANTENA)) {
				if (ventanaRB.isVisible()) {
					antenaSeleccionada = rbSeleccionada.getAntena(ventanaRB
							.getAntenaSeleccionada());
				}
				ventanaAntena = new VentanaAntena(antenaSeleccionada, proyecto,
						this, contenedorPrincipal);
				ventanaAntena.setVisible(true);
			}

			else if (comando.equals(Comandos.CONFIRMAR_EDITAR_ANTENA)) {
				if (ventanaRB.isVisible()) {
					ventanaRB.borrarAntena(antenaSeleccionada.getNombre());
				}
				rbSeleccionada.borrarAntena(antenaSeleccionada);
				// this.borrarAntena(ventanaOrigen);
				this.agregarAntena(false);
			}

			else if (comando.equals(Comandos.BORRAR_ANTENA)) {
				if (ventanaRB.isVisible()) {
					antenaSeleccionada = rbSeleccionada.getAntena(ventanaRB
							.getAntenaSeleccionada());
				}
				int opcionElegida = JOptionPane.showConfirmDialog(
						contenedorPrincipal,
						"¿ seguro que desea eliminar la antena "
								+ antenaSeleccionada.getNombre() + "?",
						"Eliminar", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.WARNING_MESSAGE);
				if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
					if (ventanaRB.isVisible()) {
						ventanaRB.borrarAntena(antenaSeleccionada.getNombre());
					} else {
						explorador.borrarAntena();
					}
					rbSeleccionada.borrarAntena(antenaSeleccionada);
				}
			}

			// COMANDOS PARA MANEJAR MODELOS

			else if (comando.equals(Comandos.AGREGAR_MODELO)) {
				this.ventanaCrearModelo = new VentanaCrearModelos(
						"Creacion de Modelos", contenedorPrincipal, this);
				this.ventanaCrearModelo.setVisible(true);
			}

			else if (comando.equals(Comandos.CONFIRMAR_AGREGAR_MODELO)) {
				this.agregarModelo(true);
			} else if (comando.equals(Comandos.EDITAR_MODELO)) {
				modeloSeleccionado = (Modelo) panelLateral.listaModelos
						.getSelectedValue();
				this.ventanaCrearModelo = new VentanaCrearModelos(
						modeloSeleccionado, contenedorPrincipal, this);
				this.ventanaCrearModelo.setVisible(true);
			}

			else if (comando.equals(Comandos.CONFIRMAR_EDITAR_MODELO)) {
				proyecto.borrarModelo(modeloSeleccionado);
				this.agregarModelo(false);
			}

			else if (comando.equals(Comandos.BORRAR_MODELO)) {
				modeloSeleccionado = proyecto.getModelo(explorador
						.getModeloSeleccionado());
				if (proyecto.modeloEstaAsignado(explorador
						.getModeloSeleccionado())) {
					JOptionPane
							.showMessageDialog(
									contenedorPrincipal,
									"No se puede borrar el modelo "
											+ explorador
													.getModeloSeleccionado()
											+ " porque existen antenas que lo tienen asignado",
									"Eliminar", JOptionPane.WARNING_MESSAGE);
				} else {
					int opcionElegida = JOptionPane.showConfirmDialog(
							contenedorPrincipal,
							"¿ seguro que desea eliminar el modelo "
									+ explorador.getModeloSeleccionado() + "?",
							"Eliminar", JOptionPane.OK_CANCEL_OPTION,
							JOptionPane.WARNING_MESSAGE);
					if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
						proyecto.borrarModelo(modeloSeleccionado);
						explorador.borrarModelo();

					}
				}
			}

			// COMANDOS PARA MANEJAR PREDICCIONES

			else if (comando.equals(Comandos.ESTIMAR_PREDICCION)) {
				try {
					ventanaPrediccion = new VentanaPrediccion(this,
							contenedorPrincipal, this.proyecto.sitios);
					ventanaPrediccion.setVisible(true);
				} catch (Exception ex) {
					ex.printStackTrace(System.out);
					JOptionPane.showMessageDialog(contenedorPrincipal, ex);
				}
			}

			else if (comando.equals(Comandos.CONFIRMAR_ESTIMAR_PREDICCION)) {
				this.calcularAtenuacion(false);
				// prediccionActual = this.tca.getPrediccion();
			}

			else if (comando.equals(Comandos.ESTIMAR_LOS)) {
				try {
					ventanaPrediccion = new VentanaPrediccion(true, this,
							contenedorPrincipal, this.proyecto.sitios);
					ventanaPrediccion.setVisible(true);
				} catch (Exception ex) {
					ex.printStackTrace(System.out);
					JOptionPane.showMessageDialog(contenedorPrincipal, ex);
				}
			}

			else if (comando.equals(Comandos.CONFIRMAR_ESTIMAR_LOS)) {
				this.calcularAtenuacion(true);
				// prediccionActual = this.tca.getPrediccion();
				this.hayLineaDeVista = true;
			}

			else if (comando.equals(Comandos.GUARDAR_PREDICCION)) {
				this.guardarPrediccion();
				// this.contenedorMapa.guardarPrediccion();
			}

			else if (comando.equals(Comandos.ABRIR_PREDICCION)) {
				this.abrirPrediccion();
			}

			else if (comando.equals(Comandos.CERRAR_PREDICCION)) {
				this.contenedorMapa.quitarCapaResultados();
				this.barraMenu.hayUnaPrediccion(false);
				this.toolbar.enablePredicciones();
				this.hayLineaDeVista = false;
			}

			else if (comando.equals(Comandos.INFO_PREDICCION)) {
				try {
					VentanaInfoPrediccion ventanaInfoPrediccion = new VentanaInfoPrediccion(
							contenedorPrincipal, prediccionActual,
							this.proyecto);
					ventanaInfoPrediccion.setVisible(true);
				} catch (DatosNoDisponiblesException ex) {
					JOptionPane.showMessageDialog(
							contenedorPrincipal,
							"Los datos no pueden ser desplegados.\n"
									+ ex.getMessage(), "Error",
							JOptionPane.WARNING_MESSAGE);
				}
			}

			else if (comando.equals(Comandos.ABRIR_MEDICIONES)) {
				VentanaAnalisisError vae = new VentanaAnalisisError(
						this.contenedorPrincipal, this.proyecto,
						this.contenedorMapa.getMapa());
			}

			else if (comando.equals(Comandos.ABRIR_MODULO_ADAPTACION)) {
				VentanaModuloAdaptacion vma = new VentanaModuloAdaptacion(
						this.contenedorPrincipal, this.proyecto,
						this.contenedorMapa.getMapa());
				Modelo modeloNuevo = VentanaModuloAdaptacion.getModelo();
				panelLateral.refrescarElementos(modeloNuevo, proyecto.getModelos());
			}

			// COMANDOS PARA MANEJAR TIPOS DE ANTENAS

			else if (comando.equals(Comandos.AGREGAR_TIPO_ANTENA)) {
				ventanaTipoAntena = new VentanaTipoAntena(this,
						this.contenedorPrincipal);
				ventanaTipoAntena.setVisible(true);
			} else if (comando.equals(Comandos.CONFIRMAR_AGREGAR_TIPO_ANTENA)) {
				this.agregarTipoAntena(true);
			} else if (comando.equals(Comandos.EDITAR_TIPO_ANTENA)) {
				tipoSeleccionado = panelLateral.getTipoAntenaSeleccionada();
				ventanaTipoAntena = new VentanaTipoAntena(tipoSeleccionado,
						this, this.contenedorPrincipal, true);
				ventanaTipoAntena.setVisible(true);
			} else if (comando.equals(Comandos.CONFIRMAR_EDITAR_TIPO_ANTENA)) {
				proyecto.borrarTipoAntena(tipoSeleccionado);
				this.agregarTipoAntena(false);
			} else if (comando.equals(Comandos.BORRAR_TIPO_ANTENA)) {
				// Se hace desde el popupmenu
			}

			// COMANDOS PARA MANEJAR CANALES

			else if (comando.equals(Comandos.AGREGAR_CANAL)) {
				ventanaCanal = new VentanaCanalFrecuencias(this,
						contenedorPrincipal);
				ventanaCanal.setVisible(true);
			} else if (comando.equals(Comandos.CONFIRMAR_AGREGAR_CANAL)) {
				this.agregarCanal(true);
			} else if (comando.equals(Comandos.EDITAR_CANAL)) {
				// canalSeleccionado = proyecto.getCanal(explorador
				// .getCanalSeleccionado());
				canalSeleccionado = (CanalFrecuencias) panelLateral.listaCanales
						.getSelectedValue();
				ventanaCanal = new VentanaCanalFrecuencias(canalSeleccionado,
						this, contenedorPrincipal, true);
				ventanaCanal.setVisible(true);
			} else if (comando.equals(Comandos.CONFIRMAR_EDITAR_CANAL)) {
				proyecto.borrarCanal(canalSeleccionado);
				this.agregarCanal(false);
			}

			else if (comando.equals(Comandos.BORRAR_CANAL)) {
				canalSeleccionado = proyecto.getCanal(explorador
						.getCanalSeleccionado());
				if (proyecto.canalEstaAsignado(canalSeleccionado.getNombre())) {
					JOptionPane
							.showMessageDialog(
									contenedorPrincipal,
									"No se puede borrar el canal "
											+ explorador.getCanalSeleccionado()
											+ " porque existen antenas que lo tienen asignado",
									"Eliminar", JOptionPane.WARNING_MESSAGE);
				} else {
					int opcionElegida = JOptionPane.showConfirmDialog(
							contenedorPrincipal,
							"¿ seguro que desea eliminar el canal "
									+ explorador.getCanalSeleccionado() + "?",
							"Eliminar", JOptionPane.OK_CANCEL_OPTION,
							JOptionPane.WARNING_MESSAGE);
					if (!(opcionElegida == JOptionPane.CANCEL_OPTION)) {
						proyecto.borrarCanal(canalSeleccionado);
						explorador.borrarCanal();
					}
				}
			}

			// COMANDOS PARA MANEJAR EL PERFIL DE USUARIO

			else if (comando.equals(Comandos.EDITAR_PERFIL)) {
				ventanaPerfil = new VentanaPerfilUsuario(
						proyecto.getPerfilUsuario(), this, contenedorPrincipal);
				ventanaPerfil.setVisible(true);
			} else if (comando.equals(Comandos.CONFIRMAR_EDITAR_PERFIL)) {
				proyecto.setPerfilUsuario(ventanaPerfil.getPerfil());
				ventanaPerfil.setVisible(false);
				ventanaPerfil.dispose();
			} else if (comando.equals("Sí")) {
				try {
					this.agregarCanalesPorDefecto();
					panelLateral.refrescarElementos(new CanalFrecuencias("o"),
							proyecto.getCanales());
					dialogCanales.setVisible(false);
				} catch (CanalMalDefinidoException e1) {
					e1.printStackTrace();
				}
			} else if (comando.equals("No")) {
				dialogCanales.setVisible(false);
			}

		} catch (Exception ex) {
			ex.printStackTrace(System.out);
			JOptionPane.showMessageDialog(contenedorPrincipal,
					"Error: \n" + ex.getMessage(), "Error",
					JOptionPane.WARNING_MESSAGE);
		}

	}

	// /****************************************************************************///////////////////////////////////

	/**
	 * Agrega un sitio al proyecto, puede ser uno nuevo o uno editado Actualiza
	 * el mapa y el explorador
	 * 
	 * @param nuevo
	 *            - si es un sitio nuevo o editado
	 * @throws Exception
	 */
	void agregarSitio(boolean nuevo) throws Exception {
		ventanaSitio.setSitio(sitioSeleccionado); // por si entre que puso
													// agregar sitio y dio
													// aceptar
													// agregó alguna
													// radiobase.
		Sitio sitioNuevo = ventanaSitio.getSitio();
		try {
			// agrego al proyecto, mapa y explorador
			proyecto.agregarSitio(sitioNuevo); // si el sitio repetido va
												// al catch
			contenedorMapa.getMapa().agregarSitio(sitioNuevo);
			panelLateral.refrescarElementos(sitioNuevo, proyecto.getSitios());
			// cierro la ventana
			this.sitioSeleccionado = new Sitio(sitioNuevo);
			ventanaSitio.setVisible(false);
			ventanaSitio.dispose();

		} catch (SitioRepetidoException ex) {
			JOptionPane.showMessageDialog(contenedorPrincipal, ex.getMessage(),
					"Sitio repetido", JOptionPane.WARNING_MESSAGE);
			if (!nuevo) {
				try {
					proyecto.agregarSitio(sitioSeleccionado);
					contenedorMapa.getMapa().agregarSitio(sitioSeleccionado);
				} catch (Exception e) {
					// si entró a editar y repitió el nombre del sitio o lo
					// puso
					// mal en el mapa, lo sacó antes de entrar a este método
					// y
					// por lo tanto
					// hay que volver a ponerlo (en ese caso no entra a esta
					// exception).
				}
			}
		} catch (SitioMalPosicionadoException ex2) {
			proyecto.borrarSitio(sitioNuevo); // Si caigo en esta excepción ya
												// agregué el sitio al
												// proyecto y
												// debo sacarlo
			JOptionPane.showMessageDialog(contenedorPrincipal,
					ex2.getMessage(), "Sitio mal ubicado",
					JOptionPane.WARNING_MESSAGE);
			if (!nuevo) {
				try {
					proyecto.agregarSitio(sitioSeleccionado);
					contenedorMapa.getMapa().agregarSitio(sitioSeleccionado);
				} catch (Exception e) {
					// si entró a editar y repitió el nombre del sitio o lo
					// puso
					// mal en el mapa, lo sacó antes de entrar a este método
					// y
					// por lo tanto
					// hay que volver a ponerlo (en ese caso no entra a esta
					// exception).
				}
			}
		}
	}

	/**
	 * Agrega una radiobase al sitio seleccionado, lo actualiza en el proyecto y
	 * en el explorador
	 * 
	 * @param nuevo
	 *            - si la radiobase a agregar es nueva o editada
	 */
	public void agregarRB(boolean nuevo) {
		try {
			ventanaRB.setRadiobase(rbSeleccionada); // si entre que entraron a
													// crear radiobase y dieron
													// aceptar agregaron
													// antenas.
			Radiobase rbNueva = ventanaRB.getRadiobase();
			sitioSeleccionado.agregarRB(rbNueva);

			if (ventanaSitio.isVisible()) {// agrego a la lista
				ventanaSitio.agregarRB(rbNueva.getNombre());
			} else {
				explorador.editarRB(rbNueva);
			}
			this.rbSeleccionada = new Radiobase(rbNueva);
			ventanaRB.setVisible(false);
			ventanaRB.dispose();

		} catch (RadiobaseRepetidaException e) {
			JOptionPane.showMessageDialog(contenedorPrincipal, e.getMessage(),
					"Error", JOptionPane.WARNING_MESSAGE);
			if (!nuevo) {
				try {
					if (ventanaSitio.isVisible())// agrego a la lista
						ventanaSitio.agregarRB(rbSeleccionada.getNombre());
					sitioSeleccionado.agregarRB(rbSeleccionada);
				} catch (RadiobaseRepetidaException ex) {
					// si entró a editar y repitió el nombre de la
					// radiobase, la
					// sacó antes de entrar a este método y por lo tanto
					// hay que volver a ponerla (en ese caso no entra a esta
					// exception).
				}
			}
		}
	}

	/**
	 * 
	 * Agrega una antena a la radiobase seleccionada, lo actualiza en el
	 * proyecto y en el explorador
	 * 
	 * @param nuevo
	 *            - si la antena es nueva o editada
	 */
	public void agregarAntena(boolean nuevo) {
		try {
			Antena nuevaAntena = ventanaAntena.getAntena();
			nuevaAntena.setTipo(proyecto.getTipoAntena(ventanaAntena
					.getTipoAntenaSeleccionada()));
			nuevaAntena.setModelo(proyecto.getModelo(ventanaAntena
					.getModeloSeleccionado()));
			// antenaSeleccionada.setFrecuencia(ventana.getFrecuencia()*1E6);
			// //como lo devuelve en Mhz, hay que pasarlo
			nuevaAntena.setCanal(proyecto.getCanal(ventanaAntena
					.getCanalSeleccionado()));

			rbSeleccionada.agregarAntena(nuevaAntena);
			if (ventanaRB.isVisible()) {
				ventanaRB.agregarAntena(nuevaAntena.getNombre());
			} else {// si viene desde popup
				explorador.renombrarAntena(nuevaAntena.getNombre());
			}
			this.antenaSeleccionada = nuevaAntena;
			ventanaAntena.setVisible(false);
			ventanaAntena.dispose();

		} catch (AntenaRepetidaException e) {
			JOptionPane.showMessageDialog(contenedorPrincipal, e.getMessage(),
					"Error", JOptionPane.WARNING_MESSAGE);
			if (!nuevo) {
				try {
					rbSeleccionada.agregarAntena(antenaSeleccionada);
					if (ventanaRB.isVisible())
						ventanaRB.agregarAntena(antenaSeleccionada.getNombre());
				} catch (AntenaRepetidaException ex) {
					// si entró a editar y repitió el nombre de la antena,
					// la
					// sacó antes de entrar a este método y por lo tanto
					// hay que volver a ponerla (en ese caso no entra a esta
					// exception).
				}
			}
		}
	}

	void agregarCanal(boolean nuevo) {
		try {
			CanalFrecuencias nuevoCanal = ventanaCanal.getCanal();
			proyecto.agregarCanal(nuevoCanal);
			if (!nuevo
					&& proyecto
							.canalEstaAsignado(canalSeleccionado.getNombre())) {
				proyecto.setearCanalEnAntenas(canalSeleccionado.getNombre(),
						nuevoCanal);
			}
			panelLateral.refrescarElementos(nuevoCanal, proyecto.getCanales());
			ventanaCanal.setVisible(false);
			ventanaCanal.dispose();
		} catch (CanalRepetidoException e) {
			JOptionPane.showMessageDialog(contenedorPrincipal, e.getMessage(),
					"Error", JOptionPane.WARNING_MESSAGE);
			if (!nuevo) {
				try {
					proyecto.agregarCanal(canalSeleccionado);
				} catch (CanalRepetidoException ex) {
					// si entró a editar y repitió el nombre del canal, lo
					// sacó
					// antes de entrar a este método y por lo tanto
					// hay que volver a ponerlo (en ese caso no entra a esta
					// exception).
				}
			}
		}
	}

	void agregarCanal(CanalFrecuencias nuevoCanal) {
		try {
			proyecto.agregarCanal(nuevoCanal);
			explorador.agregarCanal(nuevoCanal.getNombre());
		} catch (CanalRepetidoException e) {
			JOptionPane.showMessageDialog(contenedorPrincipal, e.getMessage(),
					"Error", JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Agrega un tipo nuevo de antena al proyecto, actualizandolo en el
	 * explorador
	 * 
	 */
	void agregarTipoAntena(boolean nuevo) {
		try {
			TipoAntena nuevoTipoAntena = ventanaTipoAntena.getTipoAntena();
			proyecto.agregarTipoAntena(nuevoTipoAntena);
			if (!nuevo
					&& proyecto.tipoEstaAsignado(tipoSeleccionado.getNombre())) {
				proyecto.setearTipoEnAntenas(tipoSeleccionado.getNombre(),
						nuevoTipoAntena);
			}

			panelLateral.refrescarElementos(nuevoTipoAntena,
					proyecto.getTiposAntena());
			ventanaTipoAntena.setVisible(false);
			ventanaTipoAntena.dispose();
		} catch (TipoAntenaRepetidaException e) {
			JOptionPane.showMessageDialog(contenedorPrincipal, e.getMessage(),
					"Error", JOptionPane.WARNING_MESSAGE);
			if (!nuevo) {
				try {
					proyecto.agregarTipoAntena(tipoSeleccionado);
				} catch (TipoAntenaRepetidaException ex) {
					// si entrï¿œ a editar y repitiï¿œ el nombre del tipo de
					// antena,
					// lo sacï¿œ antes de entrar a este mï¿œtodo y por lo tanto
					// hay que volver a ponerlo (en ese caso no entra a esta
					// exception).
				}
			}
		}
		contenedorPrincipal.revalidate(); // TODO: GM: Esto va? No estaba en v1.
	}

	/**
	 * Agrega un modelo al proyecto y actualiza el explorador
	 * 
	 */
	public void agregarModelo(boolean nuevo) {
		try {
			Modelo modeloNuevo = ventanaCrearModelo.getModelo();
			proyecto.agregarModelo(modeloNuevo);
			if (!nuevo
					&& proyecto.modeloEstaAsignado(modeloSeleccionado
							.getNombre())) {
				proyecto.setearModeloEnAntenas(modeloSeleccionado.getNombre(),
						modeloNuevo);
			}
			panelLateral.refrescarElementos(modeloNuevo, proyecto.getModelos());
			ventanaCrearModelo.setVisible(false);
			ventanaCrearModelo.dispose();
		} catch (ModeloRepetidoException e) {
			JOptionPane.showMessageDialog(contenedorPrincipal, e.getMessage(),
					"Error", JOptionPane.WARNING_MESSAGE);
			if (!nuevo) {
				try {
					proyecto.agregarModelo(modeloSeleccionado);
				} catch (ModeloRepetidoException ex) {
					// si entró a editar y repitió el nombre del modelo, lo
					// sacó
					// antes de entrar a este método y por lo tanto
					// hay que volver a ponerlo (en ese caso no entra a esta
					// exception).
				}
			}
		}
	}

	/**
	 * Ve que antenas n seleccionadas en ventanaPrediccion y realiza la
	 * predicción de ellas. Para ello, las junta en un array, y además toma los
	 * parámetros indicados en la interfaz y con eso crea una instancia de
	 * ThreadCalculaAtenuacion Ejecuta el método start() de dicho thread y luego
	 * (mediante la clase javax.swing.Timer) verifica cada cierto tiempo (100
	 * ms) en que estado se encuentra el calculo (usando métodos especificos de
	 * ThreadCalcularAtenuacion) y si el usuario canceló la predicción o si ya
	 * terminó. En el primer caso, utiliza terminar de ThreadCalcularAtenuacion
	 * para detener el thread y cierra la ventana. En el segundo caso, toma el
	 * PrediccionMultiAntena de ThreadCalcularAtenuacion y lo agrega a la capa
	 * resultados.
	 * 
	 */
	public void calcularAtenuacion(boolean los) {
		try {
			ArrayList antenasElegidas = this.ventanaPrediccion.getElegido();
			Antena[] antenas = new Antena[antenasElegidas.size()];
			ventanaPrediccion.estaProcesando(true);
			for (int j = 0; j < antenasElegidas.size(); j++) {
				ventanaPrediccion.setAntenaActual((String) antenasElegidas
						.get(j));
				String[] sitioRbNombre = ((String) antenasElegidas.get(j))
						.split("\\x2E"); // 2E es el ASCII del punto
				Antena antenaElegida = this.proyecto.getSitio(sitioRbNombre[0])
						.getRadiobase(sitioRbNombre[1])
						.getAntena(sitioRbNombre[2]);
				antenas[j] = antenaElegida;
				antenaElegida.resetearIndices();
			}

			tca = new ThreadCalculaAtenuacion(antenas, this.proyecto,
					this.contenedorMapa.getMapa(),
					ventanaPrediccion.getRadio(), 100.0,
					ventanaPrediccion.getPrecision(),
					ventanaPrediccion.getUsarInterpolacion());
			if (los)
				tca.setLos(true);
			tca.start();
			contador = new Timer(100, new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent evt) {
					if (!tca.seCancelo) {
						ventanaPrediccion.setAvance(tca.getCuantoVa());
						ventanaPrediccion.setAntenaActual(tca.getAntenaActual());
						if (tca.termino) {
							contador.stop();
							// PrediccionMultiAntena pma = tca.getPrediccion();
							try {
								prediccionActual = (PrediccionMultiAntena) tca
										.getPrediccion();
								// contenedorMapa.crearCapaResultados(pma);
								ventanaPrediccion.setVisible(false);
								ventanaPrediccion.dispose();
								if (!prediccionActual.getPredicciones()
										.isEmpty()) {
									contenedorMapa.crearCapaResultados(
											prediccionActual, proyecto);
									barraMenu.hayUnaPrediccion(true);
									toolbar.disablePredicciones();

									if (tca.getLos())
										contenedorMapa.quitarBarra();
								}
							} catch (PrediccionMalRealizadaException
									| ContenedorMapaException e) { // caso
								// en
								// que
								// todas
								// las
								// predicciones
								// son
								// null
								JOptionPane.showMessageDialog(new JDialog(),
										e.getMessage(), "Error",
										JOptionPane.WARNING_MESSAGE);
								e.printStackTrace();
							}
						} else if (ventanaPrediccion.cancelo) {
							int opcionElegida = JOptionPane.showConfirmDialog(
									contenedorPrincipal,
									"¿Desea cancelar la predicción en camino?",
									"predicción", JOptionPane.YES_NO_OPTION,
									JOptionPane.WARNING_MESSAGE);
							if (opcionElegida == JOptionPane.YES_OPTION) {
								tca.terminar();
								ventanaPrediccion.setVisible(false);
								ventanaPrediccion.dispose();
							} else {
								ventanaPrediccion.cancelo = false;
							}
						}
					} else {
						tca = null;
						contador.stop();
						System.gc(); // para que borre el tca
					}
				}
			});
			contador.start();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	/**
	 * Le presenta al usuario el seleccionador de archivos para que elija el
	 * directorio donde guardar la predicción. Luego guarda la Grilla de cada
	 * prediccionUniAntena de la PrediccionMultiAntena actual con el nombre de
	 * la antena en el directorio como el formato que elija el usuario.
	 * 
	 */
	public void guardarPrediccion() {
		try {
			String formatoElegido = (String) JOptionPane
					.showInputDialog(
							contenedorPrincipal,
							"Elija el formato con que desea guardar el/los archivo/s:\n",
							"Guardar Prediccion", JOptionPane.PLAIN_MESSAGE,
							null, Comandos.FORMATOS_GRIDS, "ArcInfo ASCII grid");
			if (!formatoElegido.equals(null)) {
				File directorio = archivos.guardarArchivo("", "",
						"Solo directorios");

				Iterator i = prediccionActual.getPredicciones().iterator();

				while (i.hasNext()) {
					PrediccionUniAntena prediccion = (PrediccionUniAntena) (i
							.next());
					String nombreAntena = prediccion.getNombreAntena();
					Grilla grilla = prediccion.getGrilla();
					EscritorFeatures.escribirGrilla(grilla, formatoElegido,
							directorio, nombreAntena);
				}
				proyecto.agregarLinkCapaResultados(directorio.toURL());
			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	/**
	 * Le muestra al usuario las predicciones guardadas hasta el momento. Luego
	 * intenta abrir las grillas que se encuentran en el directorio
	 * especificado. Luego busca la antena con el nombre del archivo donde el
	 * raster. Por último genera la PrediccionMultiAntena con los datos
	 * obtenidos y la pone en el contenedorMapa.
	 * 
	 */
	public void abrirPrediccion() {
		try {
			ArrayList predicciones = new ArrayList();
			this.prediccionActual = new PrediccionMultiAntena();

			Object[] listaPredicciones = proyecto.getLinksCapaResultados()
					.toArray();
			URL dirElegido = (URL) JOptionPane.showInputDialog(
					contenedorPrincipal,
					"Elija la prediccion que desea abrir:\n",
					"Abrir Prediccion", JOptionPane.PLAIN_MESSAGE, null,
					listaPredicciones, listaPredicciones[0]);

			File directorio = new File(dirElegido.getFile());

			if (directorio.isDirectory()) {

				File[] archivos = directorio.listFiles();

				for (int i = 0; i < archivos.length; i++) {
					String nombre = archivos[i].getName();
					Grilla grilla = LectorFeatures.leerAlturas(
							new URL(dirElegido.getProtocol(), dirElegido
									.getHost(), dirElegido.getPort(),
									dirElegido.getFile() + nombre),
							contenedorMapa.getMapa().getCoordinateSystem());

					String[] sitioRbNombre = archivos[i].getName().split(
							"\\x2E"); // 2E es el ASCII del punto

					Antena antena = proyecto.getSitio(sitioRbNombre[0])
							.getRadiobase(sitioRbNombre[1])
							.getAntena(sitioRbNombre[2]);

					PrediccionUniAntena prediccion = new PrediccionUniAntena(
							grilla, antena);
					prediccion.setMin(grilla.getMin()); // puede hacerlo pues
														// sé
														// que la grilla
														// devuelta por el
														// lector
					prediccion.setMax(grilla.getMax()); // tiene bien asignados
														// el máximo y el
														// mínimo.
					prediccionActual.agregarPrediccion(prediccion);
				}

				contenedorMapa.crearCapaResultados(prediccionActual,
						this.proyecto);
				barraMenu.hayUnaPrediccion(true);
				toolbar.disablePredicciones();

			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	/**
	 * Crea un nuevo proyecto
	 * 
	 */
	public void crearProyecto() {
		try {
			proyecto = ventanaProyecto.getProyecto();
			ventanaProyecto.setVisible(false);
			ventanaProyecto.dispose();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Este metodo guarda un proyecto en el formato xml
	 * 
	 */
	public void guardarProyectoaXML() {

		try {

			File archivo = archivos.guardarArchivo(proyecto.getNombre()
					+ ".xml", "xml", "Archivos xml");

			if (archivo != null) {
				OutputStream fout = null;
				if (archivo.toString().endsWith(".xml")) {
					fout = new FileOutputStream(archivo);
				} else {
					fout = new FileOutputStream(archivo + ".xml");
				}
				OutputStream bout = new BufferedOutputStream(fout);
				OutputStreamWriter out = new OutputStreamWriter(bout, "UTF-8");// "8859_1");

				out.write("<?xml version=\"1.0\"?>\r\n");
				out.write(proyecto.getXML());
				out.flush();

				this.proyecto.fueGuardado();
			}
		}

		catch (UnsupportedEncodingException e) {
			System.out
					.println("This VM does not support the Latin-1 character set.");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Se redefine la variable proyecto con el proyecto que se crea a partir del
	 * archivo elegido
	 * 
	 */
	public void leerProyecto() {
		try {
			String[] formatos = { "Archivo xml" };
			String[] extensiones = new String[] { "xml" };
			archivos = new Archivos();
			File archivo = archivos.abrirArchivo(extensiones[0], "xml");
			if (archivo == null) {
				proyecto = null;
			} else {
				proyecto = ArchivosXML.leerProyectoXmlSAX(archivo);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Se cierra la ventana principal
	 * 
	 */
	private void salir() {
		contenedorPrincipal.setVisible(false);
		contenedorPrincipal.dispose();
		System.exit(0);
	}

	public void resetVentana() throws Exception {
		explorador = new TabsExplorador(this);
		contenedorMapa = new ContenedorMapa(this);
		// TODO gg
		scrollMapa = contenedorMapa.createScrollPane();
		contenedor = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, explorador,
				scrollMapa);
		contenedor.setContinuousLayout(true);
		contenedor.setDividerSize(2);
		contenedor.setDividerLocation(tamanoPanelIzquiera);
		barraMenu = new BarraMenu(this);
		barraInferior = new BarraInferior();
	}

	private void agregarCanalesPorDefecto() throws CanalMalDefinidoException {
		ArrayList canal28 = new ArrayList();
		canal28.add(557.0);
		this.agregarCanal(new CanalFrecuencias("Canal 28", canal28));
		ArrayList canal29 = new ArrayList();
		canal29.add(563.0);
		this.agregarCanal(new CanalFrecuencias("Canal 29", canal29));
		ArrayList canal30 = new ArrayList();
		canal30.add(569.0);
		this.agregarCanal(new CanalFrecuencias("Canal 30", canal30));
		ArrayList canal31 = new ArrayList();
		canal31.add(575.0);
		this.agregarCanal(new CanalFrecuencias("Canal 31", canal31));
		ArrayList canal38 = new ArrayList();
		canal38.add(617.0);
		this.agregarCanal(new CanalFrecuencias("Canal 38", canal38));
		ArrayList canal39 = new ArrayList();
		canal39.add(623.0);
		this.agregarCanal(new CanalFrecuencias("Canal 39", canal39));
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {

	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

	class mostrarFrog extends AbstractAction {

		@Override
		public void actionPerformed(ActionEvent e) {
			mostrarFrog();
		}
	}

	public void mostrarFrog() {
		JDialog dialogo = new JDialog();
		JLabel label = new JLabel(
				"<html><img src='file:res/frog.gif' alt='Nuevo Proyecto' height='280' width='398'></html>");
		dialogo.add(label);
		dialogo.pack();
		dialogo.setLocationRelativeTo(null);
		dialogo.setVisible(true);
	}

	public JFrame frogDeBienvenida() {
		JFrame dialogo = new JFrame();
		dialogo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel label = new JLabel(
				"<html><img src='file:res/frog.gif' alt='Iniciando SAPO v2.0' height='280' width='398'><p align=\"center\">SAPO v2.0 'Michigan' - Análisis de Propagación Outdoor<br>Iniciando...</p></html>");
		dialogo.add(label);
		dialogo.pack();
		dialogo.setLocationRelativeTo(null);
		return dialogo;
	}

	private class MyDispatcher implements KeyEventDispatcher {
		int i;
		char[] codigo = { 'm', 'i', 'c', 'h', 'i', 'g', 'a', 'n' };
		long tiempo;
		long taux;

		@Override
		public boolean dispatchKeyEvent(KeyEvent e) {
			char tecla;

			if (e.getID() == KeyEvent.KEY_TYPED) {

				tecla = e.getKeyChar();
				taux = System.currentTimeMillis();
				if (taux - tiempo > 500) {
					i = 0;
				}
				System.out.println(taux - tiempo);
				tiempo = taux;

				if (tecla == codigo[i]) {
					i++;
					if (i == codigo.length) {
						mostrarFrog();
						i = 0;
					}
				}
			}
			return false;
		}

		public MyDispatcher() {
			i = 0;
			tiempo = System.currentTimeMillis();
		}

	}
}