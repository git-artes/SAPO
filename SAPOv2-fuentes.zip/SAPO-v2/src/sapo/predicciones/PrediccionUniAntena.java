package sapo.predicciones;

import sapo.raster.Grilla;
import sapo.red.Antena;

/**
 * Esta clase representa los resultados de predicción de atenuación para un
 * única antena.
 * 
 * @author Grupo de proyecto SAPO
 */
public class PrediccionUniAntena {

	/**
	 * 
	 * Grilla donde se guardan los valores de la predicción.
	 * 
	 */

	Grilla grillaResultados;

	/**
	 * Nombre de la antena con la que fue realizada la predicción, nombre
	 * completo que incluye el nombre de la radiobase y el sitio.
	 */

	String nombreAntena;

	/**
	 * 
	 * La antena con la que se realizó la predicción.
	 * 
	 */

	Antena antena;

	double maximo = -27;// 120;//120;

	double minimo = -61;// 60;//60;

	public PrediccionUniAntena(Grilla g, Antena antena) {
		grillaResultados = g;
		this.nombreAntena = antena.getSitio() + "." + antena.getRB() + "."
				+ antena.getNombre();
		this.antena = antena;
	}

	public Grilla getGrilla() {
		return grillaResultados;
	}

	public Antena getAntena() {
		return this.antena;
	}

	public String getNombreAntena() {
		return this.nombreAntena;
	}

	/**
	 * El máximo valor de la grilla. Se utiliza únicamente para visualización
	 * pues se mostraran solo aquellos valores que no superen este valor.
	 * 
	 * @param max
	 */
	public void setMax(double max) {
		maximo = max;
	}

	/**
	 * El mínimo valor de la grilla. Se utiliza únicamente para visualización
	 * pues se mostrarán solo aquellos valores que no sean menores que este
	 * valor.
	 * 
	 * @param min
	 */
	public void setMin(double min) {
		minimo = min;
	}

	public double getMax() {
		return maximo;
	}

	public double getMin() {
		return minimo;
	}

}
