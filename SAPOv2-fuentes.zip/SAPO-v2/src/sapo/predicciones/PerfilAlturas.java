package sapo.predicciones;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Esta clase representa un perfil de alturas (alturas de los obstáculos y
 * separación entre ellos). El primer y último elemento representan el
 * transmisor (o receptor) y receptor (o transmisor) respectivamente.
 * 
 * @author Grupo de proyecto SAPO
 */
public class PerfilAlturas {

	/**
	 * Alturas de los obstáculos
	 * 

	 */

	protected ArrayList alturas;

	/**
	 * Separación entre los obstáculos (la posición n-ésima indica la separación
	 * entre los obstáculos n y n+1)
	 * 

	 */

	protected ArrayList separaciones;

	/**
	 * Inicializa los contenedores con la altura inicial especificada.
	 * 
	 * @param alturaInicial
	 */
	public PerfilAlturas(double alturaInicial) {
		alturas = new ArrayList();
		alturas.add(new Double(alturaInicial));
		separaciones = new ArrayList();
	}

	/**
	 * Crea un pefil con las dos alturas especificadas y una separación entre
	 * ellas.
	 * 
	 * @param altura1
	 * @param altura2
	 * @param separacion
	 */
	public PerfilAlturas(double altura1, double altura2, double separacion) {
		alturas = new ArrayList();
		alturas.add(new Double(altura1));
		alturas.add(new Double(altura2));
		separaciones = new ArrayList();
		separaciones.add(new Double(separacion));
	}

	/**
	 * Agrega el obstáculo con altura al perfil en el último lugar separado
	 * separación del obstáculo anterior.
	 * 
	 * @param altura
	 * @param separacion
	 */
	public void agregarObstaculo(double altura, double separacion) {
		alturas.add(new Double(altura));
		separaciones.add(new Double(separacion));
	}

	/**
	 * Agrega un elemento al perfil a una distanciaAlPrimero del primer
	 * elemento. En caso de ser negativa la distancia, agrega el elemento al
	 * principio del perfil. Si distanciaAlPrimero coincide con una altura ya
	 * presente, se pone el valor más alto entre el nuevo valor y el ya
	 * presente.
	 * 
	 * @param altura
	 * @param distanciaAlPrimero
	 */
	public void agregarObstaculoRelativo(double altura,
			double distanciaAlPrimero) {
		int contador = 0;
		double distanciaRecorrida = 0;
		while (distanciaRecorrida < distanciaAlPrimero
				&& contador < separaciones.size()) {
			distanciaRecorrida += ((Double) separaciones.get(contador))
					.doubleValue();
			contador++;
		}
		if (Math.abs(distanciaRecorrida) == Math.abs(distanciaAlPrimero)) { //el
																			// abs
																			// es
																			// porque
																			// a
																			// veces
																			// la
																			// distancia
																			// viene
																			// como
																			// -0,0d
			double alturaVieja = ((Double) alturas.get(contador)).doubleValue();
			if (altura < alturaVieja) {
				alturas.remove(contador);
				alturas.add(contador, new Double(altura));
				return;
			}
		}
		if (contador > 0) {
			double distanciaAlSiguiente = distanciaRecorrida
					- distanciaAlPrimero;
			distanciaRecorrida -= ((Double) separaciones.get(contador - 1))
					.doubleValue();
			separaciones.remove(contador - 1);
			separaciones.add(contador - 1, new Double(distanciaAlPrimero
					- distanciaRecorrida));
			separaciones.add(contador, new Double(distanciaAlSiguiente));
			alturas.add(contador, new Double(altura));
		} else {
			separaciones.add(0, new Double(-distanciaAlPrimero));
			alturas.add(0, new Double(altura));
		}
	}

	/**
	 * Devuelve un array conteniendo las alturas.
	 * 

	
	 */
	public double[] getAlturas() {
		double[] arrayAlturas = new double[this.alturas.size()];
		for (int j = 0; j < arrayAlturas.length; j++) {
			arrayAlturas[j] = ((Double) alturas.get(j)).doubleValue();
		}
		return arrayAlturas;
	}

	/**
	 * Devuelve un array conteniendo todas las separaciones del perfil.
	 * 

	 
	 */
	public double[] getSeparaciones() {
		double[] arraySeparaciones = new double[this.separaciones.size()];
		for (int j = 0; j < arraySeparaciones.length; j++) {
			arraySeparaciones[j] = ((Double) separaciones.get(j)).doubleValue();
		}
		return arraySeparaciones;
	}

	/**
	 * Quita el receptor del perfil. Se usa para el modelo de Vogler-Ikegami.
	 *  
	 */
	public void sacarReceptor() {
		this.alturas.remove(alturas.size() - 1);
		this.separaciones.remove(separaciones.size() - 1);
	}

	/**
	 * 
	 * Devuelve si el perfil está vacío o no. Esto es si no tiene datos de
	 * separaciones.
	 * 

	 *  
	 */

	public boolean esVacia() {
		return this.separaciones.isEmpty();
	}

	/**
	 * 
	 * Devuelve si el perfil contiene obstáculos (o sea, datos de altura y
	 * separación de otra cosa que no sean el transmisor y el receptor).
	 * 

	 *  
	 */

	public boolean tieneObstaculos() {
		return this.separaciones.size() > 1;
	}

	/**
	 * 
	 * Devuelve la altura promedio del perfil.
	 * 

	 *  
	 */

	public double alturaPromedio() {
		double promedio = 0;
		Iterator it = alturas.iterator();
		while (it.hasNext()) {
			promedio += ((Double) it.next()).doubleValue();
		}
		return promedio / alturas.size();
	}

	/**
	 * 
	 * Devuelve la altura promedio de los obstáculos únicamente (es decir,
	 * ignora los datos en los extremos).
	 * 

	 *  
	 */

	public double alturaPromedioObstaculos() {
		if (!this.tieneObstaculos())
			return Double.NaN;
		double promedio = 0;
		for (int j = 1; j < this.alturas.size() - 1; j++) {
			promedio += ((Double) this.alturas.get(j)).doubleValue();
		}
		return promedio / (this.alturas.size() - 2);
	}

	/**
	 * 
	 * Devuelve la separación promedio.
	 * 
	 * @return - Double.NaN si no hay al menos un obstáculo.
	 *  
	 */

	public double separacionPromedio() {
		double promedio = 0;
		Iterator it = separaciones.iterator();
		while (it.hasNext()) {
			promedio += ((Double) it.next()).doubleValue();
		}
		return promedio / separaciones.size();
	}

	/**
	 * 
	 * Devuelve la separación promedio entre obstáculos únicamente (es decir,
	 * ignora los datos de los extremos)
	 * 
	 * @return - Double.NaN si hay menos de dos obstáculos.
	 *  
	 */

	public double separacionPromedioObstaculos() {
		if (this.separaciones.size() <= 2)
			return Double.NaN;
		double promedio = 0;
		for (int j = 1; j < this.separaciones.size() - 1; j++) {
			promedio += ((Double) this.separaciones.get(j)).doubleValue();
		}
		return promedio / (this.separaciones.size() - 2);
	}

	@Override
	public String toString() {
		return "alturas:\n " + this.alturas + "\n separaciones: \n"
				+ this.separaciones;
	}

}
