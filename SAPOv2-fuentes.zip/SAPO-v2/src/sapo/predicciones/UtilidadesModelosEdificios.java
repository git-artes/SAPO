package sapo.predicciones;

import java.awt.geom.Point2D;

import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureCollections;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.MultiPolygon;
import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.operation.buffer.BufferOp;
import com.vividsolutions.jts.operation.distance.DistanceOp;

/**
 * Esta clase equivale al UtilidadesModelos pero tomando en cuenta la existencia
 * de las edificaciones. Agrega algunas funcionalidades.
 * 
 * @author Grupo de proyecto SAPO
 */
public class UtilidadesModelosEdificios extends UtilidadesModelos {

	FeatureCollection fc;

	GeometryFactory gf;

	Point antena;

	String altura;

	double alturaAntena;

	Geometry ultimoEdificio;

	Coordinate[] ultimaPared;

	GeneraElipses ge;

	/**
	 * Se crea una nueva instancia de esta clase. En vez de tomar en cuenta
	 * todos los edificios presentes en la capa correspondiente, se toman en
	 * cuenta únicamente aquellos que estén a menos de radio de antena.
	 * 
	 * @param gc 
	 *            El gridCoverage con las alturas.
	 * @param fc 
	 *            Una featurecollection con los edificios.
	 * @param radio -
	 *            El radio del círculo donde se consideraran los edificios.
	 * @param antena 
	 *            El centro del círculo.
	 * @param altura 
	 *            Un string que indica el nombre del attribute de los features
	 *            que indica la altura del edificio.
	 */
	public UtilidadesModelosEdificios(GridCoverage gc, FeatureCollection fc,
			double radio, Point2D.Double antena, String altura) {
		super(gc);
		this.ge = new GeneraElipses();
		this.fc = FeatureCollections.newCollection();
		this.altura = altura;
		gf = new GeometryFactory();
		FeatureIterator fi = fc.features();
		this.antena = gf.createPoint(new Coordinate(antena.x, antena.y));
		BufferOp bo = new BufferOp(this.antena);
		bo.setEndCapStyle(BufferOp.CAP_ROUND);
		Geometry circulo = bo.getResultGeometry(radio);
		Geometry edificio;
		Feature featEdif;
		double[] alturaAntena = new double[1];
		alturaAntena = this.gc.evaluate(antena, alturaAntena);
		this.alturaAntena = alturaAntena[0];

		featEdif = fi.next();
		ultimaPared = this.getParedes(featEdif)[0];
		edificio = featEdif.getDefaultGeometry();
		try {
			do {
				if (circulo.contains(edificio) || circulo.intersects(edificio)) {
					this.fc.add(featEdif);
				}
				if (edificio.contains(gf.createPoint(new Coordinate(antena.x,
						antena.y)))) {
					this.alturaAntena += ((Double) featEdif
							.getAttribute(altura)).doubleValue();
				}
				featEdif = fi.next();
				edificio = featEdif.getDefaultGeometry();
			} while (fi.hasNext());
		} catch (java.util.NoSuchElementException e) {
			//esto solo pasa cuando tenés un solo edificio
		}
		//me fijo en el último
		if (circulo.contains(edificio) || circulo.intersects(edificio)) {
			this.fc.add(featEdif);
		}
		if (edificio.contains(gf
				.createPoint(new Coordinate(antena.x, antena.y)))) {
			this.alturaAntena += ((Double) featEdif.getAttribute(altura))
					.doubleValue();
		}
		ultimoEdificio = edificio;

	}

	/**
	 * Devuelve la altura del terreno más el del edificio donde está la antena
	 * especificada en el constructor.
	 * 

	 */

	public double getAlturaAntena() {
		return this.alturaAntena;
	}

	/**
	 * Devuelve la altura del edificio donde se encuentra el móvil.

	 */
	public double getAlturaEdificioAntena() {
		double[] alturaTerreno = new double[1];
		alturaTerreno = this.gc.evaluate(new Point2D.Double(antena.getX(),
				antena.getY()), alturaTerreno);
		return this.alturaAntena - alturaTerreno[0];
	}

	/**
	 * Estima si la primera elipse de fresnel está libre de obstáculos
	 * (únicamente se toman en cuenta las edificaciones). Para ello, se proyecta
	 * en los tres planos y se verifica la presencia de obstáculos en ellos.
	 * 
	 * @param ls 
	 *            LineString que indica las coordenadas de la antena y el móvil.
	 * @param frecuencia 
	 *            La frecuencia en Hz.
	 * @param alturas 
	 *            Las alturas (absolutas, o sea, terreno más edificación más
	 *            torre en caso de la antena) de la antena y del móvil en el
	 *            mismo orden que aparecen en ls.
	 * @return true en caso que en la primera elipse de fresnel no haya
	 *         obstáculos.
	 */
	public boolean librePrimerFresnelExacto(LineString ls, double frecuencia,
			double[] alturas) {

		Point antena = ls.getPointN(0);
		Point movil = ls.getPointN(1);
		if (ultimoEdificio.contains(movil)) {
			return false;
		}

		double radioFresnel = (Modelo.C / frecuencia) / 2.0;
		double alfa = Math.atan((movil.getX() - antena.getX())
				/ (movil.getY() - antena.getY()));
		double cosAlfa = Math.cos(alfa);
		double sinAlfa = Math.sin(alfa);
		double beta = -Math.atan((alturas[1] - alturas[0])
				/ ((movil.getX() - antena.getX()) * Math.sin(alfa) + (movil
						.getY() - antena.getY())
						* Math.cos(alfa)));
		double cosBeta = Math.cos(beta);
		double sinBeta = Math.sin(beta);
		double c = Math.sqrt(Math.pow(movil.getX() - antena.getX(), 2)
				+ Math.pow(movil.getY() - antena.getY(), 2)
				+ Math.pow(alturas[1] - alturas[0], 2)) / 2.0;
		double a = c + radioFresnel / 2.0;
		double b = Math.sqrt(Math.pow(a, 2) - Math.pow(c, 2));
		double x0 = -(movil.getX() + antena.getX()) / 2.0;
		double y0 = -(movil.getY() + antena.getY()) / 2.0;
		double z0 = -(alturas[0] + alturas[1]) / 2.0;

		if (!this.interseccionEdificio(ultimaPared, x0, y0, z0, sinAlfa,
				cosAlfa, sinBeta, cosBeta, a, b))
			return false;

		BufferOp bo = new BufferOp(ls);
		bo.setEndCapStyle(BufferOp.CAP_SQUARE);
		//un rectángulo cuyo ancho es el radio de fresnel en el medio del
		// segmento.
		double distanciaReal = Math.sqrt(Math.pow(alturas[0] - alturas[1], 2)
				+ Math.pow(ls.getLength(), 2));
		Geometry rectangulo = bo.getResultGeometry(Math.sqrt(radioFresnel
				* distanciaReal / 2.0));
		Geometry edificio;
		Feature featureEdificio;
		FeatureIterator fi = this.fc.features();

		Coordinate[][] paredes;

		while (fi.hasNext()) {
			featureEdificio = fi.next();
			edificio = featureEdificio.getDefaultGeometry();
			//Si el móvil está en el edificio, no va a tener línea de vista.
			if (edificio.contains(movil)) {
				ultimoEdificio = edificio;
				return false;
			}
			if (rectangulo.intersects(edificio)) {
				paredes = this.getParedes(featureEdificio);
				for (int i = 0; i < paredes.length; i++) {
					if (!this.interseccionEdificio(paredes[i], x0, y0, z0,
							sinAlfa, cosAlfa, sinBeta, cosBeta, a, b)) {
						ultimaPared = paredes[i];
						return false;
					}
				}
			}
		}
		return true;
	}

	/**
	 * Toma un edificio y devuelve un array de arrays de coordenadas (x,y,z)
	 * conteniendo en cada fila las cuatro coordenadas de una pared del
	 * edificio. Los dos primeros tienen la parte baja y las otras dos tienen la
	 * parte alta.
	 * 

	 */
	public Coordinate[][] getParedes(Feature edificio) {
		Polygon edif = (Polygon) ((MultiPolygon) edificio.getDefaultGeometry())
				.getGeometryN(0);
		Coordinate puntoEnEdificio = edif.getCoordinate();
		double[] alturaRelativaEdificio = new double[1];
		alturaRelativaEdificio = this.gc.evaluate(new CoordinatePoint(
				puntoEnEdificio.x, puntoEnEdificio.y), alturaRelativaEdificio);
		double altura = ((Double) edificio.getAttribute(this.altura))
				.doubleValue();
		double alturaTotalEdificio = altura + alturaRelativaEdificio[0];
		Coordinate[][] paredes = new Coordinate[edif.getNumPoints() - 1][4];
		Coordinate[] coordenadas = edif.getCoordinates();

		for (int j = 0; j < paredes.length; j++) {
			paredes[j] = new Coordinate[] {
					new Coordinate(coordenadas[j].x, coordenadas[j].y, 0),
					new Coordinate(coordenadas[j + 1].x, coordenadas[j + 1].y,
							0),
					new Coordinate(coordenadas[j + 1].x, coordenadas[j + 1].y,
							alturaTotalEdificio),
					new Coordinate(coordenadas[j].x, coordenadas[j].y,
							alturaTotalEdificio) };
		}
		return paredes;

	}

	/**
	 * Calcula la altura promedio de las edificaciones circundantes al movil a
	 * menos de radio de distancia (la altura incluye la altura del terreno)
	 *
	 */
	public double alturaPromedio(Point movil, double radio) {
		BufferOp bo = new BufferOp(movil);
		bo.setEndCapStyle(BufferOp.CAP_ROUND);
		Geometry circulo = bo.getResultGeometry(radio);
		Geometry edificio;
		Feature featEdif;
		double[] alturaRelativa = new double[1];
		FeatureIterator fi = this.fc.features();

		featEdif = fi.next();
		edificio = featEdif.getDefaultGeometry();
		double alturaTotal = 0;
		double contador = 0;
		Coordinate puntoEnEdificio;
		do {
			if (circulo.contains(edificio) || circulo.intersects(edificio)) {
				contador++;
				puntoEnEdificio = edificio.getCoordinate();
				alturaRelativa = this.gc.evaluate(new CoordinatePoint(
						puntoEnEdificio.x, puntoEnEdificio.y), alturaRelativa);
				alturaTotal += ((Double) featEdif.getAttribute(this.altura))
						.doubleValue()
						+ alturaRelativa[0];
			}
			featEdif = fi.next();
			edificio = featEdif.getDefaultGeometry();
		} while (fi.hasNext());
		if (contador != 0) {
			return alturaTotal / contador;
		} else {
			return 0;
		}
	}

	/**
	 * Verifica si la figura representada por pared corta o no la elipsoide.

	 */
	boolean interseccionEdificio(Coordinate[] pared, double x0, double y0,
			double z0, double sinAlfa, double cosAlfa, double sinBeta,
			double cosBeta, double a, double b) {
		double gama;
		double cosGama;
		double sinGama;
		double m, n;
		double j, k;
		double aE, bE;
		double aExz, bExz;
		Point centroXY, centroXZ;
		Polygon paredRotadaXY, paredRotadaXZ;
		double A, C, E, G;
		double Axz, Cxz, Exz, Gxz;
		double x, y, z;
		double comparacion;

		m = (pared[0].y - pared[1].y) / (pared[0].x - pared[1].x);
		if (!Double.isInfinite(m)) {
			n = pared[0].y - m * pared[0].x + y0 - m * x0;
			gama = -Math.atan((m * cosAlfa + sinAlfa)
					/ ((-m * sinAlfa + cosAlfa) * sinBeta));
			cosGama = Math.cos(gama);
			sinGama = Math.sin(gama);
			j = n / (m * m + 1) * cosBeta * (-m * sinAlfa + cosAlfa);
			k = n
					/ (m * m + 1)
					* (sinGama * (-m * cosAlfa - sinAlfa) + cosGama * sinBeta
							* (-m * sinAlfa + cosAlfa));
		} else {
			n = pared[0].x + x0;
			gama = Math.atan(cosAlfa / (sinAlfa * sinBeta));
			cosGama = Math.cos(gama);
			sinGama = Math.sin(gama);
			j = (n * sinAlfa * cosBeta);
			k = sinGama * n * cosAlfa + cosGama * n * sinAlfa * sinBeta;
		}
		if (Math.pow(a * j, 2) + Math.pow(b * k, 2) > Math
				.pow(j * j + k * k, 2)) { //si el plano corta la elipsoide
			Coordinate[] coordenadasXY = new Coordinate[5];
			Coordinate[] coordenadasXZ = new Coordinate[5];
			for (int cont = 0; cont < 4; cont++) {
				x = pared[cont].x + x0;
				y = pared[cont].y + y0;
				z = pared[cont].z + z0;
				coordenadasXY[cont] = new Coordinate(
						cosGama
								* (x * cosAlfa - y * sinAlfa)
								- sinGama
								* ((x * sinAlfa + y * cosAlfa) * sinBeta + z
										* cosBeta), (x * sinAlfa + y * cosAlfa)
								* cosBeta - z * sinBeta);
				coordenadasXZ[cont] = new Coordinate(
						cosGama
								* (x * cosAlfa - y * sinAlfa)
								- sinGama
								* ((x * sinAlfa + y * cosAlfa) * sinBeta + z
										* cosBeta), sinGama
								* (x * cosAlfa - y * sinAlfa)
								+ cosGama
								* ((x * sinAlfa + y * cosAlfa) * sinBeta + z
										* cosBeta));
			}
			coordenadasXY[4] = coordenadasXY[0];
			coordenadasXZ[4] = coordenadasXZ[0];
			double tgCapa = (coordenadasXZ[0].y - coordenadasXZ[1].y)
					/ (coordenadasXY[0].y - coordenadasXY[1].y);

			if (Math.abs(-j / k) < 1) {
				centroXY = gf.createPoint(new Coordinate(0, j * (j * j + k * k)
						/ (k * k * b * b / Math.pow(a, 2) + j * j)));
				A = k * k / (j * j + k * k);
				C = (k * k * b * b / (a * a) + j * j) / (j * j + k * k);
				E = -2 * j;
				G = j * j + k * k - k * k * b * b / (j * j + k * k);
				aE = Math.sqrt((E * E / (4 * C) - G) / A);
				bE = Math.sqrt(E * E - 4 * C * G) / (2 * C);
				//TODO revisar casos extremos
				paredRotadaXY = gf.createPolygon(gf
						.createLinearRing(coordenadasXY), null);
				if (paredRotadaXY.intersects(this.ge.crearElipse(centroXY, aE,
						bE, 0.0, 5))) {
					return false;
				}
			} else {
				centroXZ = gf.createPoint(new Coordinate(0, k * (j * j + k * k)
						/ (j * j * a * a / (b * b) + k * k)));
				Axz = j * j * a * a / (b * b * (j * j + k * k));
				Cxz = Axz + k * k / (j * j + k * k);
				Exz = -2 * k;
				Gxz = j * j + k * k - j * j * a * a / (j * j + k * k);
				aExz = Math.sqrt((Exz * Exz / (4 * Cxz) - Gxz) / Axz);
				bExz = Math.sqrt(Exz * Exz - 4 * Cxz * Gxz) / (2 * Cxz);
				paredRotadaXZ = gf.createPolygon(gf
						.createLinearRing(coordenadasXZ), null);
				//centroXZ = gf.createPoint(new Coordinate(0, -Exz/(2*Cxz)));
				if (paredRotadaXZ.intersects(this.ge.crearElipse(centroXZ,
						aExz, bExz, 0.0, 5))) {
					return false;
				}
			}

		}

		return true;
	}

	/**
	 * Halla el perfil entre los puntos definidos en ls (primero la antena
	 * transmisora, luego la receptora). Para ello primero se fija cuáles
	 * paredes se introducen en el elipsoide de fresnel (con radio el primer
	 * radio de fresnel por el valor de porcentaje), luego busca el punto más
	 * cercano de dicha pared a ls y ese punto es el que toma para el perfil.
	 * 
	 * @param ls 
	 *            linestring con la posición de la antena y el móvil en ese
	 *            orden
	 * @param frecuencia
	 * @param alturas
	 * @param porcentaje 
	 *            valor entre 0 y 1 que indica cuánto porcentaje del radio de
	 *            fresnel tomar (recomendado: 0.5).
	 * @return
	 */
	public PerfilAlturas hallarPerfilDeParedes(LineString ls,
			double frecuencia, double[] alturas, double porcentaje) {

		Point antena = ls.getPointN(0);
		Point movil = ls.getPointN(1);
		if (ultimoEdificio.contains(movil)) {
			return new PerfilAlturas(0);
		}

		double radioFresnel = porcentaje * (Modelo.C / frecuencia) / 2.0;
		double alfa = Math.atan((movil.getX() - antena.getX())
				/ (movil.getY() - antena.getY()));
		double cosAlfa = Math.cos(alfa);
		double sinAlfa = Math.sin(alfa);
		double beta = -Math.atan((alturas[1] - alturas[0])
				/ ((movil.getX() - antena.getX()) * Math.sin(alfa) + (movil
						.getY() - antena.getY())
						* Math.cos(alfa)));
		double cosBeta = Math.cos(beta);
		double sinBeta = Math.sin(beta);
		double c = Math.sqrt(Math.pow(movil.getX() - antena.getX(), 2)
				+ Math.pow(movil.getY() - antena.getY(), 2)
				+ Math.pow(alturas[1] - alturas[0], 2)) / 2.0;
		double a = c + radioFresnel / 2.0;
		double b = Math.sqrt(Math.pow(a, 2) - Math.pow(c, 2));
		double x0 = -(movil.getX() + antena.getX()) / 2.0;
		double y0 = -(movil.getY() + antena.getY()) / 2.0;
		double z0 = -(alturas[0] + alturas[1]) / 2.0;

		BufferOp bo = new BufferOp(ls);
		bo.setEndCapStyle(BufferOp.CAP_SQUARE);
		//un rectángulo cuyo ancho es el radio de fresnel en el medio del
		// segmento.
		double distanciaReal = Math.sqrt(Math.pow(alturas[0] - alturas[1], 2)
				+ Math.pow(ls.getLength(), 2));
		Geometry rectangulo = bo.getResultGeometry(Math.sqrt(radioFresnel
				* distanciaReal / 2.0));
		Geometry edificio;
		Feature featureEdificio;
		FeatureIterator fi = this.fc.features();

		Coordinate[][] paredes;
		PerfilAlturas perfilRetorno = new PerfilAlturas(alturas[0], alturas[1],
				ls.getLength());
		boolean intersecciono = false;
		GeometryFactory gf = new GeometryFactory();

		while (fi.hasNext()) {
			featureEdificio = fi.next();
			edificio = featureEdificio.getDefaultGeometry();
			//Si el móvil está en el edificio, no va a tener línea de vista.
			if (edificio.contains(movil)) {
				ultimoEdificio = edificio;
				return new PerfilAlturas(0);
			}
			if (rectangulo.intersects(edificio)) {
				paredes = this.getParedes(featureEdificio);
				for (int i = 0; i < paredes.length; i++) {
					if (!this.interseccionEdificio(paredes[i], x0, y0, z0,
							sinAlfa, cosAlfa, sinBeta, cosBeta, a, b)) {
						LineString pared = gf
								.createLineString(new Coordinate[] {
										paredes[i][0], paredes[i][1] });
						DistanceOp dop = new DistanceOp(pared, ls);
						Coordinate puntoCercanoLinea = dop.closestPoints()[1];
						double distancia = ls.getPointN(0).distance(
								gf.createPoint(puntoCercanoLinea));
						perfilRetorno.agregarObstaculoRelativo(paredes[i][3].z,
								distancia);
						intersecciono = true;
					}
				}
			}
		}

		if (!intersecciono)
			return new PerfilAlturas(0);
		return perfilRetorno;
	}

	/**
	 * Exactamente igual a hallarPerfilDeParedes pero se promedian los puntos de
	 * cada edificio para formar un único punto del perfil.
	 * 

	 */
	public PerfilAlturas hallarPerfilDeEdificios(LineString ls,
			double frecuencia, double[] alturas, double porcentaje) {

		Point antena = ls.getPointN(0);
		Point movil = ls.getPointN(1);
		if (ultimoEdificio.contains(movil)) {
			return new PerfilAlturas(0);
		}

		double radioFresnel = porcentaje * (Modelo.C / frecuencia) / 2.0;
		double alfa = Math.atan((movil.getX() - antena.getX())
				/ (movil.getY() - antena.getY()));
		double cosAlfa = Math.cos(alfa);
		double sinAlfa = Math.sin(alfa);
		double beta = -Math.atan((alturas[1] - alturas[0])
				/ ((movil.getX() - antena.getX()) * Math.sin(alfa) + (movil
						.getY() - antena.getY())
						* Math.cos(alfa)));
		double cosBeta = Math.cos(beta);
		double sinBeta = Math.sin(beta);
		double c = Math.sqrt(Math.pow(movil.getX() - antena.getX(), 2)
				+ Math.pow(movil.getY() - antena.getY(), 2)
				+ Math.pow(alturas[1] - alturas[0], 2)) / 2.0;
		double a = c + radioFresnel / 2.0;
		double b = Math.sqrt(Math.pow(a, 2) - Math.pow(c, 2));
		double x0 = -(movil.getX() + antena.getX()) / 2.0;
		double y0 = -(movil.getY() + antena.getY()) / 2.0;
		double z0 = -(alturas[0] + alturas[1]) / 2.0;

		BufferOp bo = new BufferOp(ls);
		bo.setEndCapStyle(BufferOp.CAP_SQUARE);
		//un rectángulo cuyo ancho es el radio de fresnel en el medio del
		// segmento.
		double distanciaReal = Math.sqrt(Math.pow(alturas[0] - alturas[1], 2)
				+ Math.pow(ls.getLength(), 2));
		Geometry rectangulo = bo.getResultGeometry(Math.sqrt(radioFresnel
				* distanciaReal / 2.0));
		Geometry edificio;
		Feature featureEdificio;
		FeatureIterator fi = this.fc.features();

		Coordinate[][] paredes;
		PerfilAlturas perfilRetorno = new PerfilAlturas(alturas[0], alturas[1],
				ls.getLength());
		boolean intersecciono = false;
		GeometryFactory gf = new GeometryFactory();

		while (fi.hasNext()) {
			featureEdificio = fi.next();
			edificio = featureEdificio.getDefaultGeometry();
			//Si el móvil está en el edificio, no va a tener línea de vista.
			if (edificio.contains(movil)) {
				ultimoEdificio = edificio;
				return new PerfilAlturas(0);
			}
			if (rectangulo.intersects(edificio)) {
				paredes = this.getParedes(featureEdificio);
				int cuantasParedesCortan = 0;
				double xPromedio = 0;
				double yPromedio = 0;
				for (int i = 0; i < paredes.length; i++) {
					if (!this.interseccionEdificio(paredes[i], x0, y0, z0,
							sinAlfa, cosAlfa, sinBeta, cosBeta, a, b)) {
						LineString pared = gf
								.createLineString(new Coordinate[] {
										paredes[i][0], paredes[i][1] });
						DistanceOp dop = new DistanceOp(pared, ls);
						Coordinate puntoCercanoLinea = dop.closestPoints()[1];
						xPromedio += puntoCercanoLinea.x;
						yPromedio += puntoCercanoLinea.y;
						cuantasParedesCortan++;
						intersecciono = true;
					}
				}
				if (cuantasParedesCortan > 0) {
					Point puntoPromedio = gf.createPoint(new Coordinate(
							xPromedio / cuantasParedesCortan, yPromedio
									/ cuantasParedesCortan));
					double distancia = ls.getPointN(0).distance(puntoPromedio);
					perfilRetorno.agregarObstaculoRelativo(paredes[0][3].z,
							distancia);
				}
			}
		}

		if (!intersecciono)
			return new PerfilAlturas(0);
		return perfilRetorno;
	}

}
