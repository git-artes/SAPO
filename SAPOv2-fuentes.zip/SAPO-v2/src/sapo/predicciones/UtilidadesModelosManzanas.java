package sapo.predicciones;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Iterator;

import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureCollections;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.operation.buffer.BufferOp;
import com.vividsolutions.jts.operation.distance.DistanceOp;

/**
 * Esta clase equivale al UtilidadesModelos pero tomando en cuenta la existencia
 * de las manzanas. Agrega algunas funcionalidades.
 * 
 * @author Grupo de proyecto SAPO
 */

public class UtilidadesModelosManzanas extends UtilidadesModelos {

	FeatureCollection fc;

	GeometryFactory gf;

	Point antena;

	Geometry ultimaManzana;

	double radioMax;

	/**
	 * La última orientación calculada que resultó no Double.NaN
	 * 

	 */
	private double ultimaOri;

	/**
	 * El último ancho calculado que resultó no Double.NaN
	 * 

	 */
	private double ultimoAncho;

	/**
	 * La ultima desq1 calculada que resultó no Double.NaN
	 * 
	 */
	private double ultimaDesq1;

	/**
	 * La ultima desq2 calculada que resultó no Double.NaN
	 * 
	 */
	private double ultimaDesq2;

	/**
	 * Se crea una nueva instancia de esta clase. En vez de tomar en cuenta
	 * todas las cuadras en la capa correspondiente, se toman en cuenta
	 * únicamente aquellos que estén a menos de radio de antena.
	 * 
	 * @param gc 
	 *            El gridCoverage con las alturas.
	 * @param fc 
	 *            Una featurecollection con las cuadras.
	 * @param radio 
	 *            El radio del círculo donde se consideraran las manzanas.
	 * @param antena 
	 *            El centro del círculo.
	 */
	public UtilidadesModelosManzanas(GridCoverage gc, FeatureCollection fc,
			double radio, Point2D.Double antena) {
		super(gc);

		this.radioMax = radio;
		this.fc = FeatureCollections.newCollection();
		gf = new GeometryFactory();
		FeatureIterator fi = fc.features();
		this.antena = gf.createPoint(new Coordinate(antena.x, antena.y));
		BufferOp bo = new BufferOp(this.antena);
		bo.setEndCapStyle(BufferOp.CAP_ROUND);
		Geometry circulo = bo.getResultGeometry(radio);

		Geometry manzana;
		Feature featManzana;

		featManzana = fi.next();
		manzana = featManzana.getDefaultGeometry();

		try {
			do {
				if (circulo.contains(manzana) || circulo.intersects(manzana)) {
					this.fc.add(featManzana);
				}

				featManzana = fi.next();
				manzana = featManzana.getDefaultGeometry();
			} while (fi.hasNext());
		} catch (java.util.NoSuchElementException e) {

		}
		//me fijo si el último entra
		if (circulo.contains(manzana) || circulo.intersects(manzana)) {
			this.fc.add(featManzana);
		}
		ultimaManzana = manzana;
		this.ultimaOri = 90;
		this.ultimoAncho = 30;
	}

	/**
	 * Calcula el ángulo de orientación de la calle. Para ello, primero busca
	 * entre las manzanas más cercanas, aquellas que se encuentren a menos de
	 * radio. Si no hay ninguna, devuelve Double.NaN pues considera que no tiene
	 * sentido calcular orientación cuando el punto se encuentra tan lejos de
	 * una manzana. Si encuentra alguna que contiene el punto, devuelve
	 * -Double.MAX_VALUE al considerar que aquellos puntos dentro de una manzana
	 * tampoco se les puede calcular una atenuación. Luego busca la cuadra más
	 * cercana (aquel lado de las manzanas que se encuentre más cerca del punto)
	 * y devuelve el menor ángulo que forma dicha cuadra con la línea que une la
	 * antena con el móvil.
	 * 
	 * @param sitioMovil 
	 *            el punto al cual se le desea hallar la orientación
	 * @param sitioAntena 
	 *            el punto donde se encuentra la antena. Puede ser distinto del
	 *            definido para esta instancia.
	 * @param radio 
	 *            la máxima distancia a la cual se buscarán cuadras para
	 *            realizar el cálculo de la atenuación.
	 * @return la orientación en grados (entre 0 y 90) o Double.NaN cuando
	 *         haya algún caso particular.
	 */
	public double calcularOrientacion(Point2D sitioMovil,
			Point2D.Double sitioAntena, double radio) {
		double resta = 0;

		Coordinate co = new Coordinate(sitioMovil.getX(), sitioMovil.getY());
		com.vividsolutions.jts.geom.Point puntoDelMovil = gf.createPoint(co);

		BufferOp bo = new BufferOp(puntoDelMovil);
		bo.setEndCapStyle(BufferOp.CAP_ROUND);
		Geometry circulo = bo.getResultGeometry(radio);

		FeatureIterator fi = this.fc.features();
		ArrayList manzanasCercanas = new ArrayList();
		Feature featManzana;

		//recorro todas las manzanas
		while (fi.hasNext()) {
			featManzana = fi.next();
			Geometry manzana = featManzana.getDefaultGeometry();

			// si alguna manzana contiene al punto, no tiene sentido calcularle
			// la orientación.
			if (manzana.contains(puntoDelMovil)) {
				return -Double.MAX_VALUE;
			} else {
				if (circulo.intersects(manzana))
					manzanasCercanas.add(manzana);
			}
		}

		// si no tiene ninguna manzana cerca, no tiene sentido definir una
		// orientación
		if (manzanasCercanas.size() == 0)
			return Double.NaN;

		//veo con qué cuadra está más cercana
		Iterator it = manzanasCercanas.iterator();
		double min = Double.MAX_VALUE;
		double distancia;
		LineString cuadraMasCercana = null;
		while (it.hasNext()) {
			Geometry manz = (Geometry) it.next();
			Coordinate[] cuadras = manz.getCoordinates(); //las cuadras
			for (int j = 0; j < cuadras.length - 1; j++) {
				LineString cuadra = gf.createLineString(new Coordinate[] {
						cuadras[j], cuadras[j + 1] });
				distancia = puntoDelMovil.distance(cuadra);
				if (distancia < min) {
					min = distancia;
					cuadraMasCercana = cuadra;
				}
			}
			//verificar con el último
			LineString cuadra = gf.createLineString(new Coordinate[] {
					cuadras[cuadras.length - 1], cuadras[0] });
			distancia = puntoDelMovil.distance(cuadra);
			if (distancia < min) {
				min = distancia;
				cuadraMasCercana = cuadra;
			}
		}

		//Ahora calculo el angulo con la radiobase
		LineString ls = gf.createLineString(new Coordinate[] {
				new Coordinate(sitioAntena.x, sitioAntena.y),
				new Coordinate(sitioMovil.getX(), sitioMovil.getY()) });
		double pendienteAntMov = Math.atan((sitioAntena.y - sitioMovil.getY())
				/ (sitioAntena.x - sitioMovil.getX()));

		Coordinate[] puntos = cuadraMasCercana.getCoordinates();
		Coordinate coord1 = puntos[0];
		Coordinate coord2 = puntos[1];
		double pendienteCuadra = Math.atan((coord2.y - coord1.y)
				/ (coord2.x - coord1.x));

		resta = pendienteAntMov - pendienteCuadra;
		if (Math.abs(resta) > Math.PI / 2) {
			resta = Math.PI - Math.abs(resta);
		}
		double orientacion = Math.abs(resta / Math.PI * 180);
		this.ultimaOri = orientacion;
		return orientacion;
	}

	/**
	 * Calcula el ancho de la calle donde se encuentre sitioMovil. En este caso
	 * sólo toma en cuenta aquellas manzanas que se encuentren a menos del radio
	 * con el que se creo esta instancia de UtilidadesModelosCuadras (esto es,
	 * para hallar la cuadra enfrentada a la más cercana al móvil). También
	 * devuelve -Double.MAX_VALUE cuando el punto está dentro de una manzana y
	 * Double.NaN no haya manzanas en el radio especificado. Para calcular el
	 * ancho de la calle, primero busca el punto más cercano de la cuadra más
	 * cercana. Luego traza una línea que parte de dicho punto hacia sitioMovil
	 * y que tiene de largo en su proyección en el eje x 2*radio. La menor
	 * distancia entre las intersecciones entre dicha línea y las otras cuadras
	 * y el punto (distinta de cero) será la que se tome como ancho de calle. Si
	 * dicha línea no se intersecciona con ninguna otra cuadra, también devuelve
	 * Double.NaN.
	 * 

	 */
	public double calcularAncho(Point2D sitioMovil, Point2D.Double sitioAntena,
			double radio) {
		double resta = 0;

		Coordinate co = new Coordinate(sitioMovil.getX(), sitioMovil.getY());
		com.vividsolutions.jts.geom.Point puntoDelMovil = gf.createPoint(co);

		BufferOp bo = new BufferOp(puntoDelMovil);
		bo.setEndCapStyle(BufferOp.CAP_ROUND);
		Geometry circulo = bo.getResultGeometry(radio);

		FeatureIterator fi = this.fc.features();
		ArrayList manzanasCercanas = new ArrayList();
		Feature featManzana;

		//recorro todas las manzanas
		while (fi.hasNext()) {
			featManzana = fi.next();
			Geometry manzana = featManzana.getDefaultGeometry();

			// si alguna manzana contiene al punto, no tiene sentido calcularle
			// el ancho.
			if (manzana.contains(puntoDelMovil)) {
				return -Double.MAX_VALUE;
			} else {
				if (circulo.intersects(manzana))
					manzanasCercanas.add(manzana);
			}
		}

		// si no tiene ninguna manzana cerca, no tiene sentido definir un ancho
		if (manzanasCercanas.size() == 0)
			return Double.NaN;

		//veo con qué cuadra está más cercana
		Iterator it = manzanasCercanas.iterator();
		double min = Double.MAX_VALUE;
		double distancia;
		LineString cuadraMasCercana = null;
		while (it.hasNext()) {
			Geometry manz = (Geometry) it.next();
			Coordinate[] cuadras = manz.getCoordinates(); //las cuadras
			for (int j = 0; j < cuadras.length - 1; j++) {
				LineString cuadra = gf.createLineString(new Coordinate[] {
						cuadras[j], cuadras[j + 1] });
				distancia = puntoDelMovil.distance(cuadra);
				if (distancia < min) {
					min = distancia;
					cuadraMasCercana = cuadra;
				}
			}
			//verificar con el último
			LineString cuadra = gf.createLineString(new Coordinate[] {
					cuadras[cuadras.length - 1], cuadras[0] });
			distancia = puntoDelMovil.distance(cuadra);
			if (distancia < min) {
				min = distancia;
				cuadraMasCercana = cuadra;
			}
		}

		//Ahora calculo el punto más cercano de la cuadra
		DistanceOp dop = new DistanceOp(puntoDelMovil, cuadraMasCercana);
		Point puntoCuadra = gf.createPoint(dop.closestPoints()[1]);
		//ahora busco el punto en la cuadra enfrentada
		double pendienteLinea = (puntoCuadra.getY() - puntoDelMovil.getY())/(puntoCuadra.getX() - puntoDelMovil.getX());
		
		Coordinate otroPunto = null;
		if (puntoCuadra.getX() > puntoDelMovil.getX()) {
			if(!(Double.isNaN(pendienteLinea) || Double.isInfinite(pendienteLinea))){
				otroPunto = new Coordinate(puntoCuadra.getX() - 2 * this.radioMax,
						puntoCuadra.getY() - 2 * radioMax * pendienteLinea);
			}else{
				otroPunto = new Coordinate(puntoCuadra.getX(),
						puntoCuadra.getY() - 2 * radioMax);
			}
		} else {
			if(!(Double.isNaN(pendienteLinea) || Double.isInfinite(pendienteLinea))){
				otroPunto = new Coordinate(puntoCuadra.getX() + 2 * this.radioMax,
						puntoCuadra.getY() + 2 * radioMax * pendienteLinea);
			}else{
				otroPunto = new Coordinate(puntoCuadra.getX(),
						puntoCuadra.getY() + 2 * radioMax);
			}
		}
		LineString linea = gf.createLineString(new Coordinate[] {
				puntoCuadra.getCoordinate(), otroPunto });
		fi = this.fc.features();
		double minDist = Double.MAX_VALUE;
		while (fi.hasNext()) {
			Geometry manz = fi.next().getDefaultGeometry();
			Coordinate[] cuadras = manz.getCoordinates(); //las cuadras
			for (int j = 0; j < cuadras.length - 1; j++) {
				LineString cuadra = gf.createLineString(new Coordinate[] {
						cuadras[j], cuadras[j + 1] });
				if (linea.intersects(cuadra)
						&& !cuadra.equals(cuadraMasCercana)) {
					Geometry interseccion = linea.intersection(cuadra);
					distancia = puntoCuadra.distance(interseccion);
					if (distancia < minDist && distancia != 0)
						minDist = distancia;
				}
			}
			//verificar con el último
			LineString cuadra = gf.createLineString(new Coordinate[] {
					cuadras[cuadras.length - 1], cuadras[0] });
			if (linea.intersects(cuadra) && !cuadra.equals(cuadraMasCercana)) {
				Geometry interseccion = linea.intersection(cuadra);
				distancia = puntoCuadra.distance(interseccion);
				if (distancia < minDist && distancia != 0)
					minDist = distancia;
			}
		}
		if (minDist == Double.MAX_VALUE) {
			return Double.NaN;
		}
		this.ultimoAncho = minDist;
		return minDist;
	}

	/**
	 * Igual que calcularOrientacion y calcularAncho, pero devuelve ambos
	 * valores en un array (la primera posición es la orientación y la segunda
	 * el ancho) aprovechando calculos que ambos tienen en común para realizar
	 * el calculo de ambos más rápido que hacerlo por separado.
	 * 

	 */
	public double[] calcularOrientacionAncho(Point2D sitioMovil,
			Point2D.Double sitioAntena, double radio) {
		double[] orientacionAncho = new double[2];
		double resta = 0;

		Coordinate co = new Coordinate(sitioMovil.getX(), sitioMovil.getY());
		com.vividsolutions.jts.geom.Point puntoDelMovil = gf.createPoint(co);

		BufferOp bo = new BufferOp(puntoDelMovil);
		bo.setEndCapStyle(BufferOp.CAP_ROUND);
		Geometry circulo = bo.getResultGeometry(radio);

		FeatureIterator fi = this.fc.features();
		ArrayList manzanasCercanas = new ArrayList();
		Feature featManzana;

		//recorro todas las manzanas
		while (fi.hasNext()) {
			featManzana = fi.next();
			Geometry manzana = featManzana.getDefaultGeometry();

			// si alguna manzana contiene al punto, no tiene sentido calcularle
			// la orientación.
			if (manzana.contains(puntoDelMovil)) {
				return new double[] { -Double.MAX_VALUE, -Double.MAX_VALUE };
			} else {
				if (circulo.intersects(manzana))
					manzanasCercanas.add(manzana);
			}
		}

		// si no tiene ninguna manzana cerca, no tiene sentido definir una
		// orientación
		if (manzanasCercanas.size() == 0)
			return new double[] { Double.NaN, Double.NaN };

		//veo con qué cuadra está más cercana
		Iterator it = manzanasCercanas.iterator();
		double min = Double.MAX_VALUE;
		double distancia;
		LineString cuadraMasCercana = null;
		while (it.hasNext()) {
			Geometry manz = (Geometry) it.next();
			Coordinate[] cuadras = manz.getCoordinates(); //las cuadras
			for (int j = 0; j < cuadras.length - 1; j++) {
				LineString cuadra = gf.createLineString(new Coordinate[] {
						cuadras[j], cuadras[j + 1] });
				distancia = puntoDelMovil.distance(cuadra);
				if (distancia < min) {
					min = distancia;
					cuadraMasCercana = cuadra;
				}
			}
			//verificar con el último
			LineString cuadra = gf.createLineString(new Coordinate[] {
					cuadras[cuadras.length - 1], cuadras[0] });
			distancia = puntoDelMovil.distance(cuadra);
			if (distancia < min) {
				min = distancia;
				cuadraMasCercana = cuadra;
			}
		}

		//		Ahora calculo el angulo con la radiobase
		LineString ls = gf.createLineString(new Coordinate[] {
				new Coordinate(sitioAntena.x, sitioAntena.y),
				new Coordinate(sitioMovil.getX(), sitioMovil.getY()) });
		double pendienteAntMov = Math.atan((sitioAntena.y - sitioMovil.getY())
				/ (sitioAntena.x - sitioMovil.getX()));

		Coordinate[] puntos = cuadraMasCercana.getCoordinates();
		Coordinate coord1 = puntos[0];
		Coordinate coord2 = puntos[1];
		double pendienteCuadra = Math.atan((coord2.y - coord1.y)
				/ (coord2.x - coord1.x));

		resta = pendienteAntMov - pendienteCuadra;
		if (Math.abs(resta) > Math.PI / 2) {
			resta = Math.PI - Math.abs(resta);
		}
		orientacionAncho[0] = Math.abs(resta / Math.PI * 180);
		this.ultimaOri = orientacionAncho[0];

		//Ahora calculo el punto más cercano de la cuadra
		DistanceOp dop = new DistanceOp(puntoDelMovil, cuadraMasCercana);
		Point puntoCuadra = gf.createPoint(dop.closestPoints()[1]);
		//ahora busco el punto en la cuadra enfrentada
		double pendienteLinea = (puntoCuadra.getY() - puntoDelMovil.getY())/(puntoCuadra.getX() - puntoDelMovil.getX());
		
		Coordinate otroPunto = null;
		if (puntoCuadra.getX() > puntoDelMovil.getX()) {
			if(!(Double.isNaN(pendienteLinea) || Double.isInfinite(pendienteLinea))){
				otroPunto = new Coordinate(puntoCuadra.getX() - 2 * this.radioMax,
						puntoCuadra.getY() - 2 * radioMax * pendienteLinea);
			}else{
				otroPunto = new Coordinate(puntoCuadra.getX(),
						puntoCuadra.getY() - 2 * radioMax);
			}
		} else {
			if(!(Double.isNaN(pendienteLinea) || Double.isInfinite(pendienteLinea))){
				otroPunto = new Coordinate(puntoCuadra.getX() + 2 * this.radioMax,
						puntoCuadra.getY() + 2 * radioMax * pendienteLinea);
			}else{
				otroPunto = new Coordinate(puntoCuadra.getX(),
						puntoCuadra.getY() + 2 * radioMax);
			}
		}
		LineString linea = gf.createLineString(new Coordinate[] {
				puntoCuadra.getCoordinate(), otroPunto });
		fi = this.fc.features();
		double minDist = Double.MAX_VALUE;
		while (fi.hasNext()) {
			Geometry manz = fi.next().getDefaultGeometry();
			Coordinate[] cuadras = manz.getCoordinates(); //las cuadras
			for (int j = 0; j < cuadras.length - 1; j++) {
				LineString cuadra = gf.createLineString(new Coordinate[] {
						cuadras[j], cuadras[j + 1] });
				try{
					if (linea.intersects(cuadra)
							&& !cuadra.equals(cuadraMasCercana)) {
						
						Geometry interseccion = linea.intersection(cuadra);
						distancia = puntoCuadra.distance(interseccion);
						if (distancia < minDist && distancia != 0)
							minDist = distancia;
					}
				}catch(com.vividsolutions.jts.util.AssertionFailedException ex){
					ex.printStackTrace(); 
				}
			}
			//verificar con el último
			LineString cuadra = gf.createLineString(new Coordinate[] {
					cuadras[cuadras.length - 1], cuadras[0] });
			if (linea.intersects(cuadra) && !cuadra.equals(cuadraMasCercana)) {
				Geometry interseccion = linea.intersection(cuadra);
				distancia = puntoCuadra.distance(interseccion);
				if (distancia < minDist && distancia != 0)
					minDist = distancia;
			}
		}
		if (minDist == Double.MAX_VALUE) {
			orientacionAncho[1] = Double.NaN;
			return orientacionAncho;
		}
		orientacionAncho[1] = minDist;
		this.ultimoAncho = minDist;

		return orientacionAncho;
	}

	/**
	 * Devuelve el último ancho calculado que no resultó Double.NaN. Útil cuando
	 * el resultado de un cálculo resulta justamente Double.NaN por causa del
	 * algoritmo utilizado y es natural suponer que el último valor calculado es
	 * una razonable aproximación al actual.
	 * 


	 */
	public double getUltimoAncho() {
		return this.ultimoAncho;
	}

	/**
	 * Devuelve la última orientación calculada que no resultó Double.NaN. Útil
	 * cuando el resultado de un cálculo resulta justamente Double.NaN por causa
	 * del algoritmo utilizado y es natural suponer que el último valor
	 * calculado es una razonable aproximación al actual.
	 * 
	

	 */
	public double getUltimaOri() {
		return this.ultimaOri;
	}

	/**
	 * Devuelve las distancias del punto del movil hasta las esquinas más
	 * cercanas. Para lograr esto se recorre la manzana mas cercana en sentido
	 * horario y antihorario partiendo de la cuadra mas cercana hasta encontrar
	 * la cuadra que forme un angulo mayor a 30 con la cuadra anterior, dado que
	 * aqui se considera que realmente hay una esquina.

	 */
	public double[] calcularDistanciaEsq(Point2D sitioMovil,
			Point2D.Double sitioAntena, double radio) {
		double resta = 0;

		double[] distanciasEsq = new double[2];

		Coordinate co = new Coordinate(sitioMovil.getX(), sitioMovil.getY());
		com.vividsolutions.jts.geom.Point puntoDelMovil = gf.createPoint(co);

		BufferOp bo = new BufferOp(puntoDelMovil);
		bo.setEndCapStyle(BufferOp.CAP_ROUND);
		Geometry circulo = bo.getResultGeometry(radio);

		FeatureIterator fi = this.fc.features();
		ArrayList manzanasCercanas = new ArrayList();
		Feature featManzana;

		//recorro todas las manzanas
		while (fi.hasNext()) {
			featManzana = fi.next();
			Geometry manzana = featManzana.getDefaultGeometry();

			// si alguna manzana contiene al punto, no tiene sentido calcularle
			// la orientación.
			if (manzana.contains(puntoDelMovil)) {
				return new double[] { -Double.MAX_VALUE, -Double.MAX_VALUE };
			} else {
				if (circulo.intersects(manzana))
					manzanasCercanas.add(manzana);
			}
		}

		// si no tiene ninguna manzana cerca, no tiene sentido definir la
		// distancia a la esquina mas cercana
		if (manzanasCercanas.size() == 0)
			return new double[] { Double.NaN, Double.NaN };

		//veo con qué cuadra está más cercana
		Iterator it = manzanasCercanas.iterator();
		double min = Double.MAX_VALUE;
		double distancia;
		LineString cuadraMasCercana = null;
		Geometry manzanaMasCercana = null;
		while (it.hasNext()) {
			Geometry manz = (Geometry) it.next();
			Coordinate[] cuadras = manz.getCoordinates(); //las cuadras

			for (int j = 0; j < cuadras.length - 1; j++) {
				LineString cuadra = gf.createLineString(new Coordinate[] {
						cuadras[j], cuadras[j + 1] });
				distancia = puntoDelMovil.distance(cuadra);
				if (distancia < min) {
					min = distancia;
					cuadraMasCercana = cuadra;
					manzanaMasCercana = manz;
				}
			}
			//verificar con el último
			LineString cuadra = gf.createLineString(new Coordinate[] {
					cuadras[cuadras.length - 1], cuadras[0] });
			distancia = puntoDelMovil.distance(cuadra);
			if (distancia < min) {
				min = distancia;
				cuadraMasCercana = cuadra;
				manzanaMasCercana = manz;
			}
		}

		LineString cuadraMasCercanaSiempre = cuadraMasCercana;

		//Ahora calculo el punto más cercano de la cuadra
		DistanceOp dop = new DistanceOp(puntoDelMovil, cuadraMasCercana);
		Point puntoCuadra = gf.createPoint(dop.closestPoints()[1]);

		//obtengo solo las cuadras de la manzana mas cercana
		Coordinate[] cuadrasManzCercana = manzanaMasCercana.getCoordinates(); //las

		// -- SENTIDO HORARIO --
		//recorro las cuadras y empiezo a calcular los angulos que forma cada
		// cuadra
		//con la siguiente para encontrar la esquina 1 (angulo menor a 30°)
		// partiendo de la cuadra mas cercana
		double angulo = 0;
		int k = 0;
		LineString proximaCuadra = null;
		cuadraMasCercana = cuadraMasCercanaSiempre;
		while ((angulo < 30) && (k < cuadrasManzCercana.length - 2)) {

			Coordinate coordA1 = cuadrasManzCercana[k];
			Coordinate coordB1 = cuadrasManzCercana[k + 1];
			LineString cuadra = gf.createLineString(new Coordinate[] { coordA1,
					coordB1 });

			if (cuadra.equals(cuadraMasCercana)) {
				Coordinate coordC1 = cuadrasManzCercana[k + 2];
				proximaCuadra = gf.createLineString(new Coordinate[] { coordB1,
						coordC1 });

				double pendienteProxCuadra = Math.atan((coordC1.y - coordB1.y)
						/ (coordC1.x - coordB1.x));
				double pendienteCuadra = Math.atan((coordB1.y - coordA1.y)
						/ (coordB1.x - coordA1.x));
				//calculo el angulo entre una cuadra y la siguiente
				angulo = pendienteProxCuadra - pendienteCuadra;
				if (Math.abs(angulo) > Math.PI / 2) {
					angulo = Math.PI - Math.abs(angulo);
				}
				angulo = Math.abs(angulo / Math.PI * 180);

				cuadraMasCercana = proximaCuadra;
			}
			k = k + 1;
		}
		// si el angulo dio menor a 30, analizo el ultimo punto
		if ((k >= cuadrasManzCercana.length - 2) && (angulo < 30)) {
			Coordinate coordA1 = cuadrasManzCercana[cuadrasManzCercana.length - 2];
			Coordinate coordB1 = cuadrasManzCercana[0];
			LineString cuadra = gf.createLineString(new Coordinate[] { coordA1,
					coordB1 });

			if (cuadra.equals(cuadraMasCercana)) {
				Coordinate coordC1 = cuadrasManzCercana[1];
				proximaCuadra = gf.createLineString(new Coordinate[] { coordB1,
						coordC1 });

				double pendienteProxCuadra = Math.atan((coordC1.y - coordB1.y)
						/ (coordC1.x - coordB1.x));
				double pendienteCuadra = Math.atan((coordB1.y - coordA1.y)
						/ (coordB1.x - coordA1.x));

				angulo = pendienteProxCuadra - pendienteCuadra;
				if (Math.abs(angulo) > Math.PI / 2) {
					angulo = Math.PI - Math.abs(angulo);
				}
				angulo = Math.abs(angulo / Math.PI * 180);

				cuadraMasCercana = proximaCuadra;

			}
		}
		//si el angulo es mayor que 30 considero que ese punto es la esquina
		Point esq1 = proximaCuadra.getStartPoint();

		//-- SENTIDO ANTIHORARIO --
		//recorro las cuadras y empiezo a calcular los angulos que forma cada
		// cuadra
		//con la siguiente para encontrar la esquina 2 (angulo menor a 30°)
		// partiendo de la cuadra mas cercana
		double angulo2 = 0;
		int i = 0;
		LineString proximaCuadra2 = null;
		cuadraMasCercana = cuadraMasCercanaSiempre;
		while ((angulo2 < 30) && (i < cuadrasManzCercana.length - 2)) {
			Coordinate coordA2 = cuadrasManzCercana[cuadrasManzCercana.length
					- 1 - i];
			Coordinate coordB2 = cuadrasManzCercana[cuadrasManzCercana.length
					- 2 - i];
			LineString cuadra2 = gf.createLineString(new Coordinate[] {
					coordA2, coordB2 });

			if (cuadra2.equals(cuadraMasCercana)) {
				Coordinate coordC2 = cuadrasManzCercana[cuadrasManzCercana.length
						- 3 - i];
				proximaCuadra2 = gf.createLineString(new Coordinate[] {
						coordB2, coordC2 });

				double pendienteProxCuadra2 = Math.atan((coordC2.y - coordB2.y)
						/ (coordC2.x - coordB2.x));
				double pendienteCuadra2 = Math.atan((coordB2.y - coordA2.y)
						/ (coordB2.x - coordA2.x));

				angulo2 = pendienteProxCuadra2 - pendienteCuadra2;
				if (Math.abs(angulo2) > Math.PI / 2) {
					angulo2 = Math.PI - Math.abs(angulo2);
				}
				angulo2 = Math.abs(angulo2 / Math.PI * 180);

				cuadraMasCercana = proximaCuadra2;
			}
			i = i + 1;
		}
		// si el angulo dio menor a 30, analizo el ultimo punto
		if ((i >= cuadrasManzCercana.length - 2) && (angulo2 < 30)) {
			Coordinate coordA2 = cuadrasManzCercana[1];
			Coordinate coordB2 = cuadrasManzCercana[0];
			LineString cuadra = gf.createLineString(new Coordinate[] { coordA2,
					coordB2 });

			if (cuadra.equals(cuadraMasCercana)) {
				Coordinate coordC2 = cuadrasManzCercana[cuadrasManzCercana.length - 2];
				proximaCuadra2 = gf.createLineString(new Coordinate[] {
						coordC2, coordB2 });

				double pendienteProxCuadra = Math.atan((coordC2.y - coordB2.y)
						/ (coordC2.x - coordB2.x));
				double pendienteCuadra = Math.atan((coordB2.y - coordA2.y)
						/ (coordB2.x - coordA2.x));

				angulo2 = pendienteProxCuadra - pendienteCuadra;
				if (Math.abs(angulo2) > Math.PI / 2) {
					angulo2 = Math.PI - Math.abs(angulo2);
				}
				angulo2 = Math.abs(angulo2 / Math.PI * 180);

				cuadraMasCercana = proximaCuadra2;
			}
		}
		//si el angulo es mayor que 30 considero que ese punto es la esquina
		Point esq2 = proximaCuadra2.getStartPoint();

		//Ahora calculo las distancias a las dos esquinas desde el pto mas
		// cercano de la cuadra mas cercana
		
		double desq1 = puntoCuadra.distance(esq1);
		double desq2 = puntoCuadra.distance(esq2);

		//descarto los punto que disten menos de 7m de algunas de las esquinas
		// (por teoría del modelo)
		if ((desq1 <= 7) || (desq2 <= 7)) {
			return new double[] { Double.NaN, Double.NaN };
		}

		else {
			distanciasEsq[0] = desq1;
			distanciasEsq[1] = desq2;

			return distanciasEsq;
		}

	}

	/**
	 * Devuelve la última distancia a la esquina 1 calculada que no resultó
	 * Double.NaN. Útil cuando el resultado de un cálculo resulta justamente
	 * Double.NaN por causa del algoritmo utilizado y es natural suponer que el
	 * último valor calculado es una razonable aproximación al actual.
	 *

	 */
	public double getUltimaDesq1() {
		return this.ultimaDesq1;
	}

	/**
	 * Devuelve la última distancia a la esquina 2 calculada que no resultó
	 * Double.NaN. Útil cuando el resultado de un cálculo resulta justamente
	 * Double.NaN por causa del algoritmo utilizado y es natural suponer que el
	 * último valor calculado es una razonable aproximación al actual.
	 *

	 */
	public double getUltimaDesq2() {
		return this.ultimaDesq2;
	}

}
