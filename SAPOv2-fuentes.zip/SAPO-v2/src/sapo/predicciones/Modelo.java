package sapo.predicciones;

import org.geotools.pt.Envelope;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;

import com.vividsolutions.jts.geom.Coordinate;

/**
 * Esta clase constituye la base para la creación de todos los modelos de propagación.
 * Define los atributos y métodos que cualquier modelo debe implementar.
 * @author Grupo de proyecto SAPO
 */
public abstract class Modelo {

	/**
	 * 
	 * El JPanel que todos los modelos tienen para ser creados. Será
	 * inicializado por el método crearPanelCreacion() que a su vez es usado en
	 * el constructo de esta clase (o sea, las clases que extiendan Modelo no
	 * tienen porque ejecutar crearPanelCreacion(), sino simplemente llamar al
	 * constructor de esta clase).
	 *  
	 */

	PanelModelos menu;

	/**
	 * 
	 * la velocidad de la luz en el vacío.
	 *  
	 */

	final static double C = 299792458; //en m/; //en m/s

	/**
	 * 
	 * Aquellos valores que pueden ser ajustados para un entorno en particular.
	 *  
	 */

	double[] parametrosAjustables;

	/**
	 * 
	 * Aquellos parámetros que no son susceptibles a ser ajustados. Por ejemplo,
	 * si el entorno es urbano, suburbano o rural.
	 *  
	 */

	Object[] parametrosNoAjustables;
	/**
	 * El nombre del modelo
	 */
	String nombreModelo;

	/**
	 * 
	 * Los nombres de los parámetros no ajustables
	 *  
	 */

	String[] nombreParametrosAjustables;

	/**
	 * 
	 * Los nombres de los parámetros no ajustables
	 *  
	 */

	String[] nombreParametrosNoAjustables;

	/**
	 * 
	 * El nombre de al implementacion en particular
	 *  
	 */

	String nombreImplementacion;

	/**
	 * Si para el calculo de la atenuación debe ser usado interpolación.
	 * 

	 */

	boolean usarInterpolacion = true;

	/**
	 * Este valor indica (en %) cuantos punto del total se llevan calculados en
	 * el caso de realizar una predicción para un mapa. Será consultado por
	 * VentanaPredicción para actualizar la barra de avance.

	 */

	int cuantoVa = 0;

	public static final String VACIO = "Propagacion en Vacio (L=A*r^n)";

	public static final String TIERRA_PLANA = "Propagacion sobre un plano conductor (G=A0*(lambda/(A1*d)^n*sin^n((A2*ht*hr)/(landa*d))))";

	public static final String TIERRA_PLANA_APROXIMADA = "Propagacion sobre un plano conductor (aproximacion) (G=(ht*hr/d^n)^2)";

	public static final String ITUR_P1546 = "Modelo Recomendación ITU-R P.1546-4: Basado en curvas";
	
	public static final String OKUMURA_HATA = "Modelo de Okumura-Hata: A0 + A1*log(fc/MHz) + A2*log(ht/m) - a(ht) + (A3 + A4*log(ht/m))*log(d/km) + f(area)";

	public static final String COST_231_WI = "Modelo COST-Walfisch-Ikegami: Sin LOS: LB  \n Con LOS: LB + Lrts + Lmsd";

	public static final String COST_231_WI_SIMPLE = "Modelo COST-Walfisch-Ikegami Simplificado (solo calcula orientacion): Sin LOS: LB  \n Con LOS: LB + Lrts + Lmsd";

	public static final String ERCEG_SUI = "Modelo de Erceg (SUI): A0*log((4*pi/c)*d0*f) + 10*gamma*log(d/d0)+ s0";

	public static final String MOPEM = "Modelo MOPEM: LB + Lrts + Lmsd + Lesq";

	public static final String VOGLER_SB = "Modelo de Saunders y Bonar con modificaciones: aplica el metodo de vogler a las edificaciones como si fueran cuchillos";

	public static final String VOGLER_IKEGAMI = "Modelo Vogler-Ikegami: modelo hibrido entre el de Vogler para Lmsd e Ikegami para Lrts";

	/*
	 * public static final String VACIO = "Propagacion en Vacio, L=A*r^n";
	 * public static final String TIERRA_PLANA = "Propagacion sobre un plano
	 * conductor (G=A0*(lambda/(A1*d)^n*sin^n((A2*ht*hr)/(landa*d))))"; public
	 * static final String TIERRA_PLANA_APROXIMADA = "Propagacion sobre un plano
	 * conductor (aproximacion) (G=(ht*hr/d^n)^2)"; public static final String
	 * OKAMURA_HATA = "Modelo de Okumura-Hata: A0 + A1*log(fc/MHz) +
	 * A2*log(ht/m) - a(ht) + (A3 + A4*log(ht/m))*log(d/km) + f(area)"; public
	 * static final String COST_231_WI = "Modelo COST-Walfisch-Ikegami: Sin LOS:
	 * LB \n Con LOS: LB + Lrts + Lmsd";
	 */

	/**
	 * Los modelos se definen por dos tipos de paramétros: los que son
	 * ajustables al entorno en particular y los que no, pues solo definen
	 * gustos del usuario. Cada implementación en particular necesitará de
	 * algunos paramétros en particular, habiendo casos donde no necesitará de
	 * parámetros no ajustables. En este último caso se le deberá pasar un array
	 * vacío.
	 * 
	 * @param parametrosAjustables
	 * @param parametrosNoAjustables
	 */
	public Modelo(double[] parametrosAjustables, Object[] parametrosNoAjustables)
			throws ModeloMalDefinidoException {
		if (this.getParametrosAjustablesPorDefecto().length != parametrosAjustables.length
				|| this.getParametrosNoAjustablesPorDefecto().length != parametrosNoAjustables.length) {
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
					"Cantidad de paramétros equivocado");
			throw e;
		}
		Object[] aux = this.getParametrosNoAjustablesPorDefecto();
		for (int j = 0; j < aux.length; j++) {
			if (!aux[j].getClass().equals(parametrosNoAjustables[j].getClass())) {
				ModeloMalDefinidoException e = new ModeloMalDefinidoException(
						"Los objectos que fueron pasados en parametros no ajustables no son de la clase adecuada");
				throw e;
			}
		}
		this.setNombres();
		this.parametrosAjustables = parametrosAjustables;
		this.parametrosNoAjustables = parametrosNoAjustables;
		this.crearPanelCreacion();
	}

	/**
	 * 
	 * Define el modelo con los parámetros por defecto y el nombre.
	 * 
	 * @throws ModeloMalDefinidoException
	 *  
	 */

	/*
	 * public Modelo(String nombre){ this.nombreModelo = nombre;
	 * this.parametrosAjustables = this.getParametrosAjustablesPorDefecto();
	 * this.parametrosNoAjustables = this.getParametrosNoAjustablesPorDefecto();
	 * this.crearPanelCreacion(); }
	 */

	/**
	 * Define el modelo con los parámetros por defecto.
	 * 
	 * @throws ModeloMalDefinidoException
	 */
	public Modelo() {
		this.setNombres();
		this.parametrosAjustables = this.getParametrosAjustablesPorDefecto();
		this.parametrosNoAjustables = this
				.getParametrosNoAjustablesPorDefecto();
		this.nombreImplementacion = nombreModelo;
		this.crearPanelCreacion();
	}

	protected abstract double[] getParametrosAjustablesPorDefecto();

	protected abstract Object[] getParametrosNoAjustablesPorDefecto();

	/**
	 * 
	 * Debe setear el nombre del modelo y los parametros de cada modelo en
	 * particular.
	 * 
	 *  
	 */

	protected abstract void setNombres();

	@Override
	public String toString() {

		String devolucion = "Modelo de propagación: " + this.nombreModelo
				+ "\n";
		devolucion += "Sus parámetros ajustables valen: \n";
		for (int j = 0; j < this.parametrosAjustables.length; j++) {
			devolucion += this.nombreParametrosAjustables[j] + "="
					+ this.parametrosAjustables[j] + "\n";
		}
		devolucion += "Sus parámetros no ajustables valen: \n";
		for (int j = 0; j < this.parametrosNoAjustables.length; j++) {
			devolucion += this.nombreParametrosNoAjustables[j] + "="
					+ this.parametrosNoAjustables[j] + "\n";
		}
		return devolucion;

	}

	/**
	 * Debe verificar que mapa tenga todos los datos necesarios para poder usar
	 * el modelo.
	 * 
	 * @param mapa
	 * @return - true si están los datos necesarios para poder usar el modelo.
	 */
	public abstract boolean verificarDatos(Mapa mapa);

	/**
	 * El modelo deberá calcular para el entorno mapa y para antena como
	 * transmisor la potencia de recepción predicha por este modelo. Ésta deberá
	 * ser calculada sólo a radioMax de antena o hasta que la pérdida de camino
	 * supere perdidaMax.
	 * 
	 * @param proyecto 
	 *            El proyecto para el cual se quiere realizar la predicción.
	 * @param mapa 
	 *            El entorno para el que se quiere realizar la prediccion
	 * @param antena 
	 *            La atena transmisora
	 * @param radioMax 
	 *            El radio a partir del cual no se calcula más la predicción
	 * @param perdidaMax 
	 *            La máxima atenuación, a partir de la cual no se calcula más la
	 *            predicción.
	 * @param precision 
	 *            el ancho del cuadrado donde se calculara la atenuación media
	 * @param hR 
	 *            la altura de la antena receptora
	 * @return  Los resultados de la predicción. El método debe verificar que
	 *         estén todos los datos necesarios (usando verificarDatos(mapa)).
	 * @throws PrediccionMalRealizadaException 
	 *             cuando hubo algún error.
	 */
	public abstract PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa,
			Antena antena, double radioMax, double perdidaMax, double precision)
			throws PrediccionMalRealizadaException;

	/**
	 * Este método deberá devolver la potencia de recepción en los puntos dados,
	 * con antena como transmisora y el entorno mapa.
	 * 
	 * @param proyecto 
	 *            El proyecto para el cual se quiere realizar la predicción
	 * @param mapa 
	 *            El entorno para el que se quiere realizar la predicción
	 * @param antena 
	 *            La antena transmisora
	 * @param puntos 
	 *            Los puntos en los cuales se quiere calcular la potencia de
	 *            recepción
	 * @param hR 
	 *            la altura de la antena receptora
	 * @return  La potencia recibida en <code>puntos</code> en el mismo orden
	 * @throws PrediccionMalRealizadaException 
	 *             cuando hubo algún error.
	 */
	public abstract double[] predecir(Proyecto proyecto, Mapa mapa,
			Antena antena, Coordinate[] puntos)
			throws PrediccionMalRealizadaException;

	/**
	 * Devuelve el rectángulo donde se puede calcular la atenuación (están
	 * presentes los datos) y además contiene a el punto.
	 * 
	 * @return  si el punto no está en una zona donde sea calculable el modelo,
	 *         debe devolver null
	 */
	public abstract Envelope areaCalculable(Mapa mapa,
			java.awt.geom.Point2D.Double punto);

	/**
	 * Indica si se debe utilizar interpolación con los datos geográficos para
	 * el cálculo de la atenuación. Aunque probablemente resulte en un resultado
	 * más preciso, también tomará más tiempo realizar la predicción.
	 * 
	 * @param usarInterpolacion

	 */
	public void setUsarInterpolacion(boolean usarInterpolacion) {
		this.usarInterpolacion = usarInterpolacion;
	}

	/**
	 * 
	 * Crea el JPanel para la creación de modelos. Inicializa la variable
	 * PanelModelos que todos los modelos tienen.
	 *  
	 */

	protected abstract void crearPanelCreacion();

	/**
	 * 
	 * Devuelve un JPanel para la creación del modelo. Será utilizado en la gui
	 * del programa para la creación de cada modelo en particular, y por lo
	 * tanto deberá incluir cualquier particularidad del modelo en sí. Los
	 * campos seran llenados con los especificados por la instancia en
	 * particular. Se limitará a devolver lo creado por crearPanelCreacion();
	 * 

	 *  
	 */

	public abstract PanelModelos getPanelCreacion();

 /**
  * Devuelve el nombre del modelo
  * @return
  */
	public String getNombreModelo() {
		return nombreModelo;
	}

	/**
	 * Setea el nombre del modelo
	 * @param nombre
	 */
	public void setNombreModelo(String nombre) {
		this.nombreModelo = nombre;
	}

	/**
	 * Le asigna el nombre especificado a esta implementación en particular.
	 * 
	 * @param nombre
	 * @throws ModeloMalDefinidoException 
	 *             Si el nombre está vacío
	 */
	public void setNombre(String nombre) throws ModeloMalDefinidoException {
		if (nombre.equals("")) {
			throw new ModeloMalDefinidoException(
					"No se pueden definir modelos con nombre vacío");
		}
		this.nombreImplementacion = nombre;
	}

	public String getNombre() {
		return nombreImplementacion;
	}

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */
	
	public String getXML() {

		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>" + nombreImplementacion
				+ "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");

		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>" + nombreParametrosAjustables[i]
					+ "</Nombre>\r\n");
			if (parametrosAjustables.length != 0) {
				result1.append("        <Valor>" + parametrosAjustables[i]
						+ "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		if (parametrosNoAjustables.length != 0) {
			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer(
						"<ParametrosNoAjustables>");
				result1.append("        <Nombre>"
						+ nombreParametrosNoAjustables[i] + "</Nombre>\r\n");
				//result.append(" <NombreParametrosNoAjustables>" +
				// nombreParametrosNoAjustables[i] +
				// "</NombreParametrosNoAjustables>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"
							+ parametrosNoAjustables[i] + "</Valor>\r\n");
				} else {
					result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");
				result.append(result1.toString());
			}
		}
		/*
		 * for (int i=0; i < nombreParametrosNoAjustables.length; i++){
		 * result.append(" <NombreParametrosNoAjustables>" +
		 * nombreParametrosNoAjustables[i] + "
		 * </NombreParametrosNoAjustables>\r\n"); if
		 * (parametrosNoAjustables.length != 0){ result.append("
		 * <ParametrosNoAjustables>" + parametrosNoAjustables[i] + "
		 * </ParametrosNoAjustables>\r\n"); }
		 *  }
		 */
		result.append("      </Modelo>\r\n");
		return result.toString();

	}

	@Override
	public boolean equals(Object o) {
		return ((Modelo) o).getNombre().equals(this.nombreImplementacion);
	}

	/**
	 * Devuelve el porcentaje de avance de la prediccion 

	 */
	public int getCuantoVa() {
		return cuantoVa;
	}
}
