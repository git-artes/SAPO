/*
 * Created on 22/02/2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package sapo.predicciones;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase es el modelo de propagación detallado en el paper de Saunders y Bonar con las modificaciones explicadas 
 * en la documentación del proyecto (la más notable, el uso de métodos RQMC)
 * @author Grupo de proyecto SAPO 
 *
 */
public class VoglerSaundersBonar extends Modelo{

	double falsoParAjustable = 1.0; 
	
	public VoglerSaundersBonar(){
		super(); 
	}
	
	/**
	 * Por ahora, en los parametros ajustabes se debe poner un único double cualquiera (es por el tema de poder 
	 * levantar modelos sin parametros Ajustables) y en los parámetos no ajustables va: un Integer con la cantidad 
	 * de repeticiones, un Double con el margen de seguridad (únicamente puede ser 0.95 o 0.9) y un Integer con 
	 * el error máximo (debe ser mayor que cero). 
	 * @param parametrosAjustables
	 * @param parametrosNoAjustables
	 * @throws ModeloMalDefinidoException
	 */
	public VoglerSaundersBonar(double[] parametrosAjustables, Object[] parametrosNoAjustables) throws ModeloMalDefinidoException{
		super(parametrosAjustables, parametrosNoAjustables);

		if(((Integer)parametrosNoAjustables[0]).intValue() < 0)
			throw new ModeloMalDefinidoException("La cantidad de repeticiones debe ser positiva"); 
		if(((Double)parametrosNoAjustables[1]).doubleValue()<0 || ((Double)parametrosNoAjustables[1]).doubleValue()>1)
			throw new ModeloMalDefinidoException("El margen de seguridad debe ser mayor que cero y menor que uno"); 
		if(((Integer)parametrosNoAjustables[2]).intValue() < 0)
			throw new ModeloMalDefinidoException("El máximo porcentaje de error debe ser siempre positivo"); 
		if(((Integer)parametrosNoAjustables[3]).intValue() < 0)
			throw new ModeloMalDefinidoException("El número máximo de edificios a ser considerados debe ser positivo"); 
			
	}
	
	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#getParametrosAjustablesPorDefecto()
	 */
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		return new double[]{}; 
	}

	/**
	 * Devuelve los parámetros no ajustables por defecto: 10 repeticiones con un margen de seguridad de 0.95 y un error 
	 * máximo del 5%. 
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		return new Object[]{
			new Integer(10),
			new Double(0.95), 
			new Integer(20), 
			new Integer(8)
		}; 
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#setNombres()
	 */
	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.VOGLER_SB;
		this.nombreParametrosAjustables = new String[]{"s/n"};
		this.nombreParametrosNoAjustables = new String[]{"Repeticiones", "Margen de seguridad", "Maximo porcentaje de error", "Maximo numero de cuchillos a ser considerados"};
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#verificarDatos(explorer.ifusuario.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia()
		&& !mapa.getCapaEdificios().esVacia(); 
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#predecir(explorer.proyecto.Proyecto, explorer.ifusuario.Mapa, explorer.red.Antena, double, double, double)
	 */
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException {
		try{
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			if(envoltura==null) 
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo Vacío es nula, verifique los datos");
			
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
			Point sitioMovil; 
			CoordinatePoint sitioRealMovil = null;  
			Coordinate[] coordenadas = new Coordinate[ancho*alto];
			int contador = 0; 
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){ 
					//for(int j=0;j<alto;j++){
					sitioMovil = new Point(i,j);
					mt.transform(new CoordinatePoint(sitioMovil.x, sitioMovil.y), sitioRealMovil);
					coordenadas[contador] = new Coordinate(sitioRealMovil.getOrdinate(0), sitioRealMovil.getOrdinate(1)); 
					contador++; 
				}
			}
			double[] datos = this.predecir(proyecto, mapa, antena, coordenadas); 
			double maximo = -Double.MAX_VALUE; 
			double minimo = Double.MAX_VALUE; 
			for(int j=0; j<datos.length; j++){
				if(datos[j]<minimo)
					minimo = datos[j]; 
				if(datos[j]>maximo)
					maximo = datos[j]; 
			}
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp; 
			
		}catch(Exception e){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+e.getMessage()); 
		}
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#predecir(explorer.proyecto.Proyecto, explorer.ifusuario.Mapa, explorer.red.Antena, com.vividsolutions.jts.geom.Coordinate[])
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException {
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Vogler-Saunders-Bonar.");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			double hT = rb.getAltura();
			double hR = proyecto.getPerfilUsuario().getAltura(); 
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
						
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia();

			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}

			UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio+100.0, sitioAntena, "altura");
			UtilidadesModelos um = new UtilidadesModelos(gc);
			
			double[] predicciones = new double[puntos.length];
			int contador = 0;
			GeometryFactory gf = new GeometryFactory(); 
			double alturaTotalMovil, atenuacionAux;
			double distancia = 0; 
			IntegralVogler integralVogler; 
			double[] distanciaYangulos = null; 
			
			int repeticiones = ((Integer)this.parametrosNoAjustables[0]).intValue(); 
			double margenSeg = ((Double)this.parametrosNoAjustables[1]).doubleValue(); 
			int maxError = ((Integer)this.parametrosNoAjustables[2]).intValue(); 
			int maxCuchillos = ((Integer)this.parametrosNoAjustables[3]).intValue();
			for(int j=0;j<predicciones.length;j++){
				sitioMovil = new Point2D.Double(puntos[j].x,puntos[j].y);
				
				LineString linea = gf.createLineString(new Coordinate[]{
						new Coordinate(sitio.getX(), sitio.getY()), 
						new Coordinate(sitioMovil.getX(), sitioMovil.getY())
				}); 
				alturaTotalMovil = ume.getAlturaTotal(sitioMovil, hR, this.usarInterpolacion);
				double[] alturas = new double[]{ ume.getAlturaAntena(), alturaTotalMovil};
				
				distanciaYangulos  = ume.calcularDistanciaReal(sitioAntena, hT+ume.getAlturaEdificioAntena(), sitioMovil, hR, this.usarInterpolacion);
				distancia = distanciaYangulos[0];
				
				PerfilAlturas perfil = ume.hallarPerfilDeEdificios(linea, antena.getFrecuencia(), alturas, 0.5);
				if(perfil.getSeparaciones().length > 1){
					integralVogler = new IntegralVogler(antena.getFrecuencia(), perfil.getSeparaciones(), perfil.getAlturas());
					atenuacionAux = 20.0*Math.log(integralVogler.calcularIntegralVoglerAproximada(repeticiones, margenSeg, maxError, maxCuchillos).modulus())/Math.log(10.0);
					//atenuacionAux = 20.0*Math.log(integralVogler.calcularIntegralVoglerTestHipotesis(repeticiones, margenSeg, maxCuchillos).modulus())/Math.log(10.0);
				}else{
					atenuacionAux = 0; 
				} 
				double atenuacionVacio = 32.44 + (20.0*Math.log(distancia/1000.0) + 20.0*Math.log(antena.getFrecuencia()/1.0E6))/Math.log(10.0);
				
//				double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
				// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
				double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
				predicciones[j] = antena.getPotencia() + gananciaE + atenuacionAux - atenuacionVacio ;
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
			}
			return predicciones; 
		}catch(Exception z){
			z.printStackTrace(); 
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#areaCalculable(explorer.ifusuario.Mapa, java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try {
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf
					.createLinearRing(new Coordinate[] { new Coordinate(0, 0),
							new Coordinate(1, 0), new Coordinate(1, 1),
							new Coordinate(0, 1), new Coordinate(0, 0) }), null);
			while (fi.hasNext() && esta == false) {
				rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf
						.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if (!esta)
				return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
			.getCoordinates();
			Envelope envoltura = new Envelope(2);
			for (int j = 0; j < coordenadas.length; j++)
				envoltura.add(new CoordinatePoint(
						coordenadas[j].x,
						coordenadas[j].y)); //genero la envoltura que contiene los cuatro vértices
			return envoltura;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#crearPanelCreacion()
	 */
	@Override
	protected void crearPanelCreacion() {
		this.menu = new MenuVoglerSaundersBonar(this.parametrosAjustables, this.parametrosNoAjustables); 
		
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#getPanelCreacion()
	 */
	@Override
	public PanelModelos getPanelCreacion() {
		return this.menu;
	}

	@Override
	public String getXML() {
		
		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>"+ nombreImplementacion + "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");
		
		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>"+ nombreParametrosAjustables[i]+ "</Nombre>\r\n");
			result1.append("        <Valor>" + 0 + "</Valor>\r\n");
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		if (parametrosNoAjustables.length != 0) {
			
			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer();
				result1 = new StringBuffer("<ParametrosNoAjustables>");
				result1.append("        <Nombre>" + nombreParametrosNoAjustables[i]+ "</Nombre>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"+ parametrosNoAjustables[i]	+ "</Valor>\r\n");
				} else {result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");		
				result.append(result1.toString());
				
			}
		}
		
		result.append("      </Modelo>\r\n");
		return result.toString();
		
	}
	
	protected class MenuVoglerSaundersBonar extends PanelModelos	implements ActionListener {

		JTextField repeticiones;
		JTextField maxError;
		JTextField maxCuchillos;
		JTextField margenSeg; 
		JButton botonPorDefecto;
		
		/**
		 * @param parametrosAjustables
		 * @param parametrosNoAjustables
		 */
		public MenuVoglerSaundersBonar(double[] parametrosAjustables, Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables) {
			//no hace nada
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			this.repeticiones.setText(parametrosNoAjustables[0].toString()); 
			this.margenSeg.setText(parametrosNoAjustables[1].toString()); 
			this.maxError.setText(parametrosNoAjustables[2].toString());
			this.maxCuchillos.setText(parametrosNoAjustables[3].toString());
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 */
		@Override
		public double[] getParametrosAjustables() throws ModeloMalDefinidoException {
			return new double[]{}; 
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 */
		@Override
		public Object[] getParametrosNoAjustables() throws ModeloMalDefinidoException {
			return new Object[]{
				new Integer(Integer.parseInt(repeticiones.getText())),
				new Double(Double.parseDouble(margenSeg.getText())), 
				new Integer(Integer.parseInt(maxError.getText())), 
				new Integer(Integer.parseInt(maxCuchillos.getText()))
			}; 
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#agregarElementos()
		 */
		@Override
		public void agregarElementos() {
			
			this.setLayout(new GridBagLayout()); 
			GridBagConstraints c = new GridBagConstraints(); 
			c.insets = new Insets(4,4,4,4); 
			
			c.fill = GridBagConstraints.NONE; 
			this.add(new JLabel("Repeticiones"), c);
			
			this.repeticiones = new JTextField(); 
			c.gridx = 1;
			c.fill = GridBagConstraints.HORIZONTAL; 
			this.add(repeticiones, c);
			
			c.gridy = 1; 
			c.gridx = 0; 
			c.fill = GridBagConstraints.NONE; 
			this.add(new JLabel("Margen de Seguridad"), c); 
			
			this.margenSeg = new JTextField(); 
			c.gridx = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			this.add(margenSeg, c);
			
			c.gridy = 2; 
			c.gridx = 0; 
			c.fill = GridBagConstraints.NONE; 
			this.add(new JLabel("Máximo Error"), c);
			
			this.maxError = new JTextField(); 
			c.gridx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL;
			this.add(maxError, c); 
			
			c.gridy = 3; 
			c.gridx = 0; 
			c.fill = GridBagConstraints.NONE; 
			this.add(new JLabel("Máxima cantidad de Cuchillos"), c);
			
			this.maxCuchillos = new JTextField(); 
			c.gridx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL;
			this.add(maxCuchillos, c);
			
			this.botonPorDefecto = new JButton("Valores por Defecto"); 
			c.gridy = 4;
			c.gridx = 1; 
			c.anchor = GridBagConstraints.LINE_END; 
			c.fill = GridBagConstraints.NONE; 
			this.add(botonPorDefecto, c); 
			
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 */
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new VoglerSaundersBonar(this.getParametrosAjustables(), this.getParametrosNoAjustables()); 
		}

		/* (non-Javadoc)
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		@Override
		public void actionPerformed(ActionEvent e) {
			VoglerSaundersBonar m = new VoglerSaundersBonar(); 
			this.setParametrosAjustables(m.parametrosAjustables);
			this.setParametrosNoAjustables(m.parametrosNoAjustables); 
		}
		
	}
	
}
