
package sapo.predicciones;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;
 
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
/**
 * Esta clase representa el modelo de atenuación MOPEM 
 * (modelo de propagación para entornos urbanos de pequeñas macroceldas). 
 * 
 * @author Grupo de proyecto SAPO 
*/
public class Mopem extends Modelo {
	

	/**
	 *
	 *  Construye el modelo de Mopem
	 * 
	 * 
	 */
	
	public Mopem() {
		super();
	}
	
	/**
	 * Construye el modelo de Mopem con los parámetros que se crean convenientes. 
	 * @param parametrosAjustables 
	 *  ver el toString del modelo para ver qué parámetro va en cada posición. 
	 * @param parametrosNoAjustables 
	 * @throws ModeloMalDefinidoException
	 */
	public Mopem(
			double[] parametrosAjustables,
			Object[] parametrosNoAjustables) throws ModeloMalDefinidoException {
		super(parametrosAjustables, parametrosNoAjustables);
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#getParametrosAjustablesPorDefecto()
	 * 
	 */
	
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		double[] parametros = Mopem.getParametrosAjustables();
		return parametros;
	}
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#getParametrosNoAjustablesPorDefecto()
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		Object[] parametros = new Object[] {};
		return parametros;
		
	}
	
	
	/**
	 *
	 *  Devuelve los parametros ajutables del modelo MOPEM

	 * 
	 */
	
	private static double[] getParametrosAjustables() {
		double[] parametros = new double[] {
				//LB
				32.44, 20, 20,
				//Lrts
				1.87, -10, 10, 10.4,
				//Lori
				-2.8, 13.2, -29.5, 30.3, -3.5,
				//Lmsd
				54, -18, -4, 0.7, 925, 27.7, -9, 
				//Lesq
				-11.32, 3.3};
		return parametros;
		
	}

	 /* (non-Javadoc)
	 *  @see explorer.modelos.Modelo#setNombres()
	 * 
	 */
	
	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.MOPEM;
		this.nombreParametrosAjustables = new String[] { "LB0", "LB1", "LB2",
				"Lrts0", "Lrts1", "Lrts2", "Lrts3", "Lori0", "Lori1", "Lori2", "Lori3", "Lori4", "Lmsd0", 
				"Lmsd1", "Lmsd2", "Lmsd3", "Lmsd4", "Lmsd5", "Lmsd6", "Lesq0", "Lesq1" };
		this.nombreParametrosNoAjustables = new String[] { "" };
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#verificarDatos(explorer.proyecto.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia()
		&& !mapa.getCapaEdificios().esVacia()
		&& !mapa.getCapaManzanas().esVacia();
		
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, double, double, double)
	 */
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo MOPEM");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			
			if(envoltura==null)
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo COST231WI es nula, verifique los datos");
			
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));			
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
			//MathTransform2D mt = gc.getGridGeometry().getGridToCoordinateSystem2D();			
			
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura();
			
			//double hR;
			double lambda = Modelo.C/antena.getFrecuencia();
			double distancia;
			double atenuacionAux;
			double atenuacionVacio;		
			
			double lB0, lB1, lB2; 
			
			double[] phiw; 
			double h, w, b, phi; 
			double lB, lmsd, lrts, lesq; 
			
			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			double[] datos = new double[ancho*alto];
			int contador = 0;
			double minimo = Double.MAX_VALUE;
			double maximo = -Double.MAX_VALUE;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			com.vividsolutions.jts.geom.Point puntoMovil; 
			
			
			UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radioMax, sitioAntena, "altura");
			UtilidadesModelosManzanas umc = new UtilidadesModelosManzanas(gc, mapa.getCapaManzanas().getFeatureCollection(), radioMax, sitioAntena);
			GeometryFactory gf = new GeometryFactory(); 
			double[] alturasEfectivas;
			double alturaTotalMovil, alturaTotalBase; 
			alturaTotalBase = hTrelativa + ume.getAlturaAntena(); 
			hTrelativa += ume.getAlturaEdificioAntena(); 
			
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){ 
					//
					sitioMovil = mt.transform(new Point(i,j),null);
					puntoMovil = gf.createPoint(new Coordinate(sitioMovil.getX(), sitioMovil.getY()));
					
					if(ume.calcularDistanciaGrid(sitioAntena, sitioMovil) < radioMax){
						
						alturaTotalMovil = ume.getAlturaTotal(sitioMovil, hRrelativa, this.usarInterpolacion);
						double[] alturas = new double[]{ alturaTotalBase, alturaTotalMovil};
						
						double[] distanciaYangulos  = ume.calcularDistanciaReal(sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion);
						distancia = distanciaYangulos[0];
						distancia = distancia/1000.0; //el modelo utiliza la distancia en km
						LineString linea = gf.createLineString(new Coordinate[]{
								new Coordinate(sitio.getX(), sitio.getY()), 
								new Coordinate(sitioMovil.getX(), sitioMovil.getY())
						}); 						
										
					
						lB0 = this.parametrosAjustables[0];
						lB1 = this.parametrosAjustables[1];
						lB2 = this.parametrosAjustables[2];
						//lB = lB0 + (lB1*Math.log(distancia) + lB2*Math.log(frecuencia))/Math.log(10.0);
						lB = lB0 + lB1*Math.log(distancia)/Math.log(10.0) + lB2*Math.log(frecuencia)/Math.log(10.0);
						
						PerfilAlturas perfil = ume.hallarPerfilDeEdificios(linea, antena.getFrecuencia(), alturas, 1.0);
						h = ume.alturaPromedio(puntoMovil, 50);
						b = perfil.separacionPromedioObstaculos();
						if(Double.isNaN(b))//en caso que haya solo un obstáculo y por lo tanto no hay separación pongo un valo entre los recomendados para el caso en que no se tengan datos
							b = 30; 
						phiw = umc.calcularOrientacionAncho(sitioMovil, sitioAntena, 40);
						phi = phiw[0];
						w = phiw[1]; 
											
						if(Double.isNaN(w))
							w = umc.getUltimoAncho(); 
						if(Double.isNaN(phi))
							phi = umc.getUltimaOri(); //si no tuvieron sentido calcularlo, tomo el último suponiendo que será razonable. 
					
						
						double[] desq = umc.calcularDistanciaEsq(sitioMovil, sitioAntena, 100);
						double desq1 = desq[0];
						double desq2 = desq[1];
						
						
					/*	if(Double.isNaN(desq1))
							desq1 = umc.getUltimaDesq1(); 
						if(Double.isNaN(phi))
							desq2 = umc.getUltimaDesq2();*/
						
						//if(!(Double.isNaN(w) || Double.isNaN(phi) || Double.isNaN(desq1) || Double.isNaN(desq2) || (desq1 == 0) || (desq2 == 0))){ //en caso que w o phi den NaN quiere decir que no tiene sentido el modelo. 
						if(!(-Double.MAX_VALUE == w || -Double.MAX_VALUE == phi || -Double.MAX_VALUE == desq1 || -Double.MAX_VALUE == desq2)){ //en caso que w o phi den NaN quiere decir que no tiene sentido el modelo.	
							double lori0 = this.parametrosAjustables[7];
							double lori1 = this.parametrosAjustables[8];
							double lori2 = this.parametrosAjustables[9];
							double lori3 = this.parametrosAjustables[10];
							double lori4 = this.parametrosAjustables[11];
							double lori = lori0*Math.pow((phi/45),4) +  lori1*Math.pow((phi/45),3) + lori2*Math.pow((phi/45),2) + lori3*(phi/45) + lori4; 
							
							
							double lrts0 = this.parametrosAjustables[3];
							double lrts1 = this.parametrosAjustables[4];
							double lrts2 = this.parametrosAjustables[5];
							double lrts3 = this.parametrosAjustables[6];
							lrts = lrts0 + lrts1*Math.log(w)/Math.log(10.0) + lrts2*Math.log(frecuencia)/Math.log(10.0) + lrts3*Math.log(h-alturaTotalMovil)/Math.log(10.0) + lori;
							
							double lmsd0 = this.parametrosAjustables[12];
							double lmsd1 = this.parametrosAjustables[13];
							double lmsd2 = this.parametrosAjustables[14];
							double lmsd3 = this.parametrosAjustables[15];
							double lmsd4 = this.parametrosAjustables[16];
							double lmsd5 = this.parametrosAjustables[17];
							double lmsd6 = this.parametrosAjustables[18];
							
							double lbsh;
							if (alturaTotalBase > h){
								lbsh = lmsd1*Math.log(1 + alturaTotalBase-h)/Math.log(10.0);
							} else {
								lbsh = 0;
							}
							 
							
							lmsd = lmsd0 + lbsh + lmsd2*Math.log(frecuencia)/Math.log(10.0) + lmsd3/lmsd4*frecuencia*Math.log(frecuencia)/Math.log(10.0) + 
							- lmsd3*Math.log(frecuencia)/Math.log(10.0) + lmsd5*Math.log(distancia)/Math.log(10.0) + lmsd6*Math.log(b)/Math.log(10.0);
							//lmsd = lmsd0 + lmsd1*Math.log(1 + alturaTotalBase - h)/Math.log(10.0) + lmsd2*Math.log(frecuencia)/Math.log(10.0) + lmsd3*(frecuencia/lmsd4 - 1)*(Math.log(frecuencia)/Math.log(10.0)) 
							//+ lmsd5*Math.log(distancia)/Math.log(10.0) + lmsd6*Math.log(b)/Math.log(10.0);
							
							double lesq0 = this.parametrosAjustables[19];
							double lesq1 = this.parametrosAjustables[20];
							
						
							if (!(Double.isNaN(desq1)) && !(Double.isNaN(desq2))){			
							lesq = lesq0 + lesq1*(Math.log(desq1)/Math.log(10.0) + Math.log(desq2)/Math.log(10.0));
							} else {
								lesq = lesq0;
							}
							atenuacionAux = lB + lrts + lmsd + lesq ;
							double log = 1 + alturaTotalBase-h;
						}else{
							atenuacionAux = Double.NaN; 
						}
					
					if(!Double.isNaN(atenuacionAux)){
//						double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
						// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
						double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
						datos[contador] = antena.getPotencia() + gananciaE - atenuacionAux ;
					}else{
						datos[contador] = Double.NaN; 	
					}
					
				
				}else{
					datos[contador] = Double.NaN;
				}
				if(datos[contador] < minimo) minimo = datos[contador];
				if(datos[contador] > maximo) maximo = datos[contador];
				contador++;
				cuantoVa = (int)((double)contador/((double)(ancho*alto))*100.0);
			}			
		}

		grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
		PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
		rp.setMax(maximo);
		rp.setMin(minimo);
		return rp;
	}catch(Exception z){
		throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
	}
}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, com.vividsolutions.jts.geom.Coordinate)
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de COST231WI");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura();
			double hT; 
			//double hR;
			double lambda = Modelo.C/antena.getFrecuencia();
			double distancia;
			double atenuacionAux;
			double atenuacionVacio;		
			
			double lB0, lB1, lB2; 
			
			double[] phiw; 
			double h, w, b, phi;
			double lB, lmsd, lrts, lesq; 
			
			double[] predicciones = new double[puntos.length];
			int contador = 0;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			com.vividsolutions.jts.geom.Point puntoMovil; 
			
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}
			
			
			UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio+100.0, sitioAntena, "altura");
			UtilidadesModelosManzanas umc = new UtilidadesModelosManzanas(gc, mapa.getCapaManzanas().getFeatureCollection(), radio+100.0, sitioAntena);
			GeometryFactory gf = new GeometryFactory(); 

			double alturaTotalMovil, alturaTotalBase; 
			alturaTotalBase = hTrelativa + ume.getAlturaAntena(); 
			hTrelativa += ume.getAlturaEdificioAntena(); 
			
			for(int j=0;j<predicciones.length;j++){
				sitioMovil = new Point2D.Double(puntos[j].x,puntos[j].y);
				alturaTotalMovil = ume.getAlturaTotal(sitioMovil, hRrelativa, this.usarInterpolacion);
				
				puntoMovil = gf.createPoint(new Coordinate(sitioMovil.getX(), sitioMovil.getY()));
				
				double[] distanciaYangulos  = ume.calcularDistanciaReal(sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion);
				distancia = distanciaYangulos[0];
				distancia = distancia/1000.0; //el modelo utiliza la distancia en km
				LineString linea = gf.createLineString(new Coordinate[]{
						new Coordinate(sitio.getX(), sitio.getY()), 
						new Coordinate(sitioMovil.getX(), sitioMovil.getY())
				}); 
		
				double[] alturas = new double[]{ alturaTotalBase, alturaTotalMovil};
					
				lB0 = this.parametrosAjustables[0];
				lB1 = this.parametrosAjustables[1];
				lB2 = this.parametrosAjustables[2];
				lB = lB0 + (lB1*Math.log(distancia) + lB2*Math.log(frecuencia))/Math.log(10.0);
				
				PerfilAlturas perfil = ume.hallarPerfilDeEdificios(linea, antena.getFrecuencia(), alturas, 1.0);
				h = ume.alturaPromedio(puntoMovil, 50);
				b = perfil.separacionPromedioObstaculos();
				if(Double.isNaN(b))//en caso que haya solo un obstáculo y por lo tanto no hay separación pongo un valo entre los recomendados para el caso en que no se tengan datos
					b = 30; 
				
				phiw = umc.calcularOrientacionAncho(sitioMovil, sitioAntena, 100);
				phi = phiw[0]; 
				w = phiw[1]; 
				if(Double.isNaN(w))
					w = umc.getUltimoAncho(); 
				if(Double.isNaN(phi))
					phi = umc.getUltimaOri(); //si no tuvieron sentido calcularlo, tomo el último suponiendo que será razonable. 
				
				
				double[] desq = umc.calcularDistanciaEsq(sitioMovil, sitioAntena, 100);
				double desq1 = desq[0];
				double desq2 = desq[1];
				
			  //if(!(Double.isNaN(w) || Double.isNaN(phi) || Double.isNaN(desq1) || Double.isNaN(desq2) || (desq1 == 0) || (desq2 == 0))){ //en caso que w o phi den NaN quiere decir que no tiene sentido el modelo. 
				if(!(-Double.MAX_VALUE == w || -Double.MAX_VALUE == phi || -Double.MAX_VALUE == desq1 || -Double.MAX_VALUE == desq2)){ //en caso que w o phi den NaN quiere decir que no tiene sentido el modelo.	
					
					double lori0 = this.parametrosAjustables[7];
					double lori1 = this.parametrosAjustables[8];
					double lori2 = this.parametrosAjustables[9];
					double lori3 = this.parametrosAjustables[10];
					double lori4 = this.parametrosAjustables[11];
					double lori = lori0*Math.pow((phi/45),4) +  lori1*Math.pow((phi/45),3) + lori2*Math.pow((phi/45),2) + lori3*(phi/45) + lori4; 
					
					
					double lrts0 = this.parametrosAjustables[3];
					double lrts1 = this.parametrosAjustables[4];
					double lrts2 = this.parametrosAjustables[5];
					double lrts3 = this.parametrosAjustables[6];
					lrts = lrts0 + lrts1*Math.log(w)/Math.log(10.0) + lrts2*Math.log(frecuencia)/Math.log(10.0) + lrts3*Math.log(h-alturaTotalMovil)/Math.log(10.0) + lori;
					
					double lmsd0 = this.parametrosAjustables[12];
					double lmsd1 = this.parametrosAjustables[13];
					double lmsd2 = this.parametrosAjustables[14];
					double lmsd3 = this.parametrosAjustables[15];
					double lmsd4 = this.parametrosAjustables[16];
					double lmsd5 = this.parametrosAjustables[17];
					double lmsd6 = this.parametrosAjustables[18];
					
					double lbsh;
					if (alturaTotalBase > h){
						lbsh = lmsd1*Math.log(1 + alturaTotalBase-h)/Math.log(10.0);
					} else {
						lbsh = 0;
					}
					
					lmsd = lmsd0 + lbsh + lmsd2*Math.log(frecuencia)/Math.log(10.0) + lmsd3/lmsd4*frecuencia*Math.log(frecuencia)/Math.log(10.0) + 
					- lmsd3*Math.log(frecuencia)/Math.log(10.0) + lmsd5*Math.log(distancia)/Math.log(10.0) + lmsd6*Math.log(b)/Math.log(10.0);
					//lmsd = lmsd0 + lmsd1*Math.log(1 + alturaTotalBase-h)/Math.log(10.0) + lmsd2*Math.log(frecuencia)/Math.log(10.0) + lmsd3*(frecuencia/lmsd4 - 1)*(Math.log(frecuencia)/Math.log(10.0)) 
					//+ lmsd5*Math.log(distancia)/Math.log(10.0) + lmsd6*Math.log(b)/Math.log(10.0);
					
					double lesq0 = this.parametrosAjustables[19];
					double lesq1 = this.parametrosAjustables[20];
					
				
					if (!(Double.isNaN(desq1)) && !(Double.isNaN(desq2))){			
					lesq = lesq0 + lesq1*(Math.log(desq1)/Math.log(10.0) + Math.log(desq2)/Math.log(10.0));
					} else {
						lesq = lesq0;
					}
					atenuacionAux = lB + lrts + lmsd + lesq ;
					
				}else{
					atenuacionAux = Double.NaN;
				}
				//}
				if(!Double.isNaN(atenuacionAux)){
					// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
					double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
//					double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
					predicciones[j] = antena.getPotencia() + gananciaE - atenuacionAux ;
				}else{
					predicciones[j] = Double.NaN; 	
				}
				
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
			}			
			
			return predicciones;
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}		
		
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#areaCalculable(explorer.proyecto.Mapa, java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try {
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf
					.createLinearRing(new Coordinate[] { new Coordinate(0, 0),
							new Coordinate(1, 0), new Coordinate(1, 1),
							new Coordinate(0, 1), new Coordinate(0, 0) }), null);
			while (fi.hasNext() && esta == false) {
				rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if (!esta)
				return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
			.getCoordinates();
			Envelope envoltura = new Envelope(2);
			for (int j = 0; j < coordenadas.length; j++)
				envoltura.add(new CoordinatePoint(
						coordenadas[j].x,
						coordenadas[j].y)); //genero la envoltura que contiene los cuatro vértices
			return envoltura;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#crearPanelCreacion()
	 * 
	 */
	
	@Override
	protected void crearPanelCreacion() {
		this.menu = new MenuMOPEM(
				this.parametrosAjustables,
				this.parametrosNoAjustables);
		
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#getPanelCreacion()
	 * 
	 */
	
	@Override
	public PanelModelos getPanelCreacion() {
		return this.menu;
	}
	
	@Override
	public String getXML() {
		
		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>"+ nombreImplementacion + "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");
		
		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>"+ nombreParametrosAjustables[i]+ "</Nombre>\r\n");
			if (parametrosAjustables.length != 0) {
				result1.append("        <Valor>"+ parametrosAjustables[i]+ "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		/*if (parametrosNoAjustables.length != 0) {
			
			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer();
				if ((i == 0)) {
					
					//Double[] paramLori =  (Double[])this.parametrosNoAjustables[i];
					double[] paramLori =  (double[])this.parametrosNoAjustables[i];
					for (int j=0; j< paramLori.length;j++){
						result1 = new StringBuffer(	"<ParametrosNoAjustablesSubitems>");
						//Double Lori = (Double) paramLori[j];
						double Lori = (double) paramLori[j];
						result1.append("        <Nombre>"+ "Lori"+ j+ "</Nombre>\r\n");
						result1.append("        <Valor>" + Lori + "</Valor>\r\n");
						result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
						result.append(result1.toString());
					}		
				}
				if ((i == 1)) {
					Object[] paramLmsd =  (Object[])this.parametrosNoAjustables[i];
					for (int j=0; j< paramLmsd.length;j++){
						double[] conjuntoLmsd =  (double[])paramLmsd[j];
						for (int h=0; h< conjuntoLmsd.length;h++){
							result1 = new StringBuffer(	"<ParametrosNoAjustablesSubitems>");
							double Lmsd = conjuntoLmsd[h];
							result1.append("        <Nombre>"+ "Lmsd"+ h+ "</Nombre>\r\n");
							result1.append("        <Valor>" + Lmsd + "</Valor>\r\n");
							result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
							result.append(result1.toString());
						}						
					}	
					
				}
				result1 = new StringBuffer("<ParametrosNoAjustables>");
				result1.append("        <Nombre>" + nombreParametrosNoAjustables[i]+ "</Nombre>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"+ parametrosNoAjustables[i]	+ "</Valor>\r\n");
				} else {result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");	
				result.append(result1.toString());
				
			}
		}
		*/
		result.append("      </Modelo>\r\n");
		return result.toString();
		
	}
	
	
/**
 * Ventana de creación de instancias del modelo MOPEM
 * @author Grupo de Proyecto SAPO.
 *
 */
	protected class MenuMOPEM extends PanelModelos
	implements
	ActionListener {
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lB0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lB1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lB2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts3;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lori0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lori1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lori2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lori3;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lori4;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsd0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsd1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsd2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsd3;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsd4;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsd5;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsd6;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lesq0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lesq1;
		
	
		//JPanel noAjustables;
		JButton botonPorDefecto;
		
		
		MenuMOPEM(
				double[] parametrosAjustables,
				Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
		}
		
		/**
		 *
		 *	  Esta implementación en particular es un panel, con dos panels dentro. Uno para los parámetros ajustables, 
		 *	  y otro para los no ajustables (este será el layout que deberían seguir los demás modelos para una 
		 *	  coherencia del programa). 
		 *	 
		 */
		
		@Override
		public void agregarElementos() {
			this.setLayout(new GridBagLayout());
			TitledBorder bordeAjustable, bordeNoAjustable, bordeVacio, bordeNoVacio;
			JPanel ajustables = new JPanel();
			ajustables.setLayout(new GridBagLayout());
			//noAjustables = new JPanel();
			//noAjustables.setLayout(new GridBagLayout());
			
			GridBagConstraints c = new GridBagConstraints();
			c.insets = new Insets(2, 2, 2, 2);
			GridBagConstraints cGrande = new GridBagConstraints();
			
			/*
			 * Creo el panel para los ajustables con un borde con título y luego lo agrego al panel. 
			 */
			
			/*
			 * LB
			 */
			JPanel ajustLB = new JPanel();
			ajustLB.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLB
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>B</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lB0 = new JTextField("");
			ajustLB.add(lB0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLB
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>B</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lB1 = new JTextField("");
			ajustLB.add(lB1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLB
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>B</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lB2 = new JTextField("");
			ajustLB.add(lB2, c);
			
			bordeVacio = BorderFactory.createTitledBorder("LB");
			ajustLB.setBorder(bordeVacio);
			
			
			/*
			 * parametros de Lmsd
			 */
			
			JPanel ajustLmsd = new JPanel();
			ajustLmsd.setLayout(new GridBagLayout());
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLmsd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsd0 = new JTextField("");
			ajustLmsd.add(lmsd0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLmsd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsd1 = new JTextField("");
			ajustLmsd.add(lmsd1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLmsd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsd2 = new JTextField("");
			ajustLmsd.add(lmsd2, c);
			
			c.gridx = 0;
			c.gridy = 3;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLmsd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>3: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 3;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsd3 = new JTextField("");
			ajustLmsd.add(lmsd3, c);
			
			c.gridx = 2;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLmsd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>4: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsd4 = new JTextField("");
			ajustLmsd.add(lmsd4, c);
			
			c.gridx = 2;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLmsd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>5: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsd5 = new JTextField("");
			ajustLmsd.add(lmsd5, c);
			
			c.gridx = 2;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLmsd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>6: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsd6 = new JTextField("");
			ajustLmsd.add(lmsd6, c);
			
			bordeVacio = BorderFactory.createTitledBorder("Lmsd");
			ajustLmsd.setBorder(bordeVacio);
			
			/*
			 * parametros de Lrts
			 */
			JPanel ajustLrts = new JPanel();
			ajustLrts.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLrts
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts0 = new JTextField("");
			ajustLrts.add(lrts0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLrts
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts1 = new JTextField("");
			ajustLrts.add(lrts1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLrts
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts2 = new JTextField("");
			ajustLrts.add(lrts2, c);
			
			c.gridx = 0;
			c.gridy = 3;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLrts
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>3: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 3;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts3 = new JTextField("");
			ajustLrts.add(lrts3, c);
			
			bordeVacio = BorderFactory.createTitledBorder("Lrts");
			ajustLrts.setBorder(bordeVacio);
			
			
			// Parametros de Lori
			
			JPanel ajustLori = new JPanel();
			ajustLori.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori0 = new JTextField("");
			ajustLori.add(lori0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori1 = new JTextField("");
			ajustLori.add(lori1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori2 = new JTextField("");
			ajustLori.add(lori2, c);
			
			c.gridx = 2;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>3: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori3 = new JTextField("");
			ajustLori.add(lori3, c);
			
			c.gridx = 2;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>4: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori4 = new JTextField("");
			ajustLori.add(lori4, c);
			
			
			
			bordeVacio = BorderFactory.createTitledBorder("Lori");
			ajustLori.setBorder(bordeVacio);
			
			/* 
			 Parametros de Lesq
			 */
			JPanel ajustLesq = new JPanel();
			ajustLesq.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLesq
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>esq</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lesq0 = new JTextField("");
			ajustLesq.add(lesq0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustLesq
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>esq</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lesq1 = new JTextField("");
			ajustLesq.add(lesq1, c);
			
			
			bordeVacio = BorderFactory.createTitledBorder("Lesq");
			ajustLesq.setBorder(bordeVacio);
			
			/*
			 * El panel total de los ajustables. 
			 */
			c.gridx = 0;
			c.gridy = 1;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			ajustables.add(ajustLB, c);
			c.gridx = 0;
			c.gridy = 3;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			ajustables.add(ajustLrts, c);
			c.gridx = 2;
			c.gridy = 1;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			ajustables.add(ajustLori, c);
			c.gridx = 2;
			c.gridy = 3;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			ajustables.add(ajustLmsd, c);
			c.gridx = 0;
			c.gridy = 5;
			c.gridwidth = 4;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			ajustables.add(ajustLesq, c);
			bordeAjustable = BorderFactory
			.createTitledBorder("Parámetros Ajustables");
			ajustables.setBorder(bordeAjustable);
			
			cGrande.gridx = 0;
			cGrande.gridy = 0;
			cGrande.gridwidth = 4;
			cGrande.gridheight = 2;
			cGrande.fill = GridBagConstraints.BOTH;
			//cGrande.weightx = 1;
			cGrande.insets = new Insets(4, 4, 4, 4);
			this.add(ajustables, cGrande);
			
			
			
			botonPorDefecto = new JButton("Valores por defecto");
			botonPorDefecto.addActionListener(this);
			cGrande.gridx = 3;
			cGrande.gridy = 4;
			cGrande.gridwidth = 1;
			cGrande.gridheight = 1;
			cGrande.anchor = GridBagConstraints.LAST_LINE_END;
			cGrande.fill = GridBagConstraints.NONE;
			//c.weightx = 0;
			this.add(botonPorDefecto, cGrande);
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 *	 
		 */
		
		@Override
		public double[] getParametrosAjustables()
		throws ModeloMalDefinidoException {
			try {
				double lB0 = Double.parseDouble(this.lB0.getText());
				double lB1 = Double.parseDouble(this.lB1.getText());
				double lB2 = Double.parseDouble(this.lB2.getText());
				double lrts0 = Double.parseDouble(this.lrts0.getText());
				double lrts1 = Double.parseDouble(this.lrts1.getText());
				double lrts2 = Double.parseDouble(this.lrts2.getText());
				double lrts3 = Double.parseDouble(this.lrts3.getText());
				double lmsd0 = Double.parseDouble(this.lmsd0.getText());
				double lmsd1 = Double.parseDouble(this.lmsd1.getText());
				double lmsd2 = Double.parseDouble(this.lmsd2.getText());
				double lmsd3 = Double.parseDouble(this.lmsd3.getText());
				double lmsd4 = Double.parseDouble(this.lmsd4.getText());
				double lmsd5 = Double.parseDouble(this.lmsd5.getText());
				double lmsd6 = Double.parseDouble(this.lmsd6.getText());
				double lori0 = Double.parseDouble(this.lori0.getText());
				double lori1 = Double.parseDouble(this.lori1.getText());
				double lori2 = Double.parseDouble(this.lori2.getText());
				double lori3 = Double.parseDouble(this.lori3.getText());
				double lori4 = Double.parseDouble(this.lori4.getText());
				double lesq0 = Double.parseDouble(this.lesq0.getText());
				double lesq1 = Double.parseDouble(this.lesq1.getText());
				double[] parametros = new double[] { lB0, lB1,
						lB2, lrts0, lrts1, lrts2, lrts3, lori0, lori1, lori2, lori3, lori4, lmsd0, lmsd1, lmsd2, lmsd3, lmsd4, 
						lmsd5, lmsd6,  lesq0, lesq1						
				};
				return parametros;
			} catch (Exception e) {
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
				"Algunos de los campos están mal");
				throw ex;
			}
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 *	 
		 */
		
		@Override
		public Object[] getParametrosNoAjustables()
		throws ModeloMalDefinidoException {
			try {
				Object[] parametrosNoAj = new Object[] {};
										
				return parametrosNoAj;
			} catch (Exception e) {
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
				"Algunos de los valores ingresados están mal");
				throw ex;
			}
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables) {
			this.lB0.setText(String.valueOf(parametrosAjustables[0]));
			this.lB1.setText(String.valueOf(parametrosAjustables[1]));
			this.lB2.setText(String.valueOf(parametrosAjustables[2]));
			this.lrts0.setText(String.valueOf(parametrosAjustables[3]));
			this.lrts1.setText(String.valueOf(parametrosAjustables[4]));
			this.lrts2.setText(String.valueOf(parametrosAjustables[5]));
			this.lrts3.setText(String.valueOf(parametrosAjustables[6]));
			this.lmsd0.setText(String.valueOf(parametrosAjustables[12]));
			this.lmsd1.setText(String.valueOf(parametrosAjustables[13]));
			this.lmsd2.setText(String.valueOf(parametrosAjustables[14]));
			this.lmsd3.setText(String.valueOf(parametrosAjustables[15]));
			this.lmsd4.setText(String.valueOf(parametrosAjustables[16]));
			this.lmsd5.setText(String.valueOf(parametrosAjustables[17]));
			this.lmsd6.setText(String.valueOf(parametrosAjustables[18]));
			this.lori0.setText(String.valueOf(parametrosAjustables[7]));
			this.lori1.setText(String.valueOf(parametrosAjustables[8]));
			this.lori2.setText(String.valueOf(parametrosAjustables[9]));
			this.lori3.setText(String.valueOf(parametrosAjustables[10]));
			this.lori4.setText(String.valueOf(parametrosAjustables[11]));
			this.lesq0.setText(String.valueOf(parametrosAjustables[19]));
			this.lesq1.setText(String.valueOf(parametrosAjustables[20]));
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			
		}
		
		/**
		 * simplemente resetea los valores a los por defecto. 
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Mopem c = new Mopem();
			this.setParametrosAjustables(c.parametrosAjustables);

		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 *	 
		 */
		
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new Mopem(this.getParametrosAjustables(), this
					.getParametrosNoAjustables());
		}
		
		/*
		 *
		 *	   (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getTamanioVentana()
		 *	 
		 */
		
		public Dimension getTamanioVentana() {
			return new Dimension(420, 440);
		}
	}
	
}
