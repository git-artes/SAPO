
package sapo.predicciones;

import java.awt.Color;

import javax.swing.JFrame;

import sapo.ifusuario.GraficadorSimple;
import umontreal.iro.lecuyer.hups.HaltonSequence;
import umontreal.iro.lecuyer.hups.KorobovLattice;
import umontreal.iro.lecuyer.hups.PointSet;
import umontreal.iro.lecuyer.hups.PointSetIterator;
import umontreal.iro.lecuyer.probdist.StudentDist;
import umontreal.iro.lecuyer.rng.MRG32k3a;
import umontreal.iro.lecuyer.stat.Tally;

/**
 * Esta clase implementa la integral de Vogler mediante métodos numéricos.
 * @author Grupo de proyecto SAPO
 */
public class IntegralVogler {

	/**
	 * el generador de números QMC
	 */
	PointSet generador;

	/**
	 * de donde saldrán los número para hacer el promedio
	 */
	PointSetIterator iterador;

	/**
	 * cuantos puntos del iterador se usarán
	 */
	int cuantos;

	/**
	 * La altura de los elementos en el perfil
	 */
	double[] h;

	/**
	 * La separación entre los elementos del perfil.
	 */
	double[] r;

	//parametros de la integral
	/**
	 * cuantos cuchillos
	 */
	int N;

	double cN;

	Complex sigmaN;

	double[] alfa;

	double[] b;

	/**
	 * frecuencia
	 */
	double f;

	/**
	 * Constructor de la clase. Se le pasan los parámetros físicos, y ella se
	 * encarga de calcular los parámetros de la integral.
	 * 
	 * @param f 
	 *            Frecuencia
	 * @param r 
	 *            Distancias entre transmisor, cuchillos y receptor.
	 * @param h 
	 *            Altura de transmisor, cuchillos y receptor.
	 * @param genera 
	 *            Un umontreal.iro.lecuyer.hups.PointSet que generara los
	 *            valores pseudo-aleatorios (se recomienda utilizar la secuencia
	 *            de Korobov)
	 * @param n 
	 *            Cuantos valores de la secuencia serán utilizadas (Muy
	 *            importante cuando se usan secuencias de largo infinito)
	 * @throws MalFormedIntegralException
	 */

	public IntegralVogler(double f, double[] r, double[] h, PointSet genera,
			int n) throws MalFormedIntegralException {
		generador = genera;
		iterador = generador.iterator();
		cuantos = n;
		this.f = f;
		this.r = r;
		this.h = h;

		N = r.length - 1;

		if (h.length != N + 2) {
			MalFormedIntegralException exception = new MalFormedIntegralException(
					"Los parametros h y r no concuerdan en su tamaño");
			throw exception;
		}
		alfa = new double[N - 1];
		b = new double[N];
		double tita;
		double k = 2 * Math.PI * f / 3e8; //el número de onda
		sigmaN = new Complex(0, 0);
		for (int j = 0; j < N - 1; j++) {
			//tita = (h[j+1]-h[j])/r[j]+(h[j+1]-h[j+2])/r[j+1];
			tita = Math.atan((h[j + 1] - h[j]) / r[j])
					+ Math.atan((h[j + 1] - h[j + 2]) / r[j + 1]);
			b[j] = tita
					* Math.pow(k * r[j] * r[j + 1] / (2 * (r[j] + r[j + 1])),
							0.5);
			alfa[j] = Math.pow(r[j] * r[j + 2]
					/ ((r[j] + r[j + 1]) * (r[j + 1] + r[j + 2])), 0.5);
			sigmaN = sigmaN.add(new Complex(0, Math.pow(b[j], 2)));
		}
		//tita = (h[N]-h[N-1])/r[N-1]+(h[N]-h[N+1])/r[N];
		tita = Math.atan((h[N] - h[N - 1]) / r[N - 1])
				+ Math.atan((h[N] - h[N + 1]) / r[N]);
		b[N - 1] = tita
				* Math.pow(k * r[N - 1] * r[N] / (2 * (r[N - 1] + r[N])), 0.5);
		sigmaN = sigmaN.add(new Complex(0, Math.pow(b[N - 1], 2)));

		cN = 1;
		double rT = 0; //largo total
		for (int j = 0; j < r.length; j++) {
			rT += r[j];
		}
		for (int j = 1; j < r.length - 1; j++) {
			cN = cN * r[j] / (r[j - 1] + r[j]);
		}
		cN = Math.pow(cN * rT / (r[N - 1] + r[N]), 0.5);
	}

	/**
	 * Igual que el otro constructor, pero el generador QMC es la secuencia de
	 * Korobov de base 1397 y cantidad 4093.

	 */
	public IntegralVogler(double f, double[] r, double[] h)
			throws MalFormedIntegralException {
		cuantos = 4093;
		int base = 1397;
		int dimension = h.length - 2;
		generador = new KorobovLattice(cuantos, base, dimension);
		iterador = generador.iterator();

		this.f = f;
		this.r = r;
		this.h = h;

		N = r.length - 1;

		if (h.length != N + 2) {
			MalFormedIntegralException exception = new MalFormedIntegralException(
					"Los parametros h y r no concuerdan en su tamaño");
			throw exception;
		}
		alfa = new double[N - 1];
		b = new double[N];
		double tita;
		double k = 2 * Math.PI * f / 3e8; //el número de onda
		sigmaN = new Complex(0, 0);
		for (int j = 0; j < N - 1; j++) {
			//tita = (h[j+1]-h[j])/r[j]+(h[j+1]-h[j+2])/r[j+1];
			tita = Math.atan((h[j + 1] - h[j]) / r[j])
					+ Math.atan((h[j + 1] - h[j + 2]) / r[j + 1]);
			b[j] = tita
					* Math.pow(k * r[j] * r[j + 1] / (2 * (r[j] + r[j + 1])),
							0.5);
			alfa[j] = Math.pow(r[j] * r[j + 2]
					/ ((r[j] + r[j + 1]) * (r[j + 1] + r[j + 2])), 0.5);
			sigmaN = sigmaN.add(new Complex(0, Math.pow(b[j], 2)));
		}
		//tita = (h[N]-h[N-1])/r[N-1]+(h[N]-h[N+1])/r[N];
		tita = Math.atan((h[N] - h[N - 1]) / r[N - 1])
				+ Math.atan((h[N] - h[N + 1]) / r[N]);
		b[N - 1] = tita
				* Math.pow(k * r[N - 1] * r[N] / (2 * (r[N - 1] + r[N])), 0.5);
		sigmaN = sigmaN.add(new Complex(0, Math.pow(b[N - 1], 2)));

		cN = 1;
		double rT = 0; //largo total
		for (int j = 0; j < r.length; j++) {
			rT += r[j];
		}
		for (int j = 1; j < r.length - 1; j++) {
			cN = cN * r[j] / (r[j - 1] + r[j]);
		}
		cN = Math.pow(cN * rT / (r[N - 1] + r[N]), 0.5);
	}

	/**
	 * Igual que el constructor, pero simplemente genera nuevamente los
	 * parametros.
	 * 

	 */
	public void recalcularParametros(double f, double[] r, double[] h,
			PointSet genera, int n) throws MalFormedIntegralException {

		generador = genera;
		iterador = generador.iterator();
		cuantos = n;
		this.f = f;
		this.r = r;
		this.h = h;

		N = r.length - 1;

		if (h.length != N + 2) {
			MalFormedIntegralException exception = new MalFormedIntegralException(
					"Los parametros h y r no concuerdan en su tamaño");
			throw exception;
		}
		alfa = new double[N - 1];
		b = new double[N];
		double tita;
		double k = 2 * Math.PI * f / 3e8; //el número de onda
		sigmaN = new Complex(0, 0);
		for (int j = 0; j < N - 1; j++) {
			//tita = (h[j+1]-h[j])/r[j]+(h[j+1]-h[j+2])/r[j+1];
			tita = Math.atan((h[j + 1] - h[j]) / r[j])
					+ Math.atan((h[j + 1] - h[j + 2]) / r[j + 1]);
			b[j] = tita
					* Math.pow(k * r[j] * r[j + 1] / (2 * (r[j] + r[j + 1])),
							0.5);
			alfa[j] = Math.pow(r[j] * r[j + 2]
					/ ((r[j] + r[j + 1]) * (r[j + 1] + r[j + 2])), 0.5);
			sigmaN = sigmaN.add(new Complex(0, Math.pow(b[j], 2)));
		}
		//tita = (h[N]-h[N-1])/r[N-1]+(h[N]-h[N+1])/r[N];
		tita = Math.atan((h[N] - h[N - 1]) / r[N - 1])
				+ Math.atan((h[N] - h[N + 1]) / r[N]);
		b[N - 1] = tita
				* Math.pow(k * r[N - 1] * r[N] / (2 * (r[N - 1] + r[N])), 0.5);
		sigmaN = sigmaN.add(new Complex(0, Math.pow(b[N - 1], 2)));

		cN = 1;
		double rT = 0; //largo total
		for (int j = 0; j < r.length; j++) {
			rT += r[j];
		}
		for (int j = 1; j < r.length - 1; j++) {
			cN = cN * r[j] / (r[j - 1] + r[j]);
		}
		cN = Math.pow(cN * rT / (r[N - 1] + r[N]), 0.5);

	}

	/**
	 * Calcula la integral mediante métodos QMC y devuelve la ganancia
	 * correspondiente.
	 * 
	 * @return El valor de la ganancia respecto al vacío (valor que hay que
	 *         multiplicar la potencia en caso de espacio vacío para hallar la
	 *         potencia recibida para el caso correspondiente)
	 */

	public Complex calcularIntegral() {

		int contador = 0;
		Tally promediadorReal = new Tally(
				"Tally que se encargara de la parte real");
		Tally promediadorImaginario = new Tally(
				"Tally que se encargara de la parte imaginaria");
		promediadorReal.init();
		promediadorImaginario.init();

		double inReal;
		double inImaginario; //partes imaginarias y reales de la integral
		Complex atenuacion;
		double[] x = new double[N]; //donde se guardaran los sucesivos valores
									// de la secuencia

		while (iterador.hasNextPoint() && contador < cuantos) {
			iterador.nextPoint(x, x.length);
			contador++;

			double B = 0;
			double cambioDeVariable = 1; //el factor que multiplica al hacer
										 // cambio de variable
			for (int j = 0; j < N; j++) {
				B += Math.pow(2, 0.5) * x[j] / (1 - x[j]) * b[j]
						+ Math.pow(b[j], 2);
				cambioDeVariable = cambioDeVariable / Math.pow(1 - x[j], 2);
			}
			double A = 0;
			for (int j = 0; j < N - 1; j++) {
				A += 2 * alfa[j] * (x[j] / (1 - x[j]))
						* (x[j + 1] / (1 - x[j + 1]))
						- Math.pow(x[j] / (1 - x[j]), 2) - Math.pow(2, 0.5)
						* (x[j] / (1 - x[j])) * b[j];
			}
			A += -Math.pow(x[N - 1] / (1 - x[N - 1]), 2) - Math.pow(2, 0.5)
					* (x[N - 1] / (1 - x[N - 1])) * b[N - 1];

			promediadorReal.add(Math.exp(A) * Math.cos(B) * cambioDeVariable);
			promediadorImaginario.add(Math.exp(A) * Math.sin(B)
					* cambioDeVariable);
		}

		inReal = promediadorReal.average();
		inImaginario = promediadorImaginario.average();
		atenuacion = new Complex(inReal, -inImaginario);
		atenuacion = atenuacion.multiply(cN * Math.pow(Math.PI, -N / 2.0));
		Complex expSigmaN = new Complex(Math.cos(sigmaN.getImaginary()), Math
				.sin(sigmaN.getImaginary()));
		atenuacion = atenuacion.multiply(expSigmaN);
		return atenuacion;

	}

	/**
	 * Igual que calcularIntegral() pero esta vez utilizando técnicas RQMC.
	 * 
	 * @param variaciones 
	 *            Cuantas variaciones se desean realizar de la secuencia QMC
	 *            original
	 * @return Idem a calcularIntegral()
	 */
	public Complex calcularIntegralRQMC(int variaciones)
			throws MalFormedIntegralException {

		if (variaciones < 0) {
			MalFormedIntegralException error = new MalFormedIntegralException(
					"Las variaciones deben ser positivas");
			throw error;
		}
		Tally promediadorReal = new Tally();
		Tally promediadorImaginario = new Tally();
		promediadorReal.init();
		promediadorImaginario.init();
		MRG32k3a aleatorio = new MRG32k3a();
		for (int j = 0; j < variaciones; j++) {
			//aleatorio = new MRG32k3a();
			this.generador.randomize(aleatorio);
			this.iterador = this.generador.iterator();
			Complex resultado = this.calcularIntegral();
			promediadorReal.add(resultado.getReal());
			promediadorImaginario.add(resultado.getImaginary());
		}
		Complex resultadoPromediado = new Complex(promediadorReal.average(),
				promediadorImaginario.average());
		return resultadoPromediado;
	}

	public Complex calcularIntegralVoglerAproximada(int variaciones,
			double seguridad, int porcMaxError, int maxCuchillos)
			throws MalFormedIntegralException {

		if (porcMaxError < 0) {
			MalFormedIntegralException error = new MalFormedIntegralException(
					"El porcentaje máximo de error debe ser positivo");
			throw error;
		}

		if (seguridad < 0 || seguridad > 1) {
			throw new MalFormedIntegralException(
					"El valor de la seguridad debe ser mayor que cero y menor que uno. ");
		}

		if (maxCuchillos < 0) {
			throw new MalFormedIntegralException(
					"La máxima cantidad de cuchillos debe ser siempre mayor que cero. ");
		}

		if (variaciones < 0) {
			throw new MalFormedIntegralException(
					"Las variaciones deben ser un número positivo. ");
		}

		double z;

		double margen = porcMaxError / 100.0;

		double parteReal = 0;
		double parteImaginaria = 0;
		boolean OK = false;

		boolean todosMasQueMenosTres = false;
		boolean totalMenorQueMaximo = false;

		while (!todosMasQueMenosTres || !totalMenorQueMaximo) {
			int indiceMinimo = 0;
			double minimo = this.b[0];
			for (int j = 0; j < this.b.length; j++) {
				if (this.b[j] < minimo) {
					minimo = this.b[j];
					indiceMinimo = j;
				}
			}
			if (minimo > -3 && this.h.length <= maxCuchillos + 2) {
				if (minimo > -3)
					todosMasQueMenosTres = true;
				if (this.h.length <= maxCuchillos + 2)
					totalMenorQueMaximo = true;
			} else {
				if (this.h.length == 3) {
					return Complex.ONE; //si solo queda un cuchillo, y hay que
										// sacarlo, devuelvo el caso LOS.
				}

				double[] hNuevo = new double[this.h.length - 1];
				hNuevo[0] = this.h[0];
				for (int j = 1; j < indiceMinimo + 1; j++)
					hNuevo[j] = this.h[j];
				for (int j = indiceMinimo + 2; j < this.h.length; j++)
					hNuevo[j - 1] = this.h[j];

				double[] rNuevo = new double[this.r.length - 1];
				rNuevo[indiceMinimo] = this.r[indiceMinimo]
						+ this.r[indiceMinimo + 1];
				for (int j = 0; j < indiceMinimo; j++)
					rNuevo[j] = this.r[j];
				for (int j = indiceMinimo + 1; j < rNuevo.length; j++)
					rNuevo[j] = this.r[j + 1];
				this.recalcularParametros(this.f, rNuevo, hNuevo,
						this.generador, this.cuantos);
			}
		}

		while (OK == false) {
			Tally promediadorReal = new Tally();
			Tally promediadorImaginario = new Tally();
			promediadorReal.init();
			promediadorImaginario.init();
			MRG32k3a aleatorio = new MRG32k3a();
			for (int j = 0; j < variaciones; j++) {
				//aleatorio = new MRG32k3a();
				this.generador.randomize(aleatorio);
				this.iterador = this.generador.iterator();
				Complex resultado = this.calcularIntegral();
				promediadorReal.add(resultado.getReal());
				promediadorImaginario.add(resultado.getImaginary());
			}
			generador.unrandomize();

			parteReal = promediadorReal.average();
			parteImaginaria = promediadorImaginario.average();

			double varImaginaria = promediadorImaginario.standardDeviation();
			double varReal = promediadorReal.standardDeviation();
			//z = NormalDist.inverseF01(1.0-(1.0-seguridad)/2.0);
			z = StudentDist.inverseF(variaciones - 1,
					1.0 - (1.0 - seguridad) / 2.0);
			double errorReal = varReal * z / Math.pow(variaciones, 0.5);
			double errorImaginario = varImaginaria * z
					/ Math.pow(variaciones, 0.5);

			System.out.println();
			System.out.print("alturas: ");
			for (int j = 0; j < this.h.length; j++)
				System.out.print(h[j] + " ");
			System.out.println();
			System.out.print("separaciones: ");
			for (int j = 0; j < this.r.length; j++)
				System.out.print(r[j] + " ");
			System.out.println();
			System.out.print("betas: ");
			for (int j = 0; j < this.b.length; j++)
				System.out.print(b[j] + " ");
			System.out.println();
			System.out.print("alfas: ");
			for (int j = 0; j < this.alfa.length; j++)
				System.out.print(alfa[j] + " ");
			System.out.println();

			System.out.println("parte real e imaginaria del resultado");
			System.out.println(parteReal);
			System.out.println(parteImaginaria);
			System.out.println("Margenes y errores reales y imaginarias: ");
			System.out.println(margen * parteReal + " - " + errorReal);
			System.out.println(margen * parteImaginaria + " - "
					+ errorImaginario);

			boolean estaBienReal = errorReal <= Math.abs(margen * parteReal);
			boolean estaBienImaginaria = errorImaginario <= Math.abs(margen
					* parteImaginaria);

			System.out
					.println("máxima parte real: "
							+ new Double(Math.abs(parteReal) + errorReal)
							+ " parte imaginaria mínima dividia 100: "
							+ new Double(
									(Math.abs(parteImaginaria) - errorImaginario) / 100.0));
			if (!estaBienReal) {
				System.out.println("falló la parte real");
				if (Math.abs(parteReal) + errorReal < (Math
						.abs(parteImaginaria) - errorImaginario) / 100.0)
					estaBienReal = true; //si la parte real es despreciable
										 // frente a la imaginaria, la ignoro
			}
			System.out.println("máxima imaginaria real: "
					+ new Double(parteImaginaria + errorImaginario)
					+ " parte real mínima dividia 100: "
					+ new Double((parteReal - errorImaginario) / 100.0));
			if (!estaBienImaginaria) {
				System.out.println("fallo la parte imaginaria");
				if (Math.abs(parteImaginaria) + errorImaginario < (Math
						.abs(parteReal) - errorImaginario) / 100.0)
					estaBienImaginaria = true; //si la parte imaginaria es
											   // despreciable frente a la real,
											   // la ignoro
			}

			if (estaBienReal && estaBienImaginaria) {
				OK = true; //si el error es menor o igual al margen permitido,
						   // entonces paro
			} else { //si no, busco el mínimo b, saco ese cuchillo y vuelvo a
					 // empezar

				if (this.h.length == 3) {
					return Complex.ONE; //si solo queda un cuchillo, y hay que
										// sacarlo, devuelvo el caso LOS.
				}

				int indiceMinimo = 0;
				double minimo = this.b[0];
				for (int j = 0; j < this.b.length; j++) {
					if (this.b[j] < minimo) {
						minimo = this.b[j];
						indiceMinimo = j;
					}
				}
				double[] hNuevo = new double[this.h.length - 1];
				hNuevo[0] = this.h[0];
				for (int j = 1; j < indiceMinimo + 1; j++)
					hNuevo[j] = this.h[j];
				for (int j = indiceMinimo + 2; j < this.h.length; j++)
					hNuevo[j - 1] = this.h[j];

				double[] rNuevo = new double[this.r.length - 1];
				rNuevo[indiceMinimo] = this.r[indiceMinimo]
						+ this.r[indiceMinimo + 1];
				for (int j = 0; j < indiceMinimo; j++)
					rNuevo[j] = this.r[j];
				for (int j = indiceMinimo + 1; j < rNuevo.length; j++)
					rNuevo[j] = this.r[j + 1];
				this.recalcularParametros(this.f, rNuevo, hNuevo,
						this.generador, this.cuantos);

			}
		}

		Complex atenuacion = new Complex(parteReal, parteImaginaria);
		return atenuacion;

	}

	/**
	 * Calcula la integral de vogler. Primero quita todos los cuchillos hasta
	 * que todos tengan un beta mayora que -3, y además cumplan que sean menos
	 * que <code>maxCuchillos</code>. Luego utiliza técnicas RQMC para
	 * calcular un primer estimador del resultado de la integral, con cuyos
	 * datos establece un intervalo de confianza. Luego, estima nuevamente la
	 * integral y verifica que esté en el intervalo de confianza. Si cumple
	 * dicha condición sale, sino quita el cuchillo menos significativo y vuelve
	 * al paso anterior.
	 * 
	 * @param variaciones 
	 *            cuantas variaciones de RQMC
	 * @param seguridad 
	 *            el factor de seguridad a utilizar para realizar el intervalor
	 *            de confianza (0.9 o 0.95 únicamente)
	 * @param maxCuchillos 
	 *            la máxima cantidad de cuchillos a tomar en cuenta.
	 * @return
	 * @throws MalFormedIntegralException
	 */
	public Complex calcularIntegralVoglerTestHipotesis(int variaciones,
			double seguridad, int maxCuchillos)
			throws MalFormedIntegralException {

		double z;
		if (seguridad == 0.9) {
			z = 1.64;
		} else {
			z = 1.96;
		}

		double centroParteReal = 0;
		double centroParteImaginaria = 0;
		double radioParteReal = 0;
		double radioParteImaginaria = 0;
		double compruebaReal = 0;
		double compruebaImaginario = 0;
		double parteReal = 0;
		double parteImaginaria = 0;
		boolean OK = false;

		Tally promediadorRealIntervalo;
		Tally promediadorImaginarioIntervalo;
		Tally promediadorRealComprueba;
		Tally promediadorImaginarioComprueba;

		boolean todosMasQueMenosTres = false;
		boolean totalMenorQueMaximo = false;

		while (!todosMasQueMenosTres || !totalMenorQueMaximo) {
			int indiceMinimo = 0;
			double minimo = this.b[0];
			for (int j = 0; j < this.b.length; j++) {
				if (this.b[j] < minimo) {
					minimo = this.b[j];
					indiceMinimo = j;
				}
			}
			if (minimo > -3 && this.h.length <= maxCuchillos + 2) {
				if (minimo > -3)
					todosMasQueMenosTres = true;
				if (this.h.length <= maxCuchillos + 2)
					totalMenorQueMaximo = true;
			} else {
				double[] hNuevo = new double[this.h.length - 1];
				hNuevo[0] = this.h[0];
				for (int j = 1; j < indiceMinimo + 1; j++)
					hNuevo[j] = this.h[j];
				for (int j = indiceMinimo + 2; j < this.h.length; j++)
					hNuevo[j - 1] = this.h[j];

				double[] rNuevo = new double[this.r.length - 1];
				rNuevo[indiceMinimo] = this.r[indiceMinimo]
						+ this.r[indiceMinimo + 1];
				for (int j = 0; j < indiceMinimo; j++)
					rNuevo[j] = this.r[j];
				for (int j = indiceMinimo + 1; j < rNuevo.length; j++)
					rNuevo[j] = this.r[j + 1];
				this.recalcularParametros(this.f, rNuevo, hNuevo,
						this.generador, this.cuantos);
			}
		}

		boolean estaBienReal = false;
		boolean estaBienImaginaria = false;

		while (OK == false) {
			promediadorRealIntervalo = new Tally();
			promediadorImaginarioIntervalo = new Tally();
			promediadorRealIntervalo.init();
			promediadorImaginarioIntervalo.init();
			MRG32k3a aleatorio = new MRG32k3a();
			for (int j = 0; j < variaciones; j++) {
				//aleatorio = new MRG32k3a();
				this.generador.randomize(aleatorio);
				this.iterador = this.generador.iterator();
				Complex resultado = this.calcularIntegral();
				promediadorRealIntervalo.add(resultado.getReal());
				promediadorImaginarioIntervalo.add(resultado.getImaginary());
			}
			generador.unrandomize(); //genero las muestras.

			centroParteReal = promediadorRealIntervalo.average();
			centroParteImaginaria = promediadorImaginarioIntervalo.average();

			double varImaginaria = promediadorImaginarioIntervalo
					.standardDeviation();
			double varReal = promediadorRealIntervalo.standardDeviation();
			radioParteReal = varReal
					* StudentDist.inverseF(variaciones - 1,
							1.0 - (1.0 - seguridad) / 2.0)
					/ Math.sqrt(variaciones);
			radioParteImaginaria = varImaginaria
					* StudentDist.inverseF(variaciones - 1,
							1.0 - (1.0 - seguridad) / 2.0)
					/ Math.sqrt(variaciones); // construyo el intervalo de
											  // confianza.

			promediadorRealComprueba = new Tally();
			promediadorImaginarioComprueba = new Tally();
			promediadorRealComprueba.init();
			promediadorImaginarioComprueba.init();
			//aleatorio = new MRG32k3a();
			for (int j = 0; j < variaciones; j++) {
				//aleatorio = new MRG32k3a();
				this.generador.randomize(aleatorio);
				this.iterador = this.generador.iterator();
				Complex resultado = this.calcularIntegral();
				promediadorRealComprueba.add(resultado.getReal());
				promediadorImaginarioComprueba.add(resultado.getImaginary());
			}
			generador.unrandomize();

			parteReal = promediadorRealComprueba.average();
			parteImaginaria = promediadorImaginarioComprueba.average(); // tomo
																		// un
																		// nuevo
																		// valor
																		// de
																		// promedio
																		// y
																		// luego
																		// verifico
																		// si
																		// pertenece
																		// al
																		// intervalo
																		// de
																		// confianza.

			System.out.println();
			System.out.print("alturas: ");
			for (int j = 0; j < this.h.length; j++)
				System.out.print(h[j] + " ");
			System.out.println();
			System.out.print("separaciones: ");
			for (int j = 0; j < this.r.length; j++)
				System.out.print(r[j] + " ");
			System.out.println();
			System.out.print("betas: ");
			for (int j = 0; j < this.b.length; j++)
				System.out.print(b[j] + " ");
			System.out.println();
			System.out.print("alfas: ");
			for (int j = 0; j < this.alfa.length; j++)
				System.out.print(alfa[j] + " ");
			System.out.println();

			System.out.println("parte real e imaginaria del resultado");
			System.out.println(parteReal);
			System.out.println(parteImaginaria);
			System.out.println("Intervalos de confianza: ");

			estaBienReal = (parteReal >= centroParteReal - radioParteReal)
					&& (parteReal <= centroParteReal + radioParteReal);
			estaBienImaginaria = (parteImaginaria >= centroParteImaginaria
					- radioParteImaginaria)
					&& (parteImaginaria <= centroParteImaginaria
							+ radioParteImaginaria);

			if (!estaBienReal) {
				if (parteReal + radioParteReal < (parteImaginaria - radioParteImaginaria) / 100.0)
					estaBienReal = true; //si la parte real es despreciable
										 // frente a la imaginaria, la ignoro
			}
			if (!estaBienImaginaria) {
				if (parteImaginaria + radioParteImaginaria < (parteReal - radioParteReal) / 100.0)
					estaBienImaginaria = true; //si la parte imaginaria es
											   // despreciable frente a la real,
											   // la ignoro
			}

			System.out.println(new Double(centroParteReal - radioParteReal)
					+ " " + new Double(centroParteReal + radioParteReal));
			System.out.println(new Double(centroParteImaginaria
					- radioParteImaginaria)
					+ " "
					+ new Double(centroParteImaginaria + radioParteImaginaria));

			if (estaBienReal && estaBienImaginaria) {
				OK = true; //si el error es menor o igual al margen permitido,
						   // entonces paro
			} else { //si no, busco el mínimo b, saco ese cuchillo y vuelvo a
					 // empezar
				int indiceMinimo = 0;
				double minimo = this.b[0];
				for (int j = 0; j < this.b.length; j++) {
					if (this.b[j] < minimo) {
						minimo = this.b[j];
						indiceMinimo = j;
					}
				}
				if (this.h.length == 3) {
					return Complex.ONE; //si solo queda un cuchillo, y hay que
										// sacarlo, devuelvo el caso LOS.
				}
				double[] hNuevo = new double[this.h.length - 1];
				hNuevo[0] = this.h[0];
				for (int j = 1; j < indiceMinimo + 1; j++)
					hNuevo[j] = this.h[j];
				for (int j = indiceMinimo + 2; j < this.h.length; j++)
					hNuevo[j - 1] = this.h[j];

				double[] rNuevo = new double[this.r.length - 1];
				rNuevo[indiceMinimo] = this.r[indiceMinimo]
						+ this.r[indiceMinimo + 1];
				for (int j = 0; j < indiceMinimo; j++)
					rNuevo[j] = this.r[j];
				for (int j = indiceMinimo + 1; j < rNuevo.length; j++)
					rNuevo[j] = this.r[j + 1];
				this.recalcularParametros(this.f, rNuevo, hNuevo,
						this.generador, this.cuantos);
			}
		}

		Complex atenuacion = new Complex(parteReal, parteImaginaria);
		return atenuacion;
	}

	/**
	 * Es un main que compara esta integral contra un caso del paper original de
	 * Vogler.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int dimension = 3;
		int cuantos = 2039;
		int base = 1487;
		KorobovLattice koro = new KorobovLattice(cuantos, base, dimension);
		HaltonSequence halton = new HaltonSequence(dimension);

		double[] error = new double[99];
		double[] x = new double[99];
		double[] realidad = new double[99];
		double[] estimacion = new double[99];
		for (int u = 1; u < 100; u++) {
			double[] r = { 100 - u, u, u, 100 - u };
			double[] h = { 0, 0, 0, 0, 0 };
			double f = 800E6;
			try {
				IntegralVogler integral = new IntegralVogler(f, r, h, koro,
						cuantos);

				//Supongamos el primer caso del paper de vogler con dos
				// cuchillos a la misma altura
				double a2 = (1 / (2 * Math.PI))
						* (Math.PI / 2 + Math.atan(integral.alfa[0]
								/ integral.cN));

				//Supongamos el segundo caso del paper de vogler con tres
				// cuchillos a la misma altura
				double a3 = (1 / (4 * Math.PI))
						* (Math.PI / 2
								+ Math.atan(integral.alfa[0] / integral.cN)
								+ Math.atan(integral.alfa[1] / integral.cN) + Math
								.atan(integral.alfa[0] * integral.alfa[1]
										/ integral.cN));
				Complex resultadoPromediado = integral
						.calcularIntegralVoglerAproximada(10, 0.95, 20, 5);
				System.out
						.println("*********** Resultado después de promediar: "
								+ resultadoPromediado);
				error[u - 1] = (a3 - resultadoPromediado.getReal()) / a3;
				x[u - 1] = u;
				realidad[u - 1] = a3;
				estimacion[u - 1] = resultadoPromediado.getReal();
			} catch (Exception e) {
				e.printStackTrace(System.out);
			}
		}

		GraficadorSimple gp1 = new GraficadorSimple("Comparación", "Korobov",
				"Tres cuchillos en línea");
		gp1.setTituloX("u", "m");
		gp1.setTituloY("Ganancia", "S/N");
		gp1.agregarDataLinea(x, realidad, "Resultado analítico", Color.BLUE);
		gp1.agregarDataLinea(x, estimacion, "Resultado estimado", Color.RED);

		JFrame ventana1 = new JFrame("Demo de Korobov");
		ventana1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana1.setSize(new java.awt.Dimension(400, 300));
		ventana1.getContentPane().add(gp1.getJPlotLayout());
		ventana1.setVisible(true);

		GraficadorSimple gp2 = new GraficadorSimple("Error", "Korobov",
				"Tres cuchillos en línea");
		gp2.setTituloX("u", "m");
		gp2.setTituloY("Error", "S/N");
		gp2.agregarDataLinea(x, error, "Error relativo", Color.RED);

		JFrame ventana2 = new JFrame("Demo de Korobov");
		ventana2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana2.setSize(new java.awt.Dimension(400, 300));
		ventana2.getContentPane().add(gp2.getJPlotLayout());
		ventana2.setVisible(true);

	}

}