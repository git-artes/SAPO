package sapo.predicciones;

/**
 * Esta excepción es lanzada al realizar una predicción si ésta no puede
 * calcularse por alguna razón.
 * 
 * @author Grupo de proyecto SAPO
 */

public class PrediccionMalRealizadaException extends Exception {

	public PrediccionMalRealizadaException(String mensaje) {
		super(mensaje);
	}

}
