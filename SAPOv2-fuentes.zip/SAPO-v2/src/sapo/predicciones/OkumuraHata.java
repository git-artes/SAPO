
package sapo.predicciones;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase representa el modelo de atenuación planteado gráficamente por Okumura y luego traducido a fórmulas por 
 * Hata. Toma en cuenta también las correcciones introducidas por el grupo de trabajo COST231. Además del constructor 
 * por defecto, se incluye un constructor para los distintos escenarios posibles según el modelo. Se 
 * recomiendan utilizar este constructor que aquel donde se les pasa los paramátros específicamente.  
 * 
 * @author Grupo de proyecto SAPO 
 *
 */
public class OkumuraHata extends Modelo {
	
	public final static int CIUDAD_MEDIA_PEQUENIA = 0;
	public final static int CIUDAD_GRANDE = 1;
	public final static int AREA_URBANA = 2;
	public final static int AREA_SUBURBANA = 3;
	public final static int AREA_ABIERTA = 4;
	

	/**
	 *
	 *  Construye el modelo de Okumura-Hata tal cual aparece en la formulación de Hata. Además, se supone 
	 *  que se trabaja en una ciudad pequeña o de mediano porte, en un área urbana y a una frecuencia de 800 MHz. 
	 * 
	 * 
	 */
	
	public OkumuraHata() {
		super();
	}
	
	/**
	 * Construye el modelo de Okumura-Hata con los parámetros que se crean convenientes. Hay que tener mucho cuidado 
	 * al utilizar este método y es siempre preferible utilizar los otros dos constructores a no ser que se esté 
	 * realizando un ajuste. Esto es porque dependiendo de la frecuencia, el tipo de área y ciudad, el modelo al 
	 * realizar el cálculo de atenuación esperará encontrar valores en los parámetros y si los encuentra, no 
	 * verificará sobre el sentido del resultado. 
	 * @param parametrosAjustables - ver el toString del modelo para ver qué parámetro va en cada posición. 
	 * @param parametrosNoAjustables - En la primera posición A4 según el toString del modelo. Luego un Integer 
	 * indicando el tipo de ciudad, un Double con la frecuencia, un ArrayList con los parámetros de a, un Integer 
	 * con el tipo de Area y por último otro ArrayList con los factores correctivos segíun área. 
	 * @throws ModeloMalDefinidoException
	 */
	public OkumuraHata(
			double[] parametrosAjustables,
			Object[] parametrosNoAjustables) throws ModeloMalDefinidoException {
		super(parametrosAjustables, parametrosNoAjustables);
	}
	
	/**
	 * Genera el modelo de Okumura-Hata para el tipo de ciudad, área y frecuencia especificado. 
	 * 
	 * @param tipoCiudad
	 * @param tipoArea
	 * @param frecuencia
	 */
	
	public OkumuraHata(int tipoCiudad, int tipoArea, double frecuencia)
	throws ModeloMalDefinidoException {
		super();
		if (tipoCiudad != OkumuraHata.CIUDAD_GRANDE
				&& tipoCiudad != OkumuraHata.CIUDAD_MEDIA_PEQUENIA) {
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
			"El tipo de ciudad especificada no es correcta");
			throw e;
		}
		if (tipoArea != OkumuraHata.AREA_ABIERTA
				&& tipoArea != OkumuraHata.AREA_SUBURBANA
				&& tipoArea != OkumuraHata.AREA_URBANA) {
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
			"El tipo de área especificada no es correcta");
			throw e;
		}
		if (frecuencia < 0) {
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
			"Las frecuencias negativas no se aceptan. ");
			throw e;
		}
		this.parametrosAjustables = OkumuraHata
		.getParametrosAjustables(frecuencia);
		ArrayList parametrosA = OkumuraHata.getParametrosA(
				tipoCiudad,
				frecuencia);
		ArrayList factoresCorrectivos = OkumuraHata
		.getFactoresCorrectivos(tipoArea);
		this.parametrosNoAjustables = new Object[] { new Double(-6.55),
				new Integer(tipoCiudad), new Double(frecuencia), parametrosA,
				new Integer(tipoArea), factoresCorrectivos, new Boolean(false) };
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#getParametrosAjustablesPorDefecto()
	 * 
	 */
	
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		double[] parametros = OkumuraHata.getParametrosAjustables(800E6);
		return parametros;
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#getParametrosNoAjustablesPorDefecto()
	 * 
	 */
	
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		ArrayList parametrosA = OkumuraHata.getParametrosA(
				OkumuraHata.CIUDAD_MEDIA_PEQUENIA,
				800E6);
		ArrayList factoresCorrectivos = OkumuraHata
		.getFactoresCorrectivos(OkumuraHata.AREA_URBANA);
		Object[] parametros = new Object[] { new Double(-6.55),
				new Integer(OkumuraHata.CIUDAD_MEDIA_PEQUENIA),
				new Double(800E6), parametrosA,
				new Integer(OkumuraHata.AREA_URBANA), factoresCorrectivos, new Boolean(false)};
		return parametros;
	}
	
	/**
	 * Dependiendo de la frecuencia, devuelve los parametros de la fÃ¯Â¿Âœrmula de Hata. Si la frecuencia supera los 1500 Mhz
	 * devuelve la formulación según COST231. 
	 * 
	 * @param frecuencia - en Hz
	 * @return
	 */
	private static double[] getParametrosAjustables(double frecuencia) {
		if (frecuencia < 1500E6) {
			double[] parametros = new double[] { 69.55, 26.16, -13.82, 44.9 };
			return parametros;
		} else {
			double[] parametros = new double[] { 46.3, 33.9, -13.82, 44.9 };
			return parametros;
		}
	}
	
	/**
	 * Devuelve los parámetros que aparecen en el término a(hr) dependiendo de la frecuencia y del tipo de ciudad. 
	 * @param tipoCiudad
	 * @param frecuencia - en Hz
	 * @return
	 */
	private static ArrayList getParametrosA(int tipoCiudad, double frecuencia) {
		if (tipoCiudad == OkumuraHata.CIUDAD_MEDIA_PEQUENIA) { //en el caso de ciudad pequeña o mediana, no se hace distinción sobre la frecuencia
			ArrayList parametrosA = new ArrayList();
			parametrosA.add(new Double(1.1));
			parametrosA.add(new Double(-0.7));
			parametrosA.add(new Double(-1.56));
			parametrosA.add(new Double(0.8));
			return parametrosA;
		} else { //en caso de ciudad grande, se distingue según la frecuencia
			if (frecuencia < 200E6) { //TODO he encontrado versiones encontradas en cuanto a que frecuencia tomar como quiebre
				ArrayList parametrosA = new ArrayList();
				parametrosA.add(new Double(8.29));
				parametrosA.add(new Double(1.54));
				parametrosA.add(new Double(2));
				parametrosA.add(new Double(-1.1));
				return parametrosA;
			} else {
				if (frecuencia < 1500E6) {
					ArrayList parametrosA = new ArrayList();
					parametrosA.add(new Double(3.2));
					parametrosA.add(new Double(11.75));
					parametrosA.add(new Double(2));
					parametrosA.add(new Double(-4.97));
					return parametrosA;
				} else {
					ArrayList parametrosA = new ArrayList();
					parametrosA.add(new Double(3.2));
					parametrosA.add(new Double(11.75));
					parametrosA.add(new Double(2));
					parametrosA.add(new Double(-4.97));
					parametrosA.add(new Double(-3));
					return parametrosA;
				}
			}
		}
	}
	
	private static ArrayList getFactoresCorrectivos(int tipoArea) {
		if (tipoArea == OkumuraHata.AREA_URBANA) {
			ArrayList factoresCorrectivos = new ArrayList();
			return factoresCorrectivos;
		} else if (tipoArea == OkumuraHata.AREA_SUBURBANA) {
			ArrayList factoresCorrectivos = new ArrayList();
			factoresCorrectivos.add(new Double(-2));
			factoresCorrectivos.add(new Double(28));
			factoresCorrectivos.add(new Double(2));
			factoresCorrectivos.add(new Double(-5.4));
			return factoresCorrectivos;
		} else {
			ArrayList factoresCorrectivos = new ArrayList();
			factoresCorrectivos.add(new Double(-4.78));
			factoresCorrectivos.add(new Double(2));
			factoresCorrectivos.add(new Double(18.33));
			factoresCorrectivos.add(new Double(-40.94));
			return factoresCorrectivos;
		}
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#setNombres()
	 * 
	 */
	
	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.OKUMURA_HATA;
		this.nombreParametrosAjustables = new String[] { "A0", "A1", "A2", "A3" };
		this.nombreParametrosNoAjustables = new String[] { "A4",
				"Tipo de Ciudad", "Frecuencia", "Parametros de a(ht)",
				"Tipo de area", "Parametros de f(area)", "Uso de alturas efectivas" };
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#verificarDatos(explorer.proyecto.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia();
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, double, double, double)
	 */
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Okumura-Hata");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			
			if(envoltura==null) 
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo Okumura-Hata es nula, verifique los datos");
			
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
						
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura();
			double hT = hTrelativa; 
			double hR = hRrelativa; 
			double lambda = Modelo.C/antena.getFrecuencia();
			double distancia;
			double atenuacionAux;
			double atenuacionVacio;
			double tipoCiudad = ((Integer)this.parametrosNoAjustables[1]).intValue();
			double frecModelo = ((Double)this.parametrosNoAjustables[2]).doubleValue();
			double tipoArea = ((Integer)this.parametrosNoAjustables[4]).intValue();
			boolean usarAlturasEfectivas = ((Boolean)this.parametrosNoAjustables[6]).booleanValue(); 
			
			double A0 = this.parametrosAjustables[0];
			double A1 = this.parametrosAjustables[1];
			double A2 = this.parametrosAjustables[2];
			double A3 = this.parametrosAjustables[3];
			double A4 = ((Double)this.parametrosNoAjustables[0]).doubleValue();
			double a = 0;
			double fArea = 0;			
					
			//CUIDADO: aunque a simple vista parece que la parte de las correcciones por altura del receptor y tipo de área
			//pueden hacerse por fuera del for, sólo esta última puede hacerse, pues la altura del receptor es la efectiva, 
			//que depende de la posición. 
			Object[] factoresCorrectivos = ((ArrayList)this.parametrosNoAjustables[5]).toArray();
			if(factoresCorrectivos.length > 0){
				double k1 = ((Double)factoresCorrectivos[0]).doubleValue();
				double k2 = ((Double)factoresCorrectivos[1]).doubleValue();
				double k3 = ((Double)factoresCorrectivos[2]).doubleValue();
				double k4 = ((Double)factoresCorrectivos[3]).doubleValue();
				if(tipoArea == OkumuraHata.AREA_SUBURBANA){
					fArea = k1*Math.pow(Math.log(frecuencia/k2)/Math.log(10.0), k3) + k4;
				}else if(tipoArea == OkumuraHata.AREA_ABIERTA){
					fArea = k1*Math.pow(Math.log(frecuencia)/Math.log(10.0), k2) + k3*Math.log(frecuencia)/Math.log(10.0) + k4;
				}
			}
			
			Object[] parametrosA = ((ArrayList)this.parametrosNoAjustables[3]).toArray();
			double c1 = ((Double)parametrosA[0]).doubleValue();
			double c2 = ((Double)parametrosA[1]).doubleValue();
			double c3 = ((Double)parametrosA[2]).doubleValue();
			double c4 = ((Double)parametrosA[3]).doubleValue();
			double[] alturasEfectivas;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;		
			
			UtilidadesModelos um = new UtilidadesModelos(gc);
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radioMax, sitioAntena, "altura");
				hTrelativa += ume.getAlturaEdificioAntena();  
			}
			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			double[] datos = new double[ancho*alto];
			int contador = 0;
			double minimo = java.lang.Double.MAX_VALUE;
			double maximo = -java.lang.Double.MAX_VALUE;
			
			double[] distanciaYangulos;
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){ 
					//A0 + A1*log(fc/MHz) + A2*log(ht/m) - a(ht) + (A3 + A4*log(ht/m))*log(d/km) + f(area)
					sitioMovil = mt.transform(new Point(i,j),null);
					double distLimiteOH = um.calcularDistanciaGrid(sitioAntena, sitioMovil);
					if(distLimiteOH < radioMax && distLimiteOH < 20000){
						distanciaYangulos = um.calcularDistanciaReal(sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion); 
						distancia = distanciaYangulos[0];
						distancia = distancia/1000; //el modelo utiliza la distancia en km
						if(usarAlturasEfectivas){
							alturasEfectivas = um.alturaEfectiva(sitioAntena, rb.getAltura(), sitioMovil, proyecto.getPerfilUsuario().getAltura(), 20, this.usarInterpolacion, true);
							hT = alturasEfectivas[0];
							hR = alturasEfectivas[1];
							hTrelativa = hT;
							hRrelativa = hR;
							if (hR < 1.0) {
								hRrelativa = 1.0;
							}
							if (hR > 10.0) { 
								hRrelativa = 10.0; 
							}
							if (hT < 30){
								hTrelativa = 30;
							}
							if (hT > 200) {
								hTrelativa = 200;
							}
						}
						atenuacionAux = A0 + A1*Math.log10(frecuencia) + A2*Math.log10(hTrelativa) + (A3 + A4*Math.log10(hTrelativa))*Math.log10(distancia);
						
						
						if(tipoCiudad == OkumuraHata.CIUDAD_GRANDE){
							a = c1*Math.pow(Math.log(c2*hRrelativa)/Math.log(10.0), c3) + c4;
							if(Double.isInfinite(a)){
								System.out.println("a: "+a); 
								System.out.println("hr: "+hRrelativa);
								System.out.println("sitio: "+sitioMovil); 
							}
							if(frecModelo > 1500E6){
								a = a + ((Double)parametrosA[4]).doubleValue();
							}
						}else if(tipoCiudad == OkumuraHata.CIUDAD_MEDIA_PEQUENIA){
							a = (c1*Math.log10(frecuencia) + c2)*hRrelativa + c3*Math.log10(frecuencia) + c4;
						}
						
						// Por lo que estuve viendo,la pérdida de vacío ya está considerada, así que la saco. 
						/*//agregamos las pérdidas por vacío
						Vacio modeloVacio = new Vacio();
						atenuacionVacio = 10.0*Math.log(modeloVacio.getParametrosAjustablesPorDefecto()[1]*Math.pow(distancia*1000.0, modeloVacio.getParametrosAjustablesPorDefecto()[0]))/Math.log(10.0);
						*/
						
						//GM: Esto fue para ver el problema de los ángulos negativos en el método getGananciaAngulo.
//						if(i==607 && j==1392){
//							System.out.println();
//						}
						// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
						double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
						datos[contador] = potencia + gananciaE - (atenuacionAux - a + fArea);
//						datos[contador] = hT;
					}else{
						datos[contador] = Double.NaN;
					}
					if(datos[contador] < minimo) minimo = datos[contador];
					if(datos[contador] > maximo) maximo = datos[contador];
					contador++;
					cuantoVa = (int)((double)contador/((double)(ancho*alto))*100.0);
				}			
			}
			
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp;
		}catch(Exception z){
			z.printStackTrace(); 
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, com.vividsolutions.jts.geom.Coordinate)
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Okumura-Hata");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura();
			double hT = hTrelativa; 
			double hR = hRrelativa; 
			double lambda = Modelo.C/antena.getFrecuencia();
			double distancia;
			double atenuacionAux;
			double atenuacionVacio;
			double tipoCiudad = ((Integer)this.parametrosNoAjustables[1]).intValue();
			double frecModelo = ((Double)this.parametrosNoAjustables[2]).doubleValue();
			double tipoArea = ((Integer)this.parametrosNoAjustables[4]).intValue();
			boolean usarAlturasEfectivas = ((Boolean)this.parametrosNoAjustables[6]).booleanValue(); 
			
			double A0 = this.parametrosAjustables[0];
			double A1 = this.parametrosAjustables[1];
			double A2 = this.parametrosAjustables[2];
			double A3 = this.parametrosAjustables[3];
			double A4 = ((Double)this.parametrosNoAjustables[0]).doubleValue();
			double a = 0;
			double fArea = 0;			
			
			//CUIDADO: aunque a simple vista parece que la parte de las correcciones por altura del receptor y tipo de área
			//pueden hacerse por fuera del for, sólo esta última puede hacerse, pues la altura del receptor es la efectiva, 
			//que depende de la posición. 
			Object[] factoresCorrectivos = ((ArrayList)this.parametrosNoAjustables[5]).toArray();
			if(factoresCorrectivos.length > 0){
				double k1 = ((Double)factoresCorrectivos[0]).doubleValue();
				double k2 = ((Double)factoresCorrectivos[1]).doubleValue();
				double k3 = ((Double)factoresCorrectivos[2]).doubleValue();
				double k4 = ((Double)factoresCorrectivos[3]).doubleValue();
				if(tipoArea == OkumuraHata.AREA_SUBURBANA){
					fArea = k1*Math.pow(Math.log(frecuencia/k2)/Math.log(10.0), k3) + k4;
				}else if(tipoArea == OkumuraHata.AREA_ABIERTA){
					fArea = k1*Math.pow(Math.log(frecuencia)/Math.log(10.0), k2) + k3*Math.log(frecuencia)/Math.log(10.0) + k4;
				}
			}
			
			Object[] parametrosA = ((ArrayList)this.parametrosNoAjustables[3]).toArray();
			double c1 = ((Double)parametrosA[0]).doubleValue();
			double c2 = ((Double)parametrosA[1]).doubleValue();
			double c3 = ((Double)parametrosA[2]).doubleValue();
			double c4 = ((Double)parametrosA[3]).doubleValue();
			double[] alturasEfectivas;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}
			
			UtilidadesModelos um = new UtilidadesModelos(gc);
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio, sitioAntena, "altura");
				hTrelativa = hTrelativa+ume.getAlturaEdificioAntena(); 
			}
			
			double[] predicciones = new double[puntos.length];
			int contador = 0;
			
			for(int j=0;j<predicciones.length;j++){
				//A0 + A1*log(fc/MHz) + A2*log(ht/m) - a(ht) + (A3 + A4*log(ht/m))*log(d/km) + f(area)
				sitioMovil = new Point2D.Double(puntos[j].x, puntos[j].y);					
				double[] distanciaYangulos = um.calcularDistanciaReal(sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion); 
				distancia = distanciaYangulos[0];
				// ojo con este método!
				distancia = distancia/1000; //el modelo utiliza la distancia en km
				if(usarAlturasEfectivas){
					alturasEfectivas = um.alturaEfectiva(sitioAntena, hTrelativa, sitioMovil, hRrelativa, 30, this.usarInterpolacion, true);
					hT = alturasEfectivas[0];
					hR = alturasEfectivas[1];
					if((hT < 1.0) || (hR < 1.0) || (hR > 10)){ //si la altura efectiva cae fuera del dominio, lo pongo con las relativas
						hT = hTrelativa;
						hR = hRrelativa; 
					}else{
						hTrelativa = hT; 
						hRrelativa = hR; 
					}
				}
				atenuacionAux = A0 + A1*Math.log(frecuencia)/Math.log(10.0) + A2*Math.log(hTrelativa)/Math.log(10.0) + (A3 + A4*Math.log(hTrelativa)/Math.log(10.0))*Math.log(distancia)/Math.log(10.0); 
				if(tipoCiudad == OkumuraHata.CIUDAD_MEDIA_PEQUENIA){
					a = (c1*Math.log(frecuencia)/Math.log(10.0) + c2)*hRrelativa + c3*Math.log(frecuencia)/Math.log(10.0) + c4;
				}
				if(tipoCiudad == OkumuraHata.CIUDAD_GRANDE){
					a = c1*Math.pow(Math.log(c2*hRrelativa)/Math.log(10.0), c3) + c4;
					if(frecModelo > 1500E6){
						a = a + ((Double)parametrosA[4]).doubleValue();
					}
				}else if(tipoCiudad == OkumuraHata.CIUDAD_MEDIA_PEQUENIA){
					a = (c1*Math.log(frecuencia)/Math.log(10.0) + c2)*hRrelativa + c3*Math.log(frecuencia)/Math.log(10.0) + c4;
				}
				
				// Por lo que estuve viendo,la pérdida de vacÃ¯Â¿Âœo ya está considerada, así que la saco. 
				/*//agregamos las pérdidas por vacío
				Vacio modeloVacio = new Vacio();
				atenuacionVacio = 10.0*Math.log(modeloVacio.getParametrosAjustablesPorDefecto()[1]*Math.pow(distancia*1000.0, modeloVacio.getParametrosAjustablesPorDefecto()[0]))/Math.log(10.0);
				*/
				
				
				double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
//				double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
				//predicciones[j] = potencia + gananciaE - (atenuacionAux - a + fArea + atenuacionVacio);
				predicciones[j] = potencia + gananciaE - (atenuacionAux - a + fArea);
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
			}		
			return predicciones;
		}catch(Exception z){
			z.printStackTrace(); 
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
	}	

	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#areaCalculable(explorer.proyecto.Mapa, java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try {
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf
					.createLinearRing(new Coordinate[] { new Coordinate(0, 0),
							new Coordinate(1, 0), new Coordinate(1, 1),
							new Coordinate(0, 1), new Coordinate(0, 0) }), null);
			while (fi.hasNext() && esta == false) {
				rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf
						.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if (!esta)
				return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
			.getCoordinates();
			double maxX = -Double.MAX_VALUE;
			double maxY = -Double.MAX_VALUE;
			double minY = Double.MAX_VALUE;
			double minX = Double.MAX_VALUE;
			for (int j = 0; j < coordenadas.length; j++) {
				if (coordenadas[j].x < minX)
					minX = coordenadas[j].x;
				if (coordenadas[j].x > maxX)
					maxX = coordenadas[j].x;
				if (coordenadas[j].y < minY)
					minY = coordenadas[j].y;
				if (coordenadas[j].y > maxY)
					maxY = coordenadas[j].y;
			}
			Envelope envoltura = new Envelope(
					new CoordinatePoint(minX, minY),
					new CoordinatePoint(maxX, maxY));
			return envoltura;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#crearPanelCreacion()
	 * 
	 */
	
	@Override
	protected void crearPanelCreacion() {
		this.menu = new MenuOkumuraHata(
				this.parametrosAjustables,
				this.parametrosNoAjustables);
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#getPanelCreacion()
	 * 
	 */
	
	@Override
	public PanelModelos getPanelCreacion() {
		return this.menu;
	}
	
	@Override
	public String getXML() {
		
		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>" + nombreImplementacion + "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");
		
		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>" + nombreParametrosAjustables[i] + "</Nombre>\r\n");
			if (parametrosAjustables.length != 0) {
				result1.append("        <Valor>" + parametrosAjustables[i] + "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		if (parametrosNoAjustables.length != 0) {
			
			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer();
				if ((i == 3)||(i == 5) ){
					ArrayList paramA = (ArrayList) this.parametrosNoAjustables[i];
					Iterator iterator = paramA.iterator();
					int m = 1;
					while (iterator.hasNext()) {
						result1 = new StringBuffer(
						"<ParametrosNoAjustablesSubitems>");
						Double c = (Double) iterator.next();
						result1.append("        <Nombre>"+ "c"+ m + "</Nombre>\r\n");
						result1.append("        <Valor>" + c + "</Valor>\r\n");
						result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
						result.append(result1.toString());
						//result.append("<c"+ m+">" + c + "</c"+m+">");
						m = m + 1;
					}
				}
				result1 = new StringBuffer("<ParametrosNoAjustables>");
				result1.append("        <Nombre>"
						+ nombreParametrosNoAjustables[i]
													   + "</Nombre>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"
							+ parametrosNoAjustables[i]
													 + "</Valor>\r\n");
				} else {
					result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");
				//}
				result.append(result1.toString());
				
			}
		}
		
		result.append("      </Modelo>\r\n");
		return result.toString();
		
	}
	
	/**
	 * Ventana de creación de instancias del modelo Okumura-Hata
	 * @author Grupo de Proyecto SAPO.
	 *
	 */
	protected class MenuOkumuraHata extends PanelModelos
	implements
	ActionListener,
	ItemListener {
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField A0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField A1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField A2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField A3;
		
		/*
		 *
		 *	  Los campos para los no ajustables 
		 *	 
		 */
		
		JTextField A4;
		JComboBox frecuencia;
		JComboBox tipoCiudad;
		JComboBox tipoArea;
		JTextField c1;
		JTextField c2;
		JTextField c3;
		JTextField c4;
		JTextField k1;
		JTextField k2;
		JTextField k3;
		JTextField k4;
		JTextField correccion;
		JLabel etiqCorreccion;
		JPanel noAjustables;
		JPanel as;
		JPanel cs;
		JButton botonPorDefecto;
		JCheckBox usoAltEfect; 
		
		final String FREC_BAJAS = "< 200 MHz";
		final String FREC_MEDIAS = "< 1500 MHz";
		final String FREC_ALTAS = "> 1500 MHz";
		
		final String CIUDAD_GRANDE = "Grande";
		final String CIUDAD_MEDIA_PEQUENIA = "Media o Pequeña";
		final String AREA_URBANA = "Urbana";
		final String AREA_SUBURBANA = "Suburbana";
		final String AREA_ABIERTA = "Abierta";
		
		MenuOkumuraHata(
				double[] parametrosAjustables,
				Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
		}
		
		/**
		 *
		 *	  Esta implementación en particular es un panel, con dos panels dentro. Uno para los parámetros ajustables, 
		 *	  y otro para los no ajustables (este serÃ¯Â¿Âœ el layout que deberÃ¯Â¿Âœan seguir los demás modelos para una 
		 *	  coherencia del programa). 
		 *	 
		 */
		
		@Override
		public void agregarElementos() {
			this.setLayout(new GridBagLayout());
			TitledBorder bordeAjustable, bordeNoAjustable;
			JPanel ajustables = new JPanel();
			ajustables.setLayout(new GridBagLayout());
			noAjustables = new JPanel();
			noAjustables.setLayout(new GridBagLayout());
			
			GridBagConstraints c = new GridBagConstraints();
			c.insets = new Insets(2, 2, 2, 2);
			GridBagConstraints cGrande = new GridBagConstraints();
			/*
			 * Creo el panel para los ajustables con un borde con título y luego lo agrego al panel. 
			 */
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustables.add(new JLabel("Parámetro A0: "), c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			A0 = new JTextField("");
			ajustables.add(A0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustables.add(new JLabel("Parámetro A1: "), c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			A1 = new JTextField("");
			ajustables.add(A1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustables.add(new JLabel("Parámetro  A2: "), c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			A2 = new JTextField("");
			ajustables.add(A2, c);
			
			c.gridx = 0;
			c.gridy = 3;
			c.fill = GridBagConstraints.REMAINDER;
			c.weightx = 0;
			ajustables.add(new JLabel("Parámetro  A3: "), c);
			
			c.gridx = 1;
			c.gridy = 3;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			A3 = new JTextField("");
			ajustables.add(A3, c);
			
			bordeAjustable = BorderFactory
			.createTitledBorder("Parámetros  Ajustables");
			ajustables.setBorder(bordeAjustable);
			cGrande.gridx = 0;
			cGrande.gridy = 0;
			cGrande.gridwidth = 2;
			cGrande.gridheight = 2;
			cGrande.fill = GridBagConstraints.BOTH;
			cGrande.weightx = 1;
			cGrande.insets = new Insets(4, 4, 4, 4);
			this.add(ajustables, cGrande);
			
			/*
			 * Creo el panel para los parámetros no ajustables y lo agrego al panel. 
			 */
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			c.weightx = 0;
			noAjustables.add(new JLabel("Parámetro  A4: "), c);
			
			c.gridx = 2;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			A4 = new JTextField("");
			noAjustables.add(A4, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			c.weightx = 0;
			noAjustables.add(new JLabel("Frecuencia: "), c);
			
			String[] listaFrecuencias = new String[] { FREC_BAJAS, FREC_MEDIAS,
					FREC_ALTAS };
			frecuencia = new JComboBox(listaFrecuencias);
			frecuencia.addItemListener(this);
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1; 
			noAjustables.add(frecuencia, c);
			
			c.gridx = 2;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			c.weightx = 1;
			c.gridwidth = 2; 
			c.anchor = GridBagConstraints.CENTER;
			usoAltEfect = new JCheckBox("Uso de alturas Efectivas"); 
			noAjustables.add(usoAltEfect, c);
			c.gridwidth = 1;  
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			c.weightx = 0;
			noAjustables.add(new JLabel("Tipo de Ciudad: "), c);
			
			String[] listaCiudad = new String[] { this.CIUDAD_GRANDE,
					this.CIUDAD_MEDIA_PEQUENIA };
			tipoCiudad = new JComboBox(listaCiudad);
			tipoCiudad.addItemListener(this);
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			noAjustables.add(tipoCiudad, c);
			
			c.gridx = 2;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			c.weightx = 0;
			noAjustables.add(new JLabel("Tipo de área: "), c);
			
			String[] listaAreas = new String[] { this.AREA_URBANA,
					this.AREA_SUBURBANA, this.AREA_ABIERTA };
			tipoArea = new JComboBox(listaAreas);
			tipoArea.setSelectedIndex(2); //para forzar a que si por defecto venía con algo que no mostraba
			//las correcciones por área, no se muestre. 
			tipoArea.addItemListener(this);
			c.gridx = 3;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			noAjustables.add(tipoArea, c);
			
			/*
			 * Creo los paneles que cambian según la frecuencia
			 */
			TitledBorder bordeA = BorderFactory
			.createTitledBorder("Parámetros de a");
			as = new JPanel(new GridLayout(5, 2));
			as.setBorder(bordeA);
			
			as.add(new JLabel("c1: "));
			c1 = new JTextField("");
			as.add(c1);
			as.add(new JLabel("c2: "));
			c2 = new JTextField("");
			as.add(c2);
			as.add(new JLabel("c3: "));
			c3 = new JTextField("");
			as.add(c3);
			as.add(new JLabel("c4: "));
			c4 = new JTextField("");
			as.add(c4);
			
			etiqCorreccion = new JLabel("Correccion: ");
			as.add(etiqCorreccion);
			correccion = new JTextField("");
			as.add(correccion);
			
			c.gridx = 0;
			c.gridy = 4;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			c.gridwidth = 2;
			noAjustables.add(as, c);
			
			TitledBorder bordeC = BorderFactory
			.createTitledBorder("Correcciones por Area");
			cs = new JPanel(new GridLayout(4, 2));
			cs.setBorder(bordeC);
			
			cs.add(new JLabel("k1: "));
			k1 = new JTextField("");
			cs.add(k1);
			cs.add(new JLabel("k2: "));
			k2 = new JTextField("");
			cs.add(k2);
			cs.add(new JLabel("k3: "));
			k3 = new JTextField("");
			cs.add(k3);
			cs.add(new JLabel("k4: "));
			k4 = new JTextField("");
			cs.add(k4);
			
			c.gridx = 2;
			c.gridy = 4;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			c.gridwidth = 2;
			noAjustables.add(cs, c);
			
			bordeNoAjustable = BorderFactory
			.createTitledBorder("Parámetros no Ajustables");
			noAjustables.setBorder(bordeNoAjustable);
			
			cGrande.gridy = 2;
			this.add(noAjustables, cGrande);
			
			botonPorDefecto = new JButton("Valores por defecto");
			botonPorDefecto.addActionListener(this);
			cGrande.gridx = 1;
			cGrande.gridy = 4;
			cGrande.gridwidth = 1;
			cGrande.gridheight = 1;
			cGrande.anchor = GridBagConstraints.LAST_LINE_END;
			cGrande.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			this.add(botonPorDefecto, cGrande);
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 *	 
		 */
		
		@Override
		public double[] getParametrosAjustables()
		throws ModeloMalDefinidoException {
			try {
				double A0 = Double.parseDouble(this.A0.getText());
				double A1 = Double.parseDouble(this.A1.getText());
				double A2 = Double.parseDouble(this.A2.getText());
				double A3 = Double.parseDouble(this.A3.getText());
				double[] parametros = new double[] { A0, A1, A2, A3 };
				return parametros;
			} catch (Exception e) {
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
				"Algunos de los campos están mal");
				throw ex;
			}
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 *	 
		 */
		
		@Override
		public Object[] getParametrosNoAjustables()
		throws ModeloMalDefinidoException {
			try {
				Object[] parametrosNoAj = new Object[7];
				parametrosNoAj[0] = new Double(Double.parseDouble(this.A4
						.getText()));
				
				Integer tipCiu = (Integer) parametrosNoAjustables[1];
				if (this.tipoCiudad.getSelectedItem()
						.equals(this.CIUDAD_GRANDE)) {
					parametrosNoAj[1] = new Integer(OkumuraHata.CIUDAD_GRANDE);
				} else {
					parametrosNoAj[1] = new Integer(
							OkumuraHata.CIUDAD_MEDIA_PEQUENIA);
				}
				
				if (this.frecuencia.getSelectedItem().equals(this.FREC_BAJAS)) {
					parametrosNoAj[2] = new Double(100E6);
				} else if (this.frecuencia.getSelectedItem().equals(
						this.FREC_MEDIAS)) {
					parametrosNoAj[2] = new Double(800E6);
				} else {
					parametrosNoAj[2] = new Double(1800E6);
				}
				
				ArrayList parametrosA = new ArrayList();
				parametrosA.add(new Double(Double.parseDouble(c1.getText())));
				parametrosA.add(new Double(Double.parseDouble(c2.getText())));
				parametrosA.add(new Double(Double.parseDouble(c3.getText())));
				parametrosA.add(new Double(Double.parseDouble(c4.getText())));
				if (this.frecuencia.getSelectedItem().equals(this.FREC_ALTAS)
						&& this.tipoCiudad.getSelectedItem().equals(
								this.CIUDAD_GRANDE)) {
					parametrosA.add(new Double(Double.parseDouble(correccion
							.getText())));
				}
				parametrosNoAj[3] = parametrosA;
				
				if (this.tipoArea.getSelectedItem().equals(this.AREA_URBANA)) {
					parametrosNoAj[4] = new Integer(OkumuraHata.AREA_URBANA);
				} else if (this.tipoArea.getSelectedItem().equals(
						this.AREA_SUBURBANA)) {
					parametrosNoAj[4] = new Integer(OkumuraHata.AREA_SUBURBANA);
				} else {
					parametrosNoAj[4] = new Integer(OkumuraHata.AREA_ABIERTA);
				}
				
				ArrayList parametrosC = new ArrayList();
				if (!parametrosNoAj[4].equals(new Integer(
						OkumuraHata.AREA_URBANA))) {
					parametrosC
					.add(new Double(Double.parseDouble(k1.getText())));
					parametrosC
					.add(new Double(Double.parseDouble(k2.getText())));
					parametrosC
					.add(new Double(Double.parseDouble(k3.getText())));
					parametrosC
					.add(new Double(Double.parseDouble(k4.getText())));
				}
				parametrosNoAj[5] = parametrosC;
				parametrosNoAj[6] = new Boolean(this.usoAltEfect.isSelected()); 
				
				return parametrosNoAj;
			} catch (Exception e) {
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
				"Algunos de los valores ingresados están mal");
				throw ex;
			}
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables) {
			this.A0.setText(String.valueOf(parametrosAjustables[0]));
			this.A1.setText(String.valueOf(parametrosAjustables[1]));
			this.A2.setText(String.valueOf(parametrosAjustables[2]));
			this.A3.setText(String.valueOf(parametrosAjustables[3]));
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			this.A4.setText(parametrosNoAjustables[0].toString());
			
			Integer tipCiu = (Integer) parametrosNoAjustables[1];
			if (tipCiu.equals(new Integer(OkumuraHata.CIUDAD_GRANDE))) {
				this.tipoCiudad.setSelectedItem(this.CIUDAD_GRANDE);
			} else {
				this.tipoCiudad.setSelectedItem(this.CIUDAD_MEDIA_PEQUENIA);
			}
			
			Double frec = (Double) parametrosNoAjustables[2];
			if (frec.doubleValue() < 200E6) {
				this.frecuencia.setSelectedItem(this.FREC_BAJAS);
			} else if (frec.doubleValue() < 1500E6) {
				this.frecuencia.setSelectedItem(this.FREC_MEDIAS);
			} else {
				this.frecuencia.setSelectedItem(this.FREC_ALTAS);
			}
			
			ArrayList parametrosA = (ArrayList) parametrosNoAjustables[3];
			c1.setText(parametrosA.get(0).toString());
			c2.setText(parametrosA.get(1).toString());
			c3.setText(parametrosA.get(2).toString());
			c4.setText(parametrosA.get(3).toString());
			if (frec.doubleValue() > 1500E6
					&& tipCiu.equals(new Integer(OkumuraHata.CIUDAD_GRANDE))) {
				correccion.setText(parametrosA.get(4).toString());
			}
			
			Integer tipoAr = (Integer) parametrosNoAjustables[4];
			if (tipoAr.equals(new Integer(OkumuraHata.AREA_URBANA))) {
				this.tipoArea.setSelectedItem(this.AREA_URBANA);
			} else if (tipoAr.equals(new Integer(OkumuraHata.AREA_SUBURBANA))) {
				this.tipoArea.setSelectedItem(this.AREA_SUBURBANA);
			} else {
				this.tipoArea.setSelectedItem(this.AREA_ABIERTA);
			}
			
			ArrayList parametrosC = (ArrayList) parametrosNoAjustables[5];
			if (!tipoAr.equals(new Integer(OkumuraHata.AREA_URBANA))) {
				k1.setText(parametrosC.get(0).toString());
				k2.setText(parametrosC.get(1).toString());
				k3.setText(parametrosC.get(2).toString());
				k4.setText(parametrosC.get(3).toString());
			}
			this.usoAltEfect.setSelected(((Boolean)parametrosNoAjustables[6]).booleanValue());
		}
		
		/**
		 * simplemente resetea los valores a los por defecto. 
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			int tipoCiudad, tipoArea;
			double frecuencia;
			if (this.tipoCiudad.getSelectedItem().equals(this.CIUDAD_GRANDE)) {
				tipoCiudad = OkumuraHata.CIUDAD_GRANDE;
			} else {
				tipoCiudad = OkumuraHata.CIUDAD_MEDIA_PEQUENIA;
			}
			if (this.tipoArea.getSelectedItem().equals(this.AREA_ABIERTA)) {
				tipoArea = OkumuraHata.AREA_ABIERTA;
			} else if (this.tipoArea.getSelectedItem().equals(
					this.AREA_SUBURBANA)) {
				tipoArea = OkumuraHata.AREA_SUBURBANA;
			} else {
				tipoArea = OkumuraHata.AREA_URBANA;
			}
			if (this.frecuencia.getSelectedItem().equals(this.FREC_ALTAS)) {
				frecuencia = 1800E6;
			} else if (this.frecuencia.getSelectedItem().equals(
					this.FREC_MEDIAS)) {
				frecuencia = 800E6;
			} else {
				frecuencia = 100;
			}
			try {
				OkumuraHata modelo = new OkumuraHata(
						tipoCiudad,
						tipoArea,
						frecuencia);
				this.setParametrosAjustables(modelo.parametrosAjustables);
				this.setParametrosNoAjustables(modelo.parametrosNoAjustables);
			} catch (Exception e) {
				e.printStackTrace(System.out);
			}
		}
		
		/* (non-Javadoc)
		 * @see java.awt.event.ItemListener#itemStateChanged(java.awt.event.ItemEvent)
		 */
		@Override
		public void itemStateChanged(ItemEvent evento) {
			if (evento.getSource().equals(this.frecuencia)
					|| evento.getSource().equals(this.tipoCiudad)) {
				boolean esGrandeYAltaFrec = (evento.getItem().equals(
						this.FREC_ALTAS) && this.tipoCiudad.getSelectedItem()
						.equals(this.CIUDAD_GRANDE))
						|| (evento.getItem().equals(this.CIUDAD_GRANDE) && frecuencia
								.getSelectedItem().equals(this.FREC_ALTAS));
				if (esGrandeYAltaFrec) {
					as.add(etiqCorreccion);
					as.add(correccion);
					as.validate();
					as.repaint();
				} else {
					as.remove(etiqCorreccion);
					as.remove(correccion);
					as.validate();
					as.repaint();
				}
			} else if (evento.getSource().equals(this.tipoArea)) {
				if (evento.getItem().equals(this.AREA_URBANA)) {
					this.noAjustables.remove(cs);
					this.noAjustables.validate();
					this.noAjustables.repaint();
				} else {
					GridBagConstraints c = new GridBagConstraints();
					c.gridx = 2;
					c.gridy = 4;
					c.fill = GridBagConstraints.HORIZONTAL;
					c.weightx = 1;
					c.gridwidth = 2;
					this.noAjustables.add(cs, c);
					this.noAjustables.validate();
					this.noAjustables.repaint();
				}
			}
			
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 *	 
		 */
		
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new OkumuraHata(this.getParametrosAjustables(), this
					.getParametrosNoAjustables());
		}
		
		/*
		 *
		 *	   (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getTamanioVentana()
		 *	 
		 */
		
		public Dimension getTamanioVentana() {
			return new Dimension(415, 460);
		}
	}
	
}
