package sapo.predicciones;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LinearRing;
import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.geom.Polygon;

/**
*Esta clase es la encarada de generar elipses, usada en el cálculo de verificación de 
*línea de vista.
*@author Grupo de proyecto SAPO
*
 */
public class GeneraElipses {

	GeometryFactory gf;

	double[] senos;

	double[] cosenos;

	public GeneraElipses() {
		gf = new GeometryFactory();
		senos = new double[365];
		cosenos = new double[365];
		for (int j = 0; j < senos.length; j++) {
			senos[j] = Math.sin(j * 2.0 * Math.PI / 365.0);
			cosenos[j] = Math.cos(j * 2.0 * Math.PI / 365.0);
		}
	}

	/**
	 * Crea una elipse con los parametros especificados.
	 * 
	 * @param centro -
	 *            El centro de la elipse
	 * @param ejeMayor -
	 *            El largo del eje mayor
	 * @param ejeMenor -
	 *            El largo del eje menor
	 * @param orientacion -
	 *            El angulo que forma el eje mayor con el eje de las x (en
	 *            radianes)
	 * @param paso -
	 *            Cada cuantos grados se tomara un nuevo punto de la elipse para
	 *            formar el poligono.
	 * @return
	 */
	public Polygon crearElipse(Point centro, double ejeMayor, double ejeMenor,
			double orientacion, int paso) {

		int cuantosPuntos = Math.round(Math.round(Math.floor(365.0 / paso)));
		Coordinate[] coordenadas = new Coordinate[cuantosPuntos + 1];
		double senoPhi = Math.sin(orientacion);
		double cosenoPhi = Math.cos(orientacion);
		for (int j = 0; j < coordenadas.length - 1; j++) {
			coordenadas[j] = new Coordinate(ejeMayor * cosenoPhi
					* cosenos[j * paso] - ejeMenor * senoPhi * senos[j * paso]
					+ centro.getX(), ejeMayor * senoPhi * cosenos[j * paso]
					+ ejeMenor * cosenoPhi * senos[j * paso] + centro.getY());
		}
		coordenadas[coordenadas.length - 1] = coordenadas[0];
		LinearRing bordeElipse = gf.createLinearRing(coordenadas);
		return gf.createPolygon(bordeElipse, null);

	}

}
