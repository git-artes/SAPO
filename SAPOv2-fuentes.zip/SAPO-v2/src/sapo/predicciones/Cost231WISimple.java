package sapo.predicciones;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase representa el modelo de atenuación de Cost-231 Walfisch-Ikegami, 
 * pero considerando los parámetros de topología fijos. 
 * 
 * @author Grupo de proyecto SAPO 
 */
public class Cost231WISimple  extends Modelo {
	
	public final static int CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS = 0;
	public final static int CENTRO_METROPOLITANO = 1;
	
	/**
	 *
	 *  Construye el modelo de Walfisch-Ikegami simplificado
	 * 
	 * 
	 */
	
	public Cost231WISimple() {
		super();
	}
	
	/**
	 * Construye el modelo de Walfisch-Ikegami con los parámetros que se crean convenientes. 
	 * @param parametrosAjustables - ver el toString del modelo para ver qué parámetro va en cada posición. 
	 * @param parametrosNoAjustables - 
	 * @throws ModeloMalDefinidoException
	 */
	public Cost231WISimple(
			double[] parametrosAjustables,
			Object[] parametrosNoAjustables) throws ModeloMalDefinidoException {
		super(parametrosAjustables, parametrosNoAjustables);
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#getParametrosAjustablesPorDefecto()
	 * 
	 */
	
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		double[] parametros = Cost231WISimple.getParametrosAjustables();
		return parametros;
	}
	
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#getParametrosNoAjustablesPorDefecto()
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		try {
			return this
			.getParametrosNoAjustablesPorDefecto(Cost231WISimple.CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS);
		} catch (ModeloMalDefinidoException e) {
			return null; //igual esto no va a pasar. 
		}
	}
	
	/**
	 * Devuelve un Array de Objects con los parametros no Ajustables por defecto <br>
	 * <ul>
	 * <li> Lugar  0 - parametros Lori
	 * <li> Lugar  1 - parametros Lmsd
	 * </ul><br><br>
	 * Lmsd es un Array de Objects con los parametros: <br>
	 * <ul>
	 * <li> Lugar  0 - parametros Lbsh
	 * <li> Lugar  1 - parametros Ka
	 * <li> Lugar  2 - parametros Kd
	 * <li> Lugar  3 - parametros Kf
	 * <ul>
	 * @param tipoDeCiudad - el tipo de ciudad
	 * @throws ModeloMalDefinidoException - cuando el tipo de ciudad no es valido. 
	 */
	protected Object[] getParametrosNoAjustablesPorDefecto(int tipoDeCiudad)
	throws ModeloMalDefinidoException {
		if (tipoDeCiudad != Cost231WISimple.CENTRO_METROPOLITANO
				&& tipoDeCiudad != Cost231WISimple.CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS)
			throw new ModeloMalDefinidoException(
			"El tipo de ciudad no es válido");
		double[] parametrosLori = this.getParametrosLori();
		Object[] parametrosLmsd = new Object[4];
		parametrosLmsd[0] = this.getParametrosLbsh();
		parametrosLmsd[1] = this.getParametrosKa();
		parametrosLmsd[2] = this.getParametrosKd();
		parametrosLmsd[3] = this.getParametrosKf(tipoDeCiudad);
		Object[] parametrosNoAjustables = new Object[6];
		parametrosNoAjustables[0] = parametrosLori;
		parametrosNoAjustables[1] = parametrosLmsd;
		parametrosNoAjustables[2] = new Integer(tipoDeCiudad);
		parametrosNoAjustables[3] = new Integer(20); 
		parametrosNoAjustables[4] = new Integer(13); 
		parametrosNoAjustables[5] = new Integer(26); 
		return parametrosNoAjustables;
	}
	
	/**
	 *
	 *  Devuelve los parametros ajutables del modelo COST231 - WI

	 * 
	 */
	
	private static double[] getParametrosAjustables() {
		double[] parametros = new double[] {
				//Lb
				42.6, 26.0, 20.0,
				//LB
				32.4, 20, 20,
				//Lrts
				-16.9, -10, 10, 20,
				//Lmsd
				-9.0 };
		return parametros;
		
	}
	/**
	 *
	 *  Devuelve los parametros de Lori por defecto

	 * 
	 */
	
	private double[] getParametrosLori() {
		double[] parametrosLori = new double[6];
		parametrosLori[0] = -10;
		parametrosLori[1] = 0.354;
		parametrosLori[2] = 2.5;
		parametrosLori[3] = 0.075;
		parametrosLori[4] = 4.0;
		parametrosLori[5] = -0.114;
		return parametrosLori;
	}
	/**
	 *
	 *  Devuelve los parametros de Lbsh por defecto

	 * 
	 */
	
	private double[] getParametrosLbsh() {
		double[] parametrosLbsh = new double[2];
		parametrosLbsh[0] = -18;
		parametrosLbsh[1] = 1.0;
		return parametrosLbsh;
	}
	/**
	 *
	 *  Devuelve los parametros que componen el factor Ka por defecto
	 *  @param distancia en km
	 *  @param hT en mts
	 *  @param h en mts
	 *  @return
	 * 
	 */
	
	private double[] getParametrosKa() {
		double[] parametrosKa = new double[3];
		parametrosKa[0] = 54.0;
		parametrosKa[1] = -0.8;
		parametrosKa[2] = 0.5;
		return parametrosKa;
		
	}
	
	/**
	 *
	 *  Devuelve los parametros que componen el factor Kd por defecto
	 *  @param hT en mts
	 *  @param h en mts
	 *  @return
	 * 
	 */
	
	private double[] getParametrosKd() {
		double[] parametrosKd = new double[2];
		parametrosKd[0] = 18.0;
		parametrosKd[1] = -15.0;
		return parametrosKd;
	}
	
	/**
	 * Devuelve los parametros Kf en función del tipo de ciudad. 
	 * @param tipoCiudad
	 * @return
	 */
	private double[] getParametrosKf(int tipoCiudad) {
		if (tipoCiudad == Cost231WISimple.CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS) {
			double[] parametrosKf = new double[3];
			parametrosKf[0] = -4;
			parametrosKf[1] = 0.7;
			parametrosKf[2] = 925;
			return parametrosKf;
		} else {
			double[] parametrosKf = new double[3];
			parametrosKf[0] = -4;
			parametrosKf[1] = 1.5;
			parametrosKf[2] = 925;
			return parametrosKf;
		}
	}
	/**
	 * 
	 * @param phi entre 0 y 90 en grados 

	 */
	private double calculoLori(double phi) {
		double Lori;
		double[] parametrosLori = ((double[]) this.parametrosNoAjustables[0]);
		if (phi < 35) {
			Lori = parametrosLori[0] + parametrosLori[1] * phi;
		} else if (phi < 55) {
			Lori = parametrosLori[2] + parametrosLori[3] * (phi - 35);
		} else {
			Lori = parametrosLori[4] + parametrosLori[5] * (phi - 55);
		}
		return Lori;
		
	}
	/**
	 * Calcula los parametros de Lbsh
	
	 */
	private double calculoLbsh(double hT, double h) {
		double Lbsh;
		// TODO Verificar posicion en el ArrayList
		double[] parametrosLbsh = (double[]) ((Object[]) this.parametrosNoAjustables[1])[0];
		double Lbsh1 = parametrosLbsh[0];
		double Lbsh2 = parametrosLbsh[1];
		if (hT > h) {
			Lbsh = Lbsh1 * Math.log(Lbsh2 + (hT - h)) / Math.log(10);
			return Lbsh;
		} else {
			Lbsh = 0;
			return Lbsh;
		}
		
	}
	/**
	 * Calcula el factor Ka segun la altura de la radiobase, la altura en el punto y la distancia
	
	 */
	private double calculoKa(double distancia, double hT, double h) {
		double Ka;
		double[] parametrosKa = (double[]) ((Object[]) this.parametrosNoAjustables[1])[1];
		double Ka1 = parametrosKa[0];
		double Ka2 = parametrosKa[1];
		double Ka3 = parametrosKa[2];
		if (hT > h) {
			Ka = Ka1;
			return Ka;
		} else if (distancia >= 0.5) {
			Ka = Ka1 + Ka2 * (hT - h);
			return Ka;
		} else {
			Ka = Ka1 + Ka2 * (hT - h) * distancia / Ka3;
			return Ka;
		}
		
	}
	
	/**
	 * Calcula el factor Kd segun la altura de la radiobase, la altura en el punto y la distancia

	 */
	private double calculoKd(double hT, double h) {
		double Kd;
		double[] parametrosKd = (double[]) ((Object[]) this.parametrosNoAjustables[1])[2];
		double Kd1 = parametrosKd[0];
		double Kd2 = parametrosKd[1];
		
		if (hT > h) {
			Kd = Kd1;
			return Kd;
		} else {
			Kd = Kd1 + Kd2 * (hT - h) / h;
			return Kd;
		}
		
	}
	/**
	 * Calcula el factor Kf segun la frecuencia y el tipo de ciudad
	
	 */
	private double calculoKf(double frecuencia) {
		double Kf;
		double[] parametrosKf = (double[]) ((Object[]) this.parametrosNoAjustables[1])[3];
		double Kf1 = parametrosKf[0];
		double Kf2 = parametrosKf[1];
		double Kf3 = parametrosKf[2];
		
		Kf = Kf1 + Kf2 * (frecuencia / Kf3 - 1);
		return Kf;
		
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#setNombres()
	 * 
	 */
	
	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.COST_231_WI_SIMPLE;
		this.nombreParametrosAjustables = new String[] { "Lb0", "Lb1", "Lb2",
				"LB0", "LB1", "LB2", "Lrts0", "Lrts1", "Lrts2", "Lrts3", "Lmsd" };
		this.nombreParametrosNoAjustables = new String[] { "Lori", "Lmsd",
		"tipo de Ciudad", "altura de edificios", "ancho de calle", "separacion de edificios" };
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#verificarDatos(explorer.proyecto.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia()
		&& !mapa.getCapaEdificios().esVacia()
		&& !mapa.getCapaManzanas().esVacia();
		
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, double, double, double)
	 */
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Cost231WISimple");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			
			if(envoltura==null)
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo Cost231WISimple es nula, verifique los datos");
			
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));			
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
			//MathTransform2D mt = gc.getGridGeometry().getGridToCoordinateSystem2D();			
						
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura();

			double lambda = Modelo.C/antena.getFrecuencia();
			double distancia;
			double atenuacionAux;
			double atenuacionVacio;		
			
			double lB0, lB1, lB2; 
			
			 
			double altoEdif = ((Integer)this.parametrosNoAjustables[3]).doubleValue(); 
			double w = ((Integer)this.parametrosNoAjustables[4]).doubleValue(); 
			double b = ((Integer)this.parametrosNoAjustables[5]).doubleValue();
			double phi, h; 
			double lmsd, lrts, lb; 
			
			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			double[] datos = new double[ancho*alto];
			int contador = 0;
			double minimo = Double.MAX_VALUE;
			double maximo = -Double.MAX_VALUE;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			com.vividsolutions.jts.geom.Point puntoMovil; 
			
			UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radioMax, sitioAntena, "altura");
			UtilidadesModelosManzanas umc = new UtilidadesModelosManzanas(gc, mapa.getCapaManzanas().getFeatureCollection(), radioMax, sitioAntena);
			GeometryFactory gf = new GeometryFactory(); 
			double[] alturasEfectivas;
			double alturaTotalMovil, alturaTotalBase; 
			alturaTotalBase = hTrelativa + ume.getAlturaAntena(); 
			hTrelativa += ume.getAlturaEdificioAntena(); 
			
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){ 
					//
					sitioMovil = mt.transform(new Point(i,j),null);
					puntoMovil = gf.createPoint(new Coordinate(sitioMovil.getX(), sitioMovil.getY()));
					alturaTotalMovil = ume.getAlturaTotal(sitioMovil, hRrelativa, this.usarInterpolacion);				
					
					if(ume.calcularDistanciaGrid(sitioAntena, sitioMovil) < radioMax){
						
						double[] distanciaYangulos  = ume.calcularDistanciaReal(sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion);
						distancia = distanciaYangulos[0];
						distancia = distancia/1000.0; //el modelo utiliza la distancia en km
						LineString linea = gf.createLineString(new Coordinate[]{
								new Coordinate(sitio.getX(), sitio.getY()), 
								new Coordinate(sitioMovil.getX(), sitioMovil.getY())
						}); 
					
						double[] alturas = new double[]{ alturaTotalBase, alturaTotalMovil};
						//si hay LOS
						if(ume.librePrimerFresnelExacto(linea, antena.getFrecuencia(), alturas)){
							lB0 = this.parametrosAjustables[0];
							lB1 = this.parametrosAjustables[1];
							lB2 = this.parametrosAjustables[2];
							atenuacionAux = lB0 + (lB1*Math.log(distancia) + lB2*Math.log(frecuencia))/Math.log(10.0);
						}else{ // si NO hay LOS
							h = ume.getAlturaTotal(sitioMovil, altoEdif, this.usarInterpolacion);
							phi = umc.calcularOrientacion(sitioMovil, sitioAntena, 40);
							if(Double.isNaN(phi))
								phi = umc.getUltimaOri(); //si no tuvieron sentido calcularlo, tomo el último suponiendo que será razonable. 
							
							if(!(-Double.MAX_VALUE == w || -Double.MAX_VALUE == phi)){ //en caso que w o phi den -Double.MAX_VALUE quiere decir que no tiene sentido el modelo. 
								double kf = this.calculoKf(frecuencia);
								double kd = this.calculoKd(alturaTotalBase, h); 
								double ka = this.calculoKa(distancia, alturaTotalBase, h);
								double lbsh = this.calculoLbsh(alturaTotalBase, h); 
								lmsd = lbsh + ka + kd*Math.log(distancia)/Math.log(10.0) + kf*Math.log(frecuencia)/Math.log(10.0) + this.parametrosAjustables[10]*Math.log(b)/Math.log(10.0);
								
								double lori = this.calculoLori(phi);
								double lrts0 = this.parametrosAjustables[6];
								double lrts1 = this.parametrosAjustables[7];
								double lrts2 = this.parametrosAjustables[8];
								double lrts3 = this.parametrosAjustables[9];
								lrts = lrts0 + lrts1*Math.log(w)/Math.log(10.0) + lrts2*Math.log(frecuencia)/Math.log(10.0) + lrts3*Math.log(h-alturaTotalMovil)/Math.log(10.0) + lori;
								
								double lb0 = this.parametrosAjustables[3];
								double lb1 = this.parametrosAjustables[4];
								double lb2 = this.parametrosAjustables[5];
								lb = lb0 + (lb1*Math.log(distancia) + lb2*Math.log(frecuencia))/Math.log(10.0); 
								if(lrts+lmsd > 0){
									atenuacionAux = lb + lrts + lmsd; 
								}else{
									atenuacionAux = lb; 
								}
							}else{
								atenuacionAux = Double.NaN; 
							}
						}
						if(!Double.isNaN(atenuacionAux)){
//							double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
							// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
							double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
							datos[contador] = antena.getPotencia() + gananciaE - atenuacionAux ;
						}else{
							datos[contador] = Double.NaN; 	
						}
						
					}else{
						datos[contador] = Double.NaN;
					}
					if(datos[contador] < minimo) minimo = datos[contador];
					if(datos[contador] > maximo) maximo = datos[contador];
					contador++;
					cuantoVa = (int)((double)contador/((double)(ancho*alto))*100.0);
				}			
			}
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp;
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, com.vividsolutions.jts.geom.Coordinate)
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Cost231WISimple");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
									
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura();
			double lambda = Modelo.C/antena.getFrecuencia();
			double distancia;
			double atenuacionAux;
			double atenuacionVacio;		
			
			double lB0, lB1, lB2; 
			
			double altoEdif = ((Integer)this.parametrosNoAjustables[3]).doubleValue(); 
			double w = ((Integer)this.parametrosNoAjustables[4]).doubleValue(); 
			double b = ((Integer)this.parametrosNoAjustables[5]).doubleValue();
			double h; 
			double phi; 
			double lmsd, lrts, lb; 
			
			double[] predicciones = new double[puntos.length];
			int contador = 0;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			com.vividsolutions.jts.geom.Point puntoMovil; 
			
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}
			
			
			UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio+100.0, sitioAntena, "altura");
			UtilidadesModelosManzanas umc = new UtilidadesModelosManzanas(gc, mapa.getCapaManzanas().getFeatureCollection(), radio+100.0, sitioAntena);
			GeometryFactory gf = new GeometryFactory(); 
			double[] alturasEfectivas;
			double alturaTotalMovil, alturaTotalBase; 
			alturaTotalBase = hTrelativa + ume.getAlturaAntena(); 
			hTrelativa += ume.getAlturaEdificioAntena(); 
			
			
			for(int j=0;j<predicciones.length;j++){
				sitioMovil = new Point2D.Double(puntos[j].x,puntos[j].y);
				puntoMovil = gf.createPoint(new Coordinate(sitioMovil.getX(), sitioMovil.getY()));
				alturaTotalMovil = ume.getAlturaTotal(sitioMovil, hRrelativa, this.usarInterpolacion);
				
				double[] distanciaYangulos  = ume.calcularDistanciaReal(sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion);
				distancia = distanciaYangulos[0];
				distancia = distancia/1000.0; //el modelo utiliza la distancia en km
				LineString linea = gf.createLineString(new Coordinate[]{
						new Coordinate(sitio.getX(), sitio.getY()), 
						new Coordinate(sitioMovil.getX(), sitioMovil.getY())
				}); 
				double[] alturas = new double[]{ alturaTotalBase, alturaTotalMovil};
				//si hay LOS
				if(ume.librePrimerFresnelExacto(linea, antena.getFrecuencia(), alturas)){
					lB0 = this.parametrosAjustables[0];
					lB1 = this.parametrosAjustables[1];
					lB2 = this.parametrosAjustables[2];
					atenuacionAux = lB0 + (lB1*Math.log(distancia) + lB2*Math.log(frecuencia))/Math.log(10.0);
				}else{ // si NO hay LOS
					phi = umc.calcularOrientacion(sitioMovil, sitioAntena, 40);
					h = ume.getAlturaTotal(sitioMovil, altoEdif, this.usarInterpolacion);
					if(Double.isNaN(phi))
						phi = umc.getUltimaOri(); //si no tuvieron sentido calcularlo, tomo el último suponiendo que será razonable.  
					
					if(!(-Double.MAX_VALUE == w || -Double.MAX_VALUE == phi)){ //en caso que w o phi den -Double.MAX_VALUE quiere decir que no tiene sentido el modelo.  
						double kf = this.calculoKf(frecuencia);
						double kd = this.calculoKd(alturaTotalBase, h); 
						double ka = this.calculoKa(distancia, alturaTotalBase, h);
						double lbsh = this.calculoLbsh(alturaTotalBase, h); 
						lmsd = lbsh + ka + kd*Math.log(distancia)/Math.log(10.0) + kf*Math.log(frecuencia)/Math.log(10.0) + this.parametrosAjustables[10]*Math.log(b)/Math.log(10.0); 
						
						double lori = this.calculoLori(phi);
						double lrts0 = this.parametrosAjustables[6];
						double lrts1 = this.parametrosAjustables[7];
						double lrts2 = this.parametrosAjustables[8];
						double lrts3 = this.parametrosAjustables[9];
						lrts = lrts0 + lrts1*Math.log(w)/Math.log(10.0) + lrts2*Math.log(frecuencia)/Math.log(10.0) + lrts3*Math.log(h-alturaTotalMovil)/Math.log(10.0) + lori; 
						
						double lb0 = this.parametrosAjustables[3];
						double lb1 = this.parametrosAjustables[4];
						double lb2 = this.parametrosAjustables[5];
						lb = lb0 + (lb1*Math.log(distancia) + lb2*Math.log(frecuencia))/Math.log(10.0); 
						if(lrts+lmsd > 0){
							atenuacionAux = lb + lrts + lmsd; 
						}else{
							atenuacionAux = lb; 
						}
					}else{
						atenuacionAux = Double.NaN; 
					}
				}
				if(!Double.isNaN(atenuacionAux)){
//					double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
					// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
					double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
					predicciones[j] = antena.getPotencia() + gananciaE - atenuacionAux ;
				}else{
					predicciones[j] = Double.NaN; 	
				}
				
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
			}			
			
			return predicciones;
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
		
		
		
		
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#areaCalculable(explorer.proyecto.Mapa, java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try {
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf
					.createLinearRing(new Coordinate[] { new Coordinate(0, 0),
							new Coordinate(1, 0), new Coordinate(1, 1),
							new Coordinate(0, 1), new Coordinate(0, 0) }), null);
			while (fi.hasNext() && esta == false) {
				rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf
						.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if (!esta)
				return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
			.getCoordinates();
			Envelope envoltura = new Envelope(2);
			for (int j = 0; j < coordenadas.length; j++)
				envoltura.add(new CoordinatePoint(
						coordenadas[j].x,
						coordenadas[j].y)); //genero la envoltura que contiene los cuatro vértices
			return envoltura;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#crearPanelCreacion()
	 * 
	 */
	
	@Override
	protected void crearPanelCreacion() {
		this.menu = new MenuCost231WISimple(
				this.parametrosAjustables,
				this.parametrosNoAjustables);
		
	}
	
	/*
	 * (non-Javadoc)
	 *  @see explorer.modelos.Modelo#getPanelCreacion()
	 * 
	 */
	
	@Override
	public PanelModelos getPanelCreacion() {
		return this.menu;
	}
	
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#getXML()
	 */
	@Override
	public String getXML() {
		
		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>"+ nombreImplementacion + "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");
		
		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>"+ nombreParametrosAjustables[i]+ "</Nombre>\r\n");
			if (parametrosAjustables.length != 0) {
				result1.append("        <Valor>"+ parametrosAjustables[i]+ "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		if (parametrosNoAjustables.length != 0) {
			
			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer();
				if ((i == 0)) {
					
					//Double[] paramLori =  (Double[])this.parametrosNoAjustables[i];
					double[] paramLori =  (double[])this.parametrosNoAjustables[i];
					for (int j=0; j< paramLori.length;j++){
						result1 = new StringBuffer(	"<ParametrosNoAjustablesSubitems>");
						//Double Lori = (Double) paramLori[j];
						double Lori = (double) paramLori[j];
						result1.append("        <Nombre>"+ "Lori"+ j+ "</Nombre>\r\n");
						result1.append("        <Valor>" + Lori + "</Valor>\r\n");
						result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
						result.append(result1.toString());
					}		
				}
				if ((i == 1)) {
					Object[] paramLmsd =  (Object[])this.parametrosNoAjustables[i];
					for (int j=0; j< paramLmsd.length;j++){
						double[] conjuntoLmsd =  (double[])paramLmsd[j];
						for (int h=0; h< conjuntoLmsd.length;h++){
							result1 = new StringBuffer(	"<ParametrosNoAjustablesSubitems>");
							double Lmsd = conjuntoLmsd[h];
							result1.append("        <Nombre>"+ "Lmsd"+ h+ "</Nombre>\r\n");
							result1.append("        <Valor>" + Lmsd + "</Valor>\r\n");
							result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
							result.append(result1.toString());
						}						
					}	
					
				}
				result1 = new StringBuffer("<ParametrosNoAjustables>");
				result1.append("        <Nombre>" + nombreParametrosNoAjustables[i]+ "</Nombre>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"+ parametrosNoAjustables[i]	+ "</Valor>\r\n");
				} else {result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");	
				result.append(result1.toString());
				
			}
		}
		
		result.append("      </Modelo>\r\n");
		return result.toString();
		
	}
	
	
	/**
	 * Ventana de creación de instancias del modelo de Cost231-Walfisch-Ikegami simplificado
	 * @author Grupo de Proyecto SAPO.
	 *
	 */
	protected class MenuCost231WISimple extends PanelModelos
	implements
	ActionListener {
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lB0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lB1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lB2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lb0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lb1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lb2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts0;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts1;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts2;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lrts3;
		/*
		 *
		 *	  Los campos para los ajustables
		 *	 
		 */
		
		JTextField lmsdA;
		
		/*
		 *
		 *	  Los campos para los no ajustables 
		 *	 
		 */
		
		JComboBox tipoCiudad;
		JTextField lbsh0;
		JTextField lbsh1;
		JTextField ka0;
		JTextField ka1;
		JTextField ka2;
		JTextField kd0;
		JTextField kd1;
		JTextField kf0;
		JTextField kf1;
		JTextField kf2;
		JTextField lori0;
		JTextField lori1;
		JTextField lori2;
		JTextField lori3;
		JTextField lori4;
		JTextField lori5;
		JTextField altoEdif;
		JTextField anchoCalles;
		JTextField separacionEdif; 
		
		JPanel noAjustables;
		JButton botonPorDefecto;
		
		public final static String CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS = " Ciudad Media y Centros Urbanos";
		public final static String CENTRO_METROPOLITANO = " Centro Metropolitano";
		
		MenuCost231WISimple(
				double[] parametrosAjustables,
				Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
		}
		
		/**
		 *
		 *	  Esta implementación en particular es un panel, con dos panels dentro. Uno para los parámetros ajustables, 
		 *	  y otro para los no ajustables (este será el layout que deberían seguir los demás modelos para una 
		 *	  coherencia del programa). 
		 *	 
		 */
		
		@Override
		public void agregarElementos() {
			this.setLayout(new GridBagLayout());
			TitledBorder bordeAjustable, bordeNoAjustable, bordeVacio, bordeNoVacio;
			JPanel ajustables = new JPanel();
			ajustables.setLayout(new GridBagLayout());
			noAjustables = new JPanel();
			noAjustables.setLayout(new GridBagLayout());
			
			GridBagConstraints c = new GridBagConstraints();
			c.insets = new Insets(2, 2, 2, 2);
			GridBagConstraints cGrande = new GridBagConstraints();
			/*
			 * Creo el panel para los ajustables con un borde con título y luego lo agrego al panel. 
			 */
			
			/*
			 * caso LOS
			 */
			JPanel ajustablesLOS = new JPanel();
			ajustablesLOS.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>b</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lb0 = new JTextField("");
			ajustablesLOS.add(lb0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>b</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lb1 = new JTextField("");
			ajustablesLOS.add(lb1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>b</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lb2 = new JTextField("");
			ajustablesLOS.add(lb2, c);
			
			bordeNoVacio = BorderFactory.createTitledBorder("Caso LOS");
			ajustablesLOS.setBorder(bordeNoVacio);
			
			/*
			 * Caso NLOS
			 */
			/*
			 * LB
			 */
			JPanel ajustablesNLOS = new JPanel();
			ajustablesNLOS.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>B</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lB0 = new JTextField("");
			ajustablesNLOS.add(lB0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>B</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lB1 = new JTextField("");
			ajustablesNLOS.add(lB1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>B</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lB2 = new JTextField("");
			ajustablesNLOS.add(lB2, c);
			
			c.gridx = 0;
			c.gridy = 3;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>msd</sub>: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 3;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lmsdA = new JTextField("");
			ajustablesNLOS.add(lmsdA, c);
			
			/*
			 * parametros de Lrts
			 */
			
			c.gridx = 2;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>0: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts0 = new JTextField("");
			ajustablesNLOS.add(lrts0, c);
			
			c.gridx = 2;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>1: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts1 = new JTextField("");
			ajustablesNLOS.add(lrts1, c);
			
			c.gridx = 2;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>2: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts2 = new JTextField("");
			ajustablesNLOS.add(lrts2, c);
			
			c.gridx = 2;
			c.gridy = 3;
			c.fill = GridBagConstraints.REMAINDER;
			ajustablesNLOS
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>rts</sub>3: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 3;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lrts3 = new JTextField("");
			ajustablesNLOS.add(lrts3, c);
			
			bordeVacio = BorderFactory.createTitledBorder("Caso NLOS");
			ajustablesNLOS.setBorder(bordeVacio);
			
			/*
			 * El panel total de los ajustables. 
			 */
			c.gridx = 0;
			c.gridy = 0;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.VERTICAL;
			ajustables.add(ajustablesLOS, c);
			c.gridx = 2;
			c.gridy = 0;
			c.gridwidth = 4;
			c.gridheight = 2;
			ajustables.add(ajustablesNLOS, c);
			c.gridx = 4;
			c.gridy = 0;
			c.gridwidth = 2;
			c.gridheight = 2;
			bordeAjustable = BorderFactory
			.createTitledBorder("Parámetros Ajustables");
			ajustables.setBorder(bordeAjustable);
			
			cGrande.gridx = 0;
			cGrande.gridy = 0;
			cGrande.gridwidth = 4;
			cGrande.gridheight = 2;
			cGrande.fill = GridBagConstraints.BOTH;
			//cGrande.weightx = 1;
			cGrande.insets = new Insets(4, 4, 4, 4);
			this.add(ajustables, cGrande);
			
			/*
			 * Creo el panel para los parámetros no ajustables y lo agrego al panel. 
			 */
			
			c.gridx = 1;
			c.gridy = 0;
			c.gridheight = 1;
			c.gridwidth = 1;
			//c.fill = GridBagConstraints.REMAINDER;
			c.weightx = 0;
			noAjustables.add(new JLabel("Tipo de Ciudad: "), c);
			
			String[] listaCiudad = new String[] {
					MenuCost231WISimple.CENTRO_METROPOLITANO,
					MenuCost231WISimple.CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS };
			tipoCiudad = new JComboBox(listaCiudad);
			c.gridx = 2;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			noAjustables.add(tipoCiudad, c);
			
			/*
			 * Lbsh
			 */
			
			JPanel noAjustLbsh = new JPanel();
			noAjustLbsh.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLbsh
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>bsh</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lbsh0 = new JTextField("");
			noAjustLbsh.add(lbsh0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLbsh
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>bsh</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lbsh1 = new JTextField("");
			noAjustLbsh.add(lbsh1, c);
			
			TitledBorder bordeLbsh = BorderFactory.createTitledBorder("Lbsh");
			noAjustLbsh.setBorder(bordeLbsh);
			
			/*
			 * ka
			 */
			JPanel noAjustka = new JPanel();
			noAjustka.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustka
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>a</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			ka0 = new JTextField("");
			noAjustka.add(ka0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustka
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>a</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			ka1 = new JTextField("");
			noAjustka.add(ka1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustka
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>a</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			ka2 = new JTextField("");
			noAjustka.add(ka2, c);
			
			TitledBorder bordeka = BorderFactory.createTitledBorder("ka");
			noAjustka.setBorder(bordeka);
			
			/*
			 * kd
			 */
			
			JPanel noAjustkd = new JPanel();
			noAjustkd.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustkd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>d</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			kd0 = new JTextField("");
			noAjustkd.add(kd0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustkd
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>d</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			kd1 = new JTextField("");
			noAjustkd.add(kd1, c);
			
			TitledBorder bordekd = BorderFactory.createTitledBorder("kd");
			noAjustkd.setBorder(bordekd);
			
			/*
			 * kf
			 */
			
			JPanel noAjustkf = new JPanel();
			noAjustkf.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustkf
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>f</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			kf0 = new JTextField("");
			noAjustkf.add(kf0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustkf
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>f</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			kf1 = new JTextField("");
			noAjustkf.add(kf1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustkf
			.add(
					new JLabel(
					"<html><div align=center>Parámetro k<sub>f</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			kf2 = new JTextField("");
			noAjustkf.add(kf2, c);
			
			TitledBorder bordekf = BorderFactory.createTitledBorder("kf");
			noAjustkf.setBorder(bordekf);
			
			/*
			 * Lori
			 */
			
			JPanel noAjustLori = new JPanel();
			noAjustLori.setLayout(new GridBagLayout());
			
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>0: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori0 = new JTextField("");
			noAjustLori.add(lori0, c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>1: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori1 = new JTextField("");
			noAjustLori.add(lori1, c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>2: </div></html>"),
					c);
			
			c.gridx = 1;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori2 = new JTextField("");
			noAjustLori.add(lori2, c);
			
			c.gridx = 2;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>3: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori3 = new JTextField("");
			noAjustLori.add(lori3, c);
			
			c.gridx = 2;
			c.gridy = 1;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>4: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori4 = new JTextField("");
			noAjustLori.add(lori4, c);
			
			c.gridx = 2;
			c.gridy = 2;
			c.fill = GridBagConstraints.REMAINDER;
			noAjustLori
			.add(
					new JLabel(
					"<html><div align=center>Parámetro L<sub>ori</sub>5: </div></html>"),
					c);
			
			c.gridx = 3;
			c.gridy = 2;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			lori5 = new JTextField("");
			noAjustLori.add(lori5, c);
			
			TitledBorder bordeLori = BorderFactory.createTitledBorder("Lori");
			noAjustLori.setBorder(bordeLori);
			
			JPanel noAjustTop = new JPanel(new GridBagLayout()); 
			c.fill = GridBagConstraints.NONE; 
			c.gridx = 0; 
			c.gridy = 0; 
			c.gridwidth = 1; 
			c.gridheight = 1;
			c.weightx = 0; 
			noAjustTop.add(new JLabel("Altura promedio edificios (m): "), c); 
			c.gridx = 1; 
			c.weightx = 1; 
			this.altoEdif = new JTextField(); 
			noAjustTop.add(altoEdif, c); 
			c.gridx = 2; 
			c.weightx = 0; 
			noAjustTop.add(new JLabel("Ancho de calle promedio (m): "), c); 
			c.gridx = 3; 
			c.weightx = 1; 
			this.anchoCalles = new JTextField(); 
			noAjustTop.add(anchoCalles, c); 
			c.gridx = 4; 
			c.weightx = 0; 
			noAjustTop.add(new JLabel("Separación de edificios promedio (m): "), c); 
			c.gridx = 5; 
			c.weightx = 1; 
			this.separacionEdif = new JTextField(); 
			noAjustTop.add(separacionEdif, c); 
			TitledBorder bordeTop = new TitledBorder("Parámetros topológicos"); 
			noAjustTop.setBorder(bordeTop); 
			
			/*
			 * Creo el panel no ajustable total y por último lo agrego al panel
			 */
			
			c.gridx = 0;
			c.gridy = 1;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			noAjustables.add(noAjustLbsh, c);
			c.gridx = 0;
			c.gridy = 3;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			noAjustables.add(noAjustka, c);
			c.gridx = 2;
			c.gridy = 3;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			noAjustables.add(noAjustkd, c);
			c.gridx = 4;
			c.gridy = 3;
			c.gridwidth = 2;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			noAjustables.add(noAjustkf, c);
			c.gridx = 2;
			c.gridy = 1;
			c.gridwidth = 4;
			c.gridheight = 2;
			c.fill = GridBagConstraints.BOTH;
			noAjustables.add(noAjustLori, c);
			c.gridx = 0; 
			c.gridy = 5; 
			c.gridwidth = 6; 
			c.gridheight = 1; 
			noAjustables.add(noAjustTop, c); 
			
			bordeNoAjustable = BorderFactory
			.createTitledBorder("Parámetros no Ajustables");
			noAjustables.setBorder(bordeNoAjustable);
			
			cGrande.gridy = 2;
			this.add(noAjustables, cGrande);
			
			botonPorDefecto = new JButton("Valores por defecto");
			botonPorDefecto.addActionListener(this);
			cGrande.gridx = 3;
			cGrande.gridy = 4;
			cGrande.gridwidth = 1;
			cGrande.gridheight = 1;
			cGrande.anchor = GridBagConstraints.LAST_LINE_END;
			cGrande.fill = GridBagConstraints.NONE;
			//c.weightx = 0;
			this.add(botonPorDefecto, cGrande);
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 *	 
		 */
		
		@Override
		public double[] getParametrosAjustables()
		throws ModeloMalDefinidoException {
			try {
				double lb0 = Double.parseDouble(this.lb0.getText());
				double lb1 = Double.parseDouble(this.lb1.getText());
				double lb2 = Double.parseDouble(this.lb2.getText());
				double lB0 = Double.parseDouble(this.lB0.getText());
				double lB1 = Double.parseDouble(this.lB1.getText());
				double lB2 = Double.parseDouble(this.lB2.getText());
				double lrts0 = Double.parseDouble(this.lrts0.getText());
				double lrts1 = Double.parseDouble(this.lrts1.getText());
				double lrts2 = Double.parseDouble(this.lrts2.getText());
				double lrts3 = Double.parseDouble(this.lrts3.getText());
				double lmsdA = Double.parseDouble(this.lmsdA.getText());
				double[] parametros = new double[] { lb0, lb1, lb2, lB0, lB1,
						lB2, lrts0, lrts1, lrts2, lrts3, lmsdA
						
				};
				return parametros;
			} catch (Exception e) {
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
				"Algunos de los campos están mal");
				throw ex;
			}
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 *	 
		 */
		
		@Override
		public Object[] getParametrosNoAjustables()
		throws ModeloMalDefinidoException {
			try {
				Object[] parametrosNoAj = new Object[6];
				if (this.tipoCiudad.getSelectedItem().equals(
						MenuCost231WISimple.CENTRO_METROPOLITANO)) {
					parametrosNoAj[2] = new Integer(
							Cost231WISimple.CENTRO_METROPOLITANO);
				} else {
					parametrosNoAj[2] = new Integer(
							Cost231WISimple.CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS);
				}
				double[] lori = new double[] {
						Double.parseDouble(this.lori0.getText()),
						Double.parseDouble(this.lori1.getText()),
						Double.parseDouble(this.lori2.getText()),
						Double.parseDouble(this.lori3.getText()),
						Double.parseDouble(this.lori4.getText()),
						Double.parseDouble(this.lori5.getText()) };
				parametrosNoAj[0] = lori;
				
				double[] lbsh = new double[] {
						Double.parseDouble(this.lbsh0.getText()),
						Double.parseDouble(this.lbsh1.getText()), };
				double[] ka = new double[] {
						Double.parseDouble(this.ka0.getText()),
						Double.parseDouble(this.ka1.getText()),
						Double.parseDouble(this.ka2.getText()), };
				double[] kd = new double[] {
						Double.parseDouble(this.kd0.getText()),
						Double.parseDouble(this.kd1.getText()), };
				double[] kf = new double[] {
						Double.parseDouble(this.kf0.getText()),
						Double.parseDouble(this.kf1.getText()),
						Double.parseDouble(this.kf2.getText()), };
				Object[] lmsd = new Object[] { lbsh, ka, kd, kf };
				parametrosNoAj[1] = lmsd;
				
				parametrosNoAj[3] = new Integer(Integer.parseInt(this.altoEdif.getText())); 
				parametrosNoAj[4] = new Integer(Integer.parseInt(this.anchoCalles.getText()));
				parametrosNoAj[5] = new Integer(Integer.parseInt(this.separacionEdif.getText()));
				
				return parametrosNoAj;
			} catch (Exception e) {
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
				"Algunos de los valores ingresados están mal");
				throw ex;
			}
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables) {
			this.lb0.setText(String.valueOf(parametrosAjustables[0]));
			this.lb1.setText(String.valueOf(parametrosAjustables[1]));
			this.lb2.setText(String.valueOf(parametrosAjustables[2]));
			this.lB0.setText(String.valueOf(parametrosAjustables[3]));
			this.lB1.setText(String.valueOf(parametrosAjustables[4]));
			this.lB2.setText(String.valueOf(parametrosAjustables[5]));
			this.lrts0.setText(String.valueOf(parametrosAjustables[6]));
			this.lrts1.setText(String.valueOf(parametrosAjustables[7]));
			this.lrts2.setText(String.valueOf(parametrosAjustables[8]));
			this.lrts3.setText(String.valueOf(parametrosAjustables[9]));
			this.lmsdA.setText(String.valueOf(parametrosAjustables[10]));
			
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			
			double[] lori = (double[]) parametrosNoAjustables[0];
			double[] lbsh = (double[]) ((Object[]) parametrosNoAjustables[1])[0];
			double[] ka = (double[]) ((Object[]) parametrosNoAjustables[1])[1];
			double[] kd = (double[]) ((Object[]) parametrosNoAjustables[1])[2];
			double[] kf = (double[]) ((Object[]) parametrosNoAjustables[1])[3];
			int tipoCiudad = ((Integer) parametrosNoAjustables[2]).intValue();
			
			this.lori0.setText(String.valueOf(lori[0]));
			this.lori1.setText(String.valueOf(lori[1]));
			this.lori2.setText(String.valueOf(lori[2]));
			this.lori3.setText(String.valueOf(lori[3]));
			this.lori4.setText(String.valueOf(lori[4]));
			this.lori5.setText(String.valueOf(lori[5]));
			this.lbsh0.setText(String.valueOf(lbsh[0]));
			this.lbsh1.setText(String.valueOf(lbsh[1]));
			this.ka0.setText(String.valueOf(ka[0]));
			this.ka1.setText(String.valueOf(ka[1]));
			this.ka2.setText(String.valueOf(ka[2]));
			this.kd0.setText(String.valueOf(kd[0]));
			this.kd1.setText(String.valueOf(kd[1]));
			this.kf0.setText(String.valueOf(kf[0]));
			this.kf1.setText(String.valueOf(kf[1]));
			this.kf2.setText(String.valueOf(kf[2]));
			
			this.altoEdif.setText(parametrosNoAjustables[3].toString());
			this.anchoCalles.setText(parametrosNoAjustables[4].toString());
			this.separacionEdif.setText(parametrosNoAjustables[5].toString());
			
			if (tipoCiudad == Cost231WISimple.CENTRO_METROPOLITANO) {
				this.tipoCiudad
				.setSelectedItem(MenuCost231WISimple.CENTRO_METROPOLITANO);
			} else {
				this.tipoCiudad
				.setSelectedItem(MenuCost231WISimple.CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS);
			}
		}
		
		/**
		 * Simplemente resetea los valores a los por defecto. 
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Cost231WISimple c = new Cost231WISimple();
			this.setParametrosAjustables(c.parametrosAjustables);
			int tipoDeCiudad = 0;
			if (this.tipoCiudad.getSelectedItem().equals(
					MenuCost231WISimple.CENTRO_METROPOLITANO)) {
				tipoDeCiudad = Cost231WISimple.CENTRO_METROPOLITANO;
			} else {
				tipoDeCiudad = Cost231WISimple.CIUDAD_MEDIA_Y_CENTROS_SUBURBANOS;
			}
			try {
				this.setParametrosNoAjustables(c
						.getParametrosNoAjustablesPorDefecto(tipoDeCiudad));
			} catch (ModeloMalDefinidoException e) {
				//igual aca no entra
			}
		}
		
		/*
		 * (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 *	 
		 */
		
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new Cost231WISimple(this.getParametrosAjustables(), this
					.getParametrosNoAjustables());
		}
		
		/*
		 *
		 *	   (non-Javadoc)
		 *	  @see explorer.ifusuario.menues.PanelModelos#getTamanioVentana()
		 *	 
		 */
		
		public Dimension getTamanioVentana() {
			return new Dimension(410, 440);
		}
	}
	
}
