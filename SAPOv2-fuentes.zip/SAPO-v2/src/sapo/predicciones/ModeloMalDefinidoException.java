package sapo.predicciones;

/**
 * Esta excepción es lanzada al crear un modelo, si los parametros no corresponden en 
 * cantidad y tipo a los establecidos para ese modelo. 
 * Al asignar un nombre a un modelo, si el nombre es vacío.
 * 
 * @author Grupo de proyecto SAPO
 *  
 */
public class ModeloMalDefinidoException extends Exception {

	public ModeloMalDefinidoException(String error) {
		super(error);
	}

}
