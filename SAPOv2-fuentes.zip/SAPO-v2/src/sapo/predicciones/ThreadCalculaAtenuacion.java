package sapo.predicciones;

import sapo.ifusuario.Mapa;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;

import com.vividsolutions.jts.geom.Coordinate;

/**
 * Esta clase es un thread que tiene cargados las antenas y los parámetros de la
 * predicción (radioMax, etc). Cuando se utiliza el método run() realiza la
 * predicción de todas las antenas y las carga a un PredicciónMultiAntena.
 * Surge dada la necesidad de no utilizar el event thread (thread donde se realiza
 * todo el trabajo relacionado con la GUI) para realiar tareas de larga duración
 * (como por ejemplo, realizar una predicción a un mapa). 
 * 
 * @author Grupo de proyecto SAPO
 */
public class ThreadCalculaAtenuacion extends Thread {

	Modelo modeloActual;

	Proyecto proyecto;

	Mapa mapa;

	double radioMax;

	double perdidaMax;

	double precision;

	Coordinate[] coordenadas;

	Antena[] antenas;

	String antenaActual = "";

	boolean usarInterpolacion;

	boolean los = false;

	PrediccionMultiAntena resultado;

	double[] resultadoCoordenadas;

	/**
	 * Verdadero solo si terminó de procesar todas las antenas.
	 */
	public boolean termino = false;

	/**
	 * Verdadero si se cancelo en la mitad del procesamiento (sin haber
	 * finalizado alguna de las antenas)
	 */
	public boolean seCancelo = false;

	/**
	 * Si hay algún error al realizar las predicciones, se pone dicha excepción
	 * en esta variable
	 */
	private PrediccionMalRealizadaException z;

	/**
	 * El modo de esta instancia
	 */
	private int modo;

	/**
	 * El modo cuando calcula la atenuación para un raster.
	 */
	private final static int MODO_RASTER = 0;

	/**
	 * El modo cuando calcula la atenuación para una serie de coordenadas.
	 */
	private final static int MODO_COORDENADAS = 1;

	/**
	 * Genera una nueva instancia con los parámetros indicados.
	 * 
	 * @param antenas 
	 *            las antenas sobre las cuales hay que realizar la predicciones.
	 * @param proyecto 
	 *            el proyecto sobre el que hay que realizar las predicciones.
	 * @param mapa 
	 *            el mapa sobre el que hay que realizar las predicciones.
	 * @param radioMax 
	 *            el radioMax con el cual realizar las predicciones.
	 * @param perdidaMax 
	 *            el maximo de pérdidas para las predicciones.
	 * @param precision 
	 *            la precisión a usar en las predicciones.
	 * @param usarInterpolacion 
	 *            Si hay que utilizar predicción o no en las predicciones.
	 */
	public ThreadCalculaAtenuacion(Antena[] antenas, Proyecto proyecto,
			Mapa mapa, double radioMax, double perdidaMax, double precision,
			boolean usarInterpolacion) {
		this.antenas = antenas;
		this.proyecto = proyecto;
		this.mapa = mapa;
		this.radioMax = radioMax;
		this.perdidaMax = perdidaMax;
		this.precision = precision;
		this.usarInterpolacion = usarInterpolacion;
		this.z = null;
		this.modo = ThreadCalculaAtenuacion.MODO_RASTER;
		this.los = false;
	}

	/**
	 * Crea una nueva instancia que calulará la atenuación para las coordenadas
	 * especificadas.

	 */
	public ThreadCalculaAtenuacion(Proyecto proyecto, Mapa mapa, Antena antena,
			Coordinate[] coordenadas, boolean usarInterpolacion) {
		this.antenas = new Antena[] { antena };
		this.proyecto = proyecto;
		this.mapa = mapa;
		this.usarInterpolacion = usarInterpolacion;
		this.z = null;
		this.modo = ThreadCalculaAtenuacion.MODO_COORDENADAS;
		this.coordenadas = coordenadas;
		this.los = false;
	}

	/**
	 * Devuelve el getCuantoVa() del modelo que esté procesando en el momento de
	 * ser llamado el método.

	 */
	public int getCuantoVa() {
		return modeloActual.getCuantoVa();
	}

	/**
	 * Llama al método predecir del modelo asociado en cada antena. Luego agrega
	 * los resultados al ResultadoMultiAntena asociado con este
	 * ThreadCalcularAtenuacion. Si en medio de una predicción se convoca el
	 * método terminar, se termina de procesar la antena actual (en la
	 * implementación actual es imposible salir en medio de un procesamiento) y
	 * se termina la ejecución.
	 */
	@Override
	public void run() {
		this.z = null;
		try {
			if (this.modo == ThreadCalculaAtenuacion.MODO_RASTER) {
				resultado = new PrediccionMultiAntena();
				for (int j = 0; j < antenas.length; j++) {
					if (!seCancelo) {
						this.antenaActual = antenas[j].getSitio() + "."
								+ antenas[j].getRB() + "."
								+ antenas[j].getNombre();
						Modelo modelo;
						if (los) {
							modelo = new LineaDeVista();
						} else {
							modelo = antenas[j].getModelo();
						}
						this.modeloActual = modelo;
						modelo.setUsarInterpolacion(this.usarInterpolacion);
						PrediccionUniAntena rp = modelo.predecir(this.proyecto,
								this.mapa, antenas[j], this.radioMax, 100.0,
								this.precision);
						resultado.agregarPrediccion(rp);
					}
				}
			} else {
				Antena antena = this.antenas[0];
				Modelo modelo = antena.getModelo();
				this.modeloActual = modelo;
				modelo.setUsarInterpolacion(this.usarInterpolacion);
				resultadoCoordenadas = modelo.predecir(proyecto, mapa, antena,
						coordenadas);
			}
		} catch (PrediccionMalRealizadaException e) {
			this.z = e;
		} finally {
			termino = true;
		}
		//notifyAll();
	}

	/**
	 * Devuelve la predicción que resulto del método run() (en caso que haya
	 * sido en modo raster, será un PrediccionMultiAntena y en caso contrario un
	 * array de doubles).

	 */
	public Object getPrediccion() throws PrediccionMalRealizadaException {
		if (this.z != null)
			throw z;
		if (this.modo == ThreadCalculaAtenuacion.MODO_RASTER) {
			return resultado;
		} else {
			return this.resultadoCoordenadas;
		}

	}

	/**
	 * Devuelve en un string la antena que se está procesando en el momento de
	 * llamarse el método.
	 */
	public String getAntenaActual() {
		return this.antenaActual;
	}

	/**
	 * setea la bandera de cancelar en true. De esta forma, cuando termina de
	 * procesar la antena actual, este thread termina.
	 *  
	 */
	public void terminar() {
		this.seCancelo = true;
	}


	public void setLos(boolean los) {
		this.los = los;
	}

	/**
	 * Devuelve si esta instancia calcula únicamente los.

	 */
	public boolean getLos() {
		return this.los;
	}

}
