package sapo.predicciones;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Polygon;

/**
 * Esta clase representa el modelo de atenuación de Erceg-SUI.
 * 
 * @autor Grupo de proyecto SAPO 
 *
 */
public class Erceg extends Modelo {
	
	public static final int TERRENO_TIPO_A = 0;
	public static final int TERRENO_TIPO_B = 1;
	public static final int TERRENO_TIPO_C = 2;
	
	public Erceg() {
		super();
	}
	
	/**
	 *Crea un modelo de Erceg a partir de los parámetros
	 */
	public Erceg(double[] parametrosAjustables, Object[] parametrosNoAjustables)
	throws ModeloMalDefinidoException {
		super(parametrosAjustables, parametrosNoAjustables);
	}
	
	/**
	 *Crea un modelo de Erceg por defecto a partir del tipo de terreno
	 */
	public Erceg(int tipoTerreno) throws ModeloMalDefinidoException {
		super();
		if (tipoTerreno != Erceg.TERRENO_TIPO_A
				&& tipoTerreno != Erceg.TERRENO_TIPO_B
				&& tipoTerreno != Erceg.TERRENO_TIPO_C) {
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
			"El tipo de terreno especificado no es correcto");
			throw e;
		}
		ArrayList parametrosGamma = getParametrosGamma(tipoTerreno);
		ArrayList parametrosS = getParametrosS(tipoTerreno);
		Double factorF = new Double(-10.8);
		if (tipoTerreno == Erceg.TERRENO_TIPO_C)
			factorF = new Double(-20);
		this.parametrosNoAjustables = new Object[] { new Double(100),
				new Integer(tipoTerreno), parametrosGamma, parametrosS,
				new Double[] { new Double(1900), new Double(6) },
				new Double[] { new Double(2), factorF } };
	}
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#getParametrosAjustablesPorDefecto()
	 */
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		double[] parametros = new double[] {};
		return parametros;
	}
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#getParametrosNoAjustablesPorDefecto()
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		ArrayList parametrosGamma = getParametrosGamma(Erceg.TERRENO_TIPO_A);
		ArrayList parametrosS = getParametrosS(Erceg.TERRENO_TIPO_A);
		Object[] parametros = new Object[] { new Double(100),
				new Integer(Erceg.TERRENO_TIPO_A), parametrosGamma,
				parametrosS, new Double[] { new Double(1900), new Double(6) },
				new Double[] { new Double(2), new Double(-10.8) } };
		return parametros;
	}
	
	private static ArrayList getParametrosGamma(int tipoTerreno) {
		if (tipoTerreno == Erceg.TERRENO_TIPO_A) {
			ArrayList parametros = new ArrayList();
			parametros.add(new Double(4.6));
			parametros.add(new Double(0.0075));
			parametros.add(new Double(12.6));
			parametros.add(new Double(0.57));
			parametros.add(new Integer(1));
			return parametros;
		} else if (tipoTerreno == Erceg.TERRENO_TIPO_B) {
			ArrayList parametros = new ArrayList();
			parametros.add(new Double(4.0));
			parametros.add(new Double(0.0065));
			parametros.add(new Double(17.1));
			parametros.add(new Double(0.75));
			parametros.add(new Integer(1));
			return parametros;
		} else {
			ArrayList parametros = new ArrayList();
			parametros.add(new Double(3.6));
			parametros.add(new Double(0.005));
			parametros.add(new Double(20));
			parametros.add(new Double(0.59));
			parametros.add(new Integer(1));
			return parametros;
		}
	}
	
	private static ArrayList getParametrosS(int tipoTerreno) {
		if (tipoTerreno == Erceg.TERRENO_TIPO_A) {
			ArrayList parametros = new ArrayList();
			//parametros.add(new Double(0));
			parametros.add(new Double(10.6));
			parametros.add(new Double(2.3));
			parametros.add(new Integer(1));
			parametros.add(new Integer(1));
			return parametros;
		} else if (tipoTerreno == Erceg.TERRENO_TIPO_B) {
			ArrayList parametros = new ArrayList();
			//parametros.add(new Double(0));
			parametros.add(new Double(9.6));
			parametros.add(new Double(3));
			parametros.add(new Integer(1));
			parametros.add(new Integer(1));
			return parametros;
		} else {
			ArrayList parametros = new ArrayList();
			//parametros.add(new Double(0));
			parametros.add(new Double(8.2));
			parametros.add(new Double(1.6));
			parametros.add(new Integer(1));
			parametros.add(new Integer(1));
			return parametros;
		}
	}
	
	/*
	 
	 private double[] getFactoresCorrectivos(double frecuencia, double hR){
	 double factorF = (((Double[])parametrosNoAjustables[4])[0]).doubleValue();
	 double f0 = (((Double[])parametrosNoAjustables[4])[1]).doubleValue();
	 double factorH = (((Double[])parametrosNoAjustables[5])[0]).doubleValue();
	 double h0 = (((Double[])parametrosNoAjustables[5])[1]).doubleValue();
	 
	 double factorCorrectivoF = factorF * Math.log(frecuencia/f0)/Math.log(10);
	 double factorCorrectivoH = factorH * Math.log(hR/h0)/Math.log(10);
	 
	 return new double[]{factorCorrectivoF, factorCorrectivoH};		
	 }
	 */

	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.ERCEG_SUI;
		this.nombreParametrosAjustables = new String[] { "s/n" };
		this.nombreParametrosNoAjustables = new String[] { "d0",
				"Tipo de Terreno", "Parametros de gamma(a,b,c,sigma,n)",
				"Parametros de s (mu,sigma,n1, n2)",
				"Factor de correcion de frecuencia(f0, factor)",
		"Factor de correcion de hR(hR0, factor)" };
	}
	
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia();
	}
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#predecir(sapo.proyecto.Proyecto, sapo.ifusuario.Mapa, sapo.red.Antena, double, double, double)
	 */
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Erceg");
			}
			
			Sitio sitio = proyecto.getSitio(antena.getSitio());
			Radiobase rb = sitio.getRadiobase(antena.getRB());
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura(); 
			
			GridCoverage gc = mapa.getCapaAlturas().getGridCoverage();
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			
			if(envoltura==null) 
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo Erceg es nula, verifique los datos");
			
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
			UtilidadesModelos um = new UtilidadesModelos(gc);				
			
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			
			//parametros
			int tipoTerreno = ((Integer)this.parametrosNoAjustables[1]).intValue();
			
			double d0 = ((Double)this.parametrosNoAjustables[0]).doubleValue();
			if (d0>=radioMax) 
				throw new PrediccionMalRealizadaException("El modelo de Erceg solo puede ser calculado para distancias mayores que d0");
			
			double lambda = Modelo.C/(frecuencia*1E6); //en metros
			double A = 20 * Math.log(4*Math.PI*d0/lambda)/Math.log(10);
			
			Object[] parametrosGamma = ((ArrayList)this.parametrosNoAjustables[2]).toArray();
			double a = ((Double)parametrosGamma[0]).doubleValue();
			double b = ((Double)parametrosGamma[1]).doubleValue();
			double c = ((Double)parametrosGamma[2]).doubleValue();
			double sigmaGamma = ((Double)parametrosGamma[3]).doubleValue();
			int nSigmaGamma = ((Integer)parametrosGamma[4]).intValue();
			double dispersionGamma = nSigmaGamma * sigmaGamma;
			
			Object[] parametrosS = ((ArrayList)this.parametrosNoAjustables[3]).toArray();
			double muSigmaS = ((Double)parametrosS[0]).doubleValue();
			double sigmaSigmaS = ((Double)parametrosS[1]).doubleValue();
			int nSigmaSigmaS = ((Integer)parametrosS[2]).intValue();
			int nSigmaS = ((Integer)parametrosS[3]).intValue();
			double dispersionS = nSigmaS * (muSigmaS + nSigmaSigmaS * sigmaSigmaS); 	
			
			double f0 = (((Double[])parametrosNoAjustables[4])[0]).doubleValue();
			double factorF = (((Double[])parametrosNoAjustables[4])[1]).doubleValue();
			double factorCorrectivoF = factorF * Math.log(frecuencia/f0)/Math.log(10);
			
			double h0 = (((Double[])parametrosNoAjustables[5])[0]).doubleValue();
			double factorH = (((Double[])parametrosNoAjustables[5])[1]).doubleValue();
			
			//variables
			double[] datos = new double[ancho*alto];
			double minimo = java.lang.Double.MAX_VALUE;
			double maximo = -java.lang.Double.MAX_VALUE;
			int contador = 0;			
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			double distancia, gananciaE, hT, hR, factorCorrectivoH, gamma, atenuacion;
			Point sitioMovil;	
			
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radioMax, sitioAntena, "altura");
				hTrelativa += ume.getAlturaEdificioAntena(); 
			}
			
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){					
					sitioMovil = new Point(i,j);
					if(um.calcularDistanciaGrid(mt, sitioAntena, sitioMovil) < radioMax){
						//double[] alturasEfectivas = um.alturaEfectiva(sitioAntena, hTrelativa, mt.transform(sitioMovil,null), hRrelativa, 30, this.usarInterpolacion);
						//hT = alturasEfectivas[0];
						//hR = alturasEfectivas[1];
						
						//TODO lo que esta arriba comentado es usando altura efectiva, esto es usando relativas
								
						hT = hTrelativa;
						hR = hRrelativa; 
						
						double[] distanciaYangulos = um.calcularDistanciaReal(mt, sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion);
						distancia = distanciaYangulos[0];
						
						if (distancia < d0){ //si es menor que d0 supongo el mejor caso
							distancia = d0; 
						}
						
//						gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
						// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
						gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 

						
						
						factorCorrectivoH = factorH * Math.log(hR/h0)/Math.log(10);
						gamma = (a - b*hT + c/hT) + dispersionGamma;
						atenuacion = A + 10*gamma*Math.log(distancia/d0)/Math.log(10) + dispersionS + factorCorrectivoF + factorCorrectivoH;
						datos[contador] = potencia + gananciaE - atenuacion;
					}else{
						datos[contador] = Double.NaN; 
					}
					
					if(datos[contador] < minimo) minimo = datos[contador];
					if(datos[contador] > maximo) maximo = datos[contador];
					contador++;
					cuantoVa = (int)((double)contador/((double)(ancho*alto))*100.0);
				}			
			}
			Grilla grilla = new Grilla();
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp;	
			
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		} 
	}
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#predecir(sapo.proyecto.Proyecto, sapo.ifusuario.Mapa, sapo.red.Antena, com.vividsolutions.jts.geom.Coordinate[])
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Erceg");
			}
			
			Sitio sitio = proyecto.getSitio(antena.getSitio());
			Radiobase rb = sitio.getRadiobase(antena.getRB());
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura(); 
			
			GridCoverage gc = mapa.getCapaAlturas().getGridCoverage();
			UtilidadesModelos um = new UtilidadesModelos(gc);				
			
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia()/1E6; //el modelo utiliza la frecuencia en Mhz
			
			//parametros
			int tipoTerreno = ((Integer)this.parametrosNoAjustables[1]).intValue();
			
			double d0 = ((Double)this.parametrosNoAjustables[0]).doubleValue();
			
			double lambda = Modelo.C/(frecuencia*1E6); //en metros
			double A = 20 * Math.log(4*Math.PI*d0/lambda)/Math.log(10);
			
			Object[] parametrosGamma = ((ArrayList)this.parametrosNoAjustables[2]).toArray();
			double a = ((Double)parametrosGamma[0]).doubleValue();
			double b = ((Double)parametrosGamma[1]).doubleValue();
			double c = ((Double)parametrosGamma[2]).doubleValue();
			double sigmaGamma = ((Double)parametrosGamma[3]).doubleValue();
			int nSigmaGamma = ((Integer)parametrosGamma[4]).intValue();
			double dispersionGamma = nSigmaGamma * sigmaGamma;
			
			Object[] parametrosS = ((ArrayList)this.parametrosNoAjustables[3]).toArray();
			double muSigmaS = ((Double)parametrosS[0]).doubleValue();
			double sigmaSigmaS = ((Double)parametrosS[1]).doubleValue();
			int nSigmaSigmaS = ((Integer)parametrosS[2]).intValue();
			int nSigmaS = ((Integer)parametrosS[3]).intValue();
			double dispersionS = nSigmaS * (muSigmaS + nSigmaSigmaS * sigmaSigmaS); 	
			
			double f0 = (((Double[])parametrosNoAjustables[4])[0]).doubleValue();
			double factorF = (((Double[])parametrosNoAjustables[4])[1]).doubleValue();
			double factorCorrectivoF = factorF * Math.log(frecuencia/f0)/Math.log(10);
			
			double h0 = (((Double[])parametrosNoAjustables[5])[0]).doubleValue();
			double factorH = (((Double[])parametrosNoAjustables[5])[1]).doubleValue();
			
			//variables
			double[] predicciones = new double[puntos.length];
			int contador = 0;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			double distancia, gananciaE, hT, hR, factorCorrectivoH, gamma, atenuacion;
			Point2D sitioMovil;	
			
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio, sitioAntena, "altura");
				hTrelativa += ume.getAlturaEdificioAntena(); 
			}
			
			for(int j=0;j<predicciones.length;j++){
				sitioMovil = new Point2D.Double(puntos[j].x,puntos[j].y);
				
				//double [] alturasEfectivas = um.alturaEfectiva(sitioAntena, hTrelativa, sitioMovil, hRrelativa, 30, this.usarInterpolacion);
				//hT = alturasEfectivas[0];
				//hR = alturasEfectivas[1];
				
				//if (hT<10 || hT>80 || hR<2 || hR>10){
				hT = hTrelativa;
				hR = hRrelativa;
				//}
				
				double[] distanciaYangulos = um.calcularDistanciaReal(sitioAntena, hTrelativa, sitioMovil, hRrelativa, this.usarInterpolacion);
				distancia = distanciaYangulos[0];						
				if (distancia <d0){
					distancia = d0; 
				}
//				gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
				// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
				gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
				
				factorCorrectivoH = factorH * Math.log(hR/h0)/Math.log(10);
				gamma = (a - b*hT + c/hT) + dispersionGamma;
				atenuacion = A + 10*gamma*Math.log(distancia/d0)/Math.log(10) + dispersionS + factorCorrectivoF + factorCorrectivoH;
				predicciones[j] = potencia + gananciaE - atenuacion;
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
			}
			
			return predicciones;	
			
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}		
	}
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#areaCalculable(sapo.ifusuario.Mapa, java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try {
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf
					.createLinearRing(new Coordinate[] { new Coordinate(0, 0),
							new Coordinate(1, 0), new Coordinate(1, 1),
							new Coordinate(0, 1), new Coordinate(0, 0) }), null);
			while (fi.hasNext() && esta == false) {
				rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf
						.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if (!esta)
				return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
			.getCoordinates();
			double maxX = -Double.MAX_VALUE;
			double maxY = -Double.MAX_VALUE;
			double minY = Double.MAX_VALUE;
			double minX = Double.MAX_VALUE;
			for (int j = 0; j < coordenadas.length; j++) {
				if (coordenadas[j].x < minX)
					minX = coordenadas[j].x;
				if (coordenadas[j].x > maxX)
					maxX = coordenadas[j].x;
				if (coordenadas[j].y < minY)
					minY = coordenadas[j].y;
				if (coordenadas[j].y > maxY)
					maxY = coordenadas[j].y;
			}
			Envelope envoltura = new Envelope(
					new CoordinatePoint(minX, minY),
					new CoordinatePoint(maxX, maxY));
			return envoltura;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}
	
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#crearPanelCreacion()
	 */
	@Override
	protected void crearPanelCreacion() {
		this.menu = new MenuErceg(
				this.parametrosAjustables,
				this.parametrosNoAjustables);
	}
	/*
	 *  (non-Javadoc)
	 * @see sapo.predicciones.Modelo#getPanelCreacion()
	 */
	@Override
	public PanelModelos getPanelCreacion() {
		return menu;
	}
	
	
	/**
	 * Ventana de creación de instancias del modelo de Erceg-SUI
	 * @author Grupo de Proyecto SAPO.
	 *
	 */
	protected class MenuErceg extends PanelModelos implements ActionListener {
		
		/*
		 *
		 *  Los campos para los no ajustables 
		 * 
		 */
		
		JTextField d0;
		/*
		 *
		 *  Los campos para los no ajustables 
		 * 
		 */
		
		JTextField a;
		/*
		 *
		 *  Los campos para los no ajustables 
		 * 
		 */
		
		JTextField b;
		/*
		 *
		 *  Los campos para los no ajustables 
		 * 
		 */
		
		JTextField c;
		/*
		 *
		 *  Los campos para los no ajustables 
		 * 
		 */
		
		JTextField sigmaGamma;
		/*
		 *
		 *  Los campos para los no ajustables 
		 * 
		 */
		
		JTextField nSigmaGamma;
		JTextField muSigmaS;
		JTextField sigmaSigmaS;
		JTextField nSigmaS;
		JTextField nSigmaSigmaS;
		JTextField f0;
		JTextField factorF;
		JTextField hR0;
		JTextField factorH;
		JComboBox tipoTerreno;
		
		JPanel noAjustables;
		
		JButton botonPorDefecto;
		
		final String TERRENO_TIPO_A = " A: ondulado / densidad de árboles media-alta";
		//final String TERRENO_TIPO_B = " B: ondulado / densidad de árboles baja";
		final String TERRENO_TIPO_B = " B: ondulado (llano) / densidad de árboles baja (media-alta)";
		final String TERRENO_TIPO_C = " C: llano / densidad de árboles baja";
		
		MenuErceg(double[] parametrosAjustables, Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
		}
		
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables) {
		}
		
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			this.d0.setText(String.valueOf(parametrosNoAjustables[0]));
			this.tipoTerreno
			.setSelectedIndex(((Integer) parametrosNoAjustables[1])
					.intValue());
			
			Object[] parametrosGamma = ((ArrayList) parametrosNoAjustables[2])
			.toArray();
			this.a.setText(String.valueOf(parametrosGamma[0]));
			this.b.setText(String.valueOf(parametrosGamma[1]));
			this.c.setText(String.valueOf(parametrosGamma[2]));
			this.sigmaGamma.setText(String.valueOf(parametrosGamma[3]));
			this.nSigmaGamma.setText(String.valueOf(parametrosGamma[4]));
			
			Object[] parametrosS = ((ArrayList) parametrosNoAjustables[3])
			.toArray();
			this.muSigmaS.setText(String.valueOf(parametrosS[0]));
			this.sigmaSigmaS.setText(String.valueOf(parametrosS[1]));
			this.nSigmaSigmaS.setText(String.valueOf(parametrosS[2]));
			this.nSigmaS.setText(String.valueOf(parametrosS[3]));
			
			this.f0.setText(String
					.valueOf(((Double[]) parametrosNoAjustables[4])[0]));
			this.factorF.setText(String
					.valueOf(((Double[]) parametrosNoAjustables[4])[1]));
			this.hR0.setText(String
					.valueOf(((Double[]) parametrosNoAjustables[5])[0]));
			this.factorH.setText(String
					.valueOf(((Double[]) parametrosNoAjustables[5])[1]));
		}
		
		@Override
		public double[] getParametrosAjustables()
		throws ModeloMalDefinidoException {
			return new double[] {};
		}
		
		@Override
		public Object[] getParametrosNoAjustables()
		throws ModeloMalDefinidoException {
			
			try {
				Object[] parametrosNoAj = new Object[6];
				parametrosNoAj[0] = new Double(Double.parseDouble(this.d0
						.getText()));
				
				if (this.tipoTerreno.getSelectedItem().equals(
						this.TERRENO_TIPO_A)) {
					parametrosNoAj[1] = new Integer(0);
				} else if (this.tipoTerreno.getSelectedItem().equals(
						this.TERRENO_TIPO_B)) {
					parametrosNoAj[1] = new Integer(1);
					
				} else if (this.tipoTerreno.getSelectedItem().equals(
						this.TERRENO_TIPO_C)) {
					parametrosNoAj[1] = new Integer(2);
				}
				
				ArrayList parametrosGamma = new ArrayList();
				parametrosGamma
				.add(new Double(Double.parseDouble(a.getText())));
				parametrosGamma
				.add(new Double(Double.parseDouble(b.getText())));
				parametrosGamma
				.add(new Double(Double.parseDouble(c.getText())));
				parametrosGamma.add(new Double(Double.parseDouble(sigmaGamma
						.getText())));
				parametrosGamma.add(new Integer(Integer.parseInt(nSigmaGamma
						.getText())));
				parametrosNoAj[2] = parametrosGamma;
				
				ArrayList parametrosS = new ArrayList();
				parametrosS.add(new Double(Double.parseDouble(muSigmaS
						.getText())));
				parametrosS.add(new Double(Double.parseDouble(sigmaSigmaS
						.getText())));
				parametrosS.add(new Integer(Integer.parseInt(nSigmaSigmaS
						.getText())));
				parametrosS
				.add(new Integer(Integer.parseInt(nSigmaS.getText())));
				parametrosNoAj[3] = parametrosS;
				
				parametrosNoAj[4] = new Double[] {
						new Double(Double.parseDouble(f0.getText())),
						new Double(Double.parseDouble(factorF.getText())) };
				parametrosNoAj[5] = new Double[] {
						new Double(Double.parseDouble(hR0.getText())),
						new Double(Double.parseDouble(factorH.getText())) };
				
				return parametrosNoAj;
				
			} catch (Exception e) {
				e.printStackTrace(System.out);
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
				"Alguno de los valores ingresados no tiene el formato correcto.");
				throw ex;
			}
			
		}
		
		@Override
		public void agregarElementos() {
			this.setLayout(new GridBagLayout());
			noAjustables = new JPanel();
			noAjustables.setLayout(new GridBagLayout());
			noAjustables.setBorder(BorderFactory
					.createTitledBorder("Parámetros no Ajustables"));
			
			GridBagConstraints g = new GridBagConstraints();
			g.insets = new Insets(2, 2, 2, 2);
			
			/*
			 * Creo el panel para los parámetros no ajustables y lo agrego al panel. 
			 */
			JPanel panelAux = new JPanel(new GridBagLayout());
			g.fill = GridBagConstraints.CENTER;
			g.gridwidth = GridBagConstraints.RELATIVE;
			panelAux.add(new JLabel("Parámetro d0 (m): "), g);
			
			g.fill = GridBagConstraints.HORIZONTAL;
			g.gridwidth = GridBagConstraints.REMAINDER;
			d0 = new JTextField(" ");
			panelAux.add(d0, g);
			
			g.fill = GridBagConstraints.CENTER;
			d0.setPreferredSize(new Dimension(100, 20));
			noAjustables.add(panelAux, g);
			
			panelAux = new JPanel(new GridBagLayout());
			g.fill = GridBagConstraints.NONE;
			g.gridwidth = GridBagConstraints.RELATIVE;
			//noAjustables.add(new JLabel("Tipo de Terreno: "), g);
			panelAux.add(new JLabel("Tipo de Terreno: "), g);
			
			g.fill = GridBagConstraints.HORIZONTAL;
			g.gridwidth = GridBagConstraints.REMAINDER;
			String[] listaTipoTerrenos = new String[] { this.TERRENO_TIPO_A,
					this.TERRENO_TIPO_B, this.TERRENO_TIPO_C };
			tipoTerreno = new JComboBox(listaTipoTerrenos);
			
			//g.fill = GridBagConstraints.CENTER;
			//noAjustables.add(tipoTerreno, g);
			panelAux.add(tipoTerreno, g);
			
			noAjustables.add(panelAux, g); //NEW
			
			panelAux = new JPanel(new GridLayout(5, 2));
			panelAux.setBorder(BorderFactory
					.createTitledBorder("Parámetros de \u03B3")); //gamma
			
			panelAux.add(new JLabel(" a: "));
			a = new JTextField("  ");
			panelAux.add(a);
			panelAux.add(new JLabel(" b (1/m): "));
			b = new JTextField("  ");
			panelAux.add(b);
			panelAux.add(new JLabel(" c (m): "));
			c = new JTextField("  ");
			panelAux.add(c);
			panelAux.add(new JLabel(" \u03C3\u03B3: ")); //sigma
			sigmaGamma = new JTextField("  ");
			panelAux.add(sigmaGamma);
			panelAux.add(new JLabel(" F. de seguridad (\u03C3\u03B3): "));
			nSigmaGamma = new JTextField("");
			panelAux.add(nSigmaGamma);
			
			//g.gridwidth = GridBagConstraints.RELATIVE;
			//panelAux.setPreferredSize(new Dimension(190,100));
			g.fill = GridBagConstraints.CENTER;
			g.gridwidth = GridBagConstraints.REMAINDER;
			noAjustables.add(panelAux, g);
			
			panelAux = new JPanel(new GridLayout(4, 2));
			panelAux.setBorder(BorderFactory
					.createTitledBorder("Parámetros de s"));
			
			panelAux.add(new JLabel(" \u03BC\u03C3: ")); //mu de sigma
			muSigmaS = new JTextField("");
			panelAux.add(muSigmaS);
			panelAux.add(new JLabel(" \u03C3\u03C3:")); //sigma de sigma
			sigmaSigmaS = new JTextField("  ");
			panelAux.add(sigmaSigmaS);
			panelAux.add(new JLabel(" F. de seguridad (\u03C3\u03C3): "), g);
			nSigmaSigmaS = new JTextField("  ");
			panelAux.add(nSigmaSigmaS);
			panelAux.add(new JLabel(" F. de seguridad (\u03C3): "), g);
			nSigmaS = new JTextField("");
			panelAux.add(nSigmaS);
			
			g.fill = GridBagConstraints.CENTER;
			//g.gridwidth = GridBagConstraints.REMAINDER;
			g.gridwidth = GridBagConstraints.RELATIVE;
			noAjustables.add(panelAux, g);
			
			panelAux = new JPanel(new GridLayout(4, 1));
			panelAux.setBorder(BorderFactory
					.createTitledBorder("Factores correctivos"));
			
			panelAux.add(new JLabel(" f0 (MHz): "));
			f0 = new JTextField("");
			panelAux.add(f0);
			panelAux.add(new JLabel(" F. multiplicativo:  "));
			factorF = new JTextField("  ");
			panelAux.add(factorF);
			
			panelAux.add(new JLabel(" hR0 (m): "));
			hR0 = new JTextField("");
			panelAux.add(hR0);
			panelAux.add(new JLabel(" F. multiplicativo:  "));
			factorH = new JTextField("  ");
			panelAux.add(factorH);
			
			g.fill = GridBagConstraints.CENTER;
			g.gridwidth = GridBagConstraints.REMAINDER;
			noAjustables.add(panelAux, g);
			
			this.add(noAjustables, g);
			
			botonPorDefecto = new JButton("Valores por defecto");
			botonPorDefecto.addActionListener(this);
			
			g.anchor = GridBagConstraints.LAST_LINE_END;
			g.fill = GridBagConstraints.NONE;
			this.add(botonPorDefecto, g);
			
		}
		
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new Erceg(this.getParametrosAjustables(), this
					.getParametrosNoAjustables());
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				Erceg modelo = new Erceg(tipoTerreno.getSelectedIndex());
				this.setParametrosAjustables(modelo.parametrosAjustables);
				this.setParametrosNoAjustables(modelo.parametrosNoAjustables);
			} catch (Exception ex) {
				ex.printStackTrace(System.out);
			}
		}
	}
	@Override
	public String getXML() {
		
		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>"+ nombreImplementacion + "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");
		
		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>"+ nombreParametrosAjustables[i]+ "</Nombre>\r\n");
			result1.append("        <Valor>" + 0 + "</Valor>\r\n");
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		if (parametrosNoAjustables.length != 0) {
			
			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer();
				if ((i == 2)) {
					
					ArrayList paramG = (ArrayList) this.parametrosNoAjustables[i];
					Iterator iterator = paramG.iterator();
					int m = 1;
					while (iterator.hasNext()) {
						result1 = new StringBuffer(
						"<ParametrosNoAjustablesSubitems>");
						if (m == 5){
							Integer c = (Integer)iterator.next();
							result1.append("        <Nombre>" + "gamma"	+ m + "</Nombre>\r\n");
							result1.append("        <Valor>" + c + "</Valor>\r\n");
							result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
							result.append(result1.toString());
							
						}else{
							Double c = (Double) iterator.next();
							result1.append("        <Nombre>" + "gamma"	+ m + "</Nombre>\r\n");
							result1.append("        <Valor>" + c + "</Valor>\r\n");
							result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
							result.append(result1.toString());
						}
						m = m + 1;
					}
				}
				if ((i == 3)) {
					ArrayList paramS = (ArrayList) this.parametrosNoAjustables[i];;
					Iterator iterator1 = paramS.iterator();
					int n = 1;
					while (iterator1.hasNext()) {
						result1 = new StringBuffer(	"<ParametrosNoAjustablesSubitems>");
						if ((n==1) || (n==2)){
							Double k = (Double) iterator1.next();
							result1.append("        <Nombre>"+ "s"+ n+ "</Nombre>\r\n");
							result1.append("        <Valor>" + k + "</Valor>\r\n");
							result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
							result.append(result1.toString());
						}else {
							Integer k = (Integer) iterator1.next();
							result1.append("        <Nombre>"+ "s"+ n+ "</Nombre>\r\n");
							result1.append("        <Valor>" + k + "</Valor>\r\n");
							result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
							result.append(result1.toString());
						}
						n = n + 1;
					}
				}
				if ((i == 4)||(i == 5)) {
					Double[] paramF =  (Double[])this.parametrosNoAjustables[i];
					for (int j=0; j< paramF.length;j++){
						result1 = new StringBuffer(	"<ParametrosNoAjustablesSubitems>");
						//if ((n==1) || (n==2)){
						Double k = (Double) paramF[j];
						result1.append("        <Nombre>"+ "fc"+ j+ "</Nombre>\r\n");
						result1.append("        <Valor>" + k + "</Valor>\r\n");
						result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
						result.append(result1.toString());
					}					
				}
				result1 = new StringBuffer("<ParametrosNoAjustables>");
				result1.append("        <Nombre>" + nombreParametrosNoAjustables[i]+ "</Nombre>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"+ parametrosNoAjustables[i]	+ "</Valor>\r\n");
				} else {result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");		
				result.append(result1.toString());
				
			}
		}
		
		result.append("      </Modelo>\r\n");
		return result.toString();
		
	}
}
