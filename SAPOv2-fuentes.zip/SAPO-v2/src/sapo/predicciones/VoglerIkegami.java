package sapo.predicciones;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase representa al modelo híbrido entre el método de Vogler para calcular la 
 * pérdida por difracción en múltiples cuchillos y la bajada hasta el móvil desde los edificios 
 * de Ikegami.  
 * @author Grupo de proyecto SAPO 
 */
public class VoglerIkegami extends Modelo{

	public VoglerIkegami(){
		super(); 
	}
	
	/**
	 * El constructor que especifica los parámetros. En los ajustables, van en el siguiente orden los 
	 * parametros de Lrts: el término independiente, el que multiplica log(w), el que multiplica 
	 * log(fc) y el que multiplica la diferencia de altura entre los edificios y el móvil. En 
	 * los no ajustables van en el siguiente orden: un Integer con la cantidad de repeticiones, 
	 * un Double con el margen de seguridad para el intervalo de confianza, un Integer con el 
	 * máximo porcentaje de error, un Integer con la cantidad máxima de edificaciones a ser 
	 * consideradas y por último un array de tamaño 6 con los parametros de Lori.  
	 * @param parametrosAjustables
	 * @param parametrosNoAjustables
	 * @throws ModeloMalDefinidoException
	 */
	public VoglerIkegami(double[] parametrosAjustables, Object[] parametrosNoAjustables) throws ModeloMalDefinidoException{
		super(parametrosAjustables, parametrosNoAjustables);
		if(((Integer)parametrosNoAjustables[0]).intValue() < 0)
			throw new ModeloMalDefinidoException("La cantidad de repeticiones debe ser positiva"); 
		if(((Double)parametrosNoAjustables[1]).doubleValue()<0 || ((Double)parametrosNoAjustables[1]).doubleValue()>1)
			throw new ModeloMalDefinidoException("El margen de seguridad debe ser mayor que cero y menor que uno"); 
		if(((Integer)parametrosNoAjustables[2]).intValue() < 0)
			throw new ModeloMalDefinidoException("El máximo porcentaje de error debe ser siempre positivo"); 
		if(((Integer)parametrosNoAjustables[3]).intValue() < 0)
			throw new ModeloMalDefinidoException("El número máximo de edificios a ser considerados debe ser positivo");
		if(((double[])parametrosNoAjustables[4]).length != 6)
			throw new ModeloMalDefinidoException("La cantidad de parametros de Lori debe ser seis. "); 
	}
	
	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#getParametrosAjustablesPorDefecto()
	 */
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		return new double[]{
				-16.9, 
				-10, 
				10, 
				20
		}; 
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#getParametrosNoAjustablesPorDefecto()
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		double[] parametrosLori = new double[6];
		parametrosLori[0] = -10;
		parametrosLori[1] = 0.354;
		parametrosLori[2] = 2.5;
		parametrosLori[3] = 0.075;
		parametrosLori[4] = 4.0;
		parametrosLori[5] = -0.114;
		return new Object[]{
				new Integer(10),
				new Double(0.95), 
				new Integer(20), 
				new Integer(8), 
				parametrosLori
			}; 
	}
	
	/**
	 * 
	 * @param phi entre 0 y 90 en grados 
	 * @return
	 */
	private double calculoLori(double phi) {
		double Lori;
		double[] parametrosLori = ((double[]) this.parametrosNoAjustables[4]);
		if (phi < 35) {
			Lori = parametrosLori[0] + parametrosLori[1] * phi;
		} else if (phi < 55) {
			Lori = parametrosLori[2] + parametrosLori[3] * (phi - 35);
		} else {
			Lori = parametrosLori[4] + parametrosLori[5] * (phi - 55);
		}
		return Lori;
		
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#setNombres()
	 */
	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.VOGLER_IKEGAMI;
		this.nombreParametrosAjustables = new String[]{"Lrts0", "Lrts1", "Lrts2", "Lrts3"};
		this.nombreParametrosNoAjustables = new String[]{"Repeticiones", "Margen_de_seguridad", "Maximo_ porcentaje_de_error", "Maximo_numero_de_cuchillos_a_ser_considerados", "Parametros_Lori: "};
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#verificarDatos(explorer.ifusuario.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia()
		&& !mapa.getCapaEdificios().esVacia()
		&& !mapa.getCapaManzanas().esVacia();
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#predecir(explorer.proyecto.Proyecto, explorer.ifusuario.Mapa, explorer.red.Antena, double, double, double)
	 */
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException {
		try{
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			if(envoltura==null) 
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo Vacío es nula, verifique los datos");
			
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
			Point sitioMovil; 
			CoordinatePoint sitioRealMovil = null;  
			Coordinate[] coordenadas = new Coordinate[ancho*alto];
			int contador = 0; 
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){ 
					//for(int j=0;j<alto;j++){
					sitioMovil = new Point(i,j);
					mt.transform(new CoordinatePoint(sitioMovil.x, sitioMovil.y), sitioRealMovil);
					coordenadas[contador] = new Coordinate(sitioRealMovil.getOrdinate(0), sitioRealMovil.getOrdinate(1)); 
					contador++; 
				}
			}
			double[] datos = this.predecir(proyecto, mapa, antena, coordenadas); 
			double maximo = -Double.MAX_VALUE; 
			double minimo = Double.MAX_VALUE; 
			for(int j=0; j<datos.length; j++){
				if(datos[j]<minimo)
					minimo = datos[j]; 
				if(datos[j]>maximo)
					maximo = datos[j]; 
			}
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp; 
			
		}catch(Exception e){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+e.getMessage()); 
		}
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#predecir(explorer.proyecto.Proyecto, explorer.ifusuario.Mapa, explorer.red.Antena, com.vividsolutions.jts.geom.Coordinate[])
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException {
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Vogler-Ikegami.");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			double hT = rb.getAltura();
			double hR = proyecto.getPerfilUsuario().getAltura(); 
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
						
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia();

			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}

			UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio+100.0, sitioAntena, "altura");
			UtilidadesModelosManzanas umc = new UtilidadesModelosManzanas(gc, mapa.getCapaManzanas().getFeatureCollection(), radio+100.0, sitioAntena);
			UtilidadesModelos um = new UtilidadesModelos(gc);
			
			double[] predicciones = new double[puntos.length];
			int contador = 0;
			GeometryFactory gf = new GeometryFactory(); 
			double alturaTotalMovil, gananciaMsd, atenuacionRts;
			double distancia = 0; 
			IntegralVogler integralVogler; 
			double[] distanciaYangulos = null; 
			double[] phiw = null; 
			double phi, w, h; 
			
			int repeticiones = ((Integer)this.parametrosNoAjustables[0]).intValue(); 
			double margenSeg = ((Double)this.parametrosNoAjustables[1]).doubleValue(); 
			int maxError = ((Integer)this.parametrosNoAjustables[2]).intValue(); 
			int maxCuchillos = ((Integer)this.parametrosNoAjustables[3]).intValue();
			
			double lrts0 = this.parametrosAjustables[0];
			double lrts1 = this.parametrosAjustables[1]; 
			double lrts2 = this.parametrosAjustables[2]; 
			double lrts3 = this.parametrosAjustables[3];
			
			for(int j=0;j<predicciones.length;j++){
				sitioMovil = new Point2D.Double(puntos[j].x,puntos[j].y);
				
				LineString linea = gf.createLineString(new Coordinate[]{
						new Coordinate(sitio.getX(), sitio.getY()), 
						new Coordinate(sitioMovil.getX(), sitioMovil.getY())
				}); 
				alturaTotalMovil = ume.getAlturaTotal(sitioMovil, hR, this.usarInterpolacion);
				double[] alturas = new double[]{ ume.getAlturaAntena()+hT, alturaTotalMovil};
				
				distanciaYangulos  = ume.calcularDistanciaReal(sitioAntena, hT+ume.getAlturaEdificioAntena(), sitioMovil, hR, this.usarInterpolacion);
				distancia = distanciaYangulos[0];
				
				phiw = umc.calcularOrientacionAncho(sitioMovil, sitioAntena, 40);
				phi = phiw[0]; 
				w = phiw[1]; 
				h = ume.alturaPromedio(gf.createPoint(new Coordinate(puntos[j].x, puntos[j].y)), 50);
				
				if(Double.isNaN(w))
					w = umc.getUltimoAncho(); 
				if(Double.isNaN(phi))
					phi = umc.getUltimaOri(); //si no tuvieron sentido calcularlo, tomo el último suponiendo que será razonable. 
				
				if(!(-Double.MAX_VALUE == w || -Double.MAX_VALUE == phi)){ //en caso que w o phi den -Double.MAX_VALUE quiere decir que no tiene sentido el modelo.  
					PerfilAlturas perfil = ume.hallarPerfilDeEdificios(linea, antena.getFrecuencia(), alturas, 0.5);
					if(perfil.getSeparaciones().length > 2){
						perfil.sacarReceptor(); 
						h = perfil.getAlturas()[perfil.getAlturas().length-1]; 
						integralVogler = new IntegralVogler(antena.getFrecuencia(), perfil.getSeparaciones(), perfil.getAlturas());
						gananciaMsd = 20.0*Math.log(integralVogler.calcularIntegralVoglerAproximada(repeticiones, margenSeg, maxError, maxCuchillos).modulus())/Math.log(10.0);
						//atenuacionAux = 20.0*Math.log(integralVogler.calcularIntegralVoglerTestHipotesis(repeticiones, margenSeg, maxCuchillos).modulus())/Math.log(10.0);
					}else{
						gananciaMsd = 0; 
					}
					System.out.println(j+"   ********************** Final atenuacionMsd: "+gananciaMsd); 
					
					atenuacionRts = lrts0 + lrts1*Math.log(w)/Math.log(10.0) + lrts2*Math.log(frecuencia/1e6)/Math.log(10.0) + lrts3*Math.log(h-alturaTotalMovil)/Math.log(10.0) + this.calculoLori(phi); 
					System.out.println(j+"   ********************** Final atenuacionRts: "+atenuacionRts);
					
					double atenuacionVacio = 32.44 + (20.0*Math.log(distancia/1000.0) + 20.0*Math.log(antena.getFrecuencia()/1.0E6))/Math.log(10.0);
					
//					double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
					// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
					double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
					predicciones[j] = antena.getPotencia() + gananciaE + gananciaMsd - atenuacionVacio - atenuacionRts;
					System.out.println(" *************************  Final final: "+predicciones[j]); 
				}else{
					predicciones[j] = Double.NaN; 
				}
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
			}
			return predicciones; 
		}catch(Exception z){
			z.printStackTrace(); 
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#areaCalculable(explorer.ifusuario.Mapa, java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try {
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf
					.createLinearRing(new Coordinate[] { new Coordinate(0, 0),
							new Coordinate(1, 0), new Coordinate(1, 1),
							new Coordinate(0, 1), new Coordinate(0, 0) }), null);
			while (fi.hasNext() && esta == false) {
				rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf
						.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if (!esta)
				return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
			.getCoordinates();
			Envelope envoltura = new Envelope(2);
			for (int j = 0; j < coordenadas.length; j++)
				envoltura.add(new CoordinatePoint(
						coordenadas[j].x,
						coordenadas[j].y)); //genero la envoltura que contiene los cuatro vértices
			return envoltura;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#crearPanelCreacion()
	 */
	@Override
	protected void crearPanelCreacion() {
		this.menu = new MenuVoglerIkegami(this.parametrosAjustables, this.parametrosNoAjustables);
		
	}

	/* (non-Javadoc)
	 * @see explorer.predicciones.Modelo#getPanelCreacion()
	 */
	@Override
	public PanelModelos getPanelCreacion() {
		return this.menu; 
	}

	@Override
	public String getXML() {
		
		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>" + nombreImplementacion + "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");
		
		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>" + nombreParametrosAjustables[i] + "</Nombre>\r\n");
			if (parametrosAjustables.length != 0) {
				result1.append("        <Valor>" + parametrosAjustables[i] + "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		if (parametrosNoAjustables.length != 0) {
			
			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer();
				if (i==4){
					double[] paramLori =  (double[])this.parametrosNoAjustables[i];
					for (int j=0; j< paramLori.length;j++){
						result1 = new StringBuffer(	"<ParametrosNoAjustablesSubitems>");
						double Lori = (double) paramLori[j];
						result1.append("        <Nombre>"+ "Lori"+ j+ "</Nombre>\r\n");
						result1.append("        <Valor>" + Lori + "</Valor>\r\n");
						result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
						result.append(result1.toString());
					}
				} 
				result1 = new StringBuffer("<ParametrosNoAjustables>");
				result1.append("        <Nombre>" + nombreParametrosNoAjustables[i]+ "</Nombre>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"+ parametrosNoAjustables[i]	+ "</Valor>\r\n");
				} else {result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");	
				result.append(result1.toString());
				
			}
		}
		
		result.append("      </Modelo>\r\n");
		return result.toString();
		
	}
	
	/**
	 * Ventana de creación de instancias del modelo Vogler-Ikegami
	 * @author Grupo de Proyecto SAPO.
	 *
	 */
	protected class MenuVoglerIkegami extends PanelModelos	implements ActionListener {

		JTextField repeticiones;
		JTextField maxError;
		JTextField maxCuchillos;
		JTextField margenSeg; 
		JTextField lori0;
		JTextField lori1;
		JTextField lori2;
		JTextField lori3;
		JTextField lori4;
		JTextField lori5;
		JTextField lrts0;
		JTextField lrts1;
		JTextField lrts2;
		JTextField lrts3; 
		JButton botonPorDefecto;
		
		/**
		 * @param parametrosAjustables
		 * @param parametrosNoAjustables
		 */
		public MenuVoglerIkegami(double[] parametrosAjustables, Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables) {
			this.lrts0.setText(String.valueOf(parametrosAjustables[0]));
			this.lrts1.setText(String.valueOf(parametrosAjustables[1])); 
			this.lrts2.setText(String.valueOf(parametrosAjustables[2])); 
			this.lrts3.setText(String.valueOf(parametrosAjustables[3])); 
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			this.repeticiones.setText(parametrosNoAjustables[0].toString()); 
			this.margenSeg.setText(parametrosNoAjustables[1].toString()); 
			this.maxError.setText(parametrosNoAjustables[2].toString());
			this.maxCuchillos.setText(parametrosNoAjustables[3].toString());
			double[] lori = (double[])parametrosNoAjustables[4]; 
			this.lori0.setText(String.valueOf(lori[0])); 
			this.lori1.setText(String.valueOf(lori[1]));
			this.lori2.setText(String.valueOf(lori[2]));
			this.lori3.setText(String.valueOf(lori[3]));
			this.lori4.setText(String.valueOf(lori[4]));
			this.lori5.setText(String.valueOf(lori[5]));
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 */
		@Override
		public double[] getParametrosAjustables() throws ModeloMalDefinidoException {
			return new double[]{
					Double.parseDouble(lrts0.getText()), 
					Double.parseDouble(lrts1.getText()), 
					Double.parseDouble(lrts2.getText()), 
					Double.parseDouble(lrts3.getText())
			}; 
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 */
		@Override
		public Object[] getParametrosNoAjustables() throws ModeloMalDefinidoException {
			double[] lori = new double[]{
					Double.parseDouble(lori0.getText()),
					Double.parseDouble(lori1.getText()),
					Double.parseDouble(lori2.getText()),
					Double.parseDouble(lori3.getText()),
					Double.parseDouble(lori4.getText()),
					Double.parseDouble(lori5.getText()),
			}; 
			return new Object[]{
					new Integer(Integer.parseInt(repeticiones.getText())),
					new Double(Double.parseDouble(margenSeg.getText())), 
					new Integer(Integer.parseInt(maxError.getText())), 
					new Integer(Integer.parseInt(maxCuchillos.getText())), 
					lori
			}; 
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#agregarElementos()
		 */
		@Override
		public void agregarElementos() {
			
			this.setLayout(new GridBagLayout()); 
			GridBagConstraints cGrande = new GridBagConstraints(); 
			cGrande.insets = new Insets(2,2,2,2); 
			
			/*
			 * panel con los parámetros ajustables
			 */
			JPanel panelAjustables = new JPanel(new GridBagLayout());
			GridBagConstraints c = new GridBagConstraints(); 
			c.insets = new Insets(4,4,4,4); 
			
			c.weightx = 0;
			c.fill = GridBagConstraints.NONE; 
			panelAjustables.add(new JLabel("Lrts0: "), c); 
			c.gridx = 1; 
			lrts0 = new JTextField();
			c.weightx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL; 
			panelAjustables.add(lrts0, c); 
			
			c.gridy = 1; 
			c.gridx = 0; 
			c.weightx = 0;
			c.fill = GridBagConstraints.NONE;
			panelAjustables.add(new JLabel("Lrts1: "), c); 
			c.gridx = 1; 
			lrts1 = new JTextField();
			c.weightx = 1;
			c.fill = GridBagConstraints.HORIZONTAL; 
			panelAjustables.add(lrts1, c);
			
			c.gridy = 0; 
			c.gridx = 2; 
			c.weightx = 0;
			c.fill = GridBagConstraints.NONE;
			panelAjustables.add(new JLabel("Lrts2: "), c); 
			c.gridx = 3; 
			lrts2 = new JTextField();
			c.weightx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL; 
			panelAjustables.add(lrts2, c);
			
			c.gridy = 1; 
			c.gridx = 2;
			c.weightx = 0; 
			c.fill = GridBagConstraints.NONE;
			panelAjustables.add(new JLabel("Lrts3: "), c); 
			lrts3 = new JTextField();
			c.gridx = 3; 
			c.weightx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL; 
			panelAjustables.add(lrts3, c);
			
			TitledBorder bordeAjustable = new TitledBorder("Parámetros Ajustables");
			panelAjustables.setBorder(bordeAjustable); 
			cGrande.fill = GridBagConstraints.BOTH;
			cGrande.gridwidth = 2; 
			this.add(panelAjustables, cGrande); 
			
			/*
			 * panel con los no ajustables
			 */
			
			/*
			 * panel con los parámetros de vogler
			 */
			JPanel panelVogler = new JPanel(new GridBagLayout()); 
			c.fill = GridBagConstraints.NONE; 
			c.anchor = GridBagConstraints.LINE_END; 
			c.gridx = 0; 
			c.gridy = 0; 
			c.weightx = 0;
			panelVogler.add(new JLabel("Repeticiones: "), c);
			
			this.repeticiones = new JTextField(); 
			c.gridx = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelVogler.add(repeticiones, c);
			
			c.gridy = 1; 
			c.gridx = 0;
			c.anchor = GridBagConstraints.LINE_END; 
			c.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			panelVogler.add(new JLabel("Margen de Seguridad: "), c); 
			
			this.margenSeg = new JTextField(); 
			c.gridx = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelVogler.add(margenSeg, c);
			
			c.gridy = 2; 
			c.gridx = 0; 
			c.fill = GridBagConstraints.NONE;
			c.anchor = GridBagConstraints.LINE_END;
			c.weightx = 0;
			panelVogler.add(new JLabel("Máximo Error: "), c);
			
			this.maxError = new JTextField(); 
			c.gridx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelVogler.add(maxError, c); 
			
			c.gridy = 3; 
			c.gridx = 0; 
			c.fill = GridBagConstraints.NONE; 
			c.anchor = GridBagConstraints.LINE_END;
			c.weightx = 0;
			panelVogler.add(new JLabel("Máxima cantidad de Cuchillos: "), c);
			
			this.maxCuchillos = new JTextField(); 
			c.gridx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelVogler.add(maxCuchillos, c);
			
			TitledBorder bordeVogler = new TitledBorder("Parámetros de la integral"); 
			panelVogler.setBorder(bordeVogler); 
			
			/*
			 * panel ikegami
			 */
			JPanel panelIkegami = new JPanel(new GridBagLayout()); 
			
			c.fill = GridBagConstraints.NONE; 
			c.gridx = 0; 
			c.gridy = 0; 
			c.weightx = 0;
			panelIkegami.add(new JLabel("Lori0: "), c);
			
			this.lori0 = new JTextField(); 
			c.gridx = 1;
			c.gridy = 0; 
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelIkegami.add(lori0, c);
			
			c.gridy = 1; 
			c.gridx = 0; 
			c.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			panelIkegami.add(new JLabel("Lori1: "), c); 
			
			this.lori1 = new JTextField(); 
			c.gridx = 1;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelIkegami.add(lori1, c);
			
			c.gridy = 2; 
			c.gridx = 0; 
			c.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			panelIkegami.add(new JLabel("Lori2: "), c);
			
			this.lori2 = new JTextField(); 
			c.gridx = 1; 
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelIkegami.add(lori2, c); 
			
			c.gridy = 0; 
			c.gridx = 2; 
			c.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			panelIkegami.add(new JLabel("Lori3: "), c);
			
			this.lori3 = new JTextField(); 
			c.gridx = 3; 
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelIkegami.add(lori3, c);
			
			c.gridy = 1; 
			c.gridx = 2; 
			c.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			panelIkegami.add(new JLabel("Lori4: "), c);
			
			this.lori4 = new JTextField(); 
			c.gridx = 3; 
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelIkegami.add(lori4, c);
			
			c.gridy = 2; 
			c.gridx = 2; 
			c.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			panelIkegami.add(new JLabel("Lori5: "), c);
			
			this.lori5 = new JTextField(); 
			c.gridx = 3; 
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1;
			panelIkegami.add(lori5, c);
			
			TitledBorder bordeIkegami = new TitledBorder("Parámetros de Lori"); 
			panelIkegami.setBorder(bordeIkegami);
			
			JPanel parametrosNoAjustables = new JPanel(new GridBagLayout()); 
			GridBagConstraints c2 = new GridBagConstraints(); 
			c2.fill = GridBagConstraints.BOTH;
			parametrosNoAjustables.add(panelVogler, c2); 
			c2.gridy = 1; 
			parametrosNoAjustables.add(panelIkegami, c2); 
			TitledBorder bordeNoAjustable = new TitledBorder("Parámetros no ajustables"); 
			parametrosNoAjustables.setBorder(bordeNoAjustable); 
			
			cGrande.gridy = 1; 
			this.add(parametrosNoAjustables, cGrande); 
			
			this.botonPorDefecto = new JButton("Valores por Defecto"); 
			botonPorDefecto.addActionListener(this); 
			cGrande.gridx = 1; 
			cGrande.gridy = 2; 
			cGrande.anchor = GridBagConstraints.LINE_END; 
			cGrande.fill = GridBagConstraints.NONE; 
			cGrande.gridwidth = 1; 
			this.add(botonPorDefecto, cGrande); 
			
		}

		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 */
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new VoglerIkegami(this.getParametrosAjustables(), this.getParametrosNoAjustables());
		}

		/* (non-Javadoc)
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			VoglerIkegami m = new VoglerIkegami();
			this.setParametrosAjustables(m.parametrosAjustables);
			this.setParametrosNoAjustables(m.parametrosNoAjustables); 
		}
		
	}
	
}
