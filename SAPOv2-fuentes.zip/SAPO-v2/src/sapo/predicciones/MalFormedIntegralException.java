
package sapo.predicciones;

/**
 *Esta excepción es lanzada cuando se utiliza mal la IntegralVogler.
 * 
 * @author Grupo de proyecto SAPO
 */
public class MalFormedIntegralException extends Exception {

	public MalFormedIntegralException(String mensaje) {
		super(mensaje);
	}

}
