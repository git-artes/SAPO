
package sapo.predicciones;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**Esta clase representa las pérdidas por vacío. 
 * 
 * @author Grupo de proyecto SAPO 
 *
 */
public class Vacio extends Modelo {
	
	/**
	 * Crea el modelo de vacio con los valores de la ecuación de Friis (n=2, A=c/(4*pi)). 
	 */
	public Vacio(){
		super();
	}
	
	/**
	 * Crea el modelo de vacío con el parámetro de propagación que convenga. 
	 * 
	 * @param parametrosAjustables - Un array de largo 1 que contendrá el valor de n. 
	 * @param parametrosNoAjustables - Debe ser un array vacío. 
	 * @throws ModeloMalDefinidoException - Además de los casos por defecto, cuando n es negativo. 
	 */
	public Vacio(double[] parametrosAjustables, Object[] parametrosNoAjustables) throws ModeloMalDefinidoException{
		super(parametrosAjustables, parametrosNoAjustables);
		if(parametrosAjustables[0]<0){
			ModeloMalDefinidoException error = new ModeloMalDefinidoException("n debe ser positivo, pues no tiene sentido que la potencia crezca con la distancia"); 
			throw error;
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#getParametrosAjustablesPorDefecto()
	 */
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		double[] parametro = new double[]{2.0, Modelo.C/(4*Math.PI)};
		return parametro;
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#getParametrosNoAjustablesPorDefecto()
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		Object[] parametros = new Object[]{};
		return parametros;
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#setNombres()
	 */
	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.VACIO;
		this.nombreParametrosAjustables = new String[]{"n", "A"};
		this.nombreParametrosNoAjustables = new String[]{"N/A"};
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#verificarDatos(explorer.proyecto.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia();
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, double, double)
	 */
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Vacío.");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			double hT = rb.getAltura();
			double hR = proyecto.getPerfilUsuario().getAltura();
						
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");			
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			
			if(envoltura==null) 
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo Vacío es nula, verifique los datos");
						
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
					
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia();
			double A = this.parametrosAjustables[1];
			double n = this.parametrosAjustables[0];
			
			UtilidadesModelos um = new UtilidadesModelos(gc);
			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			double[] datos = new double[ancho*alto];			
			int contador = 0;
			double minimo = Double.MAX_VALUE;
			double maximo = -Double.MAX_VALUE;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point sitioMovil;			
			
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radioMax, sitioAntena, "altura");
				hT += ume.getAlturaEdificioAntena(); 
			}
			
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){ 
					sitioMovil = new Point(i,j);
					if(um.calcularDistanciaGrid(mt, sitioAntena, sitioMovil) < radioMax){
						double[] distanciaYangulos = um.calcularDistanciaReal(mt, sitioAntena, hT, sitioMovil, hR, this.usarInterpolacion);
						double distancia = distanciaYangulos[0];
						// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
						double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI);
//						double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
						datos[contador] = potencia + gananciaE + 10.0*Math.log(Math.pow(A/(frecuencia*distancia),n))/Math.log(10.0);
					}else{
						datos[contador] = Double.NaN;
					}
					if(datos[contador] < minimo) minimo = datos[contador];
					if(datos[contador] > maximo) maximo = datos[contador];
					contador++;
					cuantoVa = (int)((double)contador/((double)(ancho*alto))*100.0);
				}			
			}
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			
			return rp;
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
		
		
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, com.vividsolutions.jts.geom.Coordinate)
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException{
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Vacío.");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			double hT = rb.getAltura();
			double hR = proyecto.getPerfilUsuario().getAltura(); 
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
						
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia();
			double A = this.parametrosAjustables[1];
			double n = this.parametrosAjustables[0];
			
			UtilidadesModelos um = new UtilidadesModelos(gc);
			double[] predicciones = new double[puntos.length];
			int contador = 0;
			
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D sitioMovil;
			
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio, sitioAntena, "altura");
				hT += ume.getAlturaEdificioAntena(); 
			}
			
			for(int j=0;j<predicciones.length;j++){
				sitioMovil = new Point2D.Double(puntos[j].x,puntos[j].y);
				double[] distanciaYangulos = um.calcularDistanciaReal(sitioAntena, hT, sitioMovil, hR, this.usarInterpolacion);
				double distancia = distanciaYangulos[0];
				
				// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
				double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
//				double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);										
				predicciones[j] = potencia + gananciaE + 10.0*Math.log(Math.pow(A/(frecuencia*distancia),n))/Math.log(10.0);
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
				
			}
			return predicciones; 
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#areaCalculable(explorer.proyecto.Mapa, explorer.red.Antena)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, java.awt.geom.Point2D.Double punto){
		try{
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf.createLinearRing(new Coordinate[]{new Coordinate(0,0), new Coordinate(1,0), new Coordinate(1,1), new Coordinate(0,1), new Coordinate(0,0)}), null);
			while(fi.hasNext() && esta==false){
				rectanguloAlturas = ((Polygon)fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if(!esta) return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing().getCoordinates();
			double maxX = -Double.MAX_VALUE;
			double maxY = -Double.MAX_VALUE;
			double minY = Double.MAX_VALUE;
			double minX = Double.MAX_VALUE;
			for(int j=0;j<coordenadas.length;j++){
				if(coordenadas[j].x < minX) 
					minX = coordenadas[j].x;
				if(coordenadas[j].x > maxX)
					maxX = coordenadas[j].x;
				if(coordenadas[j].y < minY)
					minY = coordenadas[j].y;
				if(coordenadas[j].y > maxY)
					maxY = coordenadas[j].y;
			}
			Envelope envoltura = new Envelope(new CoordinatePoint(minX,minY), new CoordinatePoint(maxX,maxY));
			return envoltura;			
		}catch(Exception e){
			e.printStackTrace(System.out);
			return null;
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#getPanelCreacion()
	 */
	@Override
	public PanelModelos getPanelCreacion() {
		return menu;
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#crearPanelCreacion()
	 */
	@Override
	protected void crearPanelCreacion() {
		menu = new MenuVacio(this.parametrosAjustables, this.parametrosNoAjustables);
	}
	
	/**
	 * Ventana de creación de instancias del modelo de vacio
	 * @author Grupo de Proyecto SAPO.
	 *
	 */
	protected class MenuVacio extends PanelModelos implements ActionListener{
		
		JTextField n;
		JTextField A;
		JButton botonPorDefecto;
		
		MenuVacio(double[] parametrosAjustables, Object[] parametrosNoAjustables){
			super(parametrosAjustables, parametrosNoAjustables);
		}
		
		@Override
		public void agregarElementos(){
			this.setLayout(new GridLayout(3,2));
			this.add(new JLabel("Parámetro n: "));
			n = new JTextField("");
			this.add(n);
			this.add(new JLabel("Parámetro A: "));
			A = new JTextField("");
			this.add(A);
			botonPorDefecto = new JButton("Valores por defecto");
			botonPorDefecto.addActionListener(this);
			this.add(botonPorDefecto);
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 */
		@Override
		public double[] getParametrosAjustables() throws ModeloMalDefinidoException {
			try{
				double n = Double.parseDouble(this.n.getText());
				double A = Double.parseDouble(this.A.getText());
				double[] parametros = new double[]{
						n, 
						A
				};
				//Vacio v = new Vacio(parametros, new Object[]{}); //realiza el chequeo
				return parametros;
			}catch(Exception e){
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException("Algunos de los campos están mal");
				throw ex;
			}
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 */
		@Override
		public Object[] getParametrosNoAjustables() throws ModeloMalDefinidoException {
			return new Object[]{};
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables){
			this.n.setText(String.valueOf(parametrosAjustables[0]));
			this.A.setText(String.valueOf(parametrosAjustables[1]));
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables){
			//no hay que hacer nada 
		}
		
		
		
		/**
		 * simplemente resetea los valores a los por defecto. 
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Vacio modeloVacio = new Vacio();
			this.setParametrosAjustables(modeloVacio.getParametrosAjustablesPorDefecto());
			this.setParametrosNoAjustables(modeloVacio.getParametrosNoAjustablesPorDefecto());
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 */
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new Vacio(this.getParametrosAjustables(), this.getParametrosNoAjustables());
		}
		
		/*
		 *  (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getTamanioVentana()
		 */ 
		public Dimension getTamanioVentana(){
			return new Dimension(272, 138);
		}
	}
	
	
}


