package sapo.predicciones;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;

import sapo.proyecto.PerfilUsuario;
import sapo.raster.Grilla;
import sapo.red.CanalFrecuencias;

/**
 * Esta clase representa una predicción realizada para varias antenas. Éstas
 * deben haber sido hechas en las mismas condiciones (de fundamental importancia
 * que tengan la misma precisión), pues se harán comparaciones de nivel de
 * potencia y es a partir de esta clase que se harán los estudios de cobertura,
 * interferencia, etc.
 * 
 * @author Grupo de proyecto SAPO
 *  
 */
public class PrediccionMultiAntena {
	
	/**
	 *
	 *  ArrayList donde se guardaran las PrediccionUniAntena's correspondientes a esta instancia de 
	 *  PrediccionMultiAntena. 
	 * 
	 */
	
	ArrayList prediccionesUniAntena;
	
	/**
	 *
	 *  ArrayList donde irán arrays de arrays (matrices, bah) indicando con un int en que posición de prediccionUniAntena 
	 *  está el máximo valor de potencia de recepción.  
	 * 
	 */
	
	ArrayList grillasAMostrar;
	
	double maxGlobal = -Double.MAX_VALUE;
	double minGlobal = Double.MAX_VALUE;
	

	double maxInter = -Double.MAX_VALUE;

	double minInter = Double.MAX_VALUE;
	
	/**
	 * Las grillas con los resultados a mostrar.

	 */
	
	Grilla[] grillasResultados = null;
	
	/**
	 * Las grillas con las interferencias calculadas.
	
	 */
	
	Grilla[] grillasInterferencia = null;
	
	/**
	 * Las grillas con los datos de cobertura o no (0 = no cobertura; 1 = cobertura)

	 */
	
	Grilla[] grillasCobertura = null;
	
	/**
	 *
	 *  Este valor indica que hay cobertura en el punto
	 * 
	 */
	
	public static final double HAY_COBERTURA = 1.2;
	/**
	 *
	 *  Este valor indica que no hay cobertura en el punto
	 * 
	 */
	
	public static final double NO_HAY_COBERTURA = 0.2;
	
	public PrediccionMultiAntena() {
		prediccionesUniAntena = new ArrayList();
		grillasAMostrar = new ArrayList();
	}
	
	/**
	 * Agrega las PrediccionUniAntena's que haya en predicciones. 

	 */
	public PrediccionMultiAntena(ArrayList predicciones) {
		this();
		try {
			for (int j = 0; j < predicciones.size(); j++) {
				
				this.agregarPrediccion((PrediccionUniAntena) predicciones
						.get(j));
				if (((PrediccionUniAntena) predicciones.get(j)).getMax() > this.maxGlobal)
					maxGlobal = ((PrediccionUniAntena) predicciones.get(j))
					.getMax();
				if (((PrediccionUniAntena) predicciones.get(j)).getMin() < this.minGlobal)
					minGlobal = ((PrediccionUniAntena) predicciones.get(j))
					.getMin();
				
			}
		} catch (ClassCastException e) {
		} //si no es una PrediccionUniAntena no lo agrego. 
		catch (NullPointerException e) {
		} //si es null no la agrego
	}
	
	/**
	 *
	 *  Devuelve el máximo de entre todas las predicciones. 

	 * 
	 */
	
	public double getMax() {
		return this.maxGlobal;
	}
	
	/**
	 *
	 *  Devuelve el mínimo de entre todas las predicciones. 

	 * 
	 */
	
	public double getMin() {
		return this.minGlobal;
	}
	
	/**
	 * Devuelve el máximo valor de interferencia. 

	 */
	
	public double getMaxInter() {
		if (this.maxInter == -Double.MAX_VALUE) {
			return 1;
		}
		return this.maxInter;
	}
	
	/**
	 * Devuelve el mínimo de interferncia. 

	 */
	
	public double getMinInter() {
		if (this.minInter == Double.MAX_VALUE) {
			return 0;
		}
		return this.minInter;
	}
	
	/**
	 * Agrega prediccion a las predicciones. También se fija en las zonas donde la nueva predicción se interseccione 
	 * con otras ya presentes qué valor poner en grillasAMostrar. 

	 */
	public void agregarPrediccion(PrediccionUniAntena prediccion) {
		if (prediccion != null) {
			this.prediccionesUniAntena.add(prediccion);
			
			if (prediccion.getMax() > this.maxGlobal)
				maxGlobal = prediccion.getMax();
			if (prediccion.getMin() < this.minGlobal)
				minGlobal = prediccion.getMin();
			
			PrediccionUniAntena pAux;
			Rectangle2D rect;
			Rectangle2D rectAux;
			Rectangle2D rectInter = new Rectangle2D.Double();
			double[] valorMax = new double[1]; //el valor más grande (para cuando hay intersección)
			Point2D.Double puntoActual;
			double[] valorActual = new double[1]; //el valor que tiene la predicción agregada donde haya intersección
			
			double precision = prediccion.getGrilla().altoReal
			/ prediccion.getGrilla().alto;
			int[][] matriz = new int[prediccion.getGrilla().alto][prediccion
																  .getGrilla().ancho];
			for (int j = 0; j < matriz.length; j++) {
				Arrays.fill(matriz[j], this.prediccionesUniAntena.size() - 1);
			}
			//supongo que en los lugares de la nueva predicción, va a ser esa la predicción dominante. 
			
			//Ahora me fijo qué pasa en las intersecciones con las otras predicciones. 
			for (int j = 0; j < this.prediccionesUniAntena.size() - 1; j++) {
				pAux = (PrediccionUniAntena) this.prediccionesUniAntena.get(j);
				rect = prediccion.getGrilla().getGridCoverage().getEnvelope()
				.toRectangle2D();
				rectAux = pAux.getGrilla().getGridCoverage().getEnvelope()
				.toRectangle2D();
				if (rect.intersects(rectAux.getX(), rectAux.getY(), rectAux
						.getWidth(), rectAux.getHeight())) {
					Rectangle2D.intersect(rect, rectAux, rectInter);
					for (int k = 0; k < rectInter.getWidth() / precision; k++) {
						for (int l = 0; l < rectInter.getHeight() / precision; l++) {
							puntoActual = new Point2D.Double(rectInter
									.getMinX()
									+ precision
									/ 2
									+ k
									* precision, rectInter.getMaxY()
									- precision
									/ 2
									- l
									* precision);
							int[] donde = pAux.getGrilla().puntoMatriz(
									puntoActual); //donde estoy parado en coordenadas de matriz dentro de la grilla
							int cualMax = ((int[][]) this.grillasAMostrar
									.get(j))[donde[0]][donde[1]]; //que predicción tiene el máximo
							valorMax = ((PrediccionUniAntena) this.prediccionesUniAntena
									.get(cualMax)).getGrilla().getGridCoverage()
									.evaluate(puntoActual, valorMax);
							valorActual = prediccion.getGrilla()
							.getGridCoverage().evaluate(
									puntoActual,
									valorActual);
							if (valorMax[0] < valorActual[0]
														  || new Double(valorMax[0]).isNaN()) { //si el máximo es el nuevo o el máximo es NaN, entonces se lo asigno a quien acaba de darme el otro máximo
								((int[][]) this.grillasAMostrar.get(j))[donde[0]][donde[1]] = this.prediccionesUniAntena
								.size() - 1;
							} else { //si el máximo es el ya establecido, entonces lo asigno a la matriz del actual. 
								donde = prediccion.getGrilla().puntoMatriz(
										puntoActual);
								matriz[donde[0]][donde[1]] = cualMax;
							}
						}
					}
				}
			}
			this.grillasAMostrar.add(matriz);
		}
		//else throw new ModeloMalDefinidoException ("La prediccion correspondiente a la antena prediccion "+prediccion.getNombreAntena()+ " dio nula." );
		//else JOptionPane.showMessageDialog(new JDialog(), "Alguna de las predicciones es nula.","Error", JOptionPane.WARNING_MESSAGE);
	}
	
	public ArrayList getPredicciones() {
		return this.prediccionesUniAntena;
	}
	
	/**
	 *
	 *  A partir de las matrices indicando quienes tienen el máximo se construyen Grillas conteniendo los valores de 
	 *  dichos máximos o NaN donde no corresponda mostrar. Si es la primera vez que se ejecuta en esta instancia, se 
	 *  crea y se asinga a esta instancia de PrediccionMultiAntena, sino se devuelve el ya creado. 

	 * 
	 */
	
	public Grilla[] getCoveragesAMostrar() {
		
		//Grilla[] grillasAMostrar = new Grilla[this.prediccionesUniAntena.size()];
		if (this.grillasResultados == null) {
			Grilla[] grillasAMostrar = new Grilla[this.grillasAMostrar.size()];
			try {
				int[][] quienes;
				for (int j = 0; j < grillasAMostrar.length; j++) {
					quienes = (int[][]) this.grillasAMostrar.get(j);
					grillasAMostrar[j] = new Grilla(
							((PrediccionUniAntena) this.prediccionesUniAntena
									.get(j)).getGrilla());
					for (int k = 0; k < grillasAMostrar[j].alto; k++) {
						for (int l = 0; l < grillasAMostrar[j].ancho; l++) {
							if (quienes[k][l] != j) {
								grillasAMostrar[j].setDatosSinCambiarGC(
										new double[] { Double.NaN },
										l,
										k,
										1,
										1);
							}
						}
					}
					grillasAMostrar[j].cambiarCG();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			this.grillasResultados = grillasAMostrar;
			return grillasAMostrar;
		} else {
			return this.grillasResultados;
		}
	}
	
	/**
	 *
	 *  Devuelve un array de Grillas conteniendo en cada una la C/I correspondiente al punto. Utilizando el dato 
	 *  de qué antena tiene el máximo de potencia en cada punto, calcula la interferencia como la suma del resto 
	 *  de las potencias. Luego toma la máxima potencia y la divide entre dicho valor. Las grillas tendrán valor 
	 *  Double.NaN en aquellos puntos donde no sea máximo. Si es la primera vez que se ejecuta en esta instanica, 
	 *  se crea y se asigna a esta instancia de PrediccionMultiAntena, sino se devuelve el ya creado. 

	 * 
	 */
	
	public Grilla[] getCoveragesInterferencia() {
		if (this.grillasInterferencia == null) {
			Grilla[] grillasInterferencia = new Grilla[this.grillasAMostrar
													   .size()];
			double[] valorActual = new double[1];
			double[] valorOtro = new double[1];
			try {
				int[][] quienes;
				for (int j = 0; j < grillasInterferencia.length; j++) {
					quienes = (int[][]) this.grillasAMostrar.get(j);
					grillasInterferencia[j] = new Grilla(
							((PrediccionUniAntena) this.prediccionesUniAntena
									.get(j)).getGrilla());
					CanalFrecuencias canal = ((PrediccionUniAntena) this.prediccionesUniAntena
							.get(j)).getAntena().getCanal();
					for (int k = 0; k < grillasInterferencia[j].alto; k++) {
						for (int l = 0; l < grillasInterferencia[j].ancho; l++) {
							if (quienes[k][l] != j) { //si él no es el máximo, no le corresponde mostrar nada
								grillasInterferencia[j].setDatosSinCambiarGC(
										new double[] { Double.NaN },
										l,
										k,
										1,
										1);
							} else {
								double interferencia = 0;
								Point2D puntoActual = grillasInterferencia[j]
																		   .puntoReal(new int[] { k, l });
								valorActual = ((PrediccionUniAntena) this.prediccionesUniAntena
										.get(j)).getGrilla().getGridCoverage()
										.evaluate(puntoActual, valorActual);
								for (int i = 0; i < this.prediccionesUniAntena.size(); i++) { //busco en el resto alguno que tenga potencia en mi zona de influencia
									if (i != j	&& ((PrediccionUniAntena) this.prediccionesUniAntena.get(i)).getAntena().getCanal().frecuenciaEnComun(canal)) {
										//él mismo no puede aportarse a la interferencia y solo aportan aquellas antenas
										//que tengan frecuencias en común con el actual
										try {
											valorOtro = ((PrediccionUniAntena) this.prediccionesUniAntena.get(i)).getGrilla().getGridCoverage().evaluate(puntoActual, valorOtro);
											if(!Double.isNaN(valorOtro[0])){
												interferencia += Math.pow(10, valorOtro[0]/10); //potenica en mW
											}
										} catch (org.geotools.cv.PointOutsideCoverageException e) {
											//quiere decir que el punto no estaba en el coverage, por lo tanto no 
											//aporta a la interferencia. 
										}
									}
								}
								if (interferencia == 0) {
									grillasInterferencia[j]
														 .setDatosSinCambiarGC(
														 		new double[] { Double.NaN },
																l,
																k,
																1,
																1);//TODO por ahora lo asigno con NaN cuando no hay interferencia
								} else {
									interferencia = 10*Math.log(interferencia)/Math.log(10); //potencia en dBm
									double ci = valorActual[0] - interferencia;
									grillasInterferencia[j]
														 .setDatosSinCambiarGC(
														 		new double[] { ci },
																l,
																k,
																1,
																1);
									if (ci < minInter)
										minInter = ci;
									if (ci > maxInter)
										maxInter = ci;
								}
							}
						}
					}
					grillasInterferencia[j].cambiarCG();
				}
				this.grillasInterferencia = grillasInterferencia;
				return grillasInterferencia;
			} catch (Exception e) {
				e.printStackTrace(System.out);
				return null;
			}
		} else {
			return this.grillasInterferencia;
		}
	}
	
	/**
	 * Calcula primero la potencia en cada punto, luego la interferencia y por último mediante el perfil verifican 
	 * que se cumplan las condiciones de cobertura. En aquellos lugares donde no se cuenten con datos, devuelve 
	 * Double.NaN, 0 si no hay cobertura y 1 si sí la hay. Si es la primera vez que se convoca este método, se 
	 * crea y se asigna a esta instancia de PrediccionMultiAntena, sino se devuelve el ya creado. 

	 */
	public Grilla[] getCoveragesCobertura(PerfilUsuario perfil) {
		if (this.grillasCobertura == null) {
			this.getCoveragesAMostrar();
			this.getCoveragesInterferencia();
			Grilla[] grillasCobertura = new Grilla[this.grillasAMostrar.size()];
			double minCI = perfil.getCI();
			double minPot = perfil.getSensibilidad();
			double[] pot = new double[1];
			double[] inter = new double[1];
			Point2D puntoActual;
			try {
				int[][] quienes;
				for (int j = 0; j < grillasCobertura.length; j++) {
					quienes = (int[][]) this.grillasAMostrar.get(j);
					grillasCobertura[j] = new Grilla(((PrediccionUniAntena) this.prediccionesUniAntena.get(j)).getGrilla());
					for (int k = 0; k < grillasCobertura[j].alto; k++) {
						for (int l = 0; l < grillasCobertura[j].ancho; l++) {
							if (quienes[k][l] != j) {//si no es el máximo no le corresponde mostrar nada
								grillasCobertura[j].setDatosSinCambiarGC(new double[] { Double.NaN }, l, k, 1, 1);
							} else {
								puntoActual = grillasInterferencia[j].puntoReal(new int[] { k, l });
								pot = this.grillasResultados[j].getGridCoverage().evaluate(puntoActual, pot);
								inter = grillasInterferencia[j].getGridCoverage().evaluate(puntoActual, inter);
								if (Double.isNaN(pot[0])) {
									grillasCobertura[j].setDatosSinCambiarGC(new double[]{Double.NaN}, l, k, 1, 1);
								} else {
									if (Double.isNaN(inter[0]))
										inter[0] = minCI + 1.0;//TODO si no hay datos de interferencia, supongo cobertura
									if (pot[0] > minPot && inter[0] > minCI) {
										grillasCobertura[j].setDatosSinCambiarGC(new double[] {PrediccionMultiAntena.HAY_COBERTURA}, l, k, 1, 1);
									} else {
										grillasCobertura[j].setDatosSinCambiarGC(new double[] { PrediccionMultiAntena.NO_HAY_COBERTURA }, l, k, 1, 1);
									}
								}
							}
						}
					}
					grillasCobertura[j].cambiarCG();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			this.grillasCobertura = grillasCobertura;
			return grillasCobertura;
		} else {
			return this.grillasCobertura;
		}
	}
	
}
