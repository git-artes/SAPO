package sapo.predicciones;

import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

import javax.media.jai.Interpolation;

import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.geotools.ct.MathTransform2D;
import org.geotools.ct.MathTransformFactory;
import org.geotools.cv.CannotEvaluateException;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;
import org.geotools.pt.MismatchedDimensionException;
import org.opengis.referencing.operation.TransformException;

import sapo.ifusuario.Mapa;

/**
 * Esta clase contiene una serie de mï¿œtodos ï¿œtiles comunes a todos los
 * modelos.
 * 
 * @author Grupo de proyecto SAPO
 */

public class UtilidadesModelos {

	GridCoverage gc;

	MathTransform2D mt;

	MathTransform2D mtInversa;

	double pasoX;

	double pasoY;

	Interpolation interpol = Interpolation
			.getInstance(Interpolation.INTERP_BILINEAR);

	public UtilidadesModelos(GridCoverage gc) {
		try {
			this.gc = gc;
			mt = gc.getGridGeometry().getGridToCoordinateSystem2D();
			mtInversa = (MathTransform2D) (mt.inverse());
			CoordinatePoint punto00 = mt.transform(new CoordinatePoint(0, 0),
					null);
			CoordinatePoint punto10 = mt.transform(new CoordinatePoint(1, 0),
					null);
			CoordinatePoint punto01 = mt.transform(new CoordinatePoint(0, 1),
					null);
			pasoX = punto10.getCoordinates()[0] - punto00.getCoordinates()[0];
			pasoY = punto01.getCoordinates()[1] - punto00.getCoordinates()[1];
		} catch (org.opengis.referencing.operation.NoninvertibleTransformException e) {
			e.printStackTrace(System.out);
		} catch (MismatchedDimensionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(System.out);
		} catch (TransformException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(System.out);
		}
	}

	/**
	 * Calcula la distancia entre dos puntos para la MathTransform2D dada.
	 * 
	 * @param mt
	 *            La transforamada que lleva las coordenadas matriciales a la
	 *            realidad.
	 * @param coord1
	 *            Punto en coordenadas reales.
	 * @param coord2
	 *            Punto en coordenadas de la GridCoverage (es decir, posiciï¿œn
	 *            en la matriz)
	 * @return La distancia entre coord1 y coord2 proyectado segï¿œn el
	 *         coordinateSystem de gc. Si la transformaciï¿œn no se puede
	 *         realizar devuelve Double.MAX_VALUE.
	 */
	public double calcularDistanciaGrid(MathTransform2D mt,
			Point2D.Double coord1, Point coord2) {
		try {
			Point2D puntoReal = mt.transform(coord2, null);
			// distancia vista desde arriba
			return this.calcularDistanciaGrid(coord1, puntoReal); // distancia
																	// vista
																	// desde
																	// arriba
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return Double.MAX_VALUE;
		}
	}

	/**
	 * Calcula la distancia entre dos puntos.
	 * 
	 */
	public double calcularDistanciaGrid(Point2D coord1, Point2D coord2) {
		return Math.pow(
				Math.pow(coord1.getX() - coord2.getX(), 2)
						+ Math.pow(coord1.getY() - coord2.getY(), 2), 0.5);
	}

	/**
	 * Muy similar a calcularDistanciaGrid, pero en este caso se toma tambiï¿œn
	 * en cuenta las alturas del terreno para el calculo de la distancia. Este
	 * mï¿œtodo es un poco mï¿œs lento que el anterior, pero mï¿œs exacto (pues
	 * ademï¿œs de considerar la altura del terreno y las antenas, puede
	 * interpolar los valores provistos por la gridCoverage). Debe ser usado si
	 * el terreno es lo suficientemente irregular como para que las alturas
	 * tengan alguna influencia apreciable en la distancia.
	 * 
	 * @param mt
	 *            La transformada que lleva de las coordenadas en al matriz a la
	 *            realidad. No tiene porque ser la transformada de la
	 *            gridCoverage.
	 * @param coord1
	 *            Punto en coordenadas reales de la antena.
	 * @param alturaAntena
	 *            Altura de la antena transmisora (no del terreno, sino de la
	 *            torre)
	 * @param coord2
	 *            Punto en coordenadas de la GridCoverage del mï¿œvil (es decir,
	 *            posiciï¿œn en la matriz)
	 * @param alturaMovil
	 *            Altura del mï¿œvil (no del terreno sino la relativa al mismo)
	 * @param usarInterpolacion
	 *            true si se desea interpolar el valor de la altura del terreno
	 *            en el mï¿œvil y en la antena. Debe ser usado cuando los datos
	 *            del grid de alturas sea poco "denso".
	 * @return La distancia entre coord1 y coord2 proyectados segï¿œn el
	 *         coordinateSystem y ademï¿œs tomando en cuenta las alturas de
	 *         terreno y de las antenas. Si la transformaciï¿œn no se puede
	 *         realizar devuelve Double.MAX_VALUE.
	 */
	public double[] calcularDistanciaReal(MathTransform2D mt, Point2D coord1,
			double alturaAntena, Point coord2, double alturaMovil,
			boolean usarInterpolacion) {
		try {
			Point2D puntoRealMovil = mt.transform(coord2, null);
			double distanciaReal, anguloH, anguloV;
			double distanciaPlana = this.calcularDistanciaGrid(coord1,
					puntoRealMovil); // distancia vista desde arriba
			double diferenciaAlturas;
			if (usarInterpolacion) {
				diferenciaAlturas = this
						.interpolarGridCoverage(new CoordinatePoint(coord1))[0]
						+ alturaAntena
						- (this.interpolarGridCoverage(new CoordinatePoint(
								puntoRealMovil))[0] + alturaMovil);
			} else {
				double[] aux = new double[1];
				diferenciaAlturas = this.gc.evaluate(
						new CoordinatePoint(coord1), aux)[0]
						+ alturaAntena
						- (this.gc.evaluate(
								new CoordinatePoint(puntoRealMovil), aux)[0] + alturaMovil);
			}
			distanciaReal = Math.pow(
					Math.pow(distanciaPlana, 2)
							+ Math.pow(diferenciaAlturas, 2), 0.5);
			anguloH = Math.asin((puntoRealMovil.getX() - coord1.getX())
					/ distanciaPlana)
					* 180.0 / Math.PI;
			if (puntoRealMovil.getY() < coord1.getY()) {
				anguloH = 180 - anguloH;
			}
			
			// TODO: Verificar si al ángulo hay que sumarle pi/2.
			anguloV = Math.atan(diferenciaAlturas / distanciaPlana);
			return new double[] { distanciaReal, anguloH, anguloV };
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return new double[] { Double.MAX_VALUE, 0, 0 }; // TODO??
		}
	}

	/**
	 * Muy similar a calcularDistanciaGrid, pero en este caso se toma tambiï¿œn
	 * en cuenta las alturas del terreno para el calculo de la distancia y
	 * ademï¿œs se le pasa el punto en coordenadas reales directamente. Este
	 * mï¿œtodo es un poco mï¿œs lento que el anterior, pero mï¿œs exacto (pues
	 * ademï¿œs de considerar alturas, para esto puede usar interpolaciï¿œn).
	 * Debe ser usado si el terreno es lo suficientemente irregular como para
	 * que las alturas tengan alguna influencia apreciable en la distancia y si
	 * ademï¿œs ya se calculï¿œ el punto en coordenadas reales.
	 * 
	 * @param coordAntena
	 *            Punto en coordenadas reales de la antena.
	 * @param alturaAntena
	 *            Altura de la antena transmisora (no del terreno, si no de la
	 *            torre)
	 * @param coordMovil
	 *            Punto en coordenadas reales del mï¿œvil.
	 * @param alturaMovil
	 *            Altura del mï¿œvil (no del terreno sino la relativa al mismo)
	 * @param usarInterpolacion
	 *            true si se desea interpolar el valor de la altura del terreno
	 *            en el mï¿œvil y en la antena. Debe ser usado cuando los datos
	 *            del grid de alturas sea poco "denso".
	 * @return - La distancia entre coord1 y coord2 proyectados segï¿œn el
	 *         coordinateSystem y ademï¿œs tomando en cuenta las alturas de
	 *         terreno y de las antenas. Si la transformaciï¿œn no se puede
	 *         realizar devuelve Double.MAX_VALUE.
	 */
	public double[] calcularDistanciaReal(Point2D coordAntena,
			double alturaAntena, Point2D coordMovil, double alturaMovil,
			boolean usarInterpolacion) {
		try {
			double distanciaPlana = this.calcularDistanciaGrid(coordAntena,
					coordMovil); // distancia vista desde arriba
			double diferenciaAlturas;
			double distanciaReal, anguloH, valorV;
			if (usarInterpolacion) {// TODO estaba al reves coord1 <-> coord2
				diferenciaAlturas = this
						.interpolarGridCoverage(new CoordinatePoint(coordAntena))[0]
						+ alturaAntena
						- (this.interpolarGridCoverage(new CoordinatePoint(
								coordMovil))[0] + alturaMovil);
			} else {
				double[] aux = new double[1];
				diferenciaAlturas = this.gc.evaluate(new CoordinatePoint(
						coordAntena), aux)[0]
						+ alturaAntena
						- (this.gc.evaluate(new CoordinatePoint(coordMovil),
								aux)[0] + alturaMovil);
			}
			distanciaReal = Math.pow(
					Math.pow(distanciaPlana, 2)
							+ Math.pow(diferenciaAlturas, 2), 0.5);
			anguloH = Math.asin((coordMovil.getX() - coordAntena.getX())
					/ distanciaPlana)
					* 180 / Math.PI;
			if (coordMovil.getY() < coordAntena.getY()) {
				anguloH = 180 - anguloH;
			}
			valorV = diferenciaAlturas / distanciaPlana;
			return new double[] { distanciaReal, anguloH, valorV };
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return new double[] { Double.MAX_VALUE, 0, 0 }; // TODO??
		}
	}

	/**
	 * Devuelve la altura total tomando en cuenta el terreno.
	 */
	public double getAlturaTotal(Point2D coord, double alturaRelativa,
			boolean usarInterpolacion) {
		if (usarInterpolacion) {
			return interpolarGridCoverage(new CoordinatePoint(coord))[0]
					+ alturaRelativa;
		} else {
			return gc.evaluate(new CoordinatePoint(coord), new double[1])[0]
					+ alturaRelativa;
		}
	}

	/**
	 * Dado un radio, devuelve el rectï¿œngulo con el mayor perï¿œmetro que
	 * cumpla que en todos sus puntos estï¿œn los datos necesarios para hacer la
	 * predicciï¿œn con modelo y ademï¿œs sus lados sean menores e iguales a
	 * radio. Ademï¿œs, y para poder luego comparar valores de predicciï¿œn,
	 * fuerza a que las aristas se encuentren en algï¿œn mï¿œltiplo de
	 * precisiï¿œn.
	 * 
	 */
	static Envelope calcularEnvelope(Modelo modelo, Mapa mapa, double radio,
			Point2D.Double antena, double precision) {
		Envelope rectangulo = modelo.areaCalculable(mapa, antena);
		Envelope nuevoRectangulo = new Envelope(new CoordinatePoint(
				Math.ceil((antena.x - radio) / precision) * precision,
				Math.ceil((antena.y - radio) / precision) * precision),
				new CoordinatePoint(Math.floor((antena.x + radio) / precision)
						* precision, Math.floor((antena.y + radio) / precision)
						* precision));
		nuevoRectangulo.intersect(rectangulo);
		return nuevoRectangulo;
	}

	/**
	 * Dado un envelope (rectï¿œngulo en coordenadas reales) y el tamaï¿œo de la
	 * matriz que lo representarï¿œ, devuelve la transformada que hace
	 * corresponder cada punto de la matriz en una coordenada real. Siguiendo la
	 * convenciï¿œn utilizada en geotools, el valor de la matriz representarï¿œ
	 * el valor en el centro del rectï¿œngulo asociado.
	 * 
	 * @param envoltorio
	 *            El rectï¿œngulo en coordenadas reales.
	 * @param alto
	 *            La cantidad de filas de la matriz.
	 * @param ancho
	 *            La cantidad de filas de la matriz.
	 * @return La transformada que lleva de coordenadas en la matriz a
	 *         coordenadas reales.
	 */
	static MathTransform2D transformadaParaGrid(Envelope envoltorio, int alto,
			int ancho) {
		MathTransformFactory mtf = MathTransformFactory.getDefault();
		double precisionX = envoltorio.toRectangle2D().getWidth() / ancho;
		double precisionY = envoltorio.toRectangle2D().getHeight() / alto;
		AffineTransform at = new AffineTransform(precisionX, 0.0, 0.0,
				-precisionY, envoltorio.toRectangle2D().getMinX() + precisionX
						/ 2, envoltorio.toRectangle2D().getMaxY() - precisionY
						/ 2);
		MathTransform2D mt = mtf.createAffineTransform(at);
		return mt;
	}

	/**
	 * Dado el gridcoverage con las alturas del terreno, la posiciï¿œn de la
	 * antena y el mï¿œvil y la altura (relativa al terreno alrededor) de ambos,
	 * calcula la altura efectiva de la antena y el mï¿œvil.
	 * 
	 * @param antena
	 * @param alturaAntena
	 * @param movil
	 * @param alturaMovil
	 * @param cuantos
	 *            cuantos puntos se quiere considerar en el camino entre el
	 *            mï¿œvil y la antena.
	 * @param usarInterpolacion
	 *            true si se debe interpolar los valores del grid de alturas al
	 *            estimar la altura efectiva. Debe ser utilizado cuando los
	 *            datos sean muy poco "densos".
	 * @return un array con dos elementos: la altura efectiva de la antena y la
	 *         del mï¿œvil en ese orden.
	 */
	public double[] alturaEfectiva(Point2D antena, double alturaAntena,
			Point2D movil, double alturaMovil, int pasoMetros,
			boolean usarInterpolacion, boolean rangoPromedio) {
		// ANTES: double distMetros = this.calcularDistanciaGrid(antena, movil); // El método devuelve distancia en metros.
		double[] distReal = this.calcularDistanciaReal(antena, alturaAntena, movil, alturaMovil, usarInterpolacion);
		double distMetros = distReal[0];
		//
		
		int cuantos = (int) Math.floor(distMetros / pasoMetros);
		double[] distancias = new double[cuantos + 1];
		double[] alturas = new double[cuantos + 1];
		double pasoX = (movil.getX() - antena.getX()) / cuantos;
		double pasoY = (movil.getY() - antena.getY()) / cuantos;
		double[] aux = new double[1];
		for (int j = 0; j <= cuantos; j++) {
			if (usarInterpolacion) {
				aux = this.interpolarGridCoverage(new CoordinatePoint(antena
						.getX() + j * pasoX, antena.getY() + j * pasoY));
			} else {
				gc.evaluate(new CoordinatePoint(
						antena.getX() + j * pasoX, antena.getY() + j * pasoY),
						aux);
			}
			// distancias
			distancias[j] =  (j * distMetros / cuantos)/1000; // Lo paso a km.
			// alturas
			alturas[j] = aux[0];
		} // en j = 0 tengo la antena y me muevo radialmente hasta el móvil.

		double promedioAlturas = 0.0;
		int cont = 0;
		for (int k = 0; k <= cuantos; k++) {
			if (rangoPromedio) {
				if (distancias[k] > 0.2 * distMetros/1000) {
					promedioAlturas = promedioAlturas + alturas[k];
					cont++;
				}
			} else if (!rangoPromedio) {
				if (distancias[k] > 3.0) {
					promedioAlturas = promedioAlturas + alturas[k];
					cont++;
				}
			}
		}
		promedioAlturas = promedioAlturas / cont;
		double alturaEfectivaAntena = alturas[0] + alturaAntena
				- promedioAlturas;
		double alturaEfectivaMovil = alturas[cuantos] + alturaMovil
				- promedioAlturas;
		double[] devolver = new double[] { alturaEfectivaAntena,
				alturaEfectivaMovil };
		return devolver;
	}
	
	public double[] angDespTerreno(Point2D antena, double alturaAntena,
			Point2D movil, double alturaMovil, int pasoMetros,
			boolean usarInterpolacion) {
		double distMetros = this.calcularDistanciaGrid(antena, movil); // Devuelve distancia en metros.
		//  Se calcula hasta una distancia de 16 km.
		if (distMetros > 16000.0){
			distMetros = 16000.0;
		}
		
		int cuantos = (int) Math.floor(distMetros / pasoMetros);
		if(cuantos == 0){ // GM: la distancia entre torre y movil es muy chica
			cuantos = 1;
		}
		double[] distancias = new double[cuantos + 1];
		double[] alturas = new double[cuantos + 1];
		double pasoX = (movil.getX() - antena.getX()) / cuantos;
		double pasoY = (movil.getY() - antena.getY()) / cuantos;
		double[] aux = new double[1];
		for (int j = 0; j <= cuantos; j++) {
			if (usarInterpolacion) {
				aux = this.interpolarGridCoverage(new CoordinatePoint(antena
						.getX() + j * pasoX, antena.getY() + j * pasoY));
			} else {
				gc.evaluate(new CoordinatePoint(
						antena.getX() + j * pasoX, antena.getY() + j * pasoY),
						aux);
			}// en j = 0 tengo la antena y me muevo radialmente hasta el móvil.
			// distancias
			distancias[j] =  j * distMetros / cuantos; // en METROS.
			// alturas
			alturas[j] = aux[0];
		}
		
		double relacion;
		double[] maxRelacion = new double[]{0,0}; // [valor, posicion]
		maxRelacion[0] = -Double.MAX_VALUE;
		for (int k = 1; k < cuantos; k++) { // no considero el origen (antena) ni el destino (movil)
			relacion = (alturas[k] - (alturaMovil + alturas[cuantos]))/(distMetros - distancias[k]);
			if (relacion > maxRelacion[0]) {
				maxRelacion[0] = relacion;
				maxRelacion[1] = k;
			}
		}
//		int indMax = (int)Math.floor(maxRelacion[1]);
//		double distMax = distMetros - distancias[indMax];
//		double alturaEff = maxAltura[0] - alturaMovil; // no es alturaMovil, falta considerar la altura del terreno en el movil
//		double thetaTca = Math.atan(alturaEff/distMax)*180.0/Math.PI; //en grados, para PASO 12.
//		double alturaEff = maxAltura[0] - (alturaMovil + alturas[cuantos]); // considero la altura del terreno en el movil.
		double thetaTca = Math.atan(maxRelacion[0])*180.0/Math.PI; //en grados, para PASO 12.
		
		if (thetaTca > 40.0){
			thetaTca = 40.0;
//			System.out.println("limite en 40");
		}
		if (thetaTca < 0.55){
			thetaTca = 0.55;
//			System.out.println("limite en 0.55");
		}

		// PARA PASO 13
		double relacionEff;
		double[] maxRelacionEff = new double[]{0,0}; // [valor, posicion]
		maxRelacionEff[0] = Double.MAX_VALUE;;
		for (int k = 1; k < cuantos; k++) {
			relacionEff = (alturaAntena + alturas[0] - alturas[k])/distancias[k];
			if (relacionEff < maxRelacionEff[0]) {
				maxRelacionEff[0] = relacionEff;
				maxRelacionEff[1] = k;
			}
		}
		
		double thetaEff = Math.atan(maxRelacionEff[0])*180.0/Math.PI;
		if (thetaEff < 0){
//			System.out.println("thetaEff dio negativo :(");
		}
		
		double[] angulos = new double[] { thetaTca, thetaEff }; 
		
		return angulos;  // devolvemos 2 angulos.
	}
	
	
	
	
	
	

	/**
	 * Dado una coordenada de la gridCoverage, este mï¿œtodo devuelve un valor
	 * interpolado entre los que devuelve el evaluate del gridCoverage. En
	 * geotools 2.1 ya existe una extensiï¿œn de gridCoverage que tiene este
	 * mï¿œtodo incorporado.
	 * 
	 * @param punto
	 *            coordenada donde se quiere encontrar un valor interpolado.
	 * @return
	 */
	public double[] interpolarGridCoverage(CoordinatePoint punto) {

		double[] devolver = new double[1];
		CoordinatePoint puntoMatriz;
		try {
			puntoMatriz = mtInversa.transform(punto, null);
			double x0 = punto.getCoordinates()[0];
			double y0 = punto.getCoordinates()[1];
			float deltax = (float) (puntoMatriz.getCoordinates()[0] % 1);
			float deltay = (float) (puntoMatriz.getCoordinates()[1] % 1);
			double[] s00 = new double[1];
			double[] s01 = new double[1];
			double[] s10 = new double[1];
			double[] s11 = new double[1];

			try {
				gc.evaluate(
						new CoordinatePoint(x0 - pasoX / 2, y0 - pasoY / 2),
						s00);
				gc.evaluate(
						new CoordinatePoint(x0 + pasoX / 2, y0 - pasoY / 2),
						s01);
				gc.evaluate(
						new CoordinatePoint(x0 - pasoX / 2, y0 + pasoY / 2),
						s10);
				gc.evaluate(
						new CoordinatePoint(x0 + pasoX / 2, y0 + pasoY / 2),
						s11);
				devolver[0] = interpol.interpolate(s00[0], s01[0], s10[0],
						s11[0], deltax, deltay);
			} catch (CannotEvaluateException e) {
				gc.evaluate(punto, devolver);
			}
		} catch (MismatchedDimensionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (TransformException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return devolver;
	}
}
