
package sapo.predicciones;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;


import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase representa el modelo por pérdidas debidas a una superficie conductora plana entre el transmisor y 
 * el receptor. 
 * @author Grupo de proyecto SAPO 
 *
 */
public class TierraPlana extends Modelo{
	
	/**
	 * Construye el modelo por defecto de la tierra plana. El único parámetro ajustable es el exponente de la distancia, 
	 * (n) igual a dos, y el resto de los parámetros no ajustables serán los que no aparecen en la versión simple 
	 * de este modelo. 
	 *
	 */
	public TierraPlana(){
		super();
	}
	
	/**
	 * Crea el modelo de tierra plana con el parámetro de propagación que convenga. 
	 * 
	 * @param parametrosAjustables - Un array de largo 1 que contendrá el valor de n. 
	 * @param parametrosNoAjustables -  Un array de java.lang.Double de tamaño 3 con el factor que aparece multiplicando, 
	 * luego el que divide la longitud de onda y por último lo que multiplica dentro del seno. 
	 * @throws ModeloMalDefinidoException - Además de los casos por defecto, cuando n es negativo y cuando algún 
	 * elemento en parametrosNoAjustables no es un java.lang.Double. 
	 */
	public TierraPlana(double[] parametrosAjustables, Object[] parametrosNoAjustables) throws ModeloMalDefinidoException{
		super(parametrosAjustables, parametrosNoAjustables);
		if(parametrosAjustables[0]<0){
			ModeloMalDefinidoException error = new ModeloMalDefinidoException("n debe ser positivo, pues no tiene sentido que la potencia crezca con la distancia"); 
			throw error;
		}
		int largo = parametrosNoAjustables.length;
		for(int j=0;j<largo;j++){
			if(!parametrosNoAjustables[j].getClass().equals(java.lang.Double.class)){
				ModeloMalDefinidoException error = new ModeloMalDefinidoException("Para el modelo tierra plana, los valores no ajustables deben ser reales. "); 
				throw error;
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#getParametrosAjustablesPorDefecto()
	 */
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		return new double[]{2};
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#getParametrosNoAjustablesPorDefecto()
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		return new Object[]{
				new java.lang.Double(4),
				new java.lang.Double(4*Math.PI),
				new java.lang.Double(2*Math.PI)
		};
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#setNombres()
	 */
	@Override
	protected void setNombres() {
		this.nombreModelo = Modelo.TIERRA_PLANA;
		this.nombreParametrosAjustables = new String[]{"n"};
		this.nombreParametrosNoAjustables = new String[]{"A0", "A1", "A2"};
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#verificarDatos(explorer.proyecto.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia();
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, double, double, double)
	 */
	//public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) {
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena antena, double radioMax, double perdidaMax, double precision) throws PrediccionMalRealizadaException{
		try{			
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Tierra plana");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			double hTrelativa = rb.getAltura();
			double hRrelativa = proyecto.getPerfilUsuario().getAltura(); 
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa, radioMax, new Point2D.Double(sitio.getX(),sitio.getY()), precision);
			
			if(envoltura==null) 
				throw new PrediccionMalRealizadaException("La envoltura donde puede calcularse el modelo Tierra plana es nula, verifique los datos");
			
			int ancho = Math.round(Math.round(envoltura.toRectangle2D().getWidth()/precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D().getHeight()/precision));
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(envoltura, alto, ancho); 
			//MathTransform2D mt = gc.getGridGeometry().getGridToCoordinateSystem2D();			
						
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia();			
			double lambda = Modelo.C/frecuencia;
			double A0 = ((java.lang.Double)this.parametrosNoAjustables[0]).doubleValue();
			double A1 = ((java.lang.Double)this.parametrosNoAjustables[1]).doubleValue();
			double A2 = ((java.lang.Double)this.parametrosNoAjustables[2]).doubleValue();
			double n = this.parametrosAjustables[0];
			double[] alturasEfectivas;
						
			UtilidadesModelos um = new UtilidadesModelos(gc);
			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			double[] datos = new double[ancho*alto];
			int total = alto*ancho;
			int contador = 0;
			double minimo = java.lang.Double.MAX_VALUE;
			double maximo = java.lang.Double.MIN_VALUE;
						
			Point2D.Double puntoAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D puntoMovil;	
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radioMax, puntoAntena, "altura");
				hTrelativa += ume.getAlturaEdificioAntena(); 
			}
			
			for(int j=0;j<alto;j++){
				for(int i=0;i<ancho;i++){ 
					//for(int j=0;j<alto;j++){
					puntoMovil = (mt.transform(new Point(i,j),null)); 
					if(um.calcularDistanciaGrid(puntoAntena, puntoMovil) < radioMax){
						double[] distanciaYangulos = um.calcularDistanciaReal(puntoAntena, hTrelativa, puntoMovil, hRrelativa, this.usarInterpolacion);
						double distancia = distanciaYangulos[0];
//						double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
						// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
						double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
						// GM: Agrego true porque cambió método alturaEfectiva
						alturasEfectivas = um.alturaEfectiva(puntoAntena, hTrelativa, puntoMovil, hRrelativa, 100, this.usarInterpolacion, true);
						datos[contador] = potencia + gananciaE + 10.0*Math.log(A0*Math.pow(lambda/(A1*distancia),n)*Math.pow(Math.sin(A2*alturasEfectivas[0]*alturasEfectivas[1]/(lambda*distancia)),2))/Math.log(10.0);
					}else{
						datos[contador] = Double.NaN;
					}
					if(datos[contador] < minimo) minimo = datos[contador];
					if(datos[contador] > maximo) maximo = datos[contador];
					contador++;
					cuantoVa = (int)((double)contador/((double)(ancho*alto))*100.0);
				}			
			}
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho, envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp;
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto, explorer.proyecto.Mapa, explorer.red.Antena, com.vividsolutions.jts.geom.Coordinate)
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena, Coordinate[] puntos) throws PrediccionMalRealizadaException{
		
		try{
			if(!this.verificarDatos(mapa)){
				throw new PrediccionMalRealizadaException("Faltan datos para realizar la predicción con el modelo de Tierra plana");
			}
			
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio)sitioYRb[0];
			Radiobase rb = (Radiobase)sitioYRb[1];
			double hT = rb.getAltura();
			double hR = proyecto.getPerfilUsuario().getAltura();
			
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage)f.getAttribute("grid");
						
			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia();
			double lambda = Modelo.C/frecuencia;
			double A0 = ((java.lang.Double)this.parametrosNoAjustables[0]).doubleValue();
			double A1 = ((java.lang.Double)this.parametrosNoAjustables[1]).doubleValue();
			double A2 = ((java.lang.Double)this.parametrosNoAjustables[2]).doubleValue();
			double n = this.parametrosAjustables[0];
			double[] alturasEfectivas; 
			
			UtilidadesModelos um = new UtilidadesModelos(gc);
			double[] predicciones = new double[puntos.length];
			int contador = 0; 
			
			Point2D.Double puntoAntena = new Point2D.Double(sitio.getX(), sitio.getY());
			Point2D puntoMovil;	
			double radio = 0; 
			for(int j=0; j<puntos.length; j++){
				double dist = Math.sqrt(Math.pow(sitio.getX()-puntos[j].x,2)+Math.pow(sitio.getY()-puntos[j].y, 2)); 
				if(dist > radio)
					radio = dist; 
			}
			if(!mapa.getCapaEdificios().esVacia()){
				UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc, mapa.getCapaEdificios().getFeatureCollection(), radio, puntoAntena, "altura");
				hT += ume.getAlturaEdificioAntena(); 
			}
			
			for(int j=0; j<predicciones.length; j++){
				puntoMovil = new Point2D.Double(puntos[j].x, puntos[j].y);
				double[] distanciaYangulos = um.calcularDistanciaReal(puntoAntena, hT, puntoMovil, hR, this.usarInterpolacion);
				double distancia = distanciaYangulos[0];
				// GM: OJO! CAMBIÓ getGanancia! Ahora es getGanancia(anguloH, anguloV); Antes: getGanancia(anguloH, valorV). 
				double gananciaE = antena.getGanancia(distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI); 
//				double gananciaE = antena.getGanancia(distanciaYangulos[1], distanciaYangulos[2]);
				// GM: Agrego true porque cambió método alturaEfectiva
				alturasEfectivas = um.alturaEfectiva(puntoAntena, hT, puntoMovil, hR, 100, this.usarInterpolacion, true);
				predicciones[j] = potencia + gananciaE + 10.0*Math.log(A0*Math.pow(lambda/(A1*distancia),n)*Math.pow(Math.sin(A2*alturasEfectivas[0]*alturasEfectivas[1]/(lambda*distancia)),2))/Math.log(10.0);
				contador++;
				cuantoVa = (int)((double)contador/((double)(predicciones.length))*100.0);
			}
			return predicciones;
			
		}catch(Exception z){
			throw new PrediccionMalRealizadaException("Hubo un error al realizar la predicción de "+this.getNombre()+": \n"+z.getMessage());
		}
		
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#areaCalculable(explorer.proyecto.Mapa, java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try{
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			
			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(gf.createLinearRing(new Coordinate[]{new Coordinate(0,0), new Coordinate(1,0), new Coordinate(1,1), new Coordinate(0,1), new Coordinate(0,0)}), null);
			while(fi.hasNext() && esta==false){
				rectanguloAlturas = ((Polygon)fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf.createPoint(new Coordinate(punto.x, punto.y))); //me fijo si el punto está en alguno de los gridcoverages
			}
			if(!esta) return null; //si no está, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing().getCoordinates();
			double maxX = -Double.MAX_VALUE;
			double maxY = -Double.MAX_VALUE;
			double minY = Double.MAX_VALUE;
			double minX = Double.MAX_VALUE;
			for(int j=0;j<coordenadas.length;j++){
				if(coordenadas[j].x < minX) 
					minX = coordenadas[j].x;
				if(coordenadas[j].x > maxX)
					maxX = coordenadas[j].x;
				if(coordenadas[j].y < minY)
					minY = coordenadas[j].y;
				if(coordenadas[j].y > maxY)
					maxY = coordenadas[j].y;
			}
			Envelope envoltura = new Envelope(new CoordinatePoint(minX,minY), new CoordinatePoint(maxX,maxY));
			return envoltura;			
		}catch(Exception e){
			e.printStackTrace(System.out);
			return null;
		}
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#crearPanelCreacion()
	 */
	@Override
	protected void crearPanelCreacion() {
		menu = new MenuTierraPlana(this.parametrosAjustables, this.parametrosNoAjustables);
	}
	
	/* (non-Javadoc)
	 * @see explorer.modelos.Modelo#getPanelCreacion()
	 */
	@Override
	public PanelModelos getPanelCreacion() {
		return menu;
	}
	
	
	@Override
	public String getXML() {
		
		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>" + nombreImplementacion + "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");
		
		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>" + nombreParametrosAjustables[i] + "</Nombre>\r\n");
			if (parametrosAjustables.length != 0) {
				result1.append("        <Valor>" + parametrosAjustables[i] + "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosNoAjustables>");
			result1.append("        <Nombre>" + nombreParametrosNoAjustables[i] + "</Nombre>\r\n");
			if (parametrosNoAjustables.length != 0) {
				result1.append("        <Valor>" + parametrosNoAjustables[i] + "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosNoAjustables>\r\n");
			result.append(result1.toString());
		}
		
		
		result.append("      </Modelo>\r\n");
		return result.toString();
		
	}
	
	/**
	 * Ventana de creación de instancias del modelo tierra plana
	 * @author Grupo de Proyecto SAPO.
	 *
	 */
	protected class MenuTierraPlana extends PanelModelos implements ActionListener{
		
		JTextField n;
		JTextField A0;
		JTextField A1;
		JTextField A2;
		JButton botonPorDefecto;
		
		
		MenuTierraPlana(double[] parametrosAjustables, Object[] parametrosNoAjustables){
			super(parametrosAjustables, parametrosNoAjustables);
		}
		
		/**
		 * Esta implementación en particular es un panel, con dos panels dentro. Uno para los parámetros ajustables, 
		 * y otro para los no ajustables (este será el layout que deberían seguir los demás modelos para una 
		 * coherencia del programa). 
		 */
		@Override
		public void agregarElementos(){
			this.setLayout(new GridBagLayout());
			TitledBorder bordeAjustable, bordeNoAjustable;
			JPanel ajustables = new JPanel();
			ajustables.setLayout(new GridBagLayout());
			JPanel noAjustables = new JPanel();
			noAjustables.setLayout(new GridBagLayout());
			
			GridBagConstraints c = new GridBagConstraints();
			c.insets = new Insets(2,2,2,2);
			GridBagConstraints cGrande = new GridBagConstraints();
			/*
			 * Creo el panel para los ajustables con un borde con título y luego lo agrego al panel. 
			 */
			c.gridx = 0;
			c.gridy = 0;
			c.fill = GridBagConstraints.REMAINDER;
			ajustables.add(new JLabel("Parámetro n: "), c);
			
			c.gridx = 1;
			c.gridy = 0;
			c.fill = GridBagConstraints.HORIZONTAL;
			c.weightx = 1; 
			n = new JTextField("");
			ajustables.add(n, c);
			
			bordeAjustable = BorderFactory.createTitledBorder("Parámetros Ajustables");
			ajustables.setBorder(bordeAjustable);
			cGrande.gridx = 0;
			cGrande.gridy = 0;
			cGrande.gridwidth = 2;
			cGrande.gridheight = 2;
			cGrande.fill = GridBagConstraints.BOTH;
			cGrande.weightx = 1;
			cGrande.insets = new Insets(4,4,4,4);
			this.add(ajustables, cGrande);
			
			/*
			 * Creo el panel para los parámetros no ajustables y lo agrego al panel. 
			 */
			c.fill = GridBagConstraints.NONE;
			c.gridx = 0;
			c.gridy = 0;
			c.weightx = 0;
			noAjustables.add(new JLabel("Parámetro A0: "), c);
			
			c.fill = GridBagConstraints.HORIZONTAL;
			c.gridx = 1;
			c.gridy = 0;
			c.weightx = 1;
			A0 = new JTextField("");
			noAjustables.add(A0, c);
			
			c.fill = GridBagConstraints.NONE;
			c.gridx = 0;
			c.gridy = 1;
			c.weightx = 0;
			noAjustables.add(new JLabel("Parámetro A1: "), c);
			
			c.fill = GridBagConstraints.HORIZONTAL;
			c.gridx = 1;
			c.gridy = 1;
			c.weightx = 1;
			A1 = new JTextField("");
			noAjustables.add(A1, c);
			
			c.fill = GridBagConstraints.NONE;
			c.gridx = 0;
			c.gridy = 2;
			c.weightx = 0;
			noAjustables.add(new JLabel("Parámetro A2: "), c);
			
			c.fill = GridBagConstraints.HORIZONTAL;
			c.gridx = 1;
			c.gridy = 2;
			c.weightx = 1;
			A2 = new JTextField("");
			noAjustables.add(A2, c);
			
			bordeNoAjustable = BorderFactory.createTitledBorder("Parámetros no Ajustables");
			noAjustables.setBorder(bordeNoAjustable);
			
			cGrande.gridy = 2;
			this.add(noAjustables, cGrande);
			
			botonPorDefecto = new JButton("Valores por defecto");
			botonPorDefecto.addActionListener(this);
			cGrande.gridx = 1;
			cGrande.gridy = 4;
			cGrande.gridwidth = 1;
			cGrande.gridheight = 1;
			cGrande.anchor = GridBagConstraints.LAST_LINE_END;
			cGrande.fill = GridBagConstraints.NONE;
			c.weightx = 0;
			this.add(botonPorDefecto, cGrande);
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 */
		@Override
		public double[] getParametrosAjustables() throws ModeloMalDefinidoException {
			try{
				double n = Double.parseDouble(this.n.getText());
				double[] parametros = new double[]{
						n, 
				};
				return parametros;
			}catch(Exception e){
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException("Algunos de los campos están mal");
				throw ex;
			}
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 */
		@Override
		public Object[] getParametrosNoAjustables() throws ModeloMalDefinidoException {
			try{
				double A0 = Double.parseDouble(this.A0.getText());
				double A1 = Double.parseDouble(this.A1.getText());
				double A2 = Double.parseDouble(this.A2.getText());
				return new Object[]{
						new Double(A0), 
						new Double(A1), 
						new Double(A2)
				};
			}catch(Exception e){
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException("Algunos de los valores ingresados están mal");
				throw ex;
			}
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables){
			this.n.setText(String.valueOf(parametrosAjustables[0]));
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables){
			this.A0.setText(parametrosNoAjustables[0].toString());
			this.A1.setText(parametrosNoAjustables[1].toString());
			this.A2.setText(parametrosNoAjustables[2].toString());
		}
		
		/**
		 * simplemente resetea los valores a los por defecto. 
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			TierraPlana modelo = new TierraPlana();
			this.setParametrosAjustables(modelo.getParametrosAjustablesPorDefecto());
			this.setParametrosNoAjustables(modelo.getParametrosNoAjustablesPorDefecto());
		}
		
		/* (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 */
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new TierraPlana(this.getParametrosAjustables(), this.getParametrosNoAjustables());
		}
		
		/*
		 *  (non-Javadoc)
		 * @see explorer.ifusuario.menues.PanelModelos#getTamanioVentana()
		 */ 
		public Dimension getTamanioVentana(){
			return new Dimension(265, 275);
		}
	}
	
}
