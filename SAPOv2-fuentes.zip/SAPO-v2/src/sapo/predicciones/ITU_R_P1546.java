package sapo.predicciones;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

import javax.media.jai.Interpolation;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Polygon;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.SitioMalPosicionadoException;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

/**
 * Esta clase representa el modelo Recomendación ITU-R P.1546-4 para trayectos
 * terrestres y climas templados.
 * 
 * @author Grupo de proyecto SAPO
 * 
 */
public class ITU_R_P1546 extends Modelo {

	// Trayectos que considera el modelo.
	private final static String LAND = "Terrestre";
	private final static String SEA = "Marítimo";
	private final static String COLD_SEA = "Marítimo frío";
	private final static String WARM_SEA = "Marítimo cálido";
	
	// Tipo de zona
	private final static String URBANA = "Urbana";
	private final static String URBANA_DENSA = "Urbana Densamente Poblada";
	private final static String SUBURBANA = "Suburbana";

	// Tablas
	private File cuadro1xls = new File("res/cuadro1.xls");
	private File tablasxls = new File("res/Rec_P_1546_Tab_values.xls");

	// Atributos del modelo.
	private double porcentajeTiempo;
	private double porcentajeUbicaciones;
	// h2: Altura de la antena receptora/movil por encima del terreno:
	// "Igual a la altura representativa de la ocupación del suelo en el lugar en que se halla dicha antena".
	private double h2;
	private String tipoTrayecto;
	private String tipoZona;
	
	// Visualización de resultados
	private boolean veoDBuVm;
	
	// Conf. especiales
	private boolean confEsp;

	/**
	 * 
	 * Constructor por defecto.
	 * 
	 */
	public ITU_R_P1546() {
		super();
	}

	public ITU_R_P1546(double[] parametrosAjustables,
			Object[] parametrosNoAjustables) throws ModeloMalDefinidoException { // Ajust: %Tiempo, h2, %Ubicaciones; NoAjust: tipoTrayecto, tipoZona.
		super(parametrosAjustables, parametrosNoAjustables);
		if(parametrosAjustables[0] > 50.0){ //porTiempo, h2, porUbicaciones
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
					"El porcentaje de tiempo no puede ser mayor a 50");
			throw e;
		}else if(parametrosAjustables[0] < 1.0){
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
					"El porcentaje de tiempo no puede ser menor a 1");
			throw e;
		}
		
		if(parametrosAjustables[1] < 1.0 || parametrosAjustables[1] > 99.0){
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
					"El porcentaje de ubicaciones debe estar entre 1 y 99");
			throw e;
		}

		if(!parametrosNoAjustables[0].equals(LAND)){
			ModeloMalDefinidoException e = new ModeloMalDefinidoException(
					"La implementación solo soporta trayectos terrestres.");
			throw e;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#verificarDatos(explorer.proyecto.Mapa)
	 */
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto,
	 * explorer.proyecto.Mapa, explorer.red.Antena, double, double, double)
	 */
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa,
			Antena antena, double radioMax, double perdidaMax, double precision)
			throws PrediccionMalRealizadaException {
		try {
			if (!this.verificarDatos(mapa)) {
				throw new PrediccionMalRealizadaException(
						"Para realizar la predicción con ITU-R P.1546 es necesaria la capa de alturas de terreno.");
			}

			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio) sitioYRb[0];
			Radiobase rb = (Radiobase) sitioYRb[1];

			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage) f.getAttribute("grid");
			Envelope envoltura = UtilidadesModelos.calcularEnvelope(this, mapa,
					radioMax, new Point2D.Double(sitio.getX(), sitio.getY()),
					precision);

			if (envoltura == null)
				throw new PrediccionMalRealizadaException(
						"La envoltura donde puede calcularse el modelo ITU-R P.1546 es nula, verifique los datos.");

			int ancho = Math.round(Math.round(envoltura.toRectangle2D()
					.getWidth() / precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D()
					.getHeight() / precision));
			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(
					envoltura, alto, ancho);

			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia() / 1E6; // Frecuencia en
																// Mhz.
			double ha = rb.getAltura();
			// h1: Altura de la antena transmisora de base.
			double h1;
			// hb: Altura de la antena por encima del nivel del terreno
			// promediado entre 0.2d y d kms.
			double hb;
			// heff: Altura de la antena por encima del nivel del terreno
			// promediado entre 3 y 15 kms.
			double heff;
			double distancia;

			// Uso los parámetros que ingresa el usuario.
			this.porcentajeTiempo = this.parametrosAjustables[0];
			this.h2 = proyecto.getPerfilUsuario().getAltura();
			this.porcentajeUbicaciones = this.parametrosAjustables[1];
			this.tipoTrayecto = (String) this.parametrosNoAjustables[0];
			this.tipoZona = (String) this.parametrosNoAjustables[1];
			this.veoDBuVm = ((Boolean) this.parametrosNoAjustables[2]).booleanValue();
			this.confEsp = ((Boolean) this.parametrosNoAjustables[3]).booleanValue();

			// Altura promedio del terreno entre 0.2d y d km.
			double[] promedioA;
			// Altura promedio del terreno entre 3 y 15 km.
			double[] promedioB;

			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(),
					sitio.getY());
			Point2D sitioMovil;

			UtilidadesModelos um = new UtilidadesModelos(gc);

			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			double[] datos = new double[ancho * alto];
			int contador = 0;
			int contadorEsp = 0;
			double minimo = java.lang.Double.MAX_VALUE;
			double maximo = -java.lang.Double.MAX_VALUE;
			////////////////////////////////////////////////////////////////////////////////
			double[] datosAux = new double[ancho * alto]; ////
			int vuelta = 1;

			while (vuelta <= 2) {				
				if(confEsp){
					if(vuelta == 1){
						porcentajeTiempo = 50.0;
						porcentajeUbicaciones = 50.0;
					}else if(vuelta == 2){
						contador = 0;
						porcentajeTiempo = 10.0;
						porcentajeUbicaciones = 50.0;
					}
				}else{
					vuelta = 3;
				}
				
				// COMIENZA NORMA //
				// Intensidad de campo eléctrico en dBuV/m
				double e;
				// % de tiempo nominal inferior y superior
				int[] tInfSup = paso2(porcentajeTiempo);
				// frecuencia nominal inferior y superior.
				int[] frecInfSup = paso3(frecuencia);
				// Variables para Paso 9:
				boolean pasoNueve = false;
				int hojaFSupTInf = 0;
				Object[][] tablaFSupTInf = new Object[79][10]; // tamaño de tabla de
																// datos.
				// Varibales Paso 10:
				boolean pasoDiez = false;
				int hojaFSupTSup = 0;
				Object[][] tablaFSupTSup = new Object[79][10];
				int hojaFInfTSup = 0;
				Object[][] tablaFInfTSup = new Object[79][10];

				if (frecInfSup[0] != frecInfSup[1]) {
					pasoNueve = true;
					hojaFSupTInf = eligeHoja(frecInfSup[1], tInfSup[0],
							this.tipoTrayecto);
					// obtengo los valores de la tabla a trabajar
					tablaFSupTInf = this.readExcel(this.tablasxls, hojaFSupTInf, 5,
							83, 1, 10); // recorro en filas
				}

				if (tInfSup[0] != tInfSup[1]) {
					pasoDiez = true;
					hojaFSupTSup = eligeHoja(frecInfSup[1], tInfSup[1],
							this.tipoTrayecto);
					tablaFSupTSup = this.readExcel(this.tablasxls, hojaFSupTSup, 5,
							83, 1, 10); // recorro en filas
					hojaFInfTSup = eligeHoja(frecInfSup[0], tInfSup[1],
							this.tipoTrayecto);
					// obtengo los valores de la tabla a trabajar
					tablaFInfTSup = this.readExcel(this.tablasxls, hojaFInfTSup, 5,
							83, 1, 10); // recorro en filas
				}

				// PARA EL PASO 8 //
				int hojaFInfTInf = eligeHoja(frecInfSup[0], tInfSup[0],
						this.tipoTrayecto);
				// obtengo los valores de la tabla a trabajar
				Object[][] tablaFInfTInf = this.readExcel(this.tablasxls,
						hojaFInfTInf, 5, 83, 1, 10); // recorro en filas

				// PARA EL PASO 4. //
				Object[][] cuadro1Obj = this.readExcel(this.cuadro1xls, 0, 0, 77,
						0, 0);
				Double[] cuadro1 = new Double[cuadro1Obj.length];

				for (int k = 0; k < cuadro1Obj.length; k++) {
					cuadro1[k] = (Double) (cuadro1Obj[k][0]);
				}
				
				// PARA PASOS 14 Y 15.
				double R; // en METROS.
				if (tipoZona.equals(URBANA)) {
					R = 20.0;
				} else if (tipoZona.equals(URBANA_DENSA)) {
					R = 30.0;
				} else {
					R = 10.0;
				}
				
				double[] distanciaYangulos;
				
				// Comienzo iteración en el radio establecido.
				for (int j = 0; j < alto; j++) {
					for (int i = 0; i < ancho; i++) {
						sitioMovil = mt.transform(new Point(i, j), null);
						double distLimite = um.calcularDistanciaGrid(sitioAntena,
								sitioMovil);
						if (distLimite < radioMax && distLimite > 10 && distLimite < 1000000) { //Limito a 10 metros para no caer sobre la misma base.
							distanciaYangulos = um.calcularDistanciaReal(
									sitioAntena, ha, sitioMovil, this.h2,
									this.usarInterpolacion);
							// GM: OJO CON EL MÉTODO QUE CAMBIÓ!!!!
							double gananciaE = antena.getGanancia(
									distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI);
							distancia = distanciaYangulos[0]; // distancia es el path radioeléctrico.
							distancia = distancia / 1000; // las curvas utilizan la
															// distancia en km
							if(distancia < 1){
								e = campoMenorUnKm(distancia, gananciaE, frecuencia);
							}else{
								
								if (distancia < 15) {
									promedioA = um.alturaEfectiva(sitioAntena, rb
											.getAltura(), sitioMovil, this.h2, 20,
											this.usarInterpolacion, true);
									hb = promedioA[0];
									h1 = hb;
								} else {
									promedioB = um.alturaEfectiva(sitioAntena, rb
											.getAltura(), sitioMovil, this.h2, 20,
											this.usarInterpolacion, false);
									heff = promedioB[0];
									h1 = heff;
								}
								
								//GM: En este punto se daba el error del método angDespTerreno.
//								if(i==299 && j==299){
//									System.out.println(i);
//									System.out.println(j);
//								}
								
								// ángulos para pasos 12, 13, 14 y paso 8.2.
								double angulos[] = um.angDespTerreno(sitioAntena, rb
										.getAltura(), sitioMovil, this.h2, 30,
										this.usarInterpolacion);
								// para paso 12
								double thetaTca = angulos[0];
								// para paso 13
								double thetaEff = angulos[1];
								
//								if(thetaEff == 90.0){
//									System.out.println("da 90 :(");
//								}

								// Obtengo los valores nominales de distancia.
								int[] distInfSup = paso4(distancia, cuadro1);
								
								// PASO 8
								// antes era eInf.
								e = paso8(h1, distancia, distInfSup, frecInfSup[0],
										tInfSup[0], this.tipoTrayecto, tablaFInfTInf,
										thetaEff);
								
								// PASO 9
								if (pasoNueve) {
									e = paso9(h1, distancia, frecuencia, distInfSup,
											frecInfSup, tInfSup[0], this.tipoTrayecto,
											tablaFSupTInf, e, thetaEff);
								}

								// PASO 10
								if (pasoDiez) {
									e = paso10(this.porcentajeTiempo, h1, distancia,
											frecuencia, distInfSup, frecInfSup,
											tInfSup, this.tipoTrayecto, tablaFInfTSup,
											tablaFSupTSup, e, pasoNueve, thetaEff);
								}

								// PASO 12
								e = paso12(thetaTca, frecuencia, e);

								// PASO 13
								e = paso13(distancia, this.porcentajeTiempo, thetaTca,
										thetaEff, frecuencia, e);
//								if (e < eTs){
//									System.out.println("TROPO!!!!!!!!!!!!!!!!!!1111111111111111111111");
//									e = eTs;
//								}

								// PASO 14
								e = paso14(distancia, h1, h2, frecuencia, R, e);
								
								// PASO 15
								// d is less than 15 km and h1 − R is less than 150 m.
								if(distancia < 15.0 && (h1 - R) < 150.0){
									e = paso15(distancia, frecuencia, ha, R, e);
								}
								
								// PASO 16
								if(this.porcentajeUbicaciones != 50.0){
									e = paso16(this.porcentajeUbicaciones, e);
								}
								
								// PASO 17
								e = paso17(distancia, e);
								
							}
						
							double prx;
							double Lb;
							double prxuvm;
							
							if(confEsp && vuelta == 1){
								datosAux[contador] = 2*e;
							}else if(confEsp && vuelta == 2){
								datosAux[contador] = datosAux[contador] - e;
								Lb = paso18(frecuencia, datosAux[contador]);
								prx = potencia + gananciaE - Lb;
								prxuvm = prx + 20*Math.log10(frecuencia) + 77.213;
								if(this.veoDBuVm){
									datos[contador] = prxuvm;
								}else{
									datos[contador] = prx;
								}
							}else{
								// Paso 18
								Lb = paso18(frecuencia, e);
								// Link budget
								prx = potencia + gananciaE - Lb;
								// Paso a dBuV/m
								prxuvm = prx + 20*Math.log10(frecuencia) + 77.213;

								// GM: PARA LIMITAR!!!!!!!!!!!!!!!!!!!!!!!!!
//								if(prx < -190){
//									System.out.println();//pot = -100;
//								}
								
								// Según se haya elegido, despliego resultados en dBm o dBuV/m 
								if(this.veoDBuVm){
									datos[contador] = prxuvm;
								}else{
									datos[contador] = prx;
								}
							}
						} else {
							
							if(confEsp){
								datosAux[contador] = Double.NaN;
								if(vuelta == 2){
									datos[contador] = Double.NaN;
								}
							}else{
								datos[contador] = Double.NaN;
							}
						}
						
						
//						if(contador == 135659 || contadorEsp == 135659){
//							System.out.println("");
//						}
						
						

						if(confEsp){
							if(vuelta == 2){
								if (datos[contador] < minimo)
									minimo = datos[contador];
								if (datos[contador] > maximo)
									maximo = datos[contador];
							}
							contador++;
							contadorEsp++;
							cuantoVa = (int) ((double) contadorEsp
									/ ((double) (2 * ancho * alto)) * 100.0);
						}else{
							if (datos[contador] < minimo)
								minimo = datos[contador];
							if (datos[contador] > maximo)
								maximo = datos[contador];
							contador++;
							cuantoVa = (int) ((double) contador
									/ ((double) (ancho * alto)) * 100.0);
						}
						
					}
				}	
			vuelta++;
			}
			
			//////////////////////////////////////////////////////////////////////////////
			
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho,
					envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp;
		} catch (Exception z) {
			z.printStackTrace();
			throw new PrediccionMalRealizadaException(
					"Hubo un error al realizar la predicción de "
							+ this.getNombre() + ": \n" + z.getMessage());
		}
	}
	
	
	private double campoMenorUnKm(double d, double g, double f){
		double e = 0;
		double dnf = Math.pow(10, 0.1*g)/(10*f); // km
		if(dnf > 0.1){ // limito dnf a 0.1 km
			dnf = 0.01;
		}
		dnf = 0.01;

		if(d <= dnf){
			e = 106.9 + 20*Math.log10(dnf);
		}else if(d <= 0.1){
			e = 106.9 + 20*Math.log10(d);
		}else{
			e = 106.9 + 20*Math.log10(0.1) - 20*Math.log10(0.1)*Math.log10(d/0.1);
		}
		return e;
	}

	

	// Paso 1: Determinar el tipo de trayecto: Terrestre, marítimo (frío o
	// cálido), mixto (tipo 1 o 2).

	// Paso 2: Determinar % de tiempo. 1, 10 o 50 (nominales). En caso de querer
	// otro valor, dar los valores límites (paso 10 indica)
	private int[] paso2(double porTiempo) {
		// long timer = System.currentTimeMillis();
		int[] porTiempoInfSup = new int[2];
		if (porTiempo > 1.0 && porTiempo < 10.0) {
			porTiempoInfSup[0] = 1;
			porTiempoInfSup[1] = 10;
		}
		if (porTiempo > 10.0 && porTiempo < 50.0) {
			porTiempoInfSup[0] = 10;
			porTiempoInfSup[1] = 50;
		}

		if (porTiempo == 1.0 || porTiempo == 10.0 || porTiempo == 50.0) {
			porTiempoInfSup[0] = (int) (Math.floor(porTiempo));
			porTiempoInfSup[1] = (int) (Math.floor(porTiempo));
		}
		// timer = (System.currentTimeMillis() - timer);
		// System.out.println("Paso2: " + timer);
		return porTiempoInfSup;
	}

	// Paso 3: Determinar frecuencias nominales.
	//TODO: AÑADIR TRY Y CATCH PARA EVITAR QUE SE INGRESE UNA FREQ > 2000
	private int[] paso3(double freq) {
		// long timer = System.currentTimeMillis();
		int[] freqInfSup = new int[2];
		if (freq < 600.0) {
			if (freq == 100.0) {
				freqInfSup[0] = 100;
				freqInfSup[1] = 100;
			} else {
				freqInfSup[0] = 100;
				freqInfSup[1] = 600;
			}
		} else {
			if (freq == 600.0) {
				freqInfSup[0] = 600;
				freqInfSup[1] = 600;
			} else if (freq == 2000.0) {
				freqInfSup[0] = 2000;
				freqInfSup[1] = 2000;
			} else {
				freqInfSup[0] = 600;
				freqInfSup[1] = 2000;
			}
		}
		// timer = (System.currentTimeMillis() - timer);
		// System.out.println("Paso3: " + timer);
		return freqInfSup;
	}

	// Paso 4: Determinar distancias nominales min y sup.
	public int[] paso4(double dist, Double[] cuadro1) throws Exception,
			ParseException {
		// long timer = System.currentTimeMillis();
		int[] distInfSup = new int[5];
//		double umbral = 0.00000000000001; // umbral de 1 metro.
		double umbral = 0.001; // umbral de 1 metro.
		double diferencia;

		boolean sigo = true;
		int i = 0;
		
		while (sigo) {

			diferencia = Math.abs(dist - cuadro1[i]);
			if (diferencia < umbral) {
				dist = cuadro1[i];
			}

			if (dist > cuadro1[i] && i < cuadro1.length) {
				i++;
			// GM: CAMBIO PARA CONSIDERAR EL CIRCULO DEL CENTRO.
			} else if (dist < 1.0){
				distInfSup[0] = 1;
				distInfSup[1] = 0;
				distInfSup[2] = 1;
				distInfSup[3] = 0;
				distInfSup[4] = 1;
				sigo = false;
			} else if (dist != cuadro1[i]) {
				// dist no coincide con ningún valor del cuadro1, devuelvo inf y
				// sup.
				// El 0 en la posición 2 indica que no hay coincidencia.
				distInfSup[0] = (int) Math.floor(cuadro1[i - 1]);
				distInfSup[1] = (int) Math.floor(cuadro1[i]);
				distInfSup[2] = i - 1;
				distInfSup[3] = i;
				distInfSup[4] = 0;
				sigo = false;
			} else{
				// dist coincide con uno de los valores del cuadro1, devuelvo
				// dicho valor.
				// El 1 en la posición 4 indica que hubo coincidencia.
				// El valor en la posición 1 no interesa, se setea en -1.
				distInfSup[0] = (int) Math.floor(cuadro1[i]);
				distInfSup[1] = -1;
				distInfSup[2] = i;
				distInfSup[3] = -1;
				distInfSup[4] = 1;
				sigo = false;
			}
		}
		// timer = (System.currentTimeMillis() - timer);
		// System.out.println("Paso4: " + timer);
		return distInfSup; // [dInf, dSup, indiceDInf, indiceDSup, flag]
	}

	public double interpolaLog(double magnitudReal, double y2, double y1,
			double x2, double x1) {// los índices 2 corresponden a los sup y el
									// 1 al los inf
		// E = Einf + (Esup − Einf) log (h1 / hinf) / log (hsup / hinf)
		return y1 + ((y2 - y1) * Math.log10(magnitudReal / x1))
				/ Math.log10(x2 / x1);
	}

	public int eligeHoja(int frecNominal, int tiempoNominal, String path)
			throws IOException, ParseException {// metodo que devuelve el numero
												// de hoja a usar del xls
		// File tablasxls = new File("Rec_P_1546_Tab_values.xls");
		// long timer = System.currentTimeMillis();
		if (path.equalsIgnoreCase(LAND)){
			path = "Land";
		}else if(path.equalsIgnoreCase(SEA)){
			path = "Sea";
		}else if(path.equalsIgnoreCase(COLD_SEA)){
			path = "Cold Sea";
		}else{
			path = "Warm Sea";
		}
		
		int k = 0;
		int numHoja = -1; // si devuelve un -1, no encontró nada.
		int frecHoja;
		int tiempoHoja;
		boolean sigo = true;
		while (sigo && k <= 23) { // CAMBIAR A TOTAL HOJAS.
			// las 3 celdas que indican frec, time y path.
			Object[][] columna = this.readExcel(this.tablasxls, k, 1, 3, 1, 1);
			String frec = (columna[0][0]).toString();
			String[] div = frec.split(" ");
			frecHoja = (int) (Double.parseDouble(div[0]));
			tiempoHoja = (int) (Math.floor((Double) (columna[1][0])));

			// DEFINIR EL %TIEMPO COMO DOUBLE
			if (frecHoja == frecNominal && tiempoHoja == tiempoNominal
					&& columna[2][0].equals(path)) {
				sigo = false;
				numHoja = k;
			}
			k++;
		}
		// timer = (System.currentTimeMillis() - timer);
		// System.out.println("eligeHoja: " + timer);
		return numHoja;
	}

	// Einf + (Esup − Einf) log (h1 / hinf) / log (hsup / hinf)
	// Paso 5: Para el primer tipo de propagación, seguir los Pasos 6 a 11.
	// Por ahora es solo TERRESTRE.

	// Paso 6: Para el porcentaje de tiempo nominal inferior, seguir los Pasos 7
	// a 10.
	// Paso 7: Para la frecuencia nominal inferior, seguir los Pasos 8 y 9.

	// Paso 8: Obtener la intensidad de campo rebasada en el 50% de las
	// ubicaciones para una antena
	// receptora/móvil a la altura representativa de los obstáculos
	// circundantes, R, por encima del suelo
	// para la distancia y la altura de antena transmisora/de base requeridas
	// como sigue:

	public double interpolacionLineal(double y0, double y1, double x0,
			double x1, double y) {
		return (y - y0) * (x1 - x0) / (y1 - y0) + x0;
	}

	// Asumo que ingreso frecuencias nominales.
	// Agregar try y catch por si las frecuencias no son nominales.
	public double paso8(double h1, double dist, int[] distInfSup,
			int frecNominal, int tiempoNominal, String trayecto,
			Object[][] tabla, double thetaEff) throws ParseException, Exception {
		// Paso 8.1: Para una altura de antena transmisora/de base h1 igual o
		// superior a 10 m, seguir
		// los Pasos 8.1.1 a 8.1.6:
		// long timer = System.currentTimeMillis();
		double e; // inicializo porque sino ladra
		// obtengo dInf y dSup
		// int[] distInfSup = paso4(dist);

		// Alturas h1 nominales: 10, 20, 37.5, 75, 150, 300, 600, 1.200 m
		double h1Nominal[] = new double[] { 10, 20, 37.5, 75, 150, 300, 600,
				1200 };

		if (h1 >= 10.0) {

			// Paso 8.1.1: Determinar hinf y hsup (utilizando el método indicado
			// en el § 4.1 del Anexo 5).
			double hInf = 0.0;
			double hSup = 0.0;
			int indiceHInf = 0;
			int indiceHSup = 0;
			boolean h1CoincideNominal = false;

			// Si h1 coincide con alguno de los valores nominales, solo interesa
			// hinf.
			if (h1 > 1200.0) {
				indiceHInf = 6;
				indiceHSup = 7;
				hInf = h1Nominal[indiceHInf]; // 600
				hSup = h1Nominal[indiceHSup]; // 1200
			} else {
				int i = 0;
				boolean sigo = true;
				while (sigo && i < h1Nominal.length) {
					if (h1 >= h1Nominal[i]) {
						i++;
					} else {
						if (h1 == h1Nominal[i]) {
							h1CoincideNominal = true;
						}
						hInf = h1Nominal[i - 1];
						hSup = h1Nominal[i];
						indiceHInf = i - 1;
						indiceHSup = i;
						sigo = false;
					}
				}
			}
			// Paso 8.1.2: Para hinf, seguir los Pasos 8.1.3 a 8.1.5.
			// Paso 8.1.3: Para dinf, seguir el Paso 8.1.4.

			// Paso 8.1.4: Obtener la intensidad de campo rebasada en el 50% de
			// las ubicaciones para
			// una antena receptora/móvil a la altura representativa de los
			// obstáculos circundantes, R, para
			// los valores requeridos de distancia, d, y altura de la antena
			// transmisora/de base, h1.

			int indiceDInf = distInfSup[2] + 1; // le sumo 1 porque el cuadro1
												// arranca en 1, y en la tabla
												// arranco con el 78.
			indiceHInf = indiceHInf + 1;
			double eDInf = (Double) (tabla[indiceDInf][indiceHInf]);
			// En realidad es eDInf, pero si coincide ya es el valor de campo;
			// si no coincide lo reescribo adentro del siguiente if (paso 5).

			e = eDInf;

			// Paso 8.1.5: Si la distancia requerida no coincide con la
			// distancia nominal inferior, repetir
			// el Paso 8.1.4 para la distancia nominal superior e interpolar las
			// dos intensidades de campo
			// para la distancia utilizando el método indicado en el § 5 del
			// Anexo 5.

			if (distInfSup[4] == 0) { // tengo dInf y dSup
				int indiceDSup = distInfSup[3] + 1; // le sumo 1 porque el
													// cuadro1 arranca en 1, y
													// en la tabla arranco con
													// el 78.
				double eDSup = (Double) (tabla[indiceDSup][indiceHInf]);
				e = interpolaLog(dist, eDSup, eDInf, distInfSup[1],
						distInfSup[0]);
			}

			// Paso 8.1.6: Si la altura requerida de la antena transmisora/de
			// base, h1, no coincide con uno
			// de los valores nominales, repetir los Pasos 8.1.3 a 8.1.5 e
			// interpolar/extrapolar para h1
			// utilizando el método indicado en el § 4.1 del Anexo 5. Si es
			// necesario, limitar el resultado
			// al máximo dado en el § 2 del Anexo 5.

			if (h1CoincideNominal == false) {
				// para dInf y h1
				// ///////////////////////////////////////////// ANTES
				// ///////////////////////////////////////////////////////////////////////////
				// double eHInf = eDInf;
				// indiceHSup = indiceHSup + 1; //le sumo 1 porque el cuadro1
				// arranca en 1, y en la tabla arranco con el 78.
				// double eHSup = (Double)(tabla[indiceDInf][indiceHSup]);
				// e = interpolaLog(h1, eHSup, eHInf, hSup, hInf);
				// ///////////////////////////////////////////// ANTES
				// ///////////////////////////////////////////////////////////////////////////

				int indiceDSup = distInfSup[3] + 1; // le sumo 1 porque el
													// cuadro1 arranca en 1, y
													// en la tabla arranco con
													// el 78.
				double eDSupHSup = (Double) (tabla[indiceDSup][indiceHSup]);
				double eDInfHSup = (Double) (tabla[indiceDInf][indiceHSup]);
				double eParaSup = interpolaLog(dist, eDSupHSup, eDInfHSup,
						distInfSup[1], distInfSup[0]);
				e = interpolaLog(h1, eParaSup, e, hSup, hInf);

				// Si es necesario, limito a valor máximo (SOLO trayecto
				// terrestre) TODO: ampliar a otros trayectos.
				double eMax = 106.9 - 20 * Math.log10(dist);
				if (e > eMax) {
					e = eMax;
				}
			} // cierra if >= 10

			// Paso 8.2: Para una altura de antena transmisora/de base, h1,
			// inferior a 10 m, determinar la
			// intensidad de campo para la altura y la distancia requeridas
			// utilizando el método indicado
			// en el § 4.2 del Anexo 5. Si h1 es inferior a cero, deberá
			// utilizarse también el método
			// indicado en el § 4.3 del Anexo 5.
		} else if (h1 >= 0) {
			// Entre 0 y 10: (h1 >= 0) && (h1 < 10)
			// Trayecto TERRESTRE. TODO: if Marítimo.
			// E10 y E20 se obtienen directamente de las tabulaciones asociadas
			// (4.1 - h1=10 y h1=20 son nominales)
			double e10Inf = (Double) (tabla[distInfSup[0]][1]);
			double e10Sup = (Double) (tabla[distInfSup[1]][1]);
			double e10 = interpolaLog(dist, e10Sup, e10Inf, distInfSup[1],
					distInfSup[0]);

			double e20Inf = (Double) (tabla[distInfSup[0]][2]);
			double e20Sup = (Double) (tabla[distInfSup[1]][2]);
			double e20 = interpolaLog(dist, e20Sup, e20Inf, distInfSup[1],
					distInfSup[0]);

			// variables aux
			double C1020 = e10 - e20;
			double thetaEff2 = Math.atan(10 / 9000) * 180 / Math.PI;
			double Kv;

			if (frecNominal == 100) {
				Kv = 1.35;
			} else if (frecNominal == 600) {
				Kv = 3.31;
			} else {
				Kv = 6.0;
			}

			double v = Kv * thetaEff2;
			double J = (6.9 + 20 * Math
					.log10(Math.sqrt(Math.pow(v - 0.1, 2) + 1) + v - 0.1));
			double Ch1neg10 = 6.03 - J;

			double eZero = e10 + 0.5 * (C1020 + Ch1neg10);
			e = eZero + 0.1 * h1 * (e10 - eZero);

//			if (C1020 > 0) {
//				System.out.println("C1020 dio positivo");
//			}
//			if (Ch1neg10 > 0) {
//				System.out.println("Ch1neg10 dio positivo");
//			}
		} else { // h1 negativo
			// The procedure for negative values of h1 is to obtain the field
			// strength for h1 = 0 as described in
			// § 4.2, and to add a correction Ch1 calculated as follows.
			// The effect of diffraction loss is taken into account by a
			// correction,
			// Ch1, given by cases a) or b) as
			// follows:
			// a)
			// In the case that a terrain database is available and the
			// potential
			// for discontinuities at the
			// transition around h1 = 0 is of no concern in the application of
			// this
			// Recommendation, the
			// terrain clearance angle, θeff1, from the transmitting/base
			// antenna
			// should be calculated as the
			// elevation angle of a line which just clears all terrain
			// obstructions
			// up to 15 km from the
			// transmitting/base antenna in the direction of (but not going
			// beyond)
			// the receiving/mobile
			// antenna. This clearance angle, which will have a positive value,
			// should be used instead of
			// θtca in equation (30c) in the terrain clearance angle correction
			// method given in § 11 to
			// obtain Ch1. Note that using this method can result in a
			// discontinuity
			// in field strength at the
			// transition around h1 = 0.

			// Calculo e para h1 = 0 usando 4.2:
			double e10Inf = (Double) (tabla[distInfSup[0]][1]);
			double e10Sup = (Double) (tabla[distInfSup[1]][1]);
			double e10 = interpolaLog(dist, e10Sup, e10Inf, distInfSup[1],
					distInfSup[0]);
			double e20Inf = (Double) (tabla[distInfSup[0]][2]);
			double e20Sup = (Double) (tabla[distInfSup[1]][2]);
			double e20 = interpolaLog(dist, e20Sup, e20Inf, distInfSup[1],
					distInfSup[0]);
			double C1020 = e10 - e20;
			double thetaEff2 = Math.atan(10 / 9000) * 180 / Math.PI;
			double Kv;
			if (frecNominal == 100) {
				Kv = 1.35;
			} else if (frecNominal == 600) {
				Kv = 3.31;
			} else {
				Kv = 6.0;
			}
			double v = Kv * thetaEff2;
			double J = (6.9 + 20 * Math
					.log10(Math.sqrt(Math.pow(v - 0.1, 2) + 1) + v - 0.1));
			double Ch1neg10 = 6.03 - J;
			double eZero = e10 + 0.5 * (C1020 + Ch1neg10);
			e = eZero;

			// Tengo que añadirle a e la corrección Ch1.
			// thetaEff1: desde transmisor hacia receptor, que se usa en vez de
			// thetaTca de 30c, luego inciso 11 para Ch1.
			double thetaEff1 = thetaEff;
			v = 0.065 * thetaEff1 * Math.sqrt(frecNominal);
			J = (6.9 + 20 * Math.log10(Math.sqrt(Math.pow(v - 0.1, 2) + 1) + v
					- 0.1));
			double Ch1 = 6.03 - J;

			e = e + Ch1; // TODO: REVISAR SI ES SUMA O RESTA
		}
		// timer = (System.currentTimeMillis() - timer);
		// System.out.println("Paso8: " + timer);
		return e;
	}

	// Paso 9: Si la frecuencia requerida no coincide con la frecuencia nominal
	// inferior, repetir el Paso 8
	// para la frecuencia nominal superior e interpolar o extrapolar las dos
	// intensidades de campo
	// utilizando el método indicado en el § 6 del Anexo 5. Si es necesario,
	// limitar el resultado a la
	// intensidad de campo máxima dada en el § 2 del Anexo 5.
	public double paso9(double h1, double dist, double frec, int[] distInfSup,
			int[] frecInfSup, int tiempoNominal, String trayecto,
			Object[][] tablaFSupTInf, double eInf, double thetaEff)
			throws Exception, Exception {
		// eInf es el resultado del paso 8 original (usa fNInf). Ahora me pide
		// que corra paso8 para fNSup.
		// Paso 8 con la frecuencia nominal superior (freInfSup[1]).
		// long timer = System.currentTimeMillis();
		double eSup = paso8(h1, dist, distInfSup, frecInfSup[1], tiempoNominal,
				trayecto, tablaFSupTInf, thetaEff); // fNSup, tiempo, path);
		// e = einf + (esup-einf)*log(f/finf)/log(fsup/finf)
		double e = interpolaLog(frec, eSup, eInf, frecInfSup[1], frecInfSup[0]);
		// Si es necesario, limito a valor máximo (SOLO trayecto terrestre)
		// TODO: ampliar a otros trayectos.
		double eMax = 106.9 - 20 * Math.log10(dist);
		if (e > eMax) {
			e = eMax;
		}
		// E_TLfLdLh1L = P_1546_interpolate(f,fL,fH,E_TLfLdLh1L,E_TLfHdLh1L,
		// 'normal');
		// timer = (System.currentTimeMillis() - timer);
		// System.out.println("Paso9: " + timer);
		return e;
	}

	// Paso 10: Si el porcentaje de tiempo requerido no coincide con el
	// porcentaje de tiempo nominal,
	// repetir los Pasos 7 a 9 para el porcentaje de tiempo nominal superior e
	// interpolar las dos
	// intensidades de campo utilizando el método indicado en el § 7 del Anexo
	// 5.

	public double paso10(double t, double h1, double dist, double frec,
			int[] distInfSup, int[] frecInfSup, int[] tInfSup, String trayecto,
			Object[][] tablaFInfTSup, Object[][] tablaFSupTSup, double eInf,
			boolean pasoNueve, double thetaEff) throws Exception, Exception {
		double e;
		// Pasos 7 a 9 para % de tiempo Nominal Superior.
		double eSup = paso8(h1, dist, distInfSup, frecInfSup[0], tInfSup[1],
				trayecto, tablaFInfTSup, thetaEff);
		if (pasoNueve) {
			eSup = paso9(h1, dist, frec, distInfSup, frecInfSup, tInfSup[1],
					trayecto, tablaFSupTSup, eSup, thetaEff);
		}

		// Interpolo: E = Esup(Qinf - Qt)/(Qinf - Qsup) + Einf(Qt - Qsup)/(Qinf
		// - Qsup)
		double qt = evaluoDistNormal(t / 100.0);
		double qInf = evaluoDistNormal(tInfSup[0] / 100.0);
		double qSup = evaluoDistNormal(tInfSup[1] / 100.0);

		e = eSup * (qInf - qt) / (qInf - qSup) + eInf * (qt - qSup)
				/ (qInf - qSup);
		return e;
	}

	public double paso12(double theta, double frec, double e) {
		// f en MHz, theta en grados.
		double vPrima = 0.036 * Math.sqrt(frec);
		double v = 0.065 * theta * Math.sqrt(frec);
		double J = 6.9 + 20 * Math.log10(Math.sqrt(Math.pow(v - 0.1, 2) + 1)
				+ v - 0.1);
		double JPrima = 6.9 + 20 * Math.log10(Math.sqrt(Math.pow(vPrima - 0.1,
				2) + 1) + vPrima - 0.1);
		double correccion = JPrima - J;
		// GM: agrego abs de corrección para restarla
//		if (correccion > 0){
//			System.out.println("Correccion 12 positiva");
//		}
//		correccion = Math.abs(correccion);
//		return e - correccion; // TODO: REVISAR SI ES SUMA O RESTA
		return e + correccion;
	}

	public double paso13(double d, double t, double thetaTca, double thetaEff,
			double f, double e) {
		// f en MHz, theta en grados.
		double a = 6370.0; // Radio de la Tierra.
		double k = 4.0 / 3.0;
		double thetaS = (180.0 * d) / (Math.PI * k * a) + thetaEff + thetaTca;
		if (thetaS < 0.0) {
			thetaS = 0.0;
		}
		double Lf = 5.0 * Math.log10(f) - 2.5 * Math.pow(Math.log10(f) - 3.3, 2);
		double No = 325.0;
		double Gt = 10.1 * Math.pow(-1.0*Math.log10(0.02 * t), 0.7);
		// entrar d en km
		double eTS = 24.4 - 20 * Math.log10(d) - 10 * thetaS - Lf + 0.15 * No
				+ Gt;
//GM: Antes de mail de David
//		if (eTS > 0){
//			System.out.println("Correccion 13 positiva");
//		}
//		// Agrego abs para que reste.
//		eTS = Math.abs(eTS);
//		return e + eTS; // TODO: REVISAR SI ES SUMA O RESTA
		if (eTS > e){
			return eTS;
		}else{
			return e;
		}
	}

	public double paso14(double d, double h1, double h2,
			double f, double R, double e) {

		double RPrima = (1000.0 * d * R - 15.0 * h1) / (1000.0 * d - 15.0); // en
																	// METROS.
		// Limito RPrima a 1 metro.
		if (RPrima < 1.0) {
			RPrima = 1.0;
		}
		
		double Knu = 0.0108*Math.sqrt(f);
		double hDif = RPrima - h2;
		double thetaClut = Math.atan(hDif/27.0)*180/Math.PI;
		double v = Knu*Math.sqrt(hDif*thetaClut);
		double Kh2 = 3.2 + 6.2*Math.log10(f);
		double J = 6.9 + 20 * Math.log10(Math.sqrt(Math.pow(v - 0.1, 2) + 1)
				+ v - 0.1);
		double correccion;
		
		if(h2 < RPrima){
			correccion = 6.03 - J;
		}else{
			correccion = Kh2*Math.log10(h2/RPrima);
		}
		
		if(RPrima < 10 && tipoZona.equals(URBANA)){
			correccion = Kh2*Math.log10(10/RPrima);
		}
		
		if(tipoZona.equals(SUBURBANA)){
			correccion = Kh2*Math.log10(h2/10);
		}
		
		// Agrego abs para restar correccion
//		if (correccion > 0){
//			System.out.println("Correccion 14 positiva");
//		}		
//		correccion = Math.abs(correccion);
//		return e - correccion; // TODO: REVISAR SI ES SUMA O RESTA
		return e + correccion;
	}
	
	public double paso15(double d, double f, double ha, double R, double e) {
		double correccion = -3.3*Math.log10(f)*(1.0 - 0.85*Math.log10(d))*(1.0 - 0.46*Math.log10(1.0 + ha - R));
		// Agrego abs para restar correccion
		
//		if (correccion > 0){
//			System.out.println("Correccion 15 positiva");
//		}

//		correccion = Math.abs(correccion);
//		return e - correccion; // TODO: REVISAR SI ES SUMA O RESTA
		return e + correccion;
	}
	
	public double paso16(double q, double e){ 
		double e_new = e + evaluoDistNormal(q/100)*5.5;
		return e_new; // TODO: Chequear que de valores coherentes
	}

	public double paso17(double d, double e) {
		double eMax = 106.9 - 20 * Math.log10(d);
		if (e > eMax) {
			e = eMax;
		}
		return e;
	}
	
	public double paso18(double f, double e) {
		// TODO: Hacer checkbox para elegir si graficar périda o campo.
		double Lb = 139.3 - e + 20*Math.log10(f);
		return Lb;
	}
	
	// Distribución normal acumulativa complementaria inversa.
	public double evaluoDistNormal(double x) {
		double C0 = 2.515517;
		double C1 = 0.802853;
		double C2 = 0.010328;
		double D1 = 1.432788;
		double D2 = 0.189269;
		double D3 = 0.001308;
		double T;
		double xi;
		double Q = 0;

		if (x >= 0.01 && x <= 0.99) {
			if (x <= 0.5) { // Q(x) = T(x) - XI(x)
				T = Math.sqrt(-2 * Math.log(x));
				xi = ((C2 * T + C1) * T + C0)
						/ (((D3 * T + D2) * T + D1) * T + 1);
				Q = T - xi;
			} else { // Q(x) = - { T(1-x) - XI(1-x) }
				T = Math.sqrt(-2 * Math.log(1 - x));
				xi = ((C2 * T + C1) * T + C0)
						/ (((D3 * T + D2) * T + D1) * T + 1);
				Q = xi - T;
			}
		} else {
			// tiro una excepción
		}
		return Q;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	public Object[][] readExcel(File archivo, int hoja, int filaMin,
			int filaMax, int colMin, int colMax) throws IOException,
			ParseException {
		// long timer = System.currentTimeMillis();
		Workbook w;
		Object[][] tabla = new Object[filaMax - filaMin + 1][colMax - colMin
				+ 1];
		try {
			w = Workbook.getWorkbook(archivo);
			// Obtengo la hoja que necesito
			Sheet sheet = w.getSheet(hoja);
			for (int j = colMin; j <= colMax; j++) {
				for (int i = filaMin; i <= filaMax; i++) {
					Cell celda = sheet.getCell(j, i);
					CellType tipoCelda = celda.getType();
					String contenido = celda.getContents();
					if (tipoCelda == CellType.NUMBER) {
						NumberFormat format = NumberFormat
								.getInstance(Locale.FRANCE);
						Number number = format.parse(contenido).doubleValue();
						tabla[i - filaMin][j - colMin] = number.doubleValue();
					} else {
						tabla[i - filaMin][j - colMin] = contenido;
					}
					// String contenido = sheet.getCell(j, i).getContents();
					// NumberFormat format = NumberFormat
					// .getInstance(Locale.FRANCE);
					// Number number = format.parse(contenido);
					// tabla[i - filaMin][j - colMin] = number.doubleValue();
				}
			}
		} catch (BiffException e) {
			e.printStackTrace();
		}
		// timer = (System.currentTimeMillis() - timer);
		// System.out.println("readExcel: " + timer);
		return tabla;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#areaCalculable(explorer.proyecto.Mapa,
	 * java.awt.geom.Point2D.Double)
	 */
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {
		try {
			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();

			FeatureIterator fi = fc.features();
			boolean esta = false;
			GeometryFactory gf = new GeometryFactory();
			Polygon rectanguloAlturas = gf.createPolygon(
					gf.createLinearRing(new Coordinate[] {
							new Coordinate(0, 0), new Coordinate(1, 0),
							new Coordinate(1, 1), new Coordinate(0, 1),
							new Coordinate(0, 0) }), null);
			while (fi.hasNext() && esta == false) {
				rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
				esta = rectanguloAlturas.contains(gf
						.createPoint(new Coordinate(punto.x, punto.y))); // me
																			// fijo
																			// si
																			// el
																			// punto
																			// estÃ¯Â¿Âœ
																			// en
																			// alguno
																			// de
																			// los
																			// gridcoverages
			}
			if (!esta)
				return null; // si no estÃ¯Â¿Âœ, devuelvo null
			Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
					.getCoordinates();
			double maxX = -Double.MAX_VALUE;
			double maxY = -Double.MAX_VALUE;
			double minY = Double.MAX_VALUE;
			double minX = Double.MAX_VALUE;
			for (int j = 0; j < coordenadas.length; j++) {
				if (coordenadas[j].x < minX)
					minX = coordenadas[j].x;
				if (coordenadas[j].x > maxX)
					maxX = coordenadas[j].x;
				if (coordenadas[j].y < minY)
					minY = coordenadas[j].y;
				if (coordenadas[j].y > maxY)
					maxY = coordenadas[j].y;
			}
			Envelope envoltura = new Envelope(new CoordinatePoint(minX, minY),
					new CoordinatePoint(maxX, maxY));
			return envoltura;
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#crearPanelCreacion()
	 */

	protected class MenuITUR1546 extends PanelModelos implements
			ActionListener, ItemListener {
		JTextField porTiempoField;
		JTextField porUbicacionesField;
		JComboBox<String> tipoTrayectoBox;
		JComboBox<String> tipoZonaBox;
		JCheckBox confEspCheck;
		JRadioButton uVmButton;
		JRadioButton dBmButton;
		ButtonGroup botones;

		MenuITUR1546(double[] parametrosAjustables,
				Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
		}

		public void agregarElementos() {
			GridBagLayout gbl = new GridBagLayout();
			gbl.columnWeights = new double[]{1.0};
			gbl.rowWeights = new double[]{1.0, 1.0};
			gbl.rowHeights = new int[]{150, 50};
			this.setLayout(gbl);

			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(5, 2, 5, 2);
			gbc.gridx = 0;
			gbc.gridy = 0;
			gbc.gridheight = 1;
			gbc.gridwidth = 1;
			gbc.anchor = GridBagConstraints.NORTH;
			gbc.fill = GridBagConstraints.HORIZONTAL;
			gbc.ipadx = 0;
			gbc.ipady = 10;
			
			JPanel parametros = new JPanel();
			parametros.setLayout(new GridLayout(4, 1, 0, 5));
			TitledBorder bordeParametros;
			bordeParametros = BorderFactory.createTitledBorder("Parámetros");
			parametros.setBorder(bordeParametros);
			
			parametros.add(new JLabel("Porcentaje de tiempo [1-50%]: "));
			porTiempoField = new JTextField("");
			parametros.add(porTiempoField);

			parametros.add(new JLabel("Porcentaje de ubicaciones [1-99%]: "));
			porUbicacionesField = new JTextField("");
			parametros.add(porUbicacionesField);
			
			String[] listaTipoTrayecto = new String[] { LAND, SEA,
					COLD_SEA, WARM_SEA };
			tipoTrayectoBox = new JComboBox<String>(listaTipoTrayecto);
			parametros.add(new JLabel("Tipo de trayecto: "));
			parametros.add(tipoTrayectoBox);

			String[] listaZona = new String[] { URBANA, URBANA_DENSA,
					SUBURBANA };
			tipoZonaBox = new JComboBox<String>(listaZona);
			parametros.add(new JLabel("Tipo de zona: "));
			parametros.add(tipoZonaBox);
			
			this.add(parametros, gbc);

			JPanel confEspeciales = new JPanel();
			confEspeciales.setLayout(new GridLayout(1, 1, 0, 5));
			TitledBorder bordeConfEsp;
			bordeConfEsp = BorderFactory.createTitledBorder("Configuraciones especiales");
			confEspeciales.setBorder(bordeConfEsp);
			confEspCheck = new JCheckBox("90 % del tiempo y 50 % de las ubicaciones");
			confEspCheck.addActionListener(this);
			gbc.gridy = 1;
			this.add(confEspeciales, gbc);
			confEspeciales.add(confEspCheck);
			
			JPanel visualizacion = new JPanel();
			visualizacion.setLayout(new GridLayout(2, 1, 0, 5));
			TitledBorder bordeVis;
			bordeVis = BorderFactory.createTitledBorder("Visualización de resultados");
			visualizacion.setBorder(bordeVis);

			uVmButton = new JRadioButton("Intensidad de campo E [dB(\u00B5V/m)]");
			dBmButton = new JRadioButton("Potencia recibida [dBm]");
			botones = new ButtonGroup();
			botones.add(uVmButton);
			botones.add(dBmButton);

			gbc.gridy = 2;
			this.add(visualizacion, gbc);
			visualizacion.add(uVmButton);
			visualizacion.add(dBmButton);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 */
		public double[] getParametrosAjustables()
				throws ModeloMalDefinidoException {
			try {
				double porTiempoParam = Double.parseDouble(this.porTiempoField.getText());
				double porUbicacionesParam = Double.parseDouble(this.porUbicacionesField.getText());
				double[] parametros = new double[] { porTiempoParam, porUbicacionesParam };
				return parametros;
			} catch (Exception e) {
				ModeloMalDefinidoException ex = new ModeloMalDefinidoException(
						"Algunos de los campos ingresados no son correctos.");
				throw ex;
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 */
		public Object[] getParametrosNoAjustables()
				throws ModeloMalDefinidoException {
			Object[] parametrosNoAj = new Object[4];
			if (this.tipoTrayectoBox.getSelectedItem().equals(LAND)) {
				parametrosNoAj[0] = new String(LAND);
			} else if (this.tipoTrayectoBox.getSelectedItem().equals(SEA)) {
				parametrosNoAj[0] = new String(SEA);
			} else if (this.tipoTrayectoBox.getSelectedItem().equals(COLD_SEA)) {
				parametrosNoAj[0] = new String(COLD_SEA);
			} else {
				parametrosNoAj[0] = new String(WARM_SEA);
			}

			if (this.tipoZonaBox.getSelectedItem().equals(URBANA)) {
				parametrosNoAj[1] = new String(URBANA);
			} else if (this.tipoZonaBox.getSelectedItem().equals(
					URBANA_DENSA)) {
				parametrosNoAj[1] = new String(URBANA_DENSA);
			} else {
				parametrosNoAj[1] = new String(SUBURBANA);
			}
			
			if(uVmButton.isSelected()){ // true es uVm, false es dBm
				parametrosNoAj[2] = Boolean.valueOf(true);
			}else{
				parametrosNoAj[2] = Boolean.valueOf(false);
			}
			if(confEspCheck.isSelected()){
				parametrosNoAj[3] = Boolean.valueOf(true);
			}else{
				parametrosNoAj[3] = Boolean.valueOf(false);
			}
			return parametrosNoAj;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double
		 * [])
		 */
		protected void setParametrosAjustables(double[] parametrosAjustables) {
			this.porTiempoField.setText(new Double(parametrosAjustables[0]).toString());
			this.porUbicacionesField.setText(new Double(parametrosAjustables[1]).toString());
		}
		
		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(
		 * java.lang.Object[])
		 */
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			tipoTrayectoBox.setSelectedItem(parametrosNoAjustables[0]);
			tipoZonaBox.setSelectedItem(parametrosNoAjustables[1]);
			if(((Boolean)parametrosNoAjustables[2]).booleanValue()){
				uVmButton.setSelected(true);
				dBmButton.setSelected(false);
			}else{
				dBmButton.setSelected(true);
				uVmButton.setSelected(false);
			}
			if(((Boolean)parametrosNoAjustables[3]).booleanValue()){
				confEspCheck.setSelected(true);
				porTiempoField.setEnabled(false);
				porUbicacionesField.setEnabled(false);
			}else{
				confEspCheck.setSelected(false);
			}
		}

		/**
		 * simplemente resetea los valores a los por defecto.
		 */
		public void actionPerformed(ActionEvent e) {
//			ITU_R_P1546 modeloP1546 = new ITU_R_P1546();
//			this.setParametrosAjustables(modeloP1546
//					.getParametrosAjustablesPorDefecto());
//			this.setParametrosNoAjustables(modeloP1546
//					.getParametrosNoAjustablesPorDefecto());
			if (e.getSource().equals(confEspCheck)) {
				if(confEspCheck.isSelected()){
					porTiempoField.setEnabled(false);
					porUbicacionesField.setEnabled(false);
				}else{
					porTiempoField.setEnabled(true);
					porUbicacionesField.setEnabled(true);
				}	
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 */
		public Modelo getModelo() throws ModeloMalDefinidoException {
			return new ITU_R_P1546(this.getParametrosAjustables(),
					this.getParametrosNoAjustables());
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#getTamanioVentana()
		 */
		public Dimension getTamanioVentana() {
			return new Dimension(272, 138);
		}

		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
		}

	}

	// /////////////////////////////////////////////////////////////////////////////////////////////

	protected void crearPanelCreacion() {
		this.menu = new MenuITUR1546(this.parametrosAjustables,
				this.parametrosNoAjustables);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#getPanelCreacion()
	 */

	public PanelModelos getPanelCreacion() {
		return this.menu;
	}

	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		double[] parametros = new double[2];
		parametros[0] = 50; // % de tiempo.
		parametros[1] = 50; // % de ubicaciones.
		return parametros;
	}

	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		Object[] parametro = new Object[4];
		parametro[0] = LAND;
		parametro[1] = SUBURBANA;
		parametro[2] = Boolean.valueOf(true);
		parametro[3] = Boolean.valueOf(false);
		return parametro;
	}

	protected void setNombres() {
		this.nombreModelo = Modelo.ITUR_P1546;
		this.nombreParametrosAjustables = new String[] { "Porcentaje de tiempo", "Porcentaje de ubicaciones" };
		this.nombreParametrosNoAjustables = new String[] { "Tipo de trayecto",
				"Tipo de Zona", "Tipo de visualización de resultados", "Configuraciones especiales" };
	}

	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena,
			Coordinate[] puntos) throws PrediccionMalRealizadaException {
		try {
			if (!this.verificarDatos(mapa)) {
				throw new PrediccionMalRealizadaException(
						"Para realizar la predicción con ITU-R P.1546 es necesaria la capa de alturas de terreno.");
			}
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
			Sitio sitio = (Sitio) sitioYRb[0];
			Radiobase rb = (Radiobase) sitioYRb[1];

			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage) f.getAttribute("grid");
			
			int cantPuntos = puntos.length;
			
			for(int i = 0; i < cantPuntos; i++){
				if (!mapa.getCapaAlturas().getGridCoverage().getEnvelope().contains(
						new CoordinatePoint(puntos[i].x, puntos[i].y))) {
					throw new SitioMalPosicionadoException(
							"Algún sitio está por fuera del mapa de alturas. Revise el archivo .dat y vuelva a intentarlo");
				}
			}			

			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia() / 1E6; // Frecuencia en
																// Mhz.
			double ha = rb.getAltura();
			// h1: Altura de la antena transmisora de base.
			double h1;
			// hb: Altura de la antena por encima del nivel del terreno
			// promediado entre 0.2d y d kms.
			double hb;
			// heff: Altura de la antena por encima del nivel del terreno
			// promediado entre 3 y 15 kms.
			double heff;
			double distancia;

			// Uso los parámetros que ingresa el usuario.
			this.porcentajeTiempo = this.parametrosAjustables[0];
			this.h2 = proyecto.getPerfilUsuario().getAltura();
			this.porcentajeUbicaciones = this.parametrosAjustables[1];
			this.tipoTrayecto = (String) this.parametrosNoAjustables[0];
			this.tipoZona = (String) this.parametrosNoAjustables[1];
			this.veoDBuVm = ((Boolean) this.parametrosNoAjustables[2]).booleanValue();
			this.confEsp = ((Boolean) this.parametrosNoAjustables[3]).booleanValue();

			// Altura promedio del terreno entre 0.2d y d km.
			double[] promedioA;
			// Altura promedio del terreno entre 3 y 15 km.
			double[] promedioB;

			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(),
					sitio.getY());
			Point2D sitioMovil = null;

			UtilidadesModelos um = new UtilidadesModelos(gc);

			Grilla grilla = new Grilla(gc.getCoordinateSystem());
			double[] datos = new double[cantPuntos];
			int contador = 0;
			int contadorEsp = 0;
			double minimo = java.lang.Double.MAX_VALUE;
			double maximo = -java.lang.Double.MAX_VALUE;
			////////////////////////////////////////////////////////////////////////////////
			double[] datosAux = new double[cantPuntos]; ////
			int vuelta = 1;

			while (vuelta <= 2) {				
				if(confEsp){
					if(vuelta == 1){
						porcentajeTiempo = 50.0;
						porcentajeUbicaciones = 50.0;
					}else if(vuelta == 2){
						contador = 0;
						porcentajeTiempo = 10.0;
						porcentajeUbicaciones = 50.0;
					}
				}else{
					vuelta = 3;
				}
				
				// COMIENZA NORMA //
				// Intensidad de campo eléctrico en dBuV/m
				double e;
				// % de tiempo nominal inferior y superior
				int[] tInfSup = paso2(porcentajeTiempo);
				// frecuencia nominal inferior y superior.
				int[] frecInfSup = paso3(frecuencia);
				// Variables para Paso 9:
				boolean pasoNueve = false;
				int hojaFSupTInf = 0;
				Object[][] tablaFSupTInf = new Object[79][10]; // tamaño de tabla de
																// datos.
				// Varibales Paso 10:
				boolean pasoDiez = false;
				int hojaFSupTSup = 0;
				Object[][] tablaFSupTSup = new Object[79][10];
				int hojaFInfTSup = 0;
				Object[][] tablaFInfTSup = new Object[79][10];

				if (frecInfSup[0] != frecInfSup[1]) {
					pasoNueve = true;
					hojaFSupTInf = eligeHoja(frecInfSup[1], tInfSup[0],
							this.tipoTrayecto);
					// obtengo los valores de la tabla a trabajar
					tablaFSupTInf = this.readExcel(this.tablasxls, hojaFSupTInf, 5,
							83, 1, 10); // recorro en filas
				}

				if (tInfSup[0] != tInfSup[1]) {
					pasoDiez = true;
					hojaFSupTSup = eligeHoja(frecInfSup[1], tInfSup[1],
							this.tipoTrayecto);
					tablaFSupTSup = this.readExcel(this.tablasxls, hojaFSupTSup, 5,
							83, 1, 10); // recorro en filas
					hojaFInfTSup = eligeHoja(frecInfSup[0], tInfSup[1],
							this.tipoTrayecto);
					// obtengo los valores de la tabla a trabajar
					tablaFInfTSup = this.readExcel(this.tablasxls, hojaFInfTSup, 5,
							83, 1, 10); // recorro en filas
				}

				// PARA EL PASO 8 //
				int hojaFInfTInf = eligeHoja(frecInfSup[0], tInfSup[0],
						this.tipoTrayecto);
				// obtengo los valores de la tabla a trabajar
				Object[][] tablaFInfTInf = this.readExcel(this.tablasxls,
						hojaFInfTInf, 5, 83, 1, 10); // recorro en filas

				// PARA EL PASO 4. //
				Object[][] cuadro1Obj = this.readExcel(this.cuadro1xls, 0, 0, 77,
						0, 0);
				Double[] cuadro1 = new Double[cuadro1Obj.length];

				for (int k = 0; k < cuadro1Obj.length; k++) {
					cuadro1[k] = (Double) (cuadro1Obj[k][0]);
				}
				
				// PARA PASOS 14 Y 15.
				double R; // en METROS.
				if (tipoZona.equals(URBANA)) {
					R = 20.0;
				} else if (tipoZona.equals(URBANA_DENSA)) {
					R = 30.0;
				} else {
					R = 10.0;
				}
				
				double[] distanciaYangulos;
				// Comienzo iteración en los puntos.
				for (int j = 0; j < cantPuntos; j++) {
					
					sitioMovil = new Point2D.Double(puntos[j].x, puntos[j].y);
					
						double distLimite = um.calcularDistanciaGrid(sitioAntena,
								sitioMovil);
						
						if(distLimite < 10){
							throw new SitioMalPosicionadoException(
									"Algún sitio está ubicado a una distancia menor a 10 m de la antena transmisora. Revise el archivo .dat y vuelva a intentarlo");
						}
						
						if (distLimite > 10 && distLimite < 1000000) {
							distanciaYangulos = um.calcularDistanciaReal(
									sitioAntena, ha, sitioMovil, this.h2,
									this.usarInterpolacion);
							distancia = distanciaYangulos[0]; // distancia es el path radioeléctrico.
							distancia = distancia / 1000; // las curvas utilizan la
															// distancia en km													
							
							// GM: OJO CON EL MÉTODO QUE CAMBIÓ!!!!
							double gananciaE = antena.getGanancia(
									distanciaYangulos[1], 90.0 + Math.atan(distanciaYangulos[2])*180.0/Math.PI);
							
							if(distancia < 1){
								e = campoMenorUnKm(distancia, gananciaE, frecuencia);
							}else{
								if (distancia < 15) {
									promedioA = um.alturaEfectiva(sitioAntena, rb
											.getAltura(), sitioMovil, this.h2, 20,
											this.usarInterpolacion, true);
									hb = promedioA[0];
									h1 = hb;
								} else {
									promedioB = um.alturaEfectiva(sitioAntena, rb
											.getAltura(), sitioMovil, this.h2, 20,
											this.usarInterpolacion, false);
									heff = promedioB[0];
									h1 = heff;
								}
															
								// ángulos para pasos 12, 13, 14 y paso 8.2.
								double angulos[] = um.angDespTerreno(sitioAntena, rb
										.getAltura(), sitioMovil, this.h2, 30,
										this.usarInterpolacion);
								// para paso 12
								double thetaTca = angulos[0];
								// para paso 13
								double thetaEff = angulos[1];
								
								// Obtengo los valores nominales de distancia.
								int[] distInfSup = paso4(distancia, cuadro1);
								
								// PASO 8
								e = paso8(h1, distancia, distInfSup, frecInfSup[0],
										tInfSup[0], this.tipoTrayecto, tablaFInfTInf,
										thetaEff);
								
								// PASO 9
								if (pasoNueve) {
									e = paso9(h1, distancia, frecuencia, distInfSup,
											frecInfSup, tInfSup[0], this.tipoTrayecto,
											tablaFSupTInf, e, thetaEff);
								}

								// PASO 10
								if (pasoDiez) {
									e = paso10(this.porcentajeTiempo, h1, distancia,
											frecuencia, distInfSup, frecInfSup,
											tInfSup, this.tipoTrayecto, tablaFInfTSup,
											tablaFSupTSup, e, pasoNueve, thetaEff);
								}

								// PASO 12
								e = paso12(thetaTca, frecuencia, e);

								// PASO 13
								e = paso13(distancia, this.porcentajeTiempo, thetaTca,
										thetaEff, frecuencia, e);

								// PASO 14
								e = paso14(distancia, h1, h2, frecuencia, R, e);
								
								// PASO 15
								// d is less than 15 km and h1 − R is less than 150 m.
								if(distancia < 15.0 && (h1 - R) < 150.0){
									e = paso15(distancia, frecuencia, ha, R, e);
								}
								
								// PASO 16
								if(this.porcentajeUbicaciones != 50.0){
									e = paso16(this.porcentajeUbicaciones, e);
								}
								
								// PASO 17
								e = paso17(distancia, e);
							}

							double prx;
							double Lb;
							double prxuvm;
							
							if(confEsp && vuelta == 1){
								datosAux[contador] = 2*e;
							}else if(confEsp && vuelta == 2){
								datosAux[contador] = datosAux[contador] - e;
								Lb = paso18(frecuencia, datosAux[contador]);
								prx = potencia + gananciaE - Lb;
								prxuvm = prx + 20*Math.log10(frecuencia) + 77.213;
								if(this.veoDBuVm){
									datos[contador] = prxuvm;
								}else{
									datos[contador] = prx;
								}
							}else{
								// Paso 18
								Lb = paso18(frecuencia, e);
								// Link budget
								prx = potencia + gananciaE - Lb;
								// Paso a dBuV/m
								prxuvm = prx + 20*Math.log10(frecuencia) + 77.213;

								// Según se haya elegido, despliego resultados en dBm o dBuV/m 
								if(this.veoDBuVm){
									datos[contador] = prxuvm;
								}else{
									datos[contador] = prx;
								}
							}
						} else {
							
							if(confEsp){
								datosAux[contador] = Double.NaN;
								if(vuelta == 2){
									datos[contador] = Double.NaN;
								}
							}else{
								datos[contador] = Double.NaN;
							}
						}

						if(confEsp){
							if(vuelta == 2){
								if (datos[contador] < minimo)
									minimo = datos[contador];
								if (datos[contador] > maximo)
									maximo = datos[contador];
							}
							contador++;
							contadorEsp++;
							cuantoVa = (int) ((double) contadorEsp
									/ ((double) (2 * cantPuntos)) * 100.0);
						}else{
							if (datos[contador] < minimo)
								minimo = datos[contador];
							if (datos[contador] > maximo)
								maximo = datos[contador];
							contador++;
							cuantoVa = (int) ((double) contador
									/ ((double) (cantPuntos)) * 100.0);
						}
						
					}	
			vuelta++;
			} 
			//////////////////////////////////////////////////////////////////////////////
			
			return datos;
		} catch (Exception z) {
			z.printStackTrace();
			throw new PrediccionMalRealizadaException(
					"Hubo un error al realizar la predicción de "
							+ this.getNombre() + ": \n" + z.getMessage());
		}
	}
	
	public String getXML() {

		StringBuffer result = new StringBuffer();
		result.append("		   <Modelo>");
		result.append("        <NombreImplementacion>" + nombreImplementacion
				+ "</NombreImplementacion>\r\n");
		result.append("        <Nombre>" + nombreModelo + "</Nombre>\r\n");

		for (int i = 0; i < nombreParametrosAjustables.length; i++) {
			StringBuffer result1 = new StringBuffer("<ParametrosAjustables>");
			result1.append("        <Nombre>" + nombreParametrosAjustables[i]
					+ "</Nombre>\r\n");
			if (parametrosAjustables.length != 0) {
				result1.append("        <Valor>" + parametrosAjustables[i]
						+ "</Valor>\r\n");
			} else {
				result1.append("        <Valor>" + "" + "</Valor>\r\n");
			}
			result1.append("        </ParametrosAjustables>\r\n");
			result.append(result1.toString());
		}
		if (parametrosNoAjustables.length != 0) {

			for (int i = 0; i < nombreParametrosNoAjustables.length; i++) {
				StringBuffer result1 = new StringBuffer();
//				if ((i == 3) || (i == 5)) {
//					ArrayList paramA = (ArrayList) this.parametrosNoAjustables[i];
//					Iterator iterator = paramA.iterator();
//					int m = 1;
//					while (iterator.hasNext()) {
//						result1 = new StringBuffer(
//								"<ParametrosNoAjustablesSubitems>");
//						Double c = (Double) iterator.next();
//						result1.append("        <Nombre>" + "c" + m
//								+ "</Nombre>\r\n");
//						result1.append("        <Valor>" + c + "</Valor>\r\n");
//						result1.append("        </ParametrosNoAjustablesSubitems>\r\n");
//						result.append(result1.toString());
//						// result.append("<c"+ m+">" + c + "</c"+m+">");
//						m = m + 1;
//					}
//				}
				result1 = new StringBuffer("<ParametrosNoAjustables>");
				result1.append("        <Nombre>"
						+ nombreParametrosNoAjustables[i] + "</Nombre>\r\n");
				if (parametrosNoAjustables.length != 0) {
					result1.append("        <Valor>"
							+ parametrosNoAjustables[i] + "</Valor>\r\n");
				} else {
					result1.append("        <Valor>" + "" + "</Valor>\r\n");
				}
				result1.append("        </ParametrosNoAjustables>\r\n");
				// }
				result.append(result1.toString());

			}
		}

		result.append("      </Modelo>\r\n");
		return result.toString();

	}
	
}