package sapo.predicciones;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import javax.swing.Timer;

import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;
import org.geotools.gc.GridCoverage;
import sapo.ifusuario.Mapa;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;
import umontreal.iro.lecuyer.stat.Tally;

import com.vividsolutions.jts.geom.Coordinate;

/**
 * Esta clase analiza la performance de los modelos en cuanto a precisión.
 * Contiene datos de medidas reales y las compara contra las predicciones
 * arrojadas por el modelo.
 * 
 * @author Grupo de proyecto SAPO
 */
public class AnalisisModelo {

	/**
	 * La antena a ser analizada que contiene el modelo
	 */
	Antena antena;

	/**
	 * El proyecto de donde se obtiene los datos necesarios para realizar las
	 * predicciones
	 */
	Proyecto proyecto;

	/**
	 * Contenedor para las coordenadas de donde se tiene medidas
	 */
	ArrayList coordenadas;

	/**
	 * Contenedor para las medidas de potencia
	 */
	ArrayList potencias;

	/**
	 * Contenedor para las predicciones realizadas por el modelo
	 */
	ArrayList predicciones;

	double[] perdidas;
	
	double[] distancias;
	
	double[] paramAjuste;

	/**
	 * Tally con los errores
	 */
	Tally errores;

	/**
	 * Thread encargado de calcular la atenuación.
	 */
	ThreadCalculaAtenuacion tca;

	/**
	 * Si el thread da errores al calcular, se guardan en esta variable.
	 */
	PrediccionMalRealizadaException z;

	Timer contador;

	private boolean termino;

	/**
	 * Crea una instancia con el modelo de la antena analizada. Inicialmente sin
	 * medidas ni predicciones.
	 * 
	 * @param antenaAnalizada
	 * @param proyectoAnalizado
	 */
	public AnalisisModelo(Antena antenaAnalizada, Proyecto proyectoAnalizado) {
		this.antena = antenaAnalizada;
		this.proyecto = proyectoAnalizado;
		coordenadas = new ArrayList();
		potencias = new ArrayList();
		predicciones = new ArrayList();
	}

	/**
	 * Agrega una medida de potencia en la coordenada especificada.
	 * 
	 * @param coord
	 * @param medidaPotencia
	 */
	public void agregarMedida(Coordinate coord, double medidaPotencia) {
		this.coordenadas.add(coord);
		this.potencias.add(new Double(medidaPotencia));
	}

	/**
	 * Agrega el valor de potencia predicho en <code>prediccion</code> en la
	 * coordenada <code>coord</code> siempre que dicha coordenada ya esté
	 * ingresada.
	 * 
	 * @param coord
	 * @param prediccion
	 * @throws IndexOutOfBoundsException
	 *             cuando la coordenada no está ingresada.
	 */
	public void agregarPrediccion(Coordinate coord, double prediccion)
			throws IndexOutOfBoundsException {
		int j = this.coordenadas.indexOf(coord);
		this.predicciones.ensureCapacity(j);
		this.predicciones.add(j, new Double(prediccion));
	}

	/**
	 * Calcula la potencia de recepción en los puntos especificados en el
	 * contenedor de coordenadas (aunque únicamente en aquellos puntos donde
	 * todavía no se realizó el calculo) y los agrega al contenedor de potencia.
	 * 
	 * @param mapa
	 * @throws PrediccionMalRealizadaException
	 */
	public void hacerPredicciones(Mapa mapa, boolean usarInter) {
		z = null;
		termino = false;
		Coordinate[] coordenadasDondeFalta = new Coordinate[coordenadas.size()
				- predicciones.size()];
		if (coordenadasDondeFalta.length == 0) {
			termino = true;
			return;
		}
		for (int j = this.predicciones.size(); j < this.coordenadas.size(); j++) {
			coordenadasDondeFalta[j - predicciones.size()] = (Coordinate) this.coordenadas
					.get(j);
		}
		this.tca = new ThreadCalculaAtenuacion(proyecto, mapa, antena,
				coordenadasDondeFalta, usarInter);
		tca.start();
		contador = new Timer(100, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				if (tca.termino) {
					contador.stop();
					termino = true;
					try {
						double[] prediccionesNuevas = (double[]) tca
								.getPrediccion();
						for (int j = 0; j < prediccionesNuevas.length; j++) {
							predicciones.add(new Double(prediccionesNuevas[j]));
						}
					} catch (PrediccionMalRealizadaException ex) {
						z = ex;
					}
				}
			}
		});
		contador.start();
	}

	/**
	 * Devuelve el error medio.
	 * 
	 * @return
	 * @throws PrediccionMalRealizadaException
	 *             cuando la predicción fue realizada con errores.
	 */
	public double mediaError() throws PrediccionMalRealizadaException {
		if (z != null)
			throw z;
		Tally promediador = new Tally();
		promediador.init();
		for (int j = 0; j < predicciones.size(); j++) {
			if (!Double.isNaN(((Double) predicciones.get(j)).doubleValue()))
				promediador.add(((Double) predicciones.get(j)).doubleValue()
						- ((Double) potencias.get(j)).doubleValue());
		}
		return promediador.average();
	}

	/**
	 * Devuelve la desviación estandard del error.
	 * 
	 * @return
	 * @throws PrediccionMalRealizadaException
	 *             cuando la predicción fue realizada con errores.
	 */
	public double desviacionError() throws PrediccionMalRealizadaException {
		if (z != null)
			throw z;
		Tally promediador = new Tally();
		promediador.init();
		for (int j = 0; j < predicciones.size(); j++) {
			if (!Double.isNaN(((Double) predicciones.get(j)).doubleValue()))
				promediador.add(((Double) predicciones.get(j)).doubleValue()
						- ((Double) potencias.get(j)).doubleValue());
		}
		return promediador.standardDeviation();
	}

	public double[] ajusteModelo(Mapa mapa, boolean usarInter) throws IllegalAttributeException,
			SchemaException {
		Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);
		Sitio sitio = (Sitio) sitioYRb[0];
		Radiobase rb = (Radiobase) sitioYRb[1];

		FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
		Feature f = fc.features().next();
		GridCoverage gc = (GridCoverage) f.getAttribute("grid");

		double potencia = antena.getPotencia();
		double ha = rb.getAltura();
		double distancia;

		Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(),
				sitio.getY());
		Point2D sitioMovil = null;

		UtilidadesModelos um = new UtilidadesModelos(gc);

		double[] distanciaYangulos;

		Coordinate coordenadaMovil;

		this.perdidas = new double[coordenadas.size()];
		this.distancias = new double[coordenadas.size()];
		double[][] distanciasPerdidas = new double[coordenadas.size()][2];
		double gananciaE;

		for (int j = 0; j < coordenadas.size(); j++) {
			coordenadaMovil = (Coordinate) coordenadas.get(j);
			sitioMovil = new Point2D.Double(coordenadaMovil.x, coordenadaMovil.y);
			distanciaYangulos = um.calcularDistanciaReal(sitioAntena, ha,
					sitioMovil, proyecto.getPerfilUsuario().getAltura(), usarInter);
			distancia = distanciaYangulos[0]; // distancia es el path
												// radioeléctrico.
			distancia = distancia / 1000; // km

			gananciaE = antena.getGanancia(distanciaYangulos[1],
					90.0 + Math.atan(distanciaYangulos[2]) * 180.0 / Math.PI);

			distanciasPerdidas[j][0] = distancia;
			distanciasPerdidas[j][1] = gananciaE + potencia - ((Double) (potencias.get(j))).doubleValue();
		}
		
		// Ordeno el array según distancia.
		java.util.Arrays.sort(distanciasPerdidas, new java.util.Comparator<double[]>() {
		    public int compare(double[] a, double[] b) {
		        return Double.compare(a[0], b[0]);
		    }
		});
		
		for(int i = 0; i < coordenadas.size(); i++){
			this.distancias[i] = distanciasPerdidas[i][0];
			this.perdidas[i] = distanciasPerdidas[i][1];
		}
		
		int cantidadParametros = 2;
		double[][] matrizA = new double[perdidas.length][cantidadParametros];
		double[] vectorB = new double[perdidas.length];
		// LOS = A + B * log (d)
		for (int i = 0; i < perdidas.length; i++) {
			matrizA[i][0] = 1;
			matrizA[i][1] = Math.log10(this.distancias[i]);
			vectorB[i] = perdidas[i];
		}
		
		double[][] aT = transponer(matrizA);
		double[][] A = multiplicar(aT, matrizA);
		double[][] vectorBaux = new double[1][vectorB.length];
		vectorBaux[0] = vectorB;
		double[][] B = multiplicar(aT, transponer(vectorBaux));
		// Ahora debo resolver Ax = B
		double[] vector = new double[] { B[0][0], B[1][0] };
		paramAjuste = lsolve(A, vector);
		termino = true;
		return paramAjuste;
	}

	private static double[][] transponer(double[][] matriz) {
		int filas = matriz.length;
		int columnas = matriz[0].length;
		double[][] traspuesta = new double[columnas][filas];
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[0].length; j++) {
				traspuesta[j][i] = matriz[i][j];
			}
		}
		return traspuesta;
	}

	private static void escribir(double[][] matriz) {
		System.out.println("========================");
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[0].length; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("========================");
	}

	private static void escribir(double[] vector) {
		System.out.println("========================");
		for (int i = 0; i < vector.length; i++) {
			System.out.print(vector[i] + " ");
		}
		System.out.println();

		System.out.println("========================");
	}

	private static double[][] multiplicar(double[][] A, double[][] B) {
		int n = A.length;
		int m = B[0].length;
		double[][] resultado = new double[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				resultado[i][j] = multiplicarVectores(A[i], transponer(B)[j]);
			}
		}
		return resultado;
	}

	private static double multiplicarVectores(double[] v, double[] u) {
		double result = 0;
		for (int i = 0; i < u.length; i++) {
			result += u[i] * v[i];
		}
		return result;
	}

	/*************************************************************************
	 * Compilation: javac GaussianElimination.java Execution: java
	 * GaussianElimination
	 * 
	 * Gaussian elimination with partial pivoting.
	 * 
	 * % java GaussianElimination -1.0 2.0 2.0
	 * 
	 * Copyright © 2000–2011, Robert Sedgewick and Kevin Wayne. Last updated:
	 * Wed Feb 9 09:20:16 EST 2011.
	 * 
	 *************************************************************************/
	private static final double EPSILON = 1e-10;

	// Gaussian elimination with partial pivoting
	public static double[] lsolve(double[][] A, double[] b) {
		int N = b.length;

		for (int p = 0; p < N; p++) {

			// find pivot row and swap
			int max = p;
			for (int i = p + 1; i < N; i++) {
				if (Math.abs(A[i][p]) > Math.abs(A[max][p])) {
					max = i;
				}
			}
			double[] temp = A[p];
			A[p] = A[max];
			A[max] = temp;
			double t = b[p];
			b[p] = b[max];
			b[max] = t;

			// singular or nearly singular
			if (Math.abs(A[p][p]) <= EPSILON) {
				throw new RuntimeException(
						"Matrix is singular or nearly singular");
			}

			// pivot within A and b
			for (int i = p + 1; i < N; i++) {
				double alpha = A[i][p] / A[p][p];
				b[i] -= alpha * b[p];
				for (int j = p; j < N; j++) {
					A[i][j] -= alpha * A[p][j];
				}
			}
		}

		// back substitution
		double[] x = new double[N];
		for (int i = N - 1; i >= 0; i--) {
			double sum = 0.0;
			for (int j = i + 1; j < N; j++) {
				sum += A[i][j] * x[j];
			}
			x[i] = (b[i] - sum) / A[i][i];
		}
		return x;
	}

	/**
	 * Devuelve cuantas medidas tiene este AnalisisModelo.
	 * 
	 * 
	 */
	public int cuantasMedidas() {
		return this.potencias.size();
	}
	
	/**
	 * Devuelve cuantas predicciones tiene este AnalisisModelo.
	 * 
	 */
	public int cuantasPredicciones() {
		return this.predicciones.size();
	}

	@Override
	public String toString() {
		return this.potencias.toString();
	}

	public int cuantoVa() {
		return this.tca.getCuantoVa();
	}

	/**
	 * Devuelve si termino de calcular la atenuación que se mandó con
	 * <code>hacerPredicciones</code>.
	 */
	public boolean termino() {
		return this.termino;
	}

	/**
	 * Devuelve la j-ésima coordenada
	 */
	public Coordinate getCoordenada(int j) {
		return (Coordinate) this.coordenadas.get(j);
	}

	/**
	 * Devuelve la j-ésima predicción.
	 * 
	 * @param j
	 */
	public double getPrediccion(int j) {
		return ((Double) this.predicciones.get(j)).doubleValue();
	}

	/**
	 * Devuelve la j-ésima potencia.
	 */
	public double getPotencia(int j) {
		return ((Double) this.potencias.get(j)).doubleValue();
	}

	/**
	 * Devuelve el nombre de la implementación del modelo con la que se realiza
	 * este análisis.
	 * 
	 */
	public String getModelo() {
		return this.antena.getModelo().nombreImplementacion;
	}
	
	public double[] getPerdidas(){
		return this.perdidas;
	}
	
	public double[] getDistancias(){
		return this.distancias;
	}
	
	public double[] getParamAjuste(){
		return this.paramAjuste;
	}
	
	public Antena getAntena(){
		return this.antena;
	}

}
