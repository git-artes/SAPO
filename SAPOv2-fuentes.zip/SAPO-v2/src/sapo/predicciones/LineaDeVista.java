
package sapo.predicciones;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.geom.Point2D;

import org.geotools.ct.MathTransform2D;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gc.GridCoverage;
import org.geotools.pt.CoordinatePoint;
import org.geotools.pt.Envelope;

import sapo.ifusuario.Mapa;
import sapo.ifusuario.menues.PanelModelos;
import sapo.proyecto.Proyecto;
import sapo.raster.Grilla;
import sapo.red.Antena;
import sapo.red.Radiobase;
import sapo.red.Sitio;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Polygon;

/**
*Esta clase hace la verificación de línea de vista utilizando el criterio 
*de no obstrucción de la primera zona de Fresnel 
*
*@author Grupo de proyecto SAPO
 */
public class LineaDeVista extends Modelo {

	public LineaDeVista() {
		super();
	}

	public LineaDeVista(double[] p1, Object[] p2)
			throws ModeloMalDefinidoException {
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#getParametrosAjustablesPorDefecto()
	 */
	@Override
	protected double[] getParametrosAjustablesPorDefecto() {
		// TODO Auto-generated method stub
		return new double[0];
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#getParametrosNoAjustablesPorDefecto()
	 */
	@Override
	protected Object[] getParametrosNoAjustablesPorDefecto() {
		// TODO Auto-generated method stub
		return new Object[0];
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#setNombres()
	 */
	@Override
	protected void setNombres() {
		this.nombreModelo = "Verificador de Linea de Vista";
		this.nombreParametrosAjustables = new String[] {};
		this.nombreParametrosNoAjustables = new String[] {};

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#verificarDatos(explorer.proyecto.Mapa)
	 */
	@Override
	public boolean verificarDatos(Mapa mapa) {
		return !mapa.getCapaAlturas().esVacia()
				&& !mapa.getCapaEdificios().esVacia();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto,
	 *      explorer.proyecto.Mapa, explorer.red.Antena, double, double, double)
	 */
	//public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa, Antena
	// antena, double radioMax, double perdidaMax, double precision) {
	@Override
	public PrediccionUniAntena predecir(Proyecto proyecto, Mapa mapa,
			Antena antena, double radioMax, double perdidaMax, double precision)
			throws PrediccionMalRealizadaException {
		try {
			if (!this.verificarDatos(mapa)) {
				throw new PrediccionMalRealizadaException(
						"Faltan datos para realizar la predicción con el modelo de Linea de Vista");
			}
			Object[] sitioYRb = proyecto.getSitioYRadioBase(antena);

			Sitio sitio = (Sitio) sitioYRb[0];
			Radiobase rb = (Radiobase) sitioYRb[1];
			double hT = rb.getAltura();
			double hR = proyecto.getPerfilUsuario().getAltura();

			FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();
			Feature f = fc.features().next();
			GridCoverage gc = (GridCoverage) f.getAttribute("grid");
			Envelope envoltura = UtilidadesModelosEdificios.calcularEnvelope(
					this, mapa, radioMax, new Point2D.Double(sitio.getX(),
							sitio.getY()), precision);
			int ancho = Math.round(Math.round(envoltura.toRectangle2D()
					.getWidth()
					/ precision));
			int alto = Math.round(Math.round(envoltura.toRectangle2D()
					.getHeight()
					/ precision));

			MathTransform2D mt = UtilidadesModelos.transformadaParaGrid(
					envoltura, alto, ancho);

			if (envoltura == null)
				throw new PrediccionMalRealizadaException(
						"La envoltura donde puede calcularse el modelo Línea de Vista es nula, verifique los datos");
			Grilla grilla = new Grilla(gc.getCoordinateSystem());

			double potencia = antena.getPotencia();
			double frecuencia = antena.getFrecuencia();
			double[] datos = new double[ancho * alto];
			int contador = 0;
			double minimo = 0;
			double maximo = 2;
			Point2D.Double sitioAntena = new Point2D.Double(sitio.getX(), sitio
					.getY());
			UtilidadesModelosEdificios ume = new UtilidadesModelosEdificios(gc,
					mapa.getCapaEdificios().getFeatureCollection(), radioMax,
					sitioAntena, "altura");
			GeometryFactory gf = new GeometryFactory();

			Point2D sitioMovil;
			for (int j = 0; j < alto; j++) {
				for (int i = 0; i < ancho; i++) {
					//for(int j=0;j<alto;j++){
					Point sitioMovilGrilla = new Point(i, j);
					sitioMovil = mt.transform(new Point(i, j), null);

					LineString ls = gf
							.createLineString(new Coordinate[] {
									new Coordinate(sitioAntena.x, sitioAntena.y),
									new Coordinate(sitioMovil.getX(),
											sitioMovil.getY()) });
					double[] alturaMovil = new double[1];
					alturaMovil = gc.evaluate(sitioMovil, alturaMovil);
					double[] alturas = new double[] {
							ume.getAlturaAntena() + hT, alturaMovil[0] + hR };
					if (ume.calcularDistanciaGrid(mt, sitioAntena,
							sitioMovilGrilla) < radioMax) {
						if (ume.librePrimerFresnelExacto(ls, frecuencia,
								alturas)) {
							datos[contador] = 1;
						} else {
							datos[contador] = Double.NaN;
							//datos[contador] =
							// ume.alturaPromedio(gf.createPoint(new
							// Coordinate(sitioMovil.getX(),
							// sitioMovil.getY())), 100);
						}
					} else {
						datos[contador] = Double.NaN;
					}
					if (datos[contador] < minimo)
						minimo = datos[contador];
					if (datos[contador] > maximo)
						maximo = datos[contador];
					contador++;
					cuantoVa = (int) ((double) contador
							/ ((double) (ancho * alto)) * 100.0);
				}
			}
			grilla.setDatos(gc.getCoordinateSystem(), datos, alto, ancho,
					envoltura);
			PrediccionUniAntena rp = new PrediccionUniAntena(grilla, antena);
			rp.setMax(maximo);
			rp.setMin(minimo);
			return rp;
		} catch (Exception z) {
			z.printStackTrace(System.out);
			throw new PrediccionMalRealizadaException(
					"Hubo un error al realizar la predicción de "
							+ this.getNombre() + ": \n" + z.getMessage());
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#predecir(explorer.proyecto.Proyecto,
	 *      explorer.proyecto.Mapa, explorer.red.Antena,
	 *      com.vividsolutions.jts.geom.Coordinate)
	 */
	@Override
	public double[] predecir(Proyecto proyecto, Mapa mapa, Antena antena,
			Coordinate[] puntos) {
		// TODO Auto-generated method stub
		return new double[] { 0 };
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#areaCalculable(explorer.proyecto.Mapa,
	 *      java.awt.geom.Point2D.Double)
	 */
	@Override
	public Envelope areaCalculable(Mapa mapa, Point2D.Double punto) {

		com.vividsolutions.jts.geom.Envelope envoltorioEdificios = mapa
				.getCapaEdificios().getFeatureCollection().getBounds();
		Envelope envolturaEdificios = new Envelope(new double[] {
				envoltorioEdificios.getMinX(), envoltorioEdificios.getMinY() },
				new double[] { envoltorioEdificios.getMaxX(),
						envoltorioEdificios.getMaxY() });

		FeatureCollection fc = mapa.getCapaAlturas().getFeatureCollection();

		FeatureIterator fi = fc.features();
		boolean esta = false;
		GeometryFactory gf = new GeometryFactory();
		Polygon rectanguloAlturas = gf.createPolygon(gf
				.createLinearRing(new Coordinate[] { new Coordinate(0, 0),
						new Coordinate(1, 0), new Coordinate(1, 1),
						new Coordinate(0, 1), new Coordinate(0, 0) }), null);
		while (fi.hasNext() && esta == false) {
			rectanguloAlturas = ((Polygon) fi.next().getAttribute("geom"));
			esta = rectanguloAlturas.contains(gf.createPoint(new Coordinate(
					punto.x, punto.y))); //me fijo si el punto está en alguno
										 // de los gridcoverages
		}
		if (!esta)
			return null; //si no está, devuelvo null
		Coordinate[] coordenadas = rectanguloAlturas.getExteriorRing()
				.getCoordinates();
		double maxX = -Double.MAX_VALUE;
		double maxY = -Double.MAX_VALUE;
		double minY = Double.MAX_VALUE;
		double minX = Double.MAX_VALUE;
		for (int j = 0; j < coordenadas.length; j++) {
			if (coordenadas[j].x < minX)
				minX = coordenadas[j].x;
			if (coordenadas[j].x > maxX)
				maxX = coordenadas[j].x;
			if (coordenadas[j].y < minY)
				minY = coordenadas[j].y;
			if (coordenadas[j].y > maxY)
				maxY = coordenadas[j].y;
		}
		Envelope envoltura = new Envelope(new CoordinatePoint(minX, minY),
				new CoordinatePoint(maxX, maxY));

		return envoltura;
		/*
		 * Envelope envelopeAux = ((Envelope)envoltura.clone());
		 * envelopeAux.intersect(envolturaEdificios); return envelopeAux;
		 */

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#crearPanelCreacion()
	 */
	@Override
	protected void crearPanelCreacion() {
		this.menu = new MenuLV(new double[0], new Object[0]);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.modelos.Modelo#getPanelCreacion()
	 */
	@Override
	public PanelModelos getPanelCreacion() {
		return this.menu;
	}

	protected class MenuLV extends PanelModelos {

		/**
		 * @param parametrosAjustables
		 * @param parametrosNoAjustables
		 */
		public MenuLV(double[] parametrosAjustables,
				Object[] parametrosNoAjustables) {
			super(parametrosAjustables, parametrosNoAjustables);
			// TODO Auto-generated constructor stub
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosAjustables(double[])
		 */
		@Override
		protected void setParametrosAjustables(double[] parametrosAjustables) {
			// TODO Auto-generated method stub

		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#setParametrosNoAjustables(java.lang.Object[])
		 */
		@Override
		protected void setParametrosNoAjustables(Object[] parametrosNoAjustables) {
			// TODO Auto-generated method stub

		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosAjustables()
		 */
		@Override
		public double[] getParametrosAjustables()
				throws ModeloMalDefinidoException {
			// TODO Auto-generated method stub
			return new double[0];
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#getParametrosNoAjustables()
		 */
		@Override
		public Object[] getParametrosNoAjustables()
				throws ModeloMalDefinidoException {
			// TODO Auto-generated method stub
			return new Object[0];
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#agregarElementos()
		 */
		@Override
		public void agregarElementos() {
			// TODO Auto-generated method stub

		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#getModelo()
		 */
		@Override
		public Modelo getModelo() throws ModeloMalDefinidoException {
			// TODO Auto-generated method stub
			return new LineaDeVista();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see explorer.ifusuario.menues.PanelModelos#getTamanioVentana()
		 */
		public Dimension getTamanioVentana() {
			return new Dimension(400, 160);
		}

	}

}
