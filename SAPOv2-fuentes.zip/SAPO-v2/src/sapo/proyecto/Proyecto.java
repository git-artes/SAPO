package sapo.proyecto;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import sapo.predicciones.Modelo;
import sapo.red.Antena;
import sapo.red.CanalFrecuencias;
import sapo.red.Radiobase;
import sapo.red.Sitio;
import sapo.red.TipoAntena;

/**
 * Esta clase representa un proyecto en SAPO.
 * 
 * @author Grupo de proyecto SAPO
 */
public class Proyecto {

	/**
	 * El nombre del proyecto
	 */
	String nombre;

	/**
	 * El autor del proyecto
	 */
	String autor;

	/**
	 * Campo de texto para observaciones
	 */
	String observaciones;

	/**
	 * La fecha
	 */
	String fecha;

	/**
	 * Lista de modelos dosponibles
	 */
	public ArrayList modelos;

	/**
	 * Lista de sitios creados
	 */
	public ArrayList sitios;

	/**
	 * Lista de tipos de antena disponibles
	 */
	ArrayList<TipoAntena> tiposAntena;

	/**
	 * Lsiat de cnales disponibles
	 */
	ArrayList canales;

	/**
	 * El perfil de usuario del proyecto
	 */
	PerfilUsuario perfil;

	/**
	 * Ubicacion del archivo de alturas
	 */
	URL linkCapaAlturas;

	/**
	 * Ubicacion del archivo de edificios
	 */
	URL linkCapaEdificios;
	/**
	 * Ubicacion del archivo de manzanas
	 */
	URL linkCapaManzanas;

	/**
	 * Ubicacion de los archivos de predicciones
	 */
	ArrayList linksCapaResultados;

	/**
	 * Indica si el proyecto tiene cambios sin guardar
	 */
	boolean cambiosSinGuardar;

	/**
	 * Construye un proyecto vacio
	 * 
	 */
	public Proyecto() {
		nombre = "ProyectoPorDefecto";
		autor = "";
		observaciones = "";
		fecha = new Date().toString();
		modelos = new ArrayList();
		sitios = new ArrayList();
		tiposAntena = new ArrayList();
		canales = new ArrayList();
		perfil = new PerfilUsuario();
		linkCapaAlturas = null;
		linkCapaManzanas = null;
		linkCapaEdificios = null;
		linksCapaResultados = new ArrayList();
		cambiosSinGuardar = false;
	}

	public Proyecto(String nombre) {
		this();
		this.nombre = nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
		cambiosSinGuardar = true;
	}

	public void setAutor(String autor) {
		this.autor = autor;
		cambiosSinGuardar = true;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
		cambiosSinGuardar = true;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
		cambiosSinGuardar = true;
	}

	public void setPerfilUsuario(PerfilUsuario perfil) {
		this.perfil = perfil;
		cambiosSinGuardar = true;
	}

	public PerfilUsuario getPerfilUsuario() {
		return perfil;
	}

	public String getAutor() {
		return autor;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public String getFecha() {
		return fecha;
	}

	public void setLinkCapaAlturas(URL linkCapaAlturas) {
		this.linkCapaAlturas = linkCapaAlturas;
		cambiosSinGuardar = true;
	}

	public void setLinkCapaEdificios(URL linkCapaEdificios) {
		this.linkCapaEdificios = linkCapaEdificios;
		cambiosSinGuardar = true;
	}

	public void setLinkCapaManzanas(URL linkCapaManzanas) {
		this.linkCapaManzanas = linkCapaManzanas;
		cambiosSinGuardar = true;
	}

	public void agregarLinkCapaResultados(URL linkCapaResultados) {
		this.linksCapaResultados.add(linkCapaResultados);
		cambiosSinGuardar = true;
	}

	public void agregarSitio(Sitio sitio) throws SitioRepetidoException {
		if (sitios.indexOf(sitio) != -1) {
			SitioRepetidoException sre;
			if (this.getSitio(sitio.getX(), sitio.getY()) != null) {
				sre = new SitioRepetidoException(
						"Ya existe un sitio con coordenadas ( " + sitio.getX()
								+ " , " + sitio.getY() + " )"
								+ " definido para este proyecto");
			} else {
				sre = new SitioRepetidoException(
						"Ya existe un sitio con el nombre " + sitio.getNombre()
								+ " definido para este proyecto");
			}
			throw sre;
		}
		sitios.add(sitio);
		cambiosSinGuardar = true;
	}

	public void agregarCanal(CanalFrecuencias canal)
			throws CanalRepetidoException {
		if (canales.indexOf(canal) != -1) {
			throw new CanalRepetidoException(
					"Ya existe un canal de frecuencias con el nombre "
							+ canal.getNombre()
							+ " definido para este proyecto");
		}
		canales.add(canal);
		cambiosSinGuardar = true;
	}

	public ArrayList getCanales() {
		return canales;
	}

	public void agregarModelo(Modelo modelo) throws ModeloRepetidoException {
		if (modelos.indexOf(modelo) != -1) {
			throw new ModeloRepetidoException(
					"Ya existe un modelo con el nombre " + modelo.getNombre()
							+ " definido para este proyecto");
		}
		modelos.add(modelo);
		cambiosSinGuardar = true;
	}

	public void agregarTipoAntena(TipoAntena tipoAntena)
			throws TipoAntenaRepetidaException {
		if (tiposAntena.indexOf(tipoAntena) != -1) {
			TipoAntenaRepetidaException tre = new TipoAntenaRepetidaException(
					"Ya existe una tipo de antena con el nombre "
							+ tipoAntena.getNombre()
							+ " definida para este proyecto");
			throw tre;
		}
		tiposAntena.add(tipoAntena);
		cambiosSinGuardar = true;
	}

	public void borrarTipoAntena(TipoAntena tipoAntena) {
		tiposAntena.remove(tipoAntena);
		cambiosSinGuardar = true;
	}

	public void borrarCanal(CanalFrecuencias canal) {
		canales.remove(canal);
		cambiosSinGuardar = true;
	}

	public void borrarModelo(Modelo modelo) {
		modelos.remove(modelo);
		cambiosSinGuardar = true;
	}

	public void borrarSitio(Sitio sitio) {
		sitios.remove(sitio);
		cambiosSinGuardar = true;
	}

	public void quitarModelo(Modelo modelo) {
		modelos.remove(modelo);
		cambiosSinGuardar = true;
	}

	public ArrayList<TipoAntena> getTiposAntena() {
		return tiposAntena;
	}

	public ArrayList getModelos() {
		return modelos;
	}

	public ArrayList getSitios() {
		return sitios;
	}

	public URL getLinkCapaAlturas() {
		return linkCapaAlturas;
	}

	public URL getLinkCapaEdificios() {
		return linkCapaEdificios;
	}

	public URL getLinkCapaManzanas() {
		return linkCapaManzanas;
	}

	public ArrayList getLinksCapaResultados() {
		return linksCapaResultados;
	}

	public String getNombre() {
		return nombre;
	}

	/**
	 * Dada la antena, busca cual es el sitio y radiobase a la que pertenece. En
	 * caso que no exista, devuelve null.
	 * 
	 * @param antena
	 * @return Un array de dos elementos con el primero el sitio y el segundo la
	 *         radiobase.
	 */
	public Object[] getSitioYRadioBase(Antena antena) {
		try {
			Sitio sitio = this.getSitio(antena.getSitio());
			Radiobase rb = sitio.getRadiobase(antena.getRB());
			return new Object[] { sitio, rb };

		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}

	public Sitio getSitio(double x, double y) {
		int i = 0;
		while (i < sitios.size()) {
			Sitio sitio = (Sitio) sitios.get(i);
			if ((sitio.getX() == x) & (sitio.getY() == y)) {
				return sitio;
			}
			i++;
		}
		return null;
	}

	public Sitio getSitio(String nombre) {
		int i = 0;
		while (i < sitios.size()) {
			Sitio sitio = (Sitio) sitios.get(i);
			if (sitio.getNombre().equals(nombre)) {
				return sitio;
			}
			i++;
		}
		return null;
	}

	public CanalFrecuencias getCanal(String nombre) {
		int i = 0;
		while (i < canales.size()) {
			CanalFrecuencias canal = (CanalFrecuencias) canales.get(i);
			if (canal.getNombre().equals(nombre)) {
				return canal;
			}
			i++;
		}
		return null;
	}

	public TipoAntena getTipoAntena(String nombre) {
		int i = 0;
		while (i < tiposAntena.size()) {
			TipoAntena tipoAntena = (TipoAntena) tiposAntena.get(i);
			if (tipoAntena.getNombre().equals(nombre)) {
				return tipoAntena;
			}
			i++;
		}
		return null;
	}

	public Modelo getModelo(String nombre) {
		int i = 0;
		while (i < modelos.size()) {
			Modelo modelo = (Modelo) modelos.get(i);
			if (modelo.getNombre().equals(nombre)) {
				return modelo;
			}
			i++;
		}
		return null;
	}

	/**
	 * Devuelve true si el modelo esta asignado a alguna antena del proyecto
	 * 
	 * @param nombre
	 * @return esta asignado
	 */
	public boolean modeloEstaAsignado(String nombre) {
		ArrayList antenas = new ArrayList();
		ArrayList radiobases;
		if (!sitios.isEmpty()) {
			for (int i = 0; i < sitios.size(); i++) {
				radiobases = ((Sitio) sitios.get(i)).getRadiobases();
				for (int j = 0; j < radiobases.size(); j++) {
					antenas = ((Radiobase) radiobases.get(j)).getAntenas();
					for (int k = 0; k < antenas.size(); k++) {
						if (((Antena) antenas.get(k)).getModelo().getNombre()
								.equals(nombre)) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	/**
	 * Devuelve true si el tipo esta asignado a alguna antena del proyecto
	 * 
	 * @param nombre
	 * @return esta asignado
	 */
	public boolean tipoEstaAsignado(String nombre) {
		ArrayList antenas = new ArrayList();
		ArrayList radiobases;
		if (!sitios.isEmpty()) {
			for (int i = 0; i < sitios.size(); i++) {
				radiobases = ((Sitio) sitios.get(i)).getRadiobases();
				for (int j = 0; j < radiobases.size(); j++) {
					antenas = ((Radiobase) radiobases.get(j)).getAntenas();
					for (int k = 0; k < antenas.size(); k++) {
						if (((Antena) antenas.get(k)).getTipo().getNombre()
								.equals(nombre)) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	/**
	 * Devuelve true si el canal esta asignado a alguna antena del proyecto
	 * 
	 * @param nombre
	 * @return esta asignado
	 */
	public boolean canalEstaAsignado(String nombre) {
		ArrayList antenas = new ArrayList();
		ArrayList radiobases;
		if (!sitios.isEmpty()) {
			for (int i = 0; i < sitios.size(); i++) {
				radiobases = ((Sitio) sitios.get(i)).getRadiobases();
				for (int j = 0; j < radiobases.size(); j++) {
					antenas = ((Radiobase) radiobases.get(j)).getAntenas();
					for (int k = 0; k < antenas.size(); k++) {
						if (((Antena) antenas.get(k)).getCanal().getNombre()
								.equals(nombre)) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	public void setearCanalEnAntenas(String canalAnterior,
			CanalFrecuencias canalNuevo) {
		ArrayList antenas = new ArrayList();
		ArrayList radiobases;
		if (!sitios.isEmpty()) {
			for (int i = 0; i < sitios.size(); i++) {
				radiobases = ((Sitio) sitios.get(i)).getRadiobases();
				for (int j = 0; j < radiobases.size(); j++) {
					antenas = ((Radiobase) radiobases.get(j)).getAntenas();
					for (int k = 0; k < antenas.size(); k++) {
						if (((Antena) antenas.get(k)).getCanal().getNombre()
								.equals(canalAnterior)) {
							((Antena) antenas.get(k)).setCanal(canalNuevo);
							cambiosSinGuardar = true;
						}
					}
				}
			}
		}
	}

	public void setearTipoEnAntenas(String tipoAnterior, TipoAntena tipoNuevo) {
		ArrayList antenas = new ArrayList();
		ArrayList radiobases;
		if (!sitios.isEmpty()) {
			for (int i = 0; i < sitios.size(); i++) {
				radiobases = ((Sitio) sitios.get(i)).getRadiobases();
				for (int j = 0; j < radiobases.size(); j++) {
					antenas = ((Radiobase) radiobases.get(j)).getAntenas();
					for (int k = 0; k < antenas.size(); k++) {
						if (((Antena) antenas.get(k)).getTipo().getNombre()
								.equals(tipoAnterior)) {
							((Antena) antenas.get(k)).setTipo(tipoNuevo);
							cambiosSinGuardar = true;
						}
					}
				}
			}
		}
	}

	public void setearModeloEnAntenas(String modeloAnterior, Modelo modeloNuevo) {
		ArrayList antenas = new ArrayList();
		ArrayList radiobases;
		if (!sitios.isEmpty()) {
			for (int i = 0; i < sitios.size(); i++) {
				radiobases = ((Sitio) sitios.get(i)).getRadiobases();
				for (int j = 0; j < radiobases.size(); j++) {
					antenas = ((Radiobase) radiobases.get(j)).getAntenas();
					for (int k = 0; k < antenas.size(); k++) {
						if (((Antena) antenas.get(k)).getModelo().getNombre()
								.equals(modeloAnterior)) {
							((Antena) antenas.get(k)).setModelo(modeloNuevo);
							cambiosSinGuardar = true;
						}
					}
				}
			}
		}
	}

	/*
	 * public URL getLinkCapaAlturas(){ URL dir = null; if (nomlinkCapaAlturas
	 * != null){ try { if (nomlinkCapaAlturas != ""){
	 * 
	 * dir = new URL (nomlinkCapaAlturas); } } catch (MalformedURLException e) {
	 * // TODO Auto-generated catch block e.printStackTrace(); } } return dir; }
	 */

	/**
	 * Este método indica si el proyecto está en condiciones de poder crear
	 * antenas. Es decir, cuenta con al menos un modelo, un modelo de antena y
	 * un canal de frecuencias.
	 */
	public boolean sePuedeCrearAntenas() {
		return !this.modelos.isEmpty() && !this.tiposAntena.isEmpty()
				&& !this.canales.isEmpty();
	}

	@Override
	public String toString() {
		String resultado = "PROYECTO\n";
		for (int i = 0; i < sitios.size(); i++) {
			resultado = resultado + sitios.get(i).toString() + "\n";
		}
		return resultado;
	}

	public String toStringCanal() {
		String resultado = "CANALES\n";
		for (int i = 0; i < canales.size(); i++) {
			resultado = resultado + canales.get(i).toString() + "\n";
		}
		return resultado;
	}

	/**
	 * Devuelve el xml que representa el proyecto
	 */

	public String getXML() {

		StringBuffer result = new StringBuffer();
		result.append("		   <Proyecto>");
		result.append("        <Nombre>" + nombre + "</Nombre>\r\n");
		result.append("        <Autor>" + autor + "</Autor>\r\n");
		if (!observaciones.equals("")) {
			result.append("        <Observaciones>" + observaciones
					+ "</Observaciones>\r\n");
		} else {
			String nomObs = "null";
			result.append("        <Observaciones>" + nomObs
					+ "</Observaciones>\r\n");

		}
		result.append("        <Fecha>" + fecha + "</Fecha>\r\n");
		// result.append(" <LinkCapaAlturas>" + nomlinkCapaAlturas +
		// "</LinkCapaAlturas>\r\n");
		if (linkCapaAlturas != null) {
			result.append("        <LinkCapaAlturas>"
					+ linkCapaAlturas.toString() + "</LinkCapaAlturas>\r\n");
		} else {
			String nomLinkCapaAlturas = "null";
			result.append("        <LinkCapaAlturas>" + nomLinkCapaAlturas
					+ "</LinkCapaAlturas>\r\n");
		}

		if (linkCapaEdificios != null) {
			result.append("        <LinkCapaEdificios>"
					+ linkCapaEdificios.toString() + "</LinkCapaEdificios>\r\n");
		} else {
			String nomLinkCapaEdificios = "null";
			result.append("        <LinkCapaEdificios>" + nomLinkCapaEdificios
					+ "</LinkCapaEdificios>\r\n");
		}

		if (linkCapaManzanas != null) {
			result.append("        <LinkCapaManzanas>"
					+ linkCapaManzanas.toString() + "</LinkCapaManzanas>\r\n");
		} else {
			String nomLinkCapaCuadras = "null";
			result.append("        <LinkCapaManzanas>" + nomLinkCapaCuadras
					+ "</LinkCapaManzanas>\r\n");
		}

		result.append(perfil.getXML());

		Iterator iterator = sitios.iterator();
		while (iterator.hasNext()) {
			Sitio sitio = (Sitio) iterator.next();
			result.append(sitio.getXML());
		}

		Iterator iteratorMod = modelos.iterator();
		while (iteratorMod.hasNext()) {
			Modelo modelo = (Modelo) iteratorMod.next();
			result.append(modelo.getXML());
		}

		Iterator iteratorCanalF = canales.iterator();
		while (iteratorCanalF.hasNext()) {
			CanalFrecuencias canal = (CanalFrecuencias) iteratorCanalF.next();
			result.append(canal.getXML());
		}

		Iterator iteratorTipoAntena = tiposAntena.iterator();
		while (iteratorTipoAntena.hasNext()) {
			TipoAntena tipoAntena = (TipoAntena) iteratorTipoAntena.next();
			result.append(tipoAntena.getXML());
		}

		Iterator iteratorLinks = linksCapaResultados.iterator();
		while (iteratorLinks.hasNext()) {
			String linkCapaResultados = iteratorLinks.next().toString();
			result.append("        <LinkCapaResultados>");
			result.append("        <Direccion>" + linkCapaResultados
					+ "</Direccion>\r\n");
			result.append("</LinkCapaResultados>\r\n");
		}

		// result.append(" <Predicciones>" + predicciones +
		// "</Predicciones>\r\n");

		result.append("      </Proyecto>\r\n");
		return result.toString();

	}

	/*
	 * public Sitio getSitio(String nombre){ try{ Sitio sitio = new Sitio
	 * (0,0,nombre); if(!sitios.contains(sitio)){ return null; } else return
	 * (Sitio)sitios.get(sitios.indexOf(sitio));
	 * }catch(FeatureSitioMalFormadoException e){ e.printStackTrace(System.out);
	 * return null; } }
	 */

	/**
	 * Avisa que el proyecto fue guardado.
	 */
	public void fueGuardado() {
		this.cambiosSinGuardar = false;
	}

	/**
	 * Devuelve si el proyecto tiene cambios sin guardar.
	 * 
	 * @return
	 */
	public boolean getCambiosSinGuardar() {
		return this.cambiosSinGuardar;
	}

}
