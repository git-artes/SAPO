package sapo.proyecto;

/**
 * Esta excepción es lanzada al agregar un canal al proyecto, si ya existe 
 * uno con el mismo nombre.
 * @author Grupo de proyecto SAPO
 */
public class CanalRepetidoException extends Exception {

	public CanalRepetidoException(String mensaje) {
		super(mensaje);
	}

}
