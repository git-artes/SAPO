package sapo.proyecto;

/**
  * Esta excepción es lanzada al agregar un tipo de antena al proyecto, si ya existe 
  * uno con el mismo nombre.
 * @author Grupo de proyecto SAPO
 */
public class TipoAntenaRepetidaException extends Exception {

	public TipoAntenaRepetidaException(String mensaje) {
		super(mensaje);
	}

}
