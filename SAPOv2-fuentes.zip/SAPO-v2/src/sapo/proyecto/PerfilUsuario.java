package sapo.proyecto;

/**
 * Esta clase representa el perfil de usuario de un proyecto.
 * @author Grupo de proyecto SAPO
 */
public class PerfilUsuario {

	/**
	 * La altura de la antena receptora en metros
	 */
	double altura;

	/**
	 * La sensibilidad de la antena receptora en dBm
	 */
	double sensibilidad;

	/**
	 * La minima relacion Portadora/Interferente admitida
	 */
	double CI;

	/**
	 * Para la capa de resultados, define los valores máximos (de potencia o campo eléctrico, según corresponda) de cada uno de los cinco intervalos a representar.
	 */
	double[] intCapaResults;
	
	boolean intervalosAutomaticos;

	/**
	 * Crea un perfil de usuario con los parametros por defecto
	 */
	public PerfilUsuario() {
		// cambiamos a 10m en vez de 1,5m como se usaba para redes celulares
		this.altura = 10;
		this.sensibilidad = -110;
		this.CI = 0;
		this.intCapaResults = new double[]{-100.0, -80.0, -60.0, -40.0};
//		this.intCapaResults = null;
		this.intervalosAutomaticos = true;
	}

	/**
	 * Crea un perfil de usuario con los parametros especificados
	 */
	public PerfilUsuario(double altura, double sensibilidad, double CI, double[] intervalos)
			throws PerfilUsuarioMalDefinidoException {
		if (altura < 0)
			throw new PerfilUsuarioMalDefinidoException(
					"La altura del móvil no puede ser negativa");
		if (intervalos.length != 4){
			throw new PerfilUsuarioMalDefinidoException(
					"La cantidad debe ser igual a 4.");
		}
		this.altura = altura;
		this.sensibilidad = sensibilidad;
		this.CI = CI;
		this.intCapaResults = intervalos;
		this.intervalosAutomaticos = false;
	}
	
	public PerfilUsuario(double altura, double sensibilidad, double CI)
			throws PerfilUsuarioMalDefinidoException {
		if (altura < 0)
			throw new PerfilUsuarioMalDefinidoException(
					"La altura del móvil no puede ser negativa");
		this.altura = altura;
		this.sensibilidad = sensibilidad;
		this.CI = CI;
		this.intervalosAutomaticos = true;
		this.intCapaResults = new double[]{-100.0, -80.0, -60.0, -40.0};  //TODO: Ver si funca al agregar esto!!!
	}
	
	/**
	 * Devuelve la altura del receptor en metros
	 */
	public double getAltura() {
		return altura;
	}

	/**
	 *Devuelve la sensibilidad en dBm
	 */
	public double getSensibilidad() {
		return sensibilidad;
	}

	/**
	 * Devuelve el C/I
	 */
	public double getCI() {
		return CI;
	}
	
	public double[] getIntCapaResults() {
		return intCapaResults;
	}
	
	public boolean intAutomaticos(){
		return intervalosAutomaticos;
	}
	

	/**
	 * Devuelve el xml que representa este objeto a fin de ser guardado en un
	 * proyecto
	 */
	
	public String getXML() {

		StringBuffer result = new StringBuffer("<PerfilUsuario>");
		result.append("          <Altura>" + altura + "</Altura>\r\n");
		result.append("          <Sensibilidad>" + sensibilidad
				+ "</Sensibilidad>\r\n");
		result.append("          <CI>" + CI + "</CI>\r\n");
		
		StringBuffer result1 = new StringBuffer("<IntervalosCapaResultados>");
		for (int i = 0; i < intCapaResults.length; i++) {
			result1.append("        <LimiteIntervalo>" + intCapaResults[i]
					+ "</LimiteIntervalo>\r\n");
		}
		result1.append("        </IntervalosCapaResultados>\r\n");
		result.append(result1.toString());
		
		result.append("          <intervalosAuto>" + intervalosAutomaticos + "</intervalosAuto>\r\n");
		
		result.append("        </PerfilUsuario>\r\n");
		return result.toString();

	}
}
