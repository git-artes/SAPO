package sapo.proyecto;

/**
 * Esta excepción es lanzada al agregar una implementación de un modelo al proyecto, si ya existe 
 * una con el mismo nombre.
 * 
 * @author Grupo de proyecto SAPO
 */
public class ModeloRepetidoException extends Exception {

	public ModeloRepetidoException(String mensaje) {
		super(mensaje);
	}

}
