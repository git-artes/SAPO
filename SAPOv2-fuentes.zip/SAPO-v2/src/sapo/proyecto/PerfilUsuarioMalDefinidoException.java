package sapo.proyecto;

/**
 * Esta excepción es lanzada al definir el perfil de usuario, 
 * si la altura del receptor es negativa.
 * @author Grupo de proyecto SAPO
 */
public class PerfilUsuarioMalDefinidoException extends Exception {

	public PerfilUsuarioMalDefinidoException(String mensaje) {
		super(mensaje);
	}

}
