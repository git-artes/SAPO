package sapo.proyecto;

/**
 * Esta excepción es lanzada al agregar un sitio al proyecto, si ya 
 * existe uno con el mismo nombre y/o con las mismas coordenadas.
 * 
 * @author Grupo de proyecto SAPO
 */
public class SitioRepetidoException extends Exception {

	SitioRepetidoException(String mensaje) {
		super(mensaje);
	}

}
