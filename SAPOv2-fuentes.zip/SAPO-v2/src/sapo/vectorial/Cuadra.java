package sapo.vectorial;

import org.geotools.factory.FactoryConfigurationError;
import org.geotools.feature.AttributeType;
import org.geotools.feature.AttributeTypeFactory;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureType;
import org.geotools.feature.FeatureTypeFactory;
import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;

import sapo.capas.ElementoCapa;

import com.vividsolutions.jts.geom.LineString;

/**
 * Esta clase representa una cuadra de una manzana. Es utilizada en el Generador de Edificios. 
 * @author Grupo de Proyecto SAPO.
 *  
 */
public class Cuadra implements ElementoCapa {

	Feature fCuadra;

	/**
	 * Construye una cuadra a partir del Feature
	 */
	
	public Cuadra(Feature fCuadra) {
		this.fCuadra = fCuadra;
	}

	/**
	 * 	Construye una cuadra a partir del linestring
	 * y genera el feature correspondiente. 
	 * @throws SchemaException 
	 * @throws FactoryConfigurationError 
	 * @throws IllegalAttributeException 
	 */
	public Cuadra(LineString cuadra) throws FactoryConfigurationError, SchemaException, IllegalAttributeException {
		AttributeType atribCuadra = AttributeTypeFactory.newAttributeType(
				"cuadraElegida", LineString.class);
		FeatureType ftCuadra = FeatureTypeFactory.newFeatureType(
				new AttributeType[] { atribCuadra }, "cuadraAtrib");
		fCuadra = ftCuadra.create(new Object[] { cuadra }, "cuadraElegida");
	}

	@Override
	public Feature getFeature() {
		return fCuadra;
	}

}
