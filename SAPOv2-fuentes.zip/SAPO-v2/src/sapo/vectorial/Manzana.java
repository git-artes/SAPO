package sapo.vectorial;

import org.geotools.factory.FactoryConfigurationError;
import org.geotools.feature.AttributeType;
import org.geotools.feature.AttributeTypeFactory;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureType;
import org.geotools.feature.FeatureTypeFactory;
import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;

import sapo.capas.ElementoCapa;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryCollection;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.LinearRing;
import com.vividsolutions.jts.geom.MultiLineString;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.operation.buffer.BufferOp;

/**
 * Esta clase representa una manzana.
 * @author Grupo de proyecto SAPO
 */
public class Manzana implements ElementoCapa {

	Feature fManzana;

	private Coordinate[][] cuadra;

	private double[] anchos;

	/**
	 * Construye una manzana a partir del Feature
	 */
	public Manzana(Feature ft) {
		this.fManzana = ft;
	}

	/*
	 *  (non-Javadoc)
	 * @see sapo.capas.ElementoCapa#getFeature()
	 */
	@Override
	public Feature getFeature() {
		return fManzana;
	}

	/**
	 * Construye una manzana a partir de un poligono y genera el feature correspondiente.
	 * @throws SchemaException 
	 * @throws FactoryConfigurationError 
	 * @throws IllegalAttributeException 
	 */
	public Manzana(Polygon manzana) throws FactoryConfigurationError, SchemaException, IllegalAttributeException {
		AttributeType geom = AttributeTypeFactory.newAttributeType("the_geom",
				Polygon.class);
		FeatureType ftSeleccion = FeatureTypeFactory.newFeatureType(
				new AttributeType[] { geom }, "seleccion");
		fManzana = ftSeleccion.create(new Object[] { manzana }, "seleccionado");

	}

	public void setAnchos(double[] anchos) {
		this.anchos = anchos;
	}

	public void setBloque(Coordinate[][] cuadrado) {
		cuadra = cuadrado;
	}

	public Coordinate[][] getBloque() {
		return cuadra;
	}


	public double[] getAnchos() {
		return anchos;
	}

	/**
	 * Construye una manzana a partir de los anchos de las calles y las 
	 * coordenadas de las esquinas, y genera el feature correspondiente.
	 * @throws SchemaException 
	 * @throws FactoryConfigurationError 
	 * @throws IllegalAttributeException 
	 */
	public Manzana(Coordinate[][] cuadrado, double[] anchos) throws FactoryConfigurationError, SchemaException, IllegalAttributeException {
		cuadra = cuadrado;
		this.anchos = anchos;

		//esto era crearManzana:
		Polygon manzana;
		Polygon[] polygons = new Polygon[anchos.length];
		LineString aux;
		GeometryFactory aux2 = new GeometryFactory();

		boolean sonTodosCero = true;
		for (int j = 0; j < anchos.length; j++) {
			if (anchos[j] != 0)
				sonTodosCero = false;
		}

		if (!sonTodosCero) {
			for (int i = 0; i < anchos.length; i++) {
				aux = aux2.createLineString(cuadra[i]);
				BufferOp bufOp = new BufferOp(aux);
				bufOp.setEndCapStyle(BufferOp.CAP_SQUARE);
				Double doble = new Double(anchos[i]);
				double doble2 = doble.doubleValue();
				polygons[i] = (Polygon) bufOp.getResultGeometry(doble2 / 2);
			}
			GeometryCollection polygonCollection = aux2
					.createGeometryCollection(polygons);
			Polygon union = (Polygon) polygonCollection.buffer(0);
			MultiLineString total = (MultiLineString) union.getBoundary();
			manzana = aux2.createPolygon((LinearRing) total.getGeometryN(total
					.getNumGeometries() - 1), null);
		} else {
			Coordinate[] coordenadas = new Coordinate[anchos.length + 1];
			for (int j = 0; j < anchos.length; j++) {
				coordenadas[j] = cuadra[j][0];
			}
			coordenadas[anchos.length] = cuadra[0][0];
			manzana = aux2.createPolygon(aux2.createLinearRing(coordenadas),
					null);
		}

		AttributeType geom = AttributeTypeFactory.newAttributeType("the_geom",
				Polygon.class);
		FeatureType ftRoad = FeatureTypeFactory.newFeatureType(
				new AttributeType[] { geom }, "manzana");
		fManzana = ftRoad.create(new Object[] { manzana }, "Manzana"
				+ Math.random());

	}

}
