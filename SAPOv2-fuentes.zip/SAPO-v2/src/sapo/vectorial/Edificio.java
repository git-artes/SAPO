package sapo.vectorial;

import org.geotools.factory.FactoryConfigurationError;
import org.geotools.feature.AttributeType;
import org.geotools.feature.AttributeTypeFactory;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureType;
import org.geotools.feature.FeatureTypeFactory;
import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;

import sapo.capas.ElementoCapa;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Polygon;

/**
 * Est aclase representa un edificio.
 * @author Grupo de proyecto SAPO
 */
public class Edificio implements ElementoCapa {

	Feature fEdificio;

	/*
	 * Polygon seleccion; Polygon edificio; double altura;
	 * 
	 * public int contador;
	 */
	final int MAX_ALTURA = 100;

	/**
	 * Construye un edificio a partir del Feature
	 */
	public Edificio(Feature ft) {
		this.fEdificio = ft;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see explorer.capas.ElementoCapa#getFeature()
	 */
	@Override
	public Feature getFeature() {
		return fEdificio;
	}

	/**
	 * 	Construye un edificio a partir del poligono y la altura, 
	 * y genera el feature correspondiente.
	 * @throws SchemaException 
	 * @throws FactoryConfigurationError 
	 * @throws IllegalAttributeException 
	 */
	public Edificio(Polygon edificio, double altura, String manzana) throws FactoryConfigurationError, SchemaException, IllegalAttributeException{
		AttributeType geom = AttributeTypeFactory.newAttributeType("the_geom",
				Polygon.class);
		AttributeType atribAltura = AttributeTypeFactory.newAttributeType(
				"altura", Double.class);
		FeatureType ftEdificio = FeatureTypeFactory.newFeatureType(
				new AttributeType[] { geom, atribAltura }, "edificio");

		String aux = Long.toHexString(Math.round(altura * 255 / MAX_ALTURA));
		if (aux.length() == 1)
			aux = "0" + aux;
		String color;
		color = "#" + aux + aux + aux;

		if (altura > MAX_ALTURA)
			color = "#ffffff";

		fEdificio = ftEdificio.create(new Object[] { edificio,
				new Double(altura) }, "edificio" + Math.random());
		fEdificio.setDefaultGeometry(edificio);

	}

	/**
	 * 	Construye un edificio solamente a partir del poligono, sin importar la altura.
	 * Se utiliza para la seleccion de un edificio.
	 * @throws SchemaException 
	 * @throws FactoryConfigurationError 
	 * @throws IllegalAttributeException 
	 */
	public Edificio(Polygon edificio) throws FactoryConfigurationError, SchemaException, IllegalAttributeException {
		AttributeType geom = AttributeTypeFactory.newAttributeType("the_geom",
				Polygon.class);
		FeatureType ftSeleccion = FeatureTypeFactory.newFeatureType(
				new AttributeType[] { geom }, "seleccion");
		fEdificio = ftSeleccion.create(new Object[] { edificio },
				"seleccionado");
	}

	public static String getString(Polygon edificio) {
		String resultado = "Edificio [";
		Coordinate[] vertices = edificio.getCoordinates();
		for (int j = 0; j < Math.min(vertices.length - 1, 5); j++) {
			resultado = resultado + "("
					+ String.valueOf(Math.round(vertices[j].x * 100) / 100)
					+ ","
					+ String.valueOf(Math.round(vertices[j].y * 100) / 100)
					+ ")";
		}
		if (vertices.length > 5)
			resultado = resultado + "...";
		resultado = resultado + "]";
		return resultado;
	}

}
