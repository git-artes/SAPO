package sapo.vectorial;

import org.geotools.factory.FactoryConfigurationError;
import org.geotools.feature.AttributeType;
import org.geotools.feature.AttributeTypeFactory;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureType;
import org.geotools.feature.FeatureTypeFactory;
import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;

import sapo.capas.ElementoCapa;

import com.vividsolutions.jts.geom.Point;

/**
 * Esta clase representa una esquina de una manzana. Es utilizada en el Generador de Edificios. 
 * @author Grupo de Proyecto SAPO.
 *  
 */
public class Esquina implements ElementoCapa {

	Feature fEsquina;

	/**
	 * Construye una esquina a partir del Feature
	 */
	public Esquina(Feature fEsquina) {
		this.fEsquina = fEsquina;
	}

	/*
	 *  (non-Javadoc)
	 * @see sapo.capas.ElementoCapa#getFeature()
	 */
	@Override
	public Feature getFeature() {
		return fEsquina;
	}

	/**
	 * Construye una esquina a partir de un punto y genera el feature correspondiente.
	 * @throws SchemaException 
	 * @throws FactoryConfigurationError 
	 * @throws IllegalAttributeException 
	 */
	public Esquina(Point punto) throws FactoryConfigurationError, SchemaException, IllegalAttributeException {
		AttributeType atribPunto = AttributeTypeFactory.newAttributeType(
				"esquinaElegida", Point.class);
		FeatureType ftPunto = FeatureTypeFactory.newFeatureType(
				new AttributeType[] { atribPunto }, "puntoAtrib");
		fEsquina = ftPunto.create(new Object[] { punto }, "puntoElegido");
	}

}
