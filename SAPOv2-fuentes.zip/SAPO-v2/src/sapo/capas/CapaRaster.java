package sapo.capas;

import java.io.IOException;

import org.geotools.feature.FeatureCollection;
import org.geotools.gc.GridCoverage;

import sapo.raster.Grilla;

/**
 *Esta clase constituye la base para la creación de capas constituidas por datos 
 *del tipo raster.
 * @author Grupo de proyecto SAPO
 */

public class CapaRaster extends Capa {

	/**
	 * La ultima grilla agregada a la capa
	 */
	Grilla grilla;

	/**
	 * Crea la capa con una FeatureCollection vacia y setea el estilo

	 */

	public CapaRaster() throws IOException {
		super();
	}

	/**
	 * Crea la capa con la FeatureCollection dada
	 */
	public CapaRaster(FeatureCollection fc) throws IOException {
		super(fc);
	}

	/**
	 * Devuelve el grid coverage
	 */

	public GridCoverage getGridCoverage() {
		return (GridCoverage) getFeatureCollection().features().next()
				.getAttribute("grid");
	}

	/**
	 * Agrega un ElementoCapa (Grilla) a la FeatureCollection y fija el estilo
	 * nuevamente.
	 */
	@Override
	public void agregar(ElementoCapa elemento) throws IOException {
		super.agregar(elemento);
		this.grilla = (Grilla) elemento;
		this.recargarEstilo();
	}

	/**
	 * Devuelve la Grilla
	 */
	public Grilla getGrilla() {
		return grilla;
	}

}
