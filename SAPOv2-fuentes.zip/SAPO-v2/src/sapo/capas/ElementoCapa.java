package sapo.capas;

import org.geotools.cs.CoordinateSystem;
import org.geotools.feature.Feature;

/**
 * Esta interfaz debe ser implementada por cualquier elemento que pretenda ser aï¿œadido
 * a una capa.
 * @author Grupo de proyecto SAPO
 */

public interface ElementoCapa {

	/**
	 * Devuelve un feature
	 * 
	 * @return Feature
	 */
	public Feature getFeature();
		
}
