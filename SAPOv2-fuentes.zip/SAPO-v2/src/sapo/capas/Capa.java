package sapo.capas;
import java.io.IOException;

import org.geotools.data.DataUtilities;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureCollections;
import org.geotools.map.DefaultMapLayer;
import org.geotools.styling.StyleBuilder;

/**
 * Esta clase constituye la base para la creación de capas a añadir al mapa.
 * @author Grupo de proyecto SAPO
 */

public class Capa extends DefaultMapLayer {

	/**
	 * La FeatureCollection de la capa
	 */
	FeatureCollection fc = FeatureCollections.newCollection();

	/**
	 * Crea la capa con una FeatureCollection vacia
	 */
	public Capa() throws IOException {
		super(FeatureCollections.newCollection(), new StyleBuilder()
				.createStyle());
		fc = getFeatureSource().getFeatures().collection();
	}

	/**
	 * Crea la capa con la FeatureCollection dada
	 */
	public Capa(FeatureCollection fc) throws IOException {
		super(fc, new StyleBuilder().createStyle());
		fc = getFeatureSource().getFeatures().collection();
	}

	/**
	 * Devuelve la FeatureCollection de esta Capa
	 */
	public FeatureCollection getFeatureCollection() {
		return fc;
	}

	/**
	 * Agrega un ElementoCapa a la FeatureCollection y fija el estilo
	 * nuevamente. Esto puede ser re-escrito por las clases que la extiendan
	 * para ser más eficiente.
	 * 
	 * @param el ElementoCapa a agregar
	 */
	public void agregar(ElementoCapa elemento) throws IOException {
		fc = featureSource.getFeatures().collection();
		fc.add(elemento.getFeature());
		this.featureSource = DataUtilities.source(fc);
		this.setStyle(this.getStyle());
	}
	
	/**
	 * Quita el ElementoCapa de la FeatureCollection y fija el estilo
	 * nuevamente. Esto puede ser re-escrito por las clases que la extiendan
	 * para ser más eficiente.
	 * 
	 * @param el
	 *            ElementoCapa a quitar
	 */
	public void quitar(ElementoCapa elemento) {
		fc.remove(elemento.getFeature());
		this.featureSource = DataUtilities.source(fc);
		this.setStyle(this.getStyle());
	}

	/**
	 * Indica si un determinado elemento esta incluido en la FeatureCollection
	 */
	public boolean contiene(ElementoCapa elemento) {
		return fc.contains(elemento.getFeature());
	}

	/**
	 * Indica si la FeatureCollection es vacía
	 */
	public boolean esVacia() {
		return fc.isEmpty();
	}

	/**
	 * Vacia la FeatureCollection de esta capa.
	 */
	public void vaciar() {
		fc.clear();
		this.featureSource = DataUtilities.source(fc);
		this.setStyle(this.getStyle());
	}

	/**
	 * Devuelve el tamaño de la FeatureCollection
	 */
	public int tamanio() {
		return fc.size();
	}

	/**
	 * Recarga la interfaz
	 */
	public void recargarEstilo() {
		this.setStyle(this.getStyle());
	}

}
