package sapo.capas;

import java.io.IOException;

import org.geotools.data.DataUtilities;
import org.geotools.feature.FeatureCollection;

/**
 *Esta clase constituye la base para la creaciï¿œn de capas constituidas por datos 
 *del tipo vectorial.
 * @author Grupo de proyecto SAPO
 */

public class CapaVectorial extends Capa {

	/**
	 * Crea la capa con una FeatureCollection vacia y setea el estilo

	 */
	
	public CapaVectorial() throws IOException {
		super();
	}


	/**
	 * Crea la capa con la FeatureCollection dada
	 */
	public CapaVectorial(FeatureCollection fc) throws IOException {
		super(fc);
	}

	/**
	 * Sobreescribe el mï¿œtodo del padre. Solamente agrega el elemento a la
	 * colecciï¿œn. La fijaciï¿œn del estilo debe hacerse por fuera.
	 * 
	 * @param elemento 
	 *            el elemento a agregar
	 */
//	public void agregar(ElementoCapa elemento) throws IOException {
//		fc = featureSource.getFeatures().collection();
//		fc.add(elemento.getFeature());
//		this.featureSource = DataUtilities.source(fc);
//	}
	
	
	public void agregar(ElementoCapa elemento, FeatureCollection fc) throws IOException {
		fc.add(elemento.getFeature());
		this.featureSource = DataUtilities.source(fc);
	}

	/**
	 * Sobreescribe el mï¿œtodo del padre. Solamente quita el elemento a la
	 * colecciï¿œn. La fijaciï¿œn del estilo debe hacerse por fuera.
	 * 
	 * @param elemento 
	 *            el elemento a quitar
	 */
	@Override
	public void quitar(ElementoCapa elemento) {
		fc.remove(elemento.getFeature());
	}

}
