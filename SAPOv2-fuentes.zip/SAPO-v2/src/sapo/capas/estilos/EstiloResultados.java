package sapo.capas.estilos;

import java.awt.Color;

import org.geotools.styling.ColorMap;
import org.geotools.styling.FeatureTypeStyle;
import org.geotools.styling.RasterSymbolizer;
import org.geotools.styling.Style;
import org.geotools.styling.StyleBuilder;
import org.geotools.styling.StyleVisitor;

/**
 * Esta clase define el estilo de la capa de predicciones.
 * @author Grupo de proyecto SAPO
 */

public class EstiloResultados implements Style {

	/**
	 * El estilo
	 */
	private Style estilo;

	/**
	 * El valor maximo
	 */
	double max = 80;
/**
 * El valor minimo
 */
	double min = 0;

	/**
	 * Eml mapa de colores
	 */
	ColorMap cm;

	/**
	 *  La paleta de colores
	 */
	Color[] colores;
	
	/**
	 *  Nivel de transparencia de la capa [0-255], siendo 255 totalmente transparente y 0 totalmente opaco.
	 */
	int alpha = 127;
	
	
	
	/**
	 * Construye el estilo para representar los resultados de potencia
	 *  
	 */
	public EstiloResultados() {
		StyleBuilder sb = new StyleBuilder();
		RasterSymbolizer rs = sb.createRasterSymbolizer();
		
		colores = new Color[] {
//GM: Colores SAPO v1: blanco, amarillo, anaranjado, marron, negro  
//				new Color(255, 255, 255), new Color(255, 255, 0),
//				new Color(255, 127, 0), new Color(191, 127, 63),
//				new Color(0, 0, 0) };

				// GM: Colores SAPO TV: negro, azul, turquesa, rojo
				new Color(0, 0, 0, alpha),
				new Color(0, 0, 255, alpha),
				new Color(0, 206, 255, alpha), 
				new Color(255, 255, 0, alpha),
				new Color(255, 0, 0, alpha),
				new Color(255, 0, 0, alpha) };
		
		this.

		cm = sb.createColorMap(new double[] { min, min + (max - min) / 5,
				min + 2 * (max - min) / 5, min + 3 * (max - min) / 5, min + 4 * (max - min) / 5, max},
				colores, ColorMap.TYPE_INTERVALS);
		rs.setColorMap(cm);
//		rs.setOpacity(sb.literalExpression(0.1));
		estilo = sb.createStyle(rs);
	}

	/**
	 * Devuelve el estilo
	 * 
	 * 	 */
	public Style getEstilo() {
		return this;
	}

	/**
	 * Fija el mï¿œximo valor visible del resultado de predicciï¿œn.

	 */
	public void setMax(double max) {
		this.max = max;
		StyleBuilder sb = new StyleBuilder();
		RasterSymbolizer rs = sb.createRasterSymbolizer();
		cm = sb.createColorMap(new double[] { min, min + (max - min) / 5,
				min + 2 * (max - min) / 5, min + 3 * (max - min) / 5, min + 4 * (max - min) / 5, max},
				colores, ColorMap.TYPE_INTERVALS);
		rs.setColorMap(cm);
		rs.setOpacity(sb.literalExpression(0.1));
		estilo = sb.createStyle(rs);
	}

	/**
	 * Fija el valor mï¿œnimo posible del resultado de predicciï¿œn.

	 */
	public void setMin(double min) {
		this.min = min;
		StyleBuilder sb = new StyleBuilder();
		RasterSymbolizer rs = sb.createRasterSymbolizer();
		cm = sb.createColorMap(new double[] { min, min + (max - min) / 5,
				min + 2 * (max - min) / 5, min + 3 * (max - min) / 5, min + 4 * (max - min) / 5, max},
				colores, ColorMap.TYPE_INTERVALS);
		rs.setColorMap(cm);
		rs.setOpacity(sb.literalExpression(0.1));
		estilo = sb.createStyle(rs);
	}

	/**
	 * Son los mï¿œximos y mï¿œnimos visibles de los resultados de predicciï¿œn de
	 * atenuaciï¿œn.

	 */
	public void setMaxMin(double max, double min) {
		this.setMax(max);
		this.setMin(min);
	}

	/**
	 * Devuelve el colormap utilizado por el estilo

	 */

	public ColorMap getCM() {
		return cm;
	}

	/**
	 * Devuelve los colores usados por el colormap

	 */

	public Color[] getColores() {
		return colores;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getName()
	 *  
	 */

	public String getName() {
		return estilo.getName();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setName(java.lang.String)
	 */
	public void setName(String arg0) {
		estilo.setName(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getTitle()
	 *  
	 */

	public String getTitle() {
		return estilo.getTitle();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setTitle(java.lang.String)
	 */
	public void setTitle(String arg0) {
		estilo.setTitle(arg0);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getAbstract()
	 *  
	 */

	public String getAbstract() {
		return estilo.getAbstract();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setAbstract(java.lang.String)
	 */
	public void setAbstract(String arg0) {
		estilo.setAbstract(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#isDefault()
	 *  
	 */

	public boolean isDefault() {
		return estilo.isDefault();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setIsDefault(boolean)
	 */
	public void setIsDefault(boolean arg0) {
		estilo.setIsDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setDefault(boolean)
	 */
	public void setDefault(boolean arg0) {
		estilo.setDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getFeatureTypeStyles()
	 *  
	 */

	public FeatureTypeStyle[] getFeatureTypeStyles() {
		return estilo.getFeatureTypeStyles();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setFeatureTypeStyles(org.geotools.styling.FeatureTypeStyle[])
	 */
	public void setFeatureTypeStyles(FeatureTypeStyle[] arg0) {
		estilo.setFeatureTypeStyles(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#addFeatureTypeStyle(org.geotools.styling.FeatureTypeStyle)
	 */
	public void addFeatureTypeStyle(FeatureTypeStyle arg0) {
		estilo.addFeatureTypeStyle(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#accept(org.geotools.styling.StyleVisitor)
	 */
	public void accept(StyleVisitor arg0) {
		estilo.accept(arg0);
	}
	
	public void setColorMap(double max, double min, double[] intervalos){
//		if(intervalos[0] < min){
//			intervalos[0] = min + 10.0;
//		}
//		if(intervalos[3] > max){
//			intervalos[3] = max - 10.0;
//		}
		if(intervalos[0] < min){
			this.min = intervalos[0] - 10;
		}else{
			this.min = min;
		}
		if(intervalos[3] > max){
			this.max = intervalos[3] + 10;
		}else{
			this.max = max;
		}
		
		StyleBuilder sb = new StyleBuilder();
		RasterSymbolizer rs = sb.createRasterSymbolizer();
		cm = sb.createColorMap(new double[] { this.min, intervalos[0],
				intervalos[1], intervalos[2], intervalos[3], this.max},
				colores, ColorMap.TYPE_INTERVALS);
		rs.setColorMap(cm);
		rs.setOpacity(sb.literalExpression(0.1));
		estilo = sb.createStyle(rs);
	}

}
