package sapo.capas.estilos;

import java.awt.Color;

import org.geotools.filter.IllegalFilterException;
import org.geotools.styling.FeatureTypeStyle;
import org.geotools.styling.Fill;
import org.geotools.styling.PolygonSymbolizer;
import org.geotools.styling.Style;
import org.geotools.styling.StyleBuilder;
import org.geotools.styling.StyleFactory;
import org.geotools.styling.StyleVisitor;
import org.geotools.styling.Symbolizer;

/**
 * Esta clase define el estilo de la capa de edificios.
 * @author Grupo de proyecto SAPO
 */

public class EstiloEdificios implements Style {

	/**
	 * EL estilo
	 * 
	 */
	private Style estilo;

	/**
	 * Construye el estilo para respresentar edificios (poligonos).
	 *  
	 */
	public EstiloEdificios(){
		this(false);
	}

	/**
	 * Construye el estilo para respresentar edificios cuando estan seleccionados
	 *  
	 */
	public EstiloEdificios(boolean seleccionado) {
		if (!seleccionado) {
			StyleBuilder sb = new StyleBuilder();
			PolygonSymbolizer poligonos = sb.createPolygonSymbolizer(
					Color.GREEN, Color.BLACK, 1);
			poligonos.getFill().setOpacity(sb.literalExpression(.7));
			estilo = sb.createStyle(poligonos);
		} else {
			StyleBuilder sb = new StyleBuilder();
			PolygonSymbolizer poligonos = sb.createPolygonSymbolizer(
			//Color.BLUE,
					Color.RED, 2);
			//poligonos.getFill().setOpacity(sb.literalExpression(0));
			estilo = sb.createStyle(poligonos);
		}
	}

	/**
	 * Devuelve un estilo con tonos dependientes de la altura. Requiere un atributo 
	 * especial en los edificios ("color"). No se usa.
	 * @throws IllegalFilterException 
	 */
	public static Style getEstiloAlturas() throws IllegalFilterException {
		StyleBuilder sb = new StyleBuilder();
		//FilterFactory ff = sb.getFilterFactory();
		StyleFactory sf = StyleFactory.createStyleFactory();
		Style estilo = sb.createStyle();

		// Estilo para los Features "Edificios"

		PolygonSymbolizer ps = sb.createPolygonSymbolizer(Color.GREEN,
				Color.BLACK, 2);

		Fill f = sf.getDefaultFill();
		f.setColor(sb.attributeExpression("color"));
		//f.setBackgroundColor(sb.attributeExpression("color"));
		f.setOpacity(sb.literalExpression(0.5));
		ps.setFill(f);

		//short d = sb.attributeExpression("altura");
		//System.out.println("ATRIBUTO ALTURA "+d);
		//double dd = d/100;
		//if (dd>1) dd=1;
		//ps.getFill().setOpacity(sb.literalExpression(1));

		estilo.addFeatureTypeStyle(sb.createFeatureTypeStyle("edificio",
				new Symbolizer[] { ps }));
		return estilo;
	}

	/**
	 * Devuelve le estilo
	 */
	public Style getEstilo() {
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getName()
	 *  
	 */
	@Override
	public String getName() {
		return estilo.getName();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setName(java.lang.String)
	 */
	@Override
	public void setName(String arg0) {
		estilo.setName(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getTitle()
	 *  
	 */
	@Override
	public String getTitle() {
		return estilo.getTitle();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setTitle(java.lang.String)
	 */
	@Override
	public void setTitle(String arg0) {
		estilo.setTitle(arg0);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getAbstract()
	 *  
	 */
	@Override
	public String getAbstract() {
		return estilo.getAbstract();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setAbstract(java.lang.String)
	 */
	@Override
	public void setAbstract(String arg0) {
		estilo.setAbstract(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#isDefault()
	 *  
	 */

	@Override
	public boolean isDefault() {
		return estilo.isDefault();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setIsDefault(boolean)
	 */
	@Override
	public void setIsDefault(boolean arg0) {
		estilo.setIsDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setDefault(boolean)
	 */
	@Override
	public void setDefault(boolean arg0) {
		estilo.setDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getFeatureTypeStyles()
	 *  
	 */

	@Override
	public FeatureTypeStyle[] getFeatureTypeStyles() {
		return estilo.getFeatureTypeStyles();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setFeatureTypeStyles(org.geotools.styling.FeatureTypeStyle[])
	 */
	@Override
	public void setFeatureTypeStyles(FeatureTypeStyle[] arg0) {
		estilo.setFeatureTypeStyles(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#addFeatureTypeStyle(org.geotools.styling.FeatureTypeStyle)
	 */
	@Override
	public void addFeatureTypeStyle(FeatureTypeStyle arg0) {
		estilo.addFeatureTypeStyle(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#accept(org.geotools.styling.StyleVisitor)
	 */
	@Override
	public void accept(StyleVisitor arg0) {
		estilo.accept(arg0);
	}

}
