package sapo.capas.estilos;

import org.geotools.styling.FeatureTypeStyle;
import org.geotools.styling.RasterSymbolizer;
import org.geotools.styling.Style;
import org.geotools.styling.StyleBuilder;
import org.geotools.styling.StyleVisitor;

/**
 * Esta clase define el estilo de la capa de alturas.
 * @author Grupo de proyecto SAPO
 */

public class EstiloAlturas implements Style {

	/**
	 * El estilo
	 * 

	 */
	private Style estilo;

	/**
	 * Construye el estilo para respresentar los datos de altura (raster)
	 */
	public EstiloAlturas() {
		StyleBuilder sb = new StyleBuilder();
		RasterSymbolizer rs = sb.createRasterSymbolizer();
		rs.setOpacity(sb.literalExpression(.7));
		estilo = sb.createStyle(rs);
	}

	/**
	 * Devuelve el estilo
	 */
	public Style getEstilo() {
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getName()
	 *  
	 */
	@Override
	public String getName() {
		return estilo.getName();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setName(java.lang.String)
	 */
	@Override
	public void setName(String arg0) {
		estilo.setName(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getTitle()
	 *  
	 */
	@Override
	public String getTitle() {
		return estilo.getTitle();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setTitle(java.lang.String)
	 */
	@Override
	public void setTitle(String arg0) {
		estilo.setTitle(arg0);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getAbstract()
	 *  
	 */
	@Override
	public String getAbstract() {
		return estilo.getAbstract();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setAbstract(java.lang.String)
	 */
	@Override
	public void setAbstract(String arg0) {
		estilo.setAbstract(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#isDefault()
	 *  
	 */
	@Override
	public boolean isDefault() {
		return estilo.isDefault();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setIsDefault(boolean)
	 */
	@Override
	public void setIsDefault(boolean arg0) {
		estilo.setIsDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setDefault(boolean)
	 */
	@Override
	public void setDefault(boolean arg0) {
		estilo.setDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getFeatureTypeStyles()
	 *  
	 */
	@Override
	public FeatureTypeStyle[] getFeatureTypeStyles() {
		return estilo.getFeatureTypeStyles();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setFeatureTypeStyles(org.geotools.styling.FeatureTypeStyle[])
	 */
	@Override
	public void setFeatureTypeStyles(FeatureTypeStyle[] arg0) {
		estilo.setFeatureTypeStyles(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#addFeatureTypeStyle(org.geotools.styling.FeatureTypeStyle)
	 */
	@Override
	public void addFeatureTypeStyle(FeatureTypeStyle arg0) {
		estilo.addFeatureTypeStyle(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#accept(org.geotools.styling.StyleVisitor)
	 */
	@Override
	public void accept(StyleVisitor arg0) {
		estilo.accept(arg0);
	}

}
