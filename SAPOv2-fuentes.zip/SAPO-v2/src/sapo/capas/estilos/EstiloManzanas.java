package sapo.capas.estilos;

import java.awt.Color;

import org.geotools.styling.FeatureTypeStyle;
import org.geotools.styling.Graphic;
import org.geotools.styling.LineSymbolizer;
import org.geotools.styling.Mark;
import org.geotools.styling.PointSymbolizer;
import org.geotools.styling.PolygonSymbolizer;
import org.geotools.styling.Style;
import org.geotools.styling.StyleBuilder;
import org.geotools.styling.StyleVisitor;

/**
 * Esta clase define el estilo de la capa de manzanas.
 * @author Grupo de proyecto SAPO
 */

public class EstiloManzanas implements Style {

	public static String CUADRA = "cuadra";

	public static String ESQUINA = "esquina";

	/**
	 * El estilo
	 * 

	 */
	private Style estilo;

	/**
	 * Construye el estilo para representar las manzanas (polígonos)
	 *  
	 */
	public EstiloManzanas() {
		this(false);
	}

	/**
	 * Construye el estilo para representar las manzanas cuando estan seleccionadas
	 *  
	 */
	
	public EstiloManzanas(boolean seleccionado) {
		if (!seleccionado) {
			StyleBuilder sb = new StyleBuilder();
			PolygonSymbolizer ls1 = sb.createPolygonSymbolizer(Color.BLUE,
					Color.BLACK, 2);
			//LineSymbolizer ls2 = sb.createLineSymbolizer(Color.GREEN, 4);
			estilo = sb.createStyle();
			ls1.getFill().setOpacity(sb.literalExpression(.6));
			//estilo.addFeatureTypeStyle(sb.createFeatureTypeStyle(null,
			// sb.createRule(ls2)));
			estilo.addFeatureTypeStyle(sb.createFeatureTypeStyle(null, sb
					.createRule(ls1)));
		} else {
			StyleBuilder sb = new StyleBuilder();
			PolygonSymbolizer poligonos = sb.createPolygonSymbolizer(
					Color.BLACK, Color.BLACK, 3);
			poligonos.getFill().setOpacity(sb.literalExpression(.2));
			estilo = sb.createStyle(poligonos);
		}
	}

	/**
	 * Construye el estilo para representar alguna parte de la manzana que se 
	 * encuentre seleccionado
	 * @param parte
	 * puede ser MANZANAS.Cuadra o MANZANAS.Esquina
	 */
	public EstiloManzanas(String parte) {
		if (parte.equals(CUADRA)) {
			StyleBuilder sb = new StyleBuilder();
			LineSymbolizer ls1 = sb.createLineSymbolizer(Color.RED, 3);
			LineSymbolizer ls2 = sb.createLineSymbolizer(Color.BLACK, 3);
			estilo = sb.createStyle();
			estilo.addFeatureTypeStyle(sb.createFeatureTypeStyle(null, sb
					.createRule(ls2)));
			estilo.addFeatureTypeStyle(sb.createFeatureTypeStyle(null, sb
					.createRule(ls1)));
		} else if (parte.equals(ESQUINA)) {
			StyleBuilder sb = new StyleBuilder();
			Mark punto = sb.createMark(StyleBuilder.MARK_SQUARE, Color.YELLOW,
					Color.BLACK, 1);
			Graphic graficoPunto = sb.createGraphic(null, punto, null, 1, 7, 0);
			PointSymbolizer puntos = sb.createPointSymbolizer(graficoPunto);
			estilo = sb.createStyle(puntos);
		}
	}

	/**
	 * Devuelve el estilo
	 */
	public Style getEstilo() {
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getName()
	 *  
	 */

	@Override
	public String getName() {
		return estilo.getName();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setName(java.lang.String)
	 */
	@Override
	public void setName(String arg0) {
		estilo.setName(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getTitle()
	 *  
	 */

	@Override
	public String getTitle() {
		return estilo.getTitle();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setTitle(java.lang.String)
	 */
	@Override
	public void setTitle(String arg0) {
		estilo.setTitle(arg0);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getAbstract()
	 *  
	 */

	@Override
	public String getAbstract() {
		return estilo.getAbstract();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setAbstract(java.lang.String)
	 */
	@Override
	public void setAbstract(String arg0) {
		estilo.setAbstract(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#isDefault()
	 *  
	 */

	@Override
	public boolean isDefault() {
		return estilo.isDefault();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setIsDefault(boolean)
	 */
	@Override
	public void setIsDefault(boolean arg0) {
		estilo.setIsDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setDefault(boolean)
	 */
	@Override
	public void setDefault(boolean arg0) {
		estilo.setDefault(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#getFeatureTypeStyles()
	 *  
	 */

	@Override
	public FeatureTypeStyle[] getFeatureTypeStyles() {
		return estilo.getFeatureTypeStyles();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#setFeatureTypeStyles(org.geotools.styling.FeatureTypeStyle[])
	 */
	@Override
	public void setFeatureTypeStyles(FeatureTypeStyle[] arg0) {
		estilo.setFeatureTypeStyles(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#addFeatureTypeStyle(org.geotools.styling.FeatureTypeStyle)
	 */
	@Override
	public void addFeatureTypeStyle(FeatureTypeStyle arg0) {
		estilo.addFeatureTypeStyle(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.geotools.styling.Style#accept(org.geotools.styling.StyleVisitor)
	 */
	@Override
	public void accept(StyleVisitor arg0) {
		estilo.accept(arg0);
	}

}
