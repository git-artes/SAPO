package sapo.archivos;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import sapo.predicciones.Cost231WI;
import sapo.predicciones.Cost231WISimple;
import sapo.predicciones.Erceg;
import sapo.predicciones.ITU_R_P1546;
import sapo.predicciones.Modelo;
import sapo.predicciones.Mopem;
import sapo.predicciones.OkumuraHata;
import sapo.predicciones.TierraPlana;
import sapo.predicciones.TierraPlanaAproximada;
import sapo.predicciones.Vacio;
import sapo.predicciones.VoglerIkegami;
import sapo.predicciones.VoglerSaundersBonar;
import sapo.proyecto.PerfilUsuario;
import sapo.proyecto.Proyecto;
import sapo.red.Antena;
import sapo.red.CanalFrecuencias;
import sapo.red.Radiobase;
import sapo.red.Sitio;
import sapo.red.TipoAntena;

/**
 * Esta clase se encarga de interpretar los archivos xml con los que se
 * almacenan los proyectos
 * 
 * @author Grupo de proyecto SAPO
 */

public class ArchivosXML {

	static Proyecto proyecto;

	Sitio sitio;

	/**
	 * Lee el proyecto completo guardado en formato xml en "archivo" y crea un
	 * proyecto con todos los atributos del mismo que va leyendo
	 */
	public static Proyecto leerProyectoXmlSAX(File archivo) {
		try {
			proyecto = new Proyecto();
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(archivo);

			// Leemos el documento XML

			// Etiqueta Proyecto//
			NodeList listaProy = doc.getElementsByTagName("Proyecto");
			int totalProy = listaProy.getLength();

			Node nodoPrimerProy = listaProy.item(0);
			if (nodoPrimerProy.getNodeType() == Node.ELEMENT_NODE) {

				Element elementoProy = (Element) nodoPrimerProy;

				// Etiqueta Nombre Proyecto// -------
				NodeList listaNombresProy = elementoProy
						.getElementsByTagName("Nombre");
				Element elementoNombreProy = (Element) listaNombresProy.item(0);

				NodeList textProyList = elementoNombreProy.getChildNodes();
				System.out.println("Nombre Proyecto : "
						+ ((Node) textProyList.item(0)).getNodeValue().trim());
				String nombreProyecto = ((Node) textProyList.item(0))
						.getNodeValue().trim();

				// Etiqueta Autor Proyecto// -------
				NodeList listaAutorProy = elementoProy
						.getElementsByTagName("Autor");
				Element elementoAutorProy = (Element) listaAutorProy.item(0);

				NodeList textAutorList = elementoAutorProy.getChildNodes();
				System.out.println("Autor Proyecto : "
						+ ((Node) textProyList.item(0)).getNodeValue().trim());
				String autorProyecto = ((Node) textAutorList.item(0))
						.getNodeValue().trim();

				// Etiqueta Observaciones Proyecto// -------
				NodeList listaObsProy = elementoProy
						.getElementsByTagName("Observaciones");
				Element elementoObsProy = (Element) listaObsProy.item(0);

				NodeList textObsList = elementoObsProy.getChildNodes();
				System.out.println("Observaciones : "
						+ ((Node) textObsList.item(0)).getNodeValue().trim());
				String obsProyecto = ((Node) textObsList.item(0))
						.getNodeValue().trim();
				if (obsProyecto.equals("null")) {
					obsProyecto = "";
				}

				proyecto.setNombre(nombreProyecto);
				proyecto.setAutor(autorProyecto);
				proyecto.setObservaciones(obsProyecto);

			}// end of if clause

			// Etiqueta Perfil Usuario//
			NodeList listaPerfilProy = doc
					.getElementsByTagName("PerfilUsuario");
			leerPerfil(listaPerfilProy);

			// Modelos//
			NodeList listaModelos = doc.getElementsByTagName("Modelo");
			leerModelos(listaModelos);

			NodeList listaTipoAntenas = doc.getElementsByTagName("TipoAntena");
			leerTiposAntena(listaTipoAntenas);

			// Etiqueta Canal de frecuencias//
			NodeList listaCanalFrec = doc
					.getElementsByTagName("CanalFrecuencia");
			leerCanalesFrecuencia(listaCanalFrec);

			// Etiquetas Sitios//
			NodeList listaSitios = doc.getElementsByTagName("Sitio");
			leerSitios(listaSitios);

			// Etiqueta Direccion LinkCapaResultados//
			NodeList listaLinksCRProy = doc
					.getElementsByTagName("LinkCapaResultados");
			leerLinksPredicciones(listaLinksCRProy);

			// Etiqueta Direccion CapaAlturas//
			NodeList listaLinksCAProy = doc
					.getElementsByTagName("LinkCapaAlturas");
			Element elementoLinksCAProy = (Element) listaLinksCAProy.item(0);

			NodeList textLinksCAList = elementoLinksCAProy.getChildNodes();
			System.out.println("Link Capa Alturas : "
					+ ((Node) textLinksCAList.item(0)).getNodeValue().trim());

			String linksCAProyecto = ((Node) textLinksCAList.item(0))
					.getNodeValue().trim();

			if (!linksCAProyecto.equals("null")) { // GM: Si es null no cargo
													// nada!
				URL link = new URL(linksCAProyecto);
				proyecto.setLinkCapaAlturas(link);
			}

			// Etiqueta Direccion CapaCuadras//
			NodeList listaLinksCCProy = doc
					.getElementsByTagName("LinkCapaManzanas");
			Element elementoLinksCCProy = (Element) listaLinksCCProy.item(0);

			NodeList textLinksCCList = elementoLinksCCProy.getChildNodes();
			System.out.println("Link Capa Cuadras : "
					+ ((Node) textLinksCCList.item(0)).getNodeValue().trim());

			String linksCCProyecto = ((Node) textLinksCCList.item(0))
					.getNodeValue().trim();
			if (!linksCCProyecto.equals("null")) { // GM: Si es null no cargo
													// nada!
				URL linkC = new URL(linksCCProyecto);
				proyecto.setLinkCapaManzanas(linkC);
			}

			// Etiqueta Direccion CapaEdificios//
			NodeList listaLinksCEProy = doc
					.getElementsByTagName("LinkCapaEdificios");
			Element elementoLinksCEProy = (Element) listaLinksCEProy.item(0);

			NodeList textLinksCEList = elementoLinksCEProy.getChildNodes();
			System.out.println("Link Capa Edificios : "
					+ ((Node) textLinksCEList.item(0)).getNodeValue().trim());

			String linksCEProyecto = ((Node) textLinksCEList.item(0))
					.getNodeValue().trim();
			/*
			 * if (linksCEProyecto.equals("null")){ linksCEProyecto = ""; }
			 */
			if (!linksCEProyecto.equals("null")) {
				URL linkE = new URL(linksCEProyecto);
				proyecto.setLinkCapaEdificios(linkE);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (SAXParseException err) {
			System.out.println("** Parsing error" + ", line "
					+ err.getLineNumber() + ", uri " + err.getSystemId());
			System.out.print(" ");
			err.printStackTrace(System.out);

		} catch (SAXException e) {
			Exception x = e.getException();
			((x == null) ? e : x).printStackTrace();

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return proyecto;
	}

	/**
	 * Lee el perfil del archivo xml donde se guardo el proyecto y los agrega al
	 * proyecto que se va a abrir
	 */
	public static void leerPerfil(NodeList listaPerfil) {
		try {

			Node nodoPrimerPerfil = listaPerfil.item(0);
			Element elementoPerfilProy = (Element) nodoPrimerPerfil;

			// Etiqueta Altura// -------
			NodeList listaAlturaPerfil = elementoPerfilProy
					.getElementsByTagName("Altura");
			Element elementoAlturaPerfil = (Element) listaAlturaPerfil.item(0);

			NodeList textAlturaPerfilList = elementoAlturaPerfil
					.getChildNodes();
			System.out.println("Altura Perfil : "
					+ ((Node) textAlturaPerfilList.item(0)).getNodeValue()
							.trim());
			double alturaP = Double.parseDouble(((Node) textAlturaPerfilList
					.item(0)).getNodeValue().trim());

			// Etiqueta Sensibilidad// -------
			NodeList listaSensibilidadPerfil = elementoPerfilProy
					.getElementsByTagName("Sensibilidad");
			Element elementoSPerfil = (Element) listaSensibilidadPerfil.item(0);

			NodeList textSPList = elementoSPerfil.getChildNodes();
			System.out.println("Sensibilidad Perfil : "
					+ ((Node) textSPList.item(0)).getNodeValue().trim());
			double sensibilidad = Double
					.parseDouble(((Node) textSPList.item(0)).getNodeValue()
							.trim());

			// Etiqueta C/I // ----
			NodeList listaCIPerfil = elementoPerfilProy
					.getElementsByTagName("CI");
			Element elementoCIPerfil = (Element) listaCIPerfil.item(0);

			NodeList textCIPerfilList = elementoCIPerfil.getChildNodes();
			System.out.println("C/I Perfil : "
					+ ((Node) textCIPerfilList.item(0)).getNodeValue().trim());
			double ci = Double.parseDouble(((Node) textCIPerfilList.item(0))
					.getNodeValue().trim());

			// Etiqueta LimiteIntervalo// -------
			String valorInter = "";
			NodeList listaIntervalos = elementoPerfilProy
					.getElementsByTagName("LimiteIntervalo");
			int totalIntervalos = listaIntervalos.getLength();
			double[] intervalos = new double[totalIntervalos];
			for (int s = 0; s < listaIntervalos.getLength(); s++) {
				Node nodoPrimerI = listaIntervalos.item(s);
				if (nodoPrimerI.getNodeType() == Node.ELEMENT_NODE) {
					Element elementoIntervalo = (Element) listaIntervalos
							.item(s);

					NodeList textValorIList = elementoIntervalo.getChildNodes();
					System.out.println("Intervalo "
							+ s
							+ ": "
							+ ((Node) textValorIList.item(0)).getNodeValue()
									.trim());
					valorInter = ((Node) textValorIList.item(0)).getNodeValue()
							.trim();

					intervalos[s] = Double.parseDouble(valorInter);

				}
			}

			// Etiqueta Intervalos Automaticos // ----
			NodeList listaInterAuto = elementoPerfilProy
					.getElementsByTagName("intervalosAuto");
			Element elementoIntervalosAutoPerfil = (Element) listaInterAuto
					.item(0);

			NodeList textIntervalosAutoPerfilList = elementoIntervalosAutoPerfil
					.getChildNodes();
			
			boolean intervalosAuto = Boolean.valueOf(((Node) textIntervalosAutoPerfilList.item(0))
							.getNodeValue().trim());

			System.out.println("Intervalos de resultados automáticos: "
					+ intervalosAuto);

			if (intervalosAuto) {
				PerfilUsuario perfil = new PerfilUsuario(alturaP, sensibilidad,
						ci);
				proyecto.setPerfilUsuario(perfil);
			} else {
				PerfilUsuario perfil = new PerfilUsuario(alturaP, sensibilidad,
						ci, intervalos);
				proyecto.setPerfilUsuario(perfil);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Lee los sitios del archivo xml donde se guardo el proyecto y los agrega
	 * al proyecto que se va a abrir
	 */
	public static void leerSitios(NodeList listaSitios) {
		ArrayList sitios = new ArrayList();
		try {
			int totalSitios = listaSitios.getLength();

			for (int s = 0; s < listaSitios.getLength(); s++) {

				Node nodoPrimerSitio = listaSitios.item(s);
				if (nodoPrimerSitio.getNodeType() == Node.ELEMENT_NODE) {

					Element elementoSitio = (Element) nodoPrimerSitio;

					// Etiqueta Nombre Sitio// -------
					NodeList listaNombresSitios = elementoSitio
							.getElementsByTagName("Nombre");
					Element elementoNombreSitio = (Element) listaNombresSitios
							.item(0);

					NodeList textSitioList = elementoNombreSitio
							.getChildNodes();
					System.out.println("Nombre Sitio : "
							+ ((Node) textSitioList.item(0)).getNodeValue()
									.trim());
					String nombreSitio = ((Node) textSitioList.item(0))
							.getNodeValue().trim();

					// Etiqueta Coordenada X// -------
					NodeList listaCoordX = elementoSitio
							.getElementsByTagName("CoordenadaX");
					Element elementoCoordX = (Element) listaCoordX.item(0);

					NodeList textCXList = elementoCoordX.getChildNodes();
					System.out
							.println("Coordenada X : "
									+ ((Node) textCXList.item(0))
											.getNodeValue().trim());
					double x = Double.parseDouble(((Node) textCXList.item(0))
							.getNodeValue().trim());

					// Etiqueta Coordenada Y// ----
					NodeList listaCoordY = elementoSitio
							.getElementsByTagName("CoordenadaY");
					Element elementoCoordY = (Element) listaCoordY.item(0);

					NodeList textCYList = elementoCoordY.getChildNodes();
					System.out
							.println("Coordenada Y : "
									+ ((Node) textCYList.item(0))
											.getNodeValue().trim());
					double y = Double.parseDouble(((Node) textCYList.item(0))
							.getNodeValue().trim());

					// Etiquetas Radiobases// ------
					NodeList listaRadiobases = elementoSitio
							.getElementsByTagName("Radiobase");

					ArrayList radiobases = leerRadiobases(listaRadiobases);

					Sitio sitio;
					if (radiobases.isEmpty()) {
						sitio = new Sitio(x, y, nombreSitio);
					} else {
						sitio = new Sitio(x, y, nombreSitio, radiobases);
					}
					proyecto.agregarSitio(sitio);

				}// end of if clause

			}// end of for loop with s var
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Lee las radiobases del archivo xml donde se guardo el proyecto y los
	 * agrega al proyecto que se va a abrir
	 */
	public static ArrayList leerRadiobases(NodeList listaRadiobases) {
		ArrayList radiobases = new ArrayList();
		// Radiobase radiobase = new Radiobase();
		try {
			int totalRadioBases = listaRadiobases.getLength();

			for (int r = 0; r < listaRadiobases.getLength(); r++) {
				Node nodoPrimeraRB = listaRadiobases.item(r);
				if (nodoPrimeraRB.getNodeType() == Node.ELEMENT_NODE) {

					Element elementoRadioBase = (Element) nodoPrimeraRB;

					// Etiqueta Nombre Radiobase// -------
					NodeList listaNombresRadioBases = elementoRadioBase
							.getElementsByTagName("Nombre");
					Element elementoNombreRB = (Element) listaNombresRadioBases
							.item(0);

					NodeList textRBList = elementoNombreRB.getChildNodes();
					System.out
							.println("Nombre Radiobase : "
									+ ((Node) textRBList.item(0))
											.getNodeValue().trim());
					String nombreRB = ((Node) textRBList.item(0))
							.getNodeValue().trim();

					// Etiqueta Altura Radiobase// -------
					NodeList listaAlturasRadioBases = elementoRadioBase
							.getElementsByTagName("Altura");
					Element elementoAlturaRB = (Element) listaAlturasRadioBases
							.item(0);

					NodeList textARBList = elementoAlturaRB.getChildNodes();
					System.out.println("Altura Radiobase : "
							+ ((Node) textARBList.item(0)).getNodeValue()
									.trim());
					double alturaRB = Double.parseDouble(((Node) textARBList
							.item(0)).getNodeValue().trim());

					// Etiqueta Habilitada// -------
					NodeList listaHabRadioBases = elementoRadioBase
							.getElementsByTagName("Habilitada");
					Element elementoHabilitadoRB = (Element) listaHabRadioBases
							.item(0);

					NodeList textHABRBList = elementoHabilitadoRB
							.getChildNodes();
					System.out.println("Radiobase habilitada: "
							+ ((Node) textHABRBList.item(0)).getNodeValue()
									.trim());

					// Etiquetas Antenas// -------
					NodeList listaAntenas = elementoRadioBase
							.getElementsByTagName("Antena");
					ArrayList antenas = leerAntenas(listaAntenas);

					Radiobase radiobase;
					if (antenas.isEmpty()) {
						radiobase = new Radiobase(nombreRB, alturaRB);
					} else {
						radiobase = new Radiobase(nombreRB, alturaRB, antenas);
					}

					radiobases.add(radiobase);

				}// end of if clause

			}// end of for loop with r var

		} catch (Exception e) {
			e.printStackTrace();
		}
		return radiobases;

	}

	/**
	 * Lee las antenas del archivo xml donde se guardo el proyecto y los agrega
	 * al proyecto que se va a abrir
	 */
	public static ArrayList leerAntenas(NodeList listaAntenas) {
		ArrayList antenas = new ArrayList();
		try {
			int totalAntenas = listaAntenas.getLength();

			for (int r = 0; r < listaAntenas.getLength(); r++) {
				Node nodoPrimeraAntena = listaAntenas.item(r);
				if (nodoPrimeraAntena.getNodeType() == Node.ELEMENT_NODE) {

					Element elementoAntena = (Element) nodoPrimeraAntena;

					// Etiqueta Nombre Antena// -------
					NodeList listaNombresAntenas = elementoAntena
							.getElementsByTagName("Nombre");
					Element elementoNombreAntena = (Element) listaNombresAntenas
							.item(0);

					NodeList textAntList = elementoNombreAntena.getChildNodes();
					System.out.println("Nombre Antena : "
							+ ((Node) textAntList.item(0)).getNodeValue()
									.trim());
					String nombreAnt = ((Node) textAntList.item(0))
							.getNodeValue().trim();

					// Etiqueta Potencia// -------
					NodeList listaPotAntenas = elementoAntena
							.getElementsByTagName("Potencia");
					Element elementoPotAntena = (Element) listaPotAntenas
							.item(0);

					NodeList textPAList = elementoPotAntena.getChildNodes();
					System.out
							.println("Potencia Antena : "
									+ ((Node) textPAList.item(0))
											.getNodeValue().trim());
					double potenciaAnt = Double.parseDouble(((Node) textPAList
							.item(0)).getNodeValue().trim());

					// Etiqueta Tilt// -------
					NodeList listaTiltAntenas = elementoAntena
							.getElementsByTagName("Tilt");
					Element elementoTiltAntena = (Element) listaTiltAntenas
							.item(0);

					NodeList textTiltList = elementoTiltAntena.getChildNodes();
					double tiltAnt = Double.parseDouble(((Node) textTiltList
							.item(0)).getNodeValue().trim());

					// Etiqueta Azimut// -------
					NodeList listaAzimutAntenas = elementoAntena
							.getElementsByTagName("Azimut");
					Element elementoAzimutAntena = (Element) listaAzimutAntenas
							.item(0);

					NodeList textAzimutList = elementoAzimutAntena
							.getChildNodes();
					double azimutAnt = Double
							.parseDouble(((Node) textAzimutList.item(0))
									.getNodeValue().trim());

					// Etiqueta Modelo// -------
					NodeList listaModeloAntenas = elementoAntena
							.getElementsByTagName("ModeloAntena");
					Element elementoModeloAntena = (Element) listaModeloAntenas
							.item(0);

					NodeList textModeloList = elementoModeloAntena
							.getChildNodes();
					String modeloAnt = ((Node) textModeloList.item(0))
							.getNodeValue().trim();

					// Etiqueta Tipo Antena// -------
					NodeList listaTipoAntenas = elementoAntena
							.getElementsByTagName("TipoDeAntena");
					Element elementoTipoAntena = (Element) listaTipoAntenas
							.item(0);

					NodeList textTipoList = elementoTipoAntena.getChildNodes();
					String tipoAnt = ((Node) textTipoList.item(0))
							.getNodeValue().trim();

					// Etiqueta Canal de Frecuencia// -------
					NodeList listaCanalFAntenas = elementoAntena
							.getElementsByTagName("CanalFrecuenciaAntena");
					Element elementoCanalFAntena = (Element) listaCanalFAntenas
							.item(0);

					NodeList textCanalFList = elementoCanalFAntena
							.getChildNodes();
					String canalF = ((Node) textCanalFList.item(0))
							.getNodeValue().trim();

					Modelo modelo = null;
					ArrayList modelos = proyecto.getModelos();
					Iterator i = modelos.iterator();
					while (i.hasNext()) {
						Modelo modeloAux = (Modelo) i.next();
						if (modeloAux.getNombre().equals(modeloAnt)) {
							modelo = modeloAux;
						}
					}

					CanalFrecuencias canal = null;
					ArrayList canales = proyecto.getCanales();
					Iterator it = canales.iterator();
					while (it.hasNext()) {
						CanalFrecuencias canalFrecuenciaAux = (CanalFrecuencias) it
								.next();
						if (canalFrecuenciaAux.getNombre().equals(canalF)) {
							canal = canalFrecuenciaAux;
						}
					}

					TipoAntena tipo = null;
					ArrayList tiposDeAntena = proyecto.getTiposAntena();
					Iterator iterator = tiposDeAntena.iterator();
					while (iterator.hasNext()) {
						TipoAntena tipoAux = (TipoAntena) iterator.next();
						if (tipoAux.getNombre().equals(tipoAnt)) {
							tipo = tipoAux;
						}
					}

					// Modelo modelo = determinarModelo(modeloAnt);

					Antena antena = null;
					if (modeloAnt != null && canalF != null && tipoAnt != null) {
						antena = new Antena(nombreAnt, potenciaAnt, tiltAnt,
								azimutAnt, modelo, canal, tipo);
					}

					if (modeloAnt == null && canalF == null && tipoAnt == null) {
						antena = new Antena(nombreAnt, potenciaAnt, tiltAnt,
								azimutAnt);
					}

					antenas.add(antena);

				}// end of if clause

			}// end of for loop with r var

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return antenas;

	}

	/**
	 * Lee los modelos del archivo xml donde se guardo el proyecto y los agrega
	 * al proyecto que se va a abrir
	 */
	public static void leerModelos(NodeList listaModelos) {
		// ArrayList modelos = new ArrayList();
		try {
			int totalModelos = listaModelos.getLength();

			for (int r = 0; r < listaModelos.getLength(); r++) {
				Node nodoPrimerModelo = listaModelos.item(r);
				if (nodoPrimerModelo.getNodeType() == Node.ELEMENT_NODE) {

					Element elementoModelo = (Element) nodoPrimerModelo;

					// Etiqueta Nombre Particular del Modelo// -------
					NodeList listaNombresIModelo = elementoModelo
							.getElementsByTagName("NombreImplementacion");
					Element elementoNombreIModelo = (Element) listaNombresIModelo
							.item(0);

					NodeList textModeloIList = elementoNombreIModelo
							.getChildNodes();
					System.out.println("Nombre Implementacion Modelo : "
							+ ((Node) textModeloIList.item(0)).getNodeValue()
									.trim());
					String nombreModeloImplementacion = ((Node) textModeloIList
							.item(0)).getNodeValue().trim();

					// Etiqueta Nombre del Modelo// -------
					NodeList listaNombresModelo = elementoModelo
							.getElementsByTagName("Nombre");
					Element elementoNombreModelo = (Element) listaNombresModelo
							.item(0);

					NodeList textModeloList = elementoNombreModelo
							.getChildNodes();
					System.out.println("Nombre Modelo : "
							+ ((Node) textModeloList.item(0)).getNodeValue()
									.trim());
					String nombreModelo = ((Node) textModeloList.item(0))
							.getNodeValue().trim();

					// Etiqueta Parametros Ajustables// -------
					NodeList listaPA = elementoModelo
							.getElementsByTagName("ParametrosAjustables");
					int totalPA = listaPA.getLength();
					double[] paramA = new double[totalPA];
					System.out
							.println("Cantidad total de Parametros Ajustables : "
									+ totalPA);
					for (int s = 0; s < listaPA.getLength(); s++) {
						Node nodoPrimerPA = listaPA.item(s);
						if (nodoPrimerPA.getNodeType() == Node.ELEMENT_NODE) {

							Element elementoPA = (Element) nodoPrimerPA;

							// Etiqueta Valor ParametroAjustable// -------
							NodeList listaVPA = elementoPA
									.getElementsByTagName("Valor");
							Element elementoVPA = (Element) listaVPA.item(0);

							NodeList textVPAList = elementoVPA.getChildNodes();
							System.out.println("Parametro Ajustable : "
									+ ((Node) textVPAList.item(0))
											.getNodeValue().trim());
							double pa = Double.parseDouble(((Node) textVPAList
									.item(0)).getNodeValue().trim());

							paramA[s] = pa;

						}

					}

					// Etiqueta Parametros No Ajustables// -------
					NodeList listaPNA = elementoModelo
							.getElementsByTagName("ParametrosNoAjustables");
					int totalPNA = listaPNA.getLength();
					Object[] paramNA = new Object[totalPNA];
					System.out
							.println("Cantidad total de Parametros No Ajustables : "
									+ totalPNA);
					for (int s = 0; s < listaPNA.getLength(); s++) {
						Node nodoPrimerPNA = listaPNA.item(s);
						if (nodoPrimerPNA.getNodeType() == Node.ELEMENT_NODE) {

							Element elementoPNA = (Element) nodoPrimerPNA;

							// Etiqueta Valor ParametroNoAjustable// -------
							NodeList listaVPNA = elementoPNA
									.getElementsByTagName("Valor");
							Element elementoVPNA = (Element) listaVPNA.item(0);

							NodeList textVPNAList = elementoVPNA
									.getChildNodes();
							System.out.println("Parametro No Ajustable : "
									+ ((Node) textVPNAList.item(0))
											.getNodeValue().trim());
							String pnaj = ((Node) textVPNAList.item(0))
									.getNodeValue().trim();

							paramNA[s] = pnaj;

						}

					}

					// Etiqueta Parametros No Ajustables Plus// -------
					NodeList listaPNAPlus = elementoModelo
							.getElementsByTagName("ParametrosNoAjustablesSubitems");
					int totalPNAPlus = listaPNAPlus.getLength();
					Object[] paramNAPlus = new Object[totalPNAPlus];
					System.out
							.println("Cantidad total de Parametros No Ajustables Plus: "
									+ totalPNAPlus);

					// Parametros Okumura
					ArrayList parametrosA = new ArrayList();
					ArrayList parametrosC = new ArrayList();
					// Parametros Erceg
					ArrayList parametrosG = new ArrayList();
					ArrayList parametrosS = new ArrayList();
					Double[] parametrosFf = new Double[2];
					Double[] parametrosFh = new Double[2];
					// Parametros COST-WI
					double[] parametrosLori = new double[6];
					Object[] parametrosLmsd = new Object[4];
					double[] parametrosLbsh = new double[2];
					double[] parametroska = new double[3];
					double[] parametroskd = new double[2];
					double[] parametroskf = new double[3];
					// Parametros VOGLER-IKEGAMI
					double[] parametrosLoriVI = new double[6];

					for (int s = 0; s < listaPNAPlus.getLength(); s++) {

						if ((nombreModelo.equals(Modelo.OKUMURA_HATA))) {

							Node nodoPrimerPNAPlus = listaPNAPlus.item(s);
							if (nodoPrimerPNAPlus.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoPNAPlus = (Element) nodoPrimerPNAPlus;

								// Etiqueta Valor ParametroNoAjustable// -------
								NodeList listaVPNAPlus = elementoPNAPlus
										.getElementsByTagName("Valor");
								Element elementoVPNAPlus = (Element) listaVPNAPlus
										.item(0);

								NodeList textVPNAPlusList = elementoVPNAPlus
										.getChildNodes();
								System.out
										.println("Parametro No Ajustable Plus: "
												+ ((Node) textVPNAPlusList
														.item(0))
														.getNodeValue().trim());

								double pna = Double
										.parseDouble(((Node) textVPNAPlusList
												.item(0)).getNodeValue().trim());
								java.lang.Double pnaj = new java.lang.Double(
										pna);
								// Object pna =
								// ((Node)textVPNAList.item(0)).getNodeValue().trim();
								if ((s == 0) || (s == 1) || (s == 2)
										|| (s == 3)) {
									parametrosA.add(new Double(pna));
								} else if ((s == 4) || (s == 5) || (s == 6)
										|| (s == 7)) {
									parametrosC.add((new Double(pna)));
								}

							}// if

						}// if OH

						if ((nombreModelo.equals(Modelo.ERCEG_SUI))) {

							Node nodoPrimerPNAPlus = listaPNAPlus.item(s);
							if (nodoPrimerPNAPlus.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoPNAPlus = (Element) nodoPrimerPNAPlus;

								// Etiqueta Valor ParametroNoAjustable// -------
								NodeList listaVPNAPlus = elementoPNAPlus
										.getElementsByTagName("Valor");
								Element elementoVPNAPlus = (Element) listaVPNAPlus
										.item(0);

								NodeList textVPNAPlusList = elementoVPNAPlus
										.getChildNodes();
								System.out
										.println("Parametro No Ajustable Plus: "
												+ ((Node) textVPNAPlusList
														.item(0))
														.getNodeValue().trim());
								String pna = ((Node) textVPNAPlusList.item(0))
										.getNodeValue().trim();
								if ((s == 0) || (s == 1) || (s == 2)
										|| (s == 3)) {
									parametrosG.add(new Double(pna));
								} else if (s == 4) {
									parametrosG.add(new Integer(pna));
								} else if ((s == 5) || (s == 6)) {
									parametrosS.add((new Double(pna)));
								} else if ((s == 7) || (s == 8)) {
									parametrosS.add((new Integer(pna)));
								} else if ((s == 9) || (s == 10)) {
									parametrosFf[s - 9] = new Double(pna);
								} else if ((s == 11) || (s == 12)) {
									parametrosFh[s - 11] = new Double(pna);
								}
							}// if

						}// if ERCEG

						if ((nombreModelo.equals(Modelo.COST_231_WI))) {
							Node nodoPrimerPNAPlus = listaPNAPlus.item(s);
							if (nodoPrimerPNAPlus.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoPNAPlus = (Element) nodoPrimerPNAPlus;

								// Etiqueta Valor ParametroNoAjustable// -------
								NodeList listaVPNAPlus = elementoPNAPlus
										.getElementsByTagName("Valor");
								Element elementoVPNAPlus = (Element) listaVPNAPlus
										.item(0);

								NodeList textVPNAPlusList = elementoVPNAPlus
										.getChildNodes();
								System.out
										.println("Parametro No Ajustable Plus: "
												+ ((Node) textVPNAPlusList
														.item(0))
														.getNodeValue().trim());
								String pna = ((Node) textVPNAPlusList.item(0))
										.getNodeValue().trim();

								if ((s == 0) || (s == 1) || (s == 2)
										|| (s == 3) || (s == 4) || (s == 5)) {
									parametrosLori[s] = Double.parseDouble(pna);
								} else if ((s == 6) || (s == 7)) {
									parametrosLbsh[s - 6] = Double
											.parseDouble(pna);
								} else if ((s == 8) || (s == 9) || (s == 10)) {
									parametroska[s - 8] = Double
											.parseDouble(pna);
								} else if ((s == 11) || (s == 12)) {
									parametroskd[s - 11] = Double
											.parseDouble(pna);
								} else if ((s == 13) || (s == 14) || (s == 15)) {
									parametroskf[s - 13] = Double
											.parseDouble(pna);
								}

							}// if

						}// if COST-WI

						if ((nombreModelo.equals(Modelo.VOGLER_IKEGAMI))) {
							Node nodoPrimerPNAPlus = listaPNAPlus.item(s);
							if (nodoPrimerPNAPlus.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoPNAPlus = (Element) nodoPrimerPNAPlus;

								// Etiqueta Valor ParametroNoAjustable// -------
								NodeList listaVPNAPlus = elementoPNAPlus
										.getElementsByTagName("Valor");
								Element elementoVPNAPlus = (Element) listaVPNAPlus
										.item(0);

								NodeList textVPNAPlusList = elementoVPNAPlus
										.getChildNodes();
								System.out
										.println("Parametro No Ajustable Plus: "
												+ ((Node) textVPNAPlusList
														.item(0))
														.getNodeValue().trim());
								String pna = ((Node) textVPNAPlusList.item(0))
										.getNodeValue().trim();

								// if
								// ((s==0)||(s==1)||(s==2)||(s==3)||(s==4)||(s==5)){
								parametrosLoriVI[s] = Double.parseDouble(pna);
								// }

							}// if

						}// if VOGLER-WI

					}// cierro param plus

					if ((nombreModelo.equals(Modelo.TIERRA_PLANA))) {
						paramNA[0] = new Double(Double.parseDouble(paramNA[0]
								.toString()));
						paramNA[1] = new Double(Double.parseDouble(paramNA[1]
								.toString()));
						paramNA[2] = new Double(Double.parseDouble(paramNA[2]
								.toString()));
					}
					if ((nombreModelo.equals(Modelo.ITUR_P1546))) {
						// paramNA[0] = new String(String.parseDouble(paramNA[0]
						// .toString()));
						// paramNA[1] = new Integer(Integer.parseInt(paramNA[1]
						// .toString()));
						paramNA[2] = new Boolean(Boolean.valueOf(paramNA[2]
								.toString()));
						paramNA[3] = new Boolean(Boolean.valueOf(paramNA[3]
								.toString()));
					}
					if ((nombreModelo.equals(Modelo.OKUMURA_HATA))) {
						paramNA[0] = new Double(Double.parseDouble(paramNA[0]
								.toString()));
						paramNA[1] = new Integer(Integer.parseInt(paramNA[1]
								.toString()));
						paramNA[2] = new Double(Double.parseDouble(paramNA[2]
								.toString()));
						paramNA[4] = new Integer(Integer.parseInt(paramNA[4]
								.toString()));
						paramNA[3] = parametrosA;
						paramNA[5] = parametrosC;
						paramNA[6] = new Boolean(Boolean.valueOf(paramNA[6]
								.toString()));
					}
					if ((nombreModelo.equals(Modelo.ERCEG_SUI))) {
						paramA = new double[] {};
						paramNA[0] = new Double(Double.parseDouble(paramNA[0]
								.toString()));
						paramNA[1] = new Integer(Integer.parseInt(paramNA[1]
								.toString()));
						paramNA[2] = parametrosG;
						paramNA[3] = parametrosS;
						paramNA[4] = parametrosFf;
						paramNA[5] = parametrosFh;
					}
					if ((nombreModelo.equals(Modelo.COST_231_WI))) {
						parametrosLmsd = new Object[] { parametrosLbsh,
								parametroska, parametroskd, parametroskf };
						paramNA[0] = parametrosLori;
						paramNA[1] = parametrosLmsd;
						paramNA[2] = new Integer(Integer.parseInt(paramNA[2]
								.toString()));

					}
					if ((nombreModelo.equals(Modelo.COST_231_WI_SIMPLE))) {
						parametrosLmsd = new Object[] { parametrosLbsh,
								parametroska, parametroskd, parametroskf };
						paramNA[0] = parametrosLori;
						paramNA[1] = parametrosLmsd;
						paramNA[2] = new Integer(Integer.parseInt(paramNA[2]
								.toString()));
						paramNA[3] = new Integer(Integer.parseInt(paramNA[3]
								.toString()));
						paramNA[4] = new Integer(Integer.parseInt(paramNA[4]
								.toString()));
						paramNA[5] = new Integer(Integer.parseInt(paramNA[5]
								.toString()));
					}
					if ((nombreModelo.equals(Modelo.VOGLER_SB))) {
						paramA = new double[] {};
						paramNA[0] = new Integer(Integer.parseInt(paramNA[0]
								.toString()));
						paramNA[1] = new Double(Double.parseDouble(paramNA[1]
								.toString()));
						paramNA[2] = new Integer(Integer.parseInt(paramNA[2]
								.toString()));
						paramNA[3] = new Integer(Integer.parseInt(paramNA[3]
								.toString()));
					}
					if ((nombreModelo.equals(Modelo.VOGLER_IKEGAMI))) {
						paramNA[0] = new Integer(Integer.parseInt(paramNA[0]
								.toString()));
						paramNA[1] = new Double(Double.parseDouble(paramNA[1]
								.toString()));
						paramNA[2] = new Integer(Integer.parseInt(paramNA[2]
								.toString()));
						paramNA[3] = new Integer(Integer.parseInt(paramNA[3]
								.toString()));
						paramNA[4] = parametrosLoriVI;
					}

					Modelo modelo = determinarModelo(nombreModelo, paramA,
							paramNA);
					modelo.setNombre(nombreModeloImplementacion);

					// modelos.add(modelo);

					proyecto.agregarModelo(modelo);

				}// end of if clause

			}// end of for loop with r var

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		// return modelos;

	}

	/**
	 * Lee los tipos de antena del archivo xml donde se guardo el proyecto y los
	 * agrega al proyecto que se va a abrir
	 */
	public static void leerTiposAntena(NodeList listaTipoAntenas) {

		double ganancia = 0;
		String nombreTipoAntena = "";
		String tipo = "";
		ArrayList<Double> angulosPH = new ArrayList<Double>();
		ArrayList<Double> gananciasPH = new ArrayList<Double>();
		ArrayList<Double> angulosPV = new ArrayList<Double>();
		ArrayList<Double> gananciasPV = new ArrayList<Double>();

		try {
			int totalTipoAnt = listaTipoAntenas.getLength();
			for (int r = 0; r < listaTipoAntenas.getLength(); r++) {
				Node nodoPrimerTipoAntena = listaTipoAntenas.item(r);
				if (nodoPrimerTipoAntena.getNodeType() == Node.ELEMENT_NODE) {

					Element elementoTipoDeAntena = (Element) nodoPrimerTipoAntena;

					// Etiqueta Nombre Tipo Antena// -------
					NodeList listaNombresTipoAntena = elementoTipoDeAntena
							.getElementsByTagName("NombreTipo");
					Element elementoNombreTipoAntena = (Element) listaNombresTipoAntena
							.item(0);

					NodeList textTipoAntenaList = elementoNombreTipoAntena
							.getChildNodes();
					System.out.println("Nombre Tipo Antena : "
							+ ((Node) textTipoAntenaList.item(0))
									.getNodeValue().trim());
					nombreTipoAntena = ((Node) textTipoAntenaList.item(0))
							.getNodeValue().trim();

					// Etiqueta Tipo Antena// -------
					NodeList listaTipoAntena = elementoTipoDeAntena
							.getElementsByTagName("Tipo");
					Element elementoTipoAntena = (Element) listaTipoAntena
							.item(0);

					NodeList textTipoList = elementoTipoAntena.getChildNodes();
					System.out.println("Tipo Antena : "
							+ ((Node) textTipoList.item(0)).getNodeValue()
									.trim());
					tipo = ((Node) textTipoList.item(0)).getNodeValue().trim();

					if (tipo.equals("Directiva")) {

						// Etiqueta Ganancia// -------
						NodeList listaNombreG = elementoTipoDeAntena
								.getElementsByTagName("Ganancia");
						Element elementoNombreG = (Element) listaNombreG
								.item(0);

						NodeList textGList = elementoNombreG.getChildNodes();
						System.out.println("Ganancia: "
								+ ((Node) textGList.item(0)).getNodeValue()
										.trim());
						ganancia = Double
								.parseDouble(((Node) textGList.item(0))
										.getNodeValue().trim());

						// Etiqueta PatronH// -------

						angulosPH = new ArrayList<Double>();
						gananciasPH = new ArrayList<Double>();

						NodeList listaPatronH = elementoTipoDeAntena
								.getElementsByTagName("PatronH");
						Element elementoPatronH = (Element) listaPatronH
								.item(0);

						NodeList textAngList = elementoPatronH
								.getElementsByTagName("Angulo");

						// ArrayList angulos = new ArrayList();
						int totalAng = textAngList.getLength();
						int s = 0;
						while (s < totalAng) {
							Node nodoPrimerA = textAngList.item(s);
							if (nodoPrimerA.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoA = (Element) nodoPrimerA;

								// Etiqueta Angulo// -------
								NodeList listaA = elementoA
										.getElementsByTagName("Valor");
								// Element elementoNombreA =
								// (Element)listaA.item(0);
								Element elementoNombreA = (Element) listaA
										.item(0);

								NodeList textAList = elementoNombreA
										.getChildNodes();
								System.out.println("Angulo : "
										+ ((Node) textAList.item(0))
												.getNodeValue().trim());
								// double angulo =
								// Double.parseDouble(((Node)textAList.item(0)).getNodeValue().trim());
								String angulo = ((Node) textAList.item(0))
										.getNodeValue().trim();
								angulosPH.add(Double.parseDouble(angulo));

							}
							s++;
						}

						NodeList textGAList = elementoPatronH
								.getElementsByTagName("Ganancia");

						// ArrayList ganancias = new ArrayList();
						int totalGA = textGAList.getLength();
						for (int l = 0; l < totalGA; l++) {
							/*
							 * int r=0; while (r <totalGA){
							 */
							Node nodoPrimerGA = textGAList.item(l);
							if (nodoPrimerGA.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoGA = (Element) nodoPrimerGA;

								// Etiqueta Angulo// -------
								NodeList listaGA = elementoGA
										.getElementsByTagName("Valor");
								// Element elementoNombreA =
								// (Element)listaA.item(0);
								Element elementoNombreGA = (Element) listaGA
										.item(0);

								NodeList textGANList = elementoNombreGA
										.getChildNodes();
								System.out.println("Ganancia : "
										+ ((Node) textGANList.item(0))
												.getNodeValue().trim());
								// double angulo =
								// Double.parseDouble(((Node)textAList.item(0)).getNodeValue().trim());
								String gananciaP = ((Node) textGANList.item(0))
										.getNodeValue().trim();
								gananciasPH.add(Double.parseDouble(gananciaP));

							}

						}

						// Etiqueta PatronV// -------

						angulosPV = new ArrayList<Double>();
						gananciasPV = new ArrayList<Double>();

						NodeList listaPatronV = elementoTipoDeAntena
								.getElementsByTagName("PatronV");
						Element elementoPatronV = (Element) listaPatronV
								.item(0);

						NodeList textAngVList = elementoPatronV
								.getElementsByTagName("Angulo");

						// ArrayList angulos = new ArrayList();
						int totalAngV = textAngVList.getLength();
						for (int m = 0; m < textAngVList.getLength(); m++) {

							Node nodoPrimerAV = textAngVList.item(m);
							if (nodoPrimerAV.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoAV = (Element) nodoPrimerAV;

								// Etiqueta Angulo// -------
								NodeList listaAV = elementoAV
										.getElementsByTagName("Valor");
								// Element elementoNombreA =
								// (Element)listaA.item(0);
								Element elementoNombreAV = (Element) listaAV
										.item(0);

								NodeList textAVList = elementoNombreAV
										.getChildNodes();
								System.out.println("Angulo PV: "
										+ ((Node) textAVList.item(0))
												.getNodeValue().trim());
								// double angulo =
								// Double.parseDouble(((Node)textAList.item(0)).getNodeValue().trim());
								String angulo = ((Node) textAVList.item(0))
										.getNodeValue().trim();
								angulosPV.add(Double.parseDouble(angulo));

							}

						}

						NodeList textGAVList = elementoPatronV
								.getElementsByTagName("Ganancia");

						// ArrayList ganancias = new ArrayList();
						int totalGAV = textGAVList.getLength();
						for (int l = 0; l < totalGAV; l++) {
							/*
							 * int r=0; while (r <totalGA){
							 */
							Node nodoPrimerGAV = textGAVList.item(l);
							if (nodoPrimerGAV.getNodeType() == Node.ELEMENT_NODE) {

								Element elementoGAV = (Element) nodoPrimerGAV;

								// Etiqueta Angulo// -------
								NodeList listaGAV = elementoGAV
										.getElementsByTagName("Valor");
								// Element elementoNombreA =
								// (Element)listaA.item(0);
								Element elementoNombreGAV = (Element) listaGAV
										.item(0);

								NodeList textGANVList = elementoNombreGAV
										.getChildNodes();
								System.out.println("Ganancia PV: "
										+ ((Node) textGANVList.item(0))
												.getNodeValue().trim());
								// double angulo =
								// Double.parseDouble(((Node)textAList.item(0)).getNodeValue().trim());
								String gananciaP = ((Node) textGANVList.item(0))
										.getNodeValue().trim();
								gananciasPV.add(Double.parseDouble(gananciaP));

							}

						}

					}

					Object[] datosPH = new Object[] {};
					Object[] datosPV = new Object[] {};

					datosPH = new Object[] { angulosPH, gananciasPH };
					datosPV = new Object[] { angulosPV, gananciasPV };
					// PatronRadiacion patronH = new PatronRadiacion(datosPH);
					TipoAntena tipoAntena;
					if (tipo.equals("Isotropica")) {
						tipoAntena = new TipoAntena(nombreTipoAntena, ganancia,
								tipo);
					} else {
						tipoAntena = new TipoAntena(nombreTipoAntena, ganancia,
								datosPH, datosPV, tipo);
					}

					proyecto.agregarTipoAntena(tipoAntena);

				}// end of if clause

			}// end of for loop with s var , hasta aca cree el Tipo de Antena
				// nuevo

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Lee los canales de frecuencia con sus respectivas frecuencias del archivo
	 * xml donde se guardo el proyecto y los agrega al proyecto que se va a
	 * abrir
	 */
	public static void leerCanalesFrecuencia(NodeList listaCanales) {

		// ArrayList canal = new ArrayList();
		String nombreCanal = "";
		String frecuencia = "";
		try {
			int totalcanal = listaCanales.getLength();
			for (int r = 0; r < listaCanales.getLength(); r++) {
				Node nodoPrimerCanal = listaCanales.item(r);
				if (nodoPrimerCanal.getNodeType() == Node.ELEMENT_NODE) {

					Element elementoCanal = (Element) nodoPrimerCanal;

					// Etiqueta Nombre Canal// -------
					NodeList listaNombresTipoAntena = elementoCanal
							.getElementsByTagName("Nombre");
					Element elementoNombreCanal = (Element) listaNombresTipoAntena
							.item(0);

					NodeList textNombreCanalList = elementoNombreCanal
							.getChildNodes();
					System.out.println("Nombre Canal : "
							+ ((Node) textNombreCanalList.item(0))
									.getNodeValue().trim());
					nombreCanal = ((Node) textNombreCanalList.item(0))
							.getNodeValue().trim();

					// Etiqueta Frecuencia// -------
					NodeList listaNombreF = elementoCanal
							.getElementsByTagName("Frecuencia");
					ArrayList<Double> frecuencias = new ArrayList<Double>();
					int totalFrec = listaNombreF.getLength();
					for (int s = 0; s < listaNombreF.getLength(); s++) {
						Node nodoPrimerF = listaNombreF.item(s);
						if (nodoPrimerF.getNodeType() == Node.ELEMENT_NODE) {

							Element elementoF = (Element) nodoPrimerF;

							// Etiqueta Frec// -------
							NodeList listaF = elementoF
									.getElementsByTagName("Valor");
							Element elementoNombreF = (Element) listaF.item(0);

							NodeList textNombreFList = elementoNombreF
									.getChildNodes();
							System.out.println("Frecuencia : "
									+ ((Node) textNombreFList.item(0))
											.getNodeValue().trim());
							frecuencia = ((Node) textNombreFList.item(0))
									.getNodeValue().trim();

							frecuencias.add(Double.parseDouble(frecuencia));

						}
					}

					CanalFrecuencias canalF = new CanalFrecuencias(nombreCanal,
							frecuencias);

					// canalesDeFrecuencias.add(canalF);

					proyecto.agregarCanal(canalF);

				}// end of if clause

			}// end of for loop with r var

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Lee los links(direcciones URL) de las predicciones que fueron guardadas
	 * en el archivo XML y los agrega al proyecto que se decidio abrir
	 */
	public static void leerLinksPredicciones(NodeList listaLinksCRProy) {
		ArrayList linksPredicciones = new ArrayList();
		try {
			int totalLinks = listaLinksCRProy.getLength();
			for (int r = 0; r < totalLinks; r++) {
				Node nodoPrimerLink = listaLinksCRProy.item(r);
				if (nodoPrimerLink.getNodeType() == Node.ELEMENT_NODE) {

					Element elementoLink = (Element) nodoPrimerLink;

					// Etiqueta Direccion// -------
					NodeList listaNombresLink = elementoLink
							.getElementsByTagName("Direccion");
					Element elementoNombreLink = (Element) listaNombresLink
							.item(0);

					NodeList textNombreLinkList = elementoNombreLink
							.getChildNodes();
					System.out.println("Link Prediccion : "
							+ ((Node) textNombreLinkList.item(0))
									.getNodeValue().trim());
					String link = ((Node) textNombreLinkList.item(0))
							.getNodeValue().trim();

					URL linkCapaResultados = new URL(link);

					proyecto.agregarLinkCapaResultados(linkCapaResultados);

				}// end of if clause

			}// end of for loop with r var

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	/**
	 * Crea un modelo en base al nombre del modelo, los parametros ajustables y
	 * los parametros no ajustables
	 */
	public static Modelo determinarModelo(String nombreModelo,
			double[] parametrosAjustables, Object[] parametrosNoAjustables) {
		Modelo modelo = null;
		try {

			if (nombreModelo.equals(Modelo.VACIO)) {
				modelo = new Vacio(parametrosAjustables, parametrosNoAjustables);
			} else if (nombreModelo.equals(Modelo.ITUR_P1546)) {
				modelo = new ITU_R_P1546(parametrosAjustables,
						parametrosNoAjustables);
			} else if (nombreModelo.equals(Modelo.OKUMURA_HATA)) {
				modelo = new OkumuraHata(parametrosAjustables,
						parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.TIERRA_PLANA)) {
				modelo = new TierraPlana(parametrosAjustables,
						parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.TIERRA_PLANA_APROXIMADA)) {
				modelo = new TierraPlanaAproximada(parametrosAjustables,
						parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.COST_231_WI)) {
				modelo = new Cost231WI(parametrosAjustables,
						parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.COST_231_WI_SIMPLE)) {
				modelo = new Cost231WISimple(parametrosAjustables,
						parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.ERCEG_SUI)) {
				modelo = new Erceg(parametrosAjustables, parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.MOPEM)) {
				modelo = new Mopem(parametrosAjustables, parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.VOGLER_SB)) {
				modelo = new VoglerSaundersBonar(parametrosAjustables,
						parametrosNoAjustables);

			} else if (nombreModelo.equals(Modelo.VOGLER_IKEGAMI)) {
				modelo = new VoglerIkegami(parametrosAjustables,
						parametrosNoAjustables);

			} else {
				System.out.println("NO ENCONTRO MODELO");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return modelo;
	}
}
