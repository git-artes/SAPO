package sapo.archivos;

import java.awt.image.WritableRaster;
import java.io.IOException;
import java.io.Reader;
import java.io.StreamTokenizer;
import java.net.URL;

import javax.media.jai.RasterFactory;

import org.geotools.data.arcgrid.ArcGridRaster;

/**
 * Esta clase corrige algunos problemas de la clase org.geotools.data.arcgrid.ArcGridRaster 
 * @author Grupo de proyecto SAPO
 */

public class ArcGridRasterGeneral extends ArcGridRaster {

	public ArcGridRasterGeneral(URL srcURL) throws IOException {
		super(srcURL);
	}

	/**
	 * * Returns the WritableRaster of the raster
	 * 
	 * @return RenderedImage
	 *  
	 */

	@Override
	public WritableRaster readRaster() throws IOException {

		// open reader and make tokenizer
		Reader reader = openReader();
		StreamTokenizer st = new StreamTokenizer(reader);

		// parse header
		parseHeader(st);

		// reconfigure tokenizer
		st.resetSyntax();
		st.parseNumbers();
		st.whitespaceChars(' ', ' ');
		st.whitespaceChars(' ', '\t');
		st.whitespaceChars('\n', '\n');
		st.whitespaceChars('\r', '\r');//linefeed (on windows only?)
		st.whitespaceChars('\f', '\f');//form feed (on printers????)
		st.eolIsSignificant(false);
		st.ordinaryChars('E', 'E');

		// allocate raster, for now this is done with floating point data,
		// though eventually it should be configurable
		WritableRaster raster = RasterFactory.createBandedRaster(
				java.awt.image.DataBuffer.TYPE_FLOAT, getNCols(), getNRows(),
				1, null);

		// Read values from grid and put into raster.
		// Values must be numbers, which may be simple <num>, or expressed
		// in scientific notation <num>E<exp>.
		// The following loop can read both, even if mixed.

		// The loop expects a token to be read already
		st.nextToken();

		this.maxValue = -Long.MAX_VALUE; //para corregir el bug que el máximo
										 // sea Long.MIN_VALUE
		for (int y = 0; y < getNRows(); y++) {
			for (int x = 0; x < getNCols(); x++) {

				// this call always reads the next token
				double d = readCell(st, x, y);

				// mask no data values with NaN
				if (d == getNoData()) {
					d = Double.NaN;
				} else {
					minValue = Math.min(minValue, d);
					maxValue = Math.max(maxValue, d);
				}

				// set the value at x,y in band 0 to the parsed value
				raster.setSample(x, y, 0, d);

			}
		}

		reader.close();

		return raster;
	}

	/***************************************************************************
	 * Parse a number.
	 */
	private double readCell(StreamTokenizer st, int x, int y)
			throws IOException {
		double d = 0;

		// read a token, expected: a number
		switch (st.ttype) {
		case StreamTokenizer.TT_NUMBER:
			d = (float) st.nval;
			break;
		case StreamTokenizer.TT_EOF:
			throw new IOException("Unexpected EOF at " + x + "," + y);
		default:
			throw new IOException("Unknown token " + st.ttype);
		}

		// read another. May be an exponent of this number.
		// If its not an exponent, its the next number. Fall through
		// and token is prefetched for next loop...
		switch (st.nextToken()) {
		case 'e':
		case 'E':
			// now read the exponent
			st.nextToken();
			if (st.ttype != StreamTokenizer.TT_NUMBER)
				throw new IOException("Expected exponent at " + x + "," + y);
			// calculate
			d = d * Math.pow(10.0, st.nval);

			// prefetch for next loop
			st.nextToken();

			break;
		case StreamTokenizer.TT_NUMBER:
		case StreamTokenizer.TT_EOF:
			break;
		default:
			throw new IOException("Expected Number or EOF");
		}

		return d;
	}
}
