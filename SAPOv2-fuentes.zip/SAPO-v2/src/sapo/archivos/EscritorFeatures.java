package sapo.archivos;

import java.awt.image.WritableRaster;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;

import org.geotools.data.FeatureStore;
import org.geotools.data.FeatureWriter;
import org.geotools.data.arcgrid.ArcGridRaster;
import org.geotools.data.shapefile.ShapefileDataStore;
import org.geotools.feature.AttributeType;
import org.geotools.feature.AttributeTypeFactory;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.feature.FeatureType;
import org.geotools.feature.FeatureTypeFactory;

import sapo.predicciones.AnalisisModelo;
import sapo.principal.Comandos;
import sapo.raster.Grilla;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.MultiPolygon;
import com.vividsolutions.jts.geom.Polygon;

/**
 * Esta clase toma features y las escribe a disco en distintos formatos.
 * 
 * @author Grupo de proyecto SAPO
 */

public class EscritorFeatures {

	/**
	 * Escribe la grilla en el directorio y archivo especficado.
	 * 
	 * @param grilla 
	 *            la grilla a ser escrita
	 * @param formatoElegido 
	 *            un String especificando el formato deseado. Debe estar entre
	 *            los que aparecen en Comandos.FORMATOS_GRIDS.
	 * @param directorio 
	 *            El directorio donde se desea guardar el archivo.
	 * @param nombreArchivo 
	 *            El nombre del archivo.
	 */
	public static void escribirGrilla(Grilla grilla, String formatoElegido,
			File directorio, String nombreArchivo)
			throws MalformedURLException, IOException {
		ArcGridRaster agRaster = null;
		boolean comprimido = false;
		boolean grass = false;
		String[] formatos = Comandos.FORMATOS_GRIDS;
		String[] extensiones = new String[0];

		if (formatoElegido.equals(formatos[0])) {
			comprimido = false;
			grass = false;
			extensiones = new String[] { "arc", "asc", "grd" };
		}
		if (formatoElegido.equals(formatos[1])) {
			comprimido = true;
			grass = false;
			extensiones = new String[] { "arc.gz", "asc.gz", "grd.gz" };
		}
		if (formatoElegido.equals(formatos[2])) {
			comprimido = false;
			grass = true;
			extensiones = new String[] { "arx" };
		}
		if (formatoElegido.equals(formatos[3])) {
			comprimido = true;
			grass = true;
			extensiones = new String[] { "arx.gz" };
		}

		directorio.mkdir();

		File archivo = new File(directorio, nombreArchivo + "."
				+ extensiones[0]);

		WritableRaster raster = grilla.getRaster();
		double xMin = grilla.getGridCoverage().getEnvelope().getMinimum(0);
		double yMin = grilla.getGridCoverage().getEnvelope().getMinimum(1);
		double xMax = grilla.getGridCoverage().getEnvelope().getMaximum(0);
		double yMax = grilla.getGridCoverage().getEnvelope().getMaximum(1);
		double paso = Math.max((yMax - yMin) / raster.getHeight(),
				(xMax - xMin) / raster.getWidth());

		if (grass) {
			agRaster = new GRASSArcGridRasterGeneral(archivo.toURL());
		} else {
			agRaster = new ArcGridRasterGeneral(archivo.toURL());
		}
		agRaster.writeRaster(raster, xMin, yMin, paso, comprimido);

	}

	/**
	 * Escribe en el mismo formato que las medidas de donde se leyó el
	 * analisisModelo, las predicciones realizadas por el mismo.
	 */
	public static void escribirPredicciones(AnalisisModelo am, File destino)
			throws IOException {

		BufferedWriter out = new BufferedWriter(new FileWriter(destino));
		Coordinate coordenada;
		for (int j = 0; j < am.cuantasMedidas(); j++) {
			coordenada = am.getCoordenada(j);
			out.write(coordenada.x + " " + coordenada.y + " "
					+ am.getPrediccion(j) + "\n");
		}
		out.close();

	}
	
	public static void escribirAjuste(AnalisisModelo am, File destino)
			throws IOException {

		BufferedWriter out = new BufferedWriter(new FileWriter(destino));
		Coordinate coordenada;
		double ajuste;
		for (int j = 0; j < am.cuantasMedidas(); j++) {
			coordenada = am.getCoordenada(j);
			ajuste = am.getParamAjuste()[0] + am.getParamAjuste()[1]*Math.log10(am.getDistancias()[j]);
			out.write(coordenada.x + " " + coordenada.y + " "
					+ ajuste + "\n");			
		}
		out.close();

	}


	/**
	 * Escribe un shp de edificios a partir de la FeatueCollection
	 * 
	 * @param fc 
	 * *            la FeatureColection de edificios
	 * @param destino 
	 *            el archivo de destino
	 */
	public static void escribirShpEdificios(FeatureCollection fc, File destino) {
		try {
			org.geotools.data.shapefile.ShapefileDataStore store = new ShapefileDataStore(
					destino.toURL());
			AttributeType geom = AttributeTypeFactory.newAttributeType(
					"the_geom", Polygon.class);
			AttributeType atribAltura = AttributeTypeFactory.newAttributeType(
					"altura", Double.class);
			//AttributeType atribColor =
			// AttributeTypeFactory.newAttributeType("color",String.class);
			//AttributeType atribManzana =
			// AttributeTypeFactory.newAttributeType("manzana",String.class);
			FeatureType ftEdificio = FeatureTypeFactory.newFeatureType(
					new AttributeType[] { geom, atribAltura }, "edificio");
			store.createSchema(ftEdificio);

			FeatureWriter aWriter = store.getFeatureWriter("edificio",
					((FeatureStore) store.getFeatureSource("edificio"))
							.getTransaction());
			FeatureIterator lector = fc.features();
			while (lector.hasNext()) {
				Feature edificio = lector.next();
				Geometry geometria = edificio.getDefaultGeometry();
				if (geometria.getClass().equals(
						com.vividsolutions.jts.geom.MultiPolygon.class)) {
					edificio
							.setDefaultGeometry(((MultiPolygon) geometria)
									.getGeometryN(0));
				}
				Feature aNewFeature = aWriter.next();
				//System.out.println("atrib a setear:" +
				// edificio.getAttribute("altura"));

				aNewFeature.setAttribute("the_geom", edificio
						.getAttribute("the_geom"));
				aNewFeature.setAttribute("altura", edificio
						.getAttribute("altura"));

				//aNewFeature.setAttributes(edificio.getAttributes(null));
				aWriter.write();
			}
			aWriter.close();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}

	/**
	 * Escribe un shp de manzanas a partir de la FeatueCollection
	 * 
	 * @param fc 
	 *            la FeatureColection de manzanas
	 * @param destino 
	 *             el archivo de destino
	 */
	public static void escribirShpManzanas(FeatureCollection fc, File destino) {
		try {
			org.geotools.data.shapefile.ShapefileDataStore store = new ShapefileDataStore(
					destino.toURL());
			AttributeType geom = AttributeTypeFactory.newAttributeType(
					"the_geom", Polygon.class);
			FeatureType ftManzana = FeatureTypeFactory.newFeatureType(
					new AttributeType[] { geom }, "manzana");
			store.createSchema(ftManzana);

			FeatureWriter aWriter = store.getFeatureWriter("manzana",
					((FeatureStore) store.getFeatureSource("manzana"))
							.getTransaction());
			FeatureIterator lector = fc.features();
			while (lector.hasNext()) {
				Feature manzana = lector.next();
				Feature aNewFeature = aWriter.next();
				aNewFeature.setAttribute("the_geom", manzana
						.getAttribute("the_geom"));
				//aNewFeature.setAttributes(manzana.getAttributes(null));
				aWriter.write();
			}
			aWriter.close();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}

}
