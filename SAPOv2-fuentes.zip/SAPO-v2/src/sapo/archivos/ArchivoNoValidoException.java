package sapo.archivos;

/**
 * Esta excepción es lanzada al leer un archivo raster o vectorial, si la extensión 
 * no está entre las soportadas o si hay algún error al extraer los datos del archivo.
 * @author Grupo de proyecto SAPO
 */

public class ArchivoNoValidoException extends Exception {

	public ArchivoNoValidoException(String mensaje) {
		super("El archivo no es valido. " + mensaje);
	}

}
