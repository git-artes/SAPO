package sapo.archivos;

import java.io.File;
import java.net.MalformedURLException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * Esta clase maneja la apertura y guardado de archivos
 * 
 * @author Grupo de proyecto SAPO
 */

public class Archivos {

	JFileChooser fileChooser;

	/**
	 * Crea una instancia de Archivos
	 * 
	 */
	public Archivos() {
		this.fileChooser = new JFileChooser();
	}

	/**
	 * Permite seleccionar un archivo de disco
	 */
	public File abrirArchivo(String extension, String descripcion)
			throws MalformedURLException {
		File f = null;
		fileChooser.setFileFilter(new FiltroArchivo(extension, descripcion));
		int resultado = fileChooser.showOpenDialog(null);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			f = fileChooser.getSelectedFile();
		}
		return f;
	}

	/*
	 * public static File abrirArchivoF(String extension, String descripcion)
	 * throws MalformedURLException{ URL direccion = null; File f = null;
	 * JFileChooser fileChooser = new JFileChooser();
	 * fileChooser.setFileFilter(new FiltroArchivo(extension, descripcion)); int
	 * resultado = fileChooser.showOpenDialog(null); if (resultado ==
	 * JFileChooser.APPROVE_OPTION) { f = fileChooser.getSelectedFile();
	 * direccion = f.toURL(); } return f; }
	 */

	/**
	 * Permite seleccionar un archivo de disco filtrando la visualizacion segun
	 * varias extensiones
	 */
	public File abrirArchivo(String[] extensiones, String descripcion)
			throws MalformedURLException {
		File f = null;
		fileChooser.setFileFilter(new FiltroArchivo(extensiones, descripcion));
		int resultado = fileChooser.showOpenDialog(null);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			f = fileChooser.getSelectedFile();
		}
		return f;
	}

	/**
	 * Permite guardar un archivo a disco
	 */
	public File guardarArchivo(String nombreSugerido, String extension,
			String descripcion) throws MalformedURLException {
		int result;
		File f = null;
		fileChooser.setFileFilter(new FiltroArchivo(extension, descripcion));
		fileChooser.setSelectedFile(new File(nombreSugerido));
		int resultado = fileChooser.showSaveDialog(fileChooser);
		f = fileChooser.getSelectedFile();
		while (f.exists() && resultado == JFileChooser.APPROVE_OPTION) {
			result = JOptionPane.showConfirmDialog(fileChooser,
					"El archivo seleccionado existe\n ¿Desea sobreescribirlo?",
					"Sobreescribir", JOptionPane.YES_NO_OPTION);
			if (result == JOptionPane.YES_OPTION) {
				return f;
			} else {
				resultado = fileChooser.showSaveDialog(fileChooser);
			}
		}
		return f;
	}

	/**
	 * Permite guardar un archivo a disco filtrando la visualizacion segun
	 * varias extensiones
	 */

	public File guardarArchivo(String nombreSugerido, String[] extensiones,
			String descripcion) throws MalformedURLException {
		File f = null;
		fileChooser.setFileFilter(new FiltroArchivo(extensiones, descripcion));
		fileChooser.setSelectedFile(new File(nombreSugerido));
		int resultado = fileChooser.showSaveDialog(null);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			f = fileChooser.getSelectedFile();
		}
		return f;
	}

	/**
	 * Devuelve el último nombre seleccionado.
	 */
	public String getUltimoNombre() {
		return this.fileChooser.getSelectedFile().getName();
	}

}
