package sapo.archivos;

import java.awt.image.WritableRaster;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.geotools.cs.CoordinateSystem;
import org.geotools.data.FeatureSource;
import org.geotools.data.shapefile.ShapefileDataStore;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureCollections;
import org.geotools.feature.IllegalAttributeException;
import org.geotools.feature.SchemaException;

import sapo.predicciones.AnalisisModelo;
import sapo.raster.Grilla;
import sapo.red.Sitio;
import sapo.vectorial.Manzana;

import com.vividsolutions.jts.geom.Coordinate;

/**
 * 
 * Esta clase es la que realiza la conversiï¿œn entre archivos y features. Es
 * decir, sus mï¿œtodos toman archivos y devuelven las features que contienen.
 * Depende del formato del archivo, quï¿œ features devolverï¿œ o intentarï¿œ
 * devolver.
 * 
 * @author Grupo de proyecto SAPO
 */

public class LectorFeatures {

	/**
	 * Este mï¿œtodo toma un archivo que contenga un ArcGridRaster o un
	 * GrassArcGridRaster y lo devuelve en una Grilla (NOTA la Grilla devuelta
	 * tiene asignados correctamente el mï¿œximo y el mï¿œnimo).
	 * 
	 * @param direccionLinkCapaAlturas 
	 *            el archivo a leer
	 * @param cs 
	 *            el sistema de coordenadas que debe tener la grilla
	 * @return  una grilla con los datos del archivo
	 * @throws ArchivoNoValidoException 
	 *             Cuando el archivo especificado no tiene una terminaciï¿œn
	 *             soportada o hubo algï¿œn problema creando la grilla.
	 * @throws IOException 
	 *             si hubo algï¿œn problema al leer el archivo.
	 */
	public static Grilla leerAlturas(URL direccionLinkCapaAlturas,
			CoordinateSystem cs) throws ArchivoNoValidoException, IOException {
		WritableRaster raster = null;
		double xMin = 0;
		double yMin = 0;
		double pasoX = 1;
		double pasoY = 1;
		double min, max;

		String nombre = direccionLinkCapaAlturas.getFile();

		if (nombre.endsWith(".asc") || nombre.endsWith(".asc.gz")
				|| nombre.endsWith(".arc") || nombre.endsWith(".arc.gz")
				|| nombre.endsWith(".grd") || nombre.endsWith(".grd.gz")) {

			ArcGridRasterGeneral agr = new ArcGridRasterGeneral(
					direccionLinkCapaAlturas);
			raster = agr.readRaster();
			xMin = agr.getXlCorner();
			yMin = agr.getYlCorner();
			pasoX = agr.getCellSize();
			pasoY = pasoX;
			min = agr.getMinValue();
			max = agr.getMaxValue();
		} else if (nombre.endsWith(".arx") || nombre.endsWith(".arx.gz")) {

			GRASSArcGridRasterGeneral GRASSagr = new GRASSArcGridRasterGeneral(
					direccionLinkCapaAlturas);
			raster = GRASSagr.readRaster();
			xMin = GRASSagr.getXlCorner();
			yMin = GRASSagr.getYlCorner();
			pasoX = GRASSagr.getPasoX();
			pasoY = GRASSagr.getPasoY();
			min = GRASSagr.getMinValue();
			max = GRASSagr.getMaxValue();
			//pasoY = pasoX;
		} else {
			throw new ArchivoNoValidoException(
					"La extensiï¿œn del archivo no ha sido reconocida.\n"
							+ "Las extensiones vï¿œlidas son: asc, arc, grd, arx, asc.gz, arc.gz, grd.gz, arx.gz");
			/*
			 * JOptionPane.showMessageDialog(this, "La extensiï¿œn del archivo no
			 * ha sido reconocida.\n"+"Las extensiones vï¿œlidas son: asc, arc,
			 * grd, arx, asc.gz, arc.gz, grd.gz, arx.gz", "Abrir archivo",
			 * JOptionPane.WARNING_MESSAGE); //direccion =
			 * Archivos.abrirArchivo(new String[]{"asc","arc","grd","arx","gz"},
			 * "ArcInfo ASCII o GRASS ASCII").toURL(); dirCapaAlturas =
			 * Archivos.abrirArchivo(new String[]{"asc","arc","grd","arx","gz"},
			 * "ArcInfo ASCII o GRASS ASCII").toURL();
			 */
		}
		try {
			Grilla grilla = new Grilla(nombre, cs, raster, xMin, yMin, pasoX,
					pasoY);
			grilla.setMax(max);
			grilla.setMin(min);
			return grilla;
		} catch (IllegalAttributeException e) {
			e.printStackTrace();
			throw new ArchivoNoValidoException(
					"Hubo un problema al crear la grilla a partir del archivo. \n"
							+ e.getMessage());
		} catch (SchemaException e) {
			e.printStackTrace();
			throw new ArchivoNoValidoException(
					"Hubo un problema al crear la grilla a partir del archivo. \n"
							+ e.getMessage());
		}
	}

	/**
	 * Obtiene un FeatureCollection del .shp indicado por el URL.
	 * 
	 * @param link 
	 *            la URL del archivo a obtener el FeatureCollection.
	 * @return  la featureCollection obtenida del archivo.
	 * @throws ArchivoNoValidoException 
	 *             cuando la URL no es vï¿œlida, o cuando hubo algï¿œn problema al
	 *             crear el featureCollection (por ejemplo, el archivo no
	 *             contenï¿œa una featurecollection).
	 */
	public static FeatureCollection leerShp(URL link)
			throws ArchivoNoValidoException {
		try {
			ShapefileDataStore store = new ShapefileDataStore(link);
			String name = store.getTypeNames()[0]; //El cero es para ya
												   // quedarse con el primer
												   // elemento del array,
			//que dado que es un shapefile es el ï¿œnico que hay.
			FeatureSource source = store.getFeatureSource(name);
			FeatureCollection fc = source.getFeatures().collection();
			return fc;
		} catch (MalformedURLException e) {
			throw new ArchivoNoValidoException(
					"El nombre del archivo indicado no es vï¿œlido. ");
		} catch (IOException e) {
			throw new ArchivoNoValidoException(
					"Hubo un problema al leer el shp. \n" + e.getMessage());
		}
	}

	/**
	 * Obtiene un FeatureCollection del .txt indicado por el URL.
	 * 
	 * @param link 
	 *            la URL del archivo a obtener el FeatureCollection.
	 * @return la featureCollection obtenida del archivo.
	 * @throws ArchivoNoValidoException 
	 *             cuando la URL no es vï¿œlida, o cuando hubo algï¿œn problema al
	 *             crear la FeatureCollection
	 */
	public static FeatureCollection leerTxtManzanas(URL link)
			throws ArchivoNoValidoException {
		try {
			FeatureCollection manzanas = FeatureCollections.newCollection();
			BufferedReader in = new BufferedReader(new FileReader(link
					.getFile()));

			String[] linea;

			Coordinate[] aux = new Coordinate[2]; //lugar donde se guardaran
												  // las esquinas de c/cuadra
			Coordinate[][] manzana; //lugar donde se guardaran las cuadras para
									// armar la manzana
			double[] anchos;
			int contador = 0;

			String oracion = in.readLine(); //leo una lï¿œnea del archivo
			contador = 0;

			while (oracion != null) {
				linea = oracion.split(" ");
				linea = in.readLine().split(" ");//leo la siguiente lï¿œnea,
												 // donde estï¿œn los datos
				int i = 0;
				manzana = new Coordinate[linea.length / 2][2];
				while (i < linea.length - 2) {
					aux = new Coordinate[] {
							new Coordinate(Double.parseDouble(linea[i]), Double
									.parseDouble(linea[i + 1])),
							new Coordinate(Double.parseDouble(linea[i + 2]),
									Double.parseDouble(linea[i + 3])) };
					manzana[i / 2] = aux;
					i++;
					i++;
				}
				in.readLine(); //me salteo una lï¿œnea
				linea = in.readLine().split(" ");
				anchos = new double[linea.length];
				for (i = 0; i < anchos.length; i++) {
					anchos[i] = Double.parseDouble(linea[i]);
				}
				//retorno[contador] = new Manzana(manzana,anchos);
				contador++;
				manzanas.add(new Manzana(manzana, anchos).getFeature());
				//}
				oracion = in.readLine();
			}

			if (manzanas.isEmpty()) {
				throw new ArchivoNoValidoException(
						"Hubo un problema al leer el archivo.");
			}
			return manzanas;
		} catch (Exception e) {
			throw new ArchivoNoValidoException(
					"Hubo un problema al leer el archivo. \n" + e.getMessage());
		}

	}

	/**
	 * Obtiene del archivo indicado por <code>link</code> datos de coordenadas
	 * (primera y segunda columna) y la potencia medida (tercera columna, todas
	 * separadas entre sï¿œ por un espacio) y las agrega a <code>am</code>.
	 */
	public static void agregarMedidas(AnalisisModelo am, URL link, boolean wgs)
			throws ArchivoNoValidoException {
		try {
			BufferedReader in = new BufferedReader(new FileReader(link
					.getFile()));
			String linea = in.readLine();
			Coordinate coordenada;
			double potencia;
			Sitio aux = new Sitio();
			while (linea != null && !linea.equals("")) {
				String[] datos = linea.split(" ");
				if(wgs){
					double[] sirgas = aux.cambioCoord(Double.parseDouble(datos[0]), Double.parseDouble(datos[1]));
					coordenada = new Coordinate(sirgas[0],
							sirgas[1]);
				}else{
					coordenada = new Coordinate(Double.parseDouble(datos[0]),
							Double.parseDouble(datos[1]));
				}
				potencia = Double.parseDouble(datos[2]);
				am.agregarMedida(coordenada, potencia);
				linea = in.readLine();
			}
		} catch (FileNotFoundException e) {
			throw new ArchivoNoValidoException("El archivo" + link
					+ " no fue encontrado");
		} catch (IOException e) {
			throw new ArchivoNoValidoException("Hubo un problema de I/O");
		} catch (Exception e) {
			throw new ArchivoNoValidoException(
					"El archivo no cumple el formato esperado. ");
		}
	}

	public static void agregarPredicciones(AnalisisModelo am, URL link)
			throws ArchivoNoValidoException, IndexOutOfBoundsException {
		try {
			BufferedReader in = new BufferedReader(new FileReader(link
					.getFile()));
			String linea = in.readLine();
			Coordinate coordenada = null;
			double prediccion;
			while (linea != null && !linea.equals("")) {
				String[] datos = linea.split(" ");
				try {
					coordenada = new Coordinate(Double.parseDouble(datos[0]),
							Double.parseDouble(datos[1]));
					prediccion = Double.parseDouble(datos[2]);
				} catch (IndexOutOfBoundsException e) {
					throw new Exception(
							"Este error lo toma el catch de mï¿œs abajo y sirve para que "
									+ "el IndexOutOfBounds solo lo agarre el catch de abajo y lo mande para arriba "
									+ "pues es en el caso que quiera agregar predicciones en coordenadas aï¿œn inexistentes. ");
				}
				am.agregarPrediccion(coordenada, prediccion);
				linea = in.readLine();
			}
		} catch (IndexOutOfBoundsException e) {
			throw new IndexOutOfBoundsException(
					"No existen cï¿œlculos realizados para las coordenadas especï¿œficadas en el archivo. ");
		} catch (FileNotFoundException e) {
			throw new ArchivoNoValidoException("El archivo" + link
					+ " no fue encontrado");
		} catch (IOException e) {
			throw new ArchivoNoValidoException("Hubo un problema de I/O");
		} catch (Exception e) {
			throw new ArchivoNoValidoException(
					"El archivo no cumple el formato esperado. ");
		}
	}

}
