package sapo.archivos;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;

import org.geotools.data.FeatureReader;
import org.geotools.data.FeatureSource;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureCollections;
import org.geotools.feature.FeatureIterator;
import org.geotools.renderer.j2d.GeoMouseEvent;

import sapo.capas.CapaVectorial;
import sapo.capas.estilos.EstiloEdificios;
import sapo.capas.estilos.EstiloManzanas;
import sapo.ifusuario.ContenedorMapaGeneral;
import sapo.ifusuario.EdificioMalIngresadoException;
import sapo.ifusuario.MapaEdificios;
import sapo.ifusuario.PanelEdificios;
import sapo.ifusuario.menues.BarraInferior;
import sapo.vectorial.Cuadra;
import sapo.vectorial.Edificio;
import sapo.vectorial.Esquina;
import sapo.vectorial.Manzana;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineSegment;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.MultiPolygon;
import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.operation.buffer.BufferOp;

/**
 * Esta clase es la encargada de manejar el flujo de ejecución del Generador de Edificios, 
 * módulo que permite la creación de edificios mediante una interfaz gráfica. 
 * Permite devolver la FeatureCollection de edificios y/o manzanas.
 * @author Grupo de Proyecto SAPO.
 */

public class GeneradorEdificios implements ActionListener, MouseListener,
		MouseMotionListener {

	/**
	 * La ventana principal del Generador de Edificios
	 */
	JDialog contenedorPrincipal;

	/**
	 * El panel para ingreso de datos y despliegue de informacion
	 */
	PanelEdificios botones;

	/**
	 * El panel que contieen el mapa y permite las acciones de zoom
	 */
	ContenedorMapaGeneral mp;

	/**
	 * El mapa con las diferentes capas a desplegar
	 */
	MapaEdificios mapa;

	/**
	 * La barra que despliega las coordenadas del raton
	 */
	BarraInferior barra;

	/**
	 * La direccion URL del shp de edificios generado
	 * 
	 */
	URL linkEdificios;

	/**
	 * La direccion URL del shp de manzanas generado
	 * 
	 */
	URL linkManzanas;

	/**
	 * La FeatureCollection con los edificios que se van generando
	 * 
	 */
	FeatureCollection edificios = FeatureCollections.newCollection();

	/**
	 * Crea un Generador de Edificios a partir de las capas de manzanas y
	 * edificios. Éstas pueden ser nulas.
	 */
	public GeneradorEdificios(JFrame duenio, CapaVectorial capaManzanas,
			CapaVectorial capaEdificios)  {
		try {
			contenedorPrincipal = new JDialog(duenio, true);
			contenedorPrincipal.setTitle("SAPO - Generador de Edificios v.0.1");
			contenedorPrincipal.setSize(new Dimension(400, 180));

			if (capaManzanas.esVacia()) {
				int opcionElegida = JOptionPane
						.showConfirmDialog(
								contenedorPrincipal,
								" Debe disponer de la capa de manzanas para utilizar el Generador de Edificios.\n "
										+ "Utilice la opción Abrir Datos del menú para cargar el shp y vuelva a intentar.\n"
										+ "¿Desea generar un shp a partir de un archivo de texto?\n\n",
								"Error", JOptionPane.YES_NO_OPTION,
								JOptionPane.QUESTION_MESSAGE);
				if (opcionElegida == JOptionPane.YES_OPTION) {
					Archivos archivos = new Archivos();
					File archivoTxt = archivos.abrirArchivo("txt",
							"Archivo de manzanas");
					FeatureCollection manzanas = LectorFeatures
							.leerTxtManzanas(archivoTxt.toURL());
					capaManzanas = new CapaVectorial(manzanas);
					capaManzanas.setStyle(new EstiloManzanas());
					JOptionPane
							.showMessageDialog(
									contenedorPrincipal,
									"Debe elegir un nombre con el cual generar almacenar el shp generado. ",
									"Guardar", JOptionPane.INFORMATION_MESSAGE);
					archivos = new Archivos();
					File archivoManz = archivos.guardarArchivo("", "shp",
							"Archivos shp");
					if (archivoManz != null) {
						EscritorFeatures.escribirShpManzanas(manzanas,
								archivoManz);
						linkManzanas = archivoManz.toURL();
					}
				} else
					return;

			}

			edificios = capaEdificios.getFeatureSource().getFeatures()
					.collection();

			barra = new BarraInferior();
			botones = new PanelEdificios(this, barra);

			mp = new ContenedorMapaGeneral();
			mapa = new MapaEdificios(capaManzanas, capaEdificios);
			mp.setPreferredSize(new Dimension(530, 470));

			mp.setMapContext(mapa);
			mp.agregarBarraEscala();
			mp.addMouseListener(this);
			mp.addMouseMotionListener(this);
			//mp.getRenderer().addLayer(new RenderedMapScale());

			JSplitPane contenedor = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
					mp.createScrollPane(), botones);
			contenedor.setContinuousLayout(true);
			contenedor.setDividerSize(2);

			contenedorPrincipal.getContentPane().add(contenedor);

			contenedorPrincipal.pack();
			contenedorPrincipal.setLocationRelativeTo(duenio);
			contenedorPrincipal.setVisible(true);
		} catch (MalformedURLException e){
			JOptionPane.showMessageDialog(contenedorPrincipal, e.toString(),
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch (ArchivoNoValidoException e) {
			JOptionPane.showMessageDialog(contenedorPrincipal, e.toString(),
					"Error", JOptionPane.ERROR_MESSAGE);

		} catch(IOException e){
			JOptionPane.showMessageDialog(contenedorPrincipal, e.toString(),
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch(Exception e){
			JOptionPane.showMessageDialog(contenedorPrincipal, e.toString(),
					"Error", JOptionPane.ERROR_MESSAGE);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource().equals(botones.getAceptar())) {
				try {
					double anchoEdif = botones.getAncho();
					double profEdif = botones.getProfundidad();
					double distanciaEsq = botones.getDistancia();
					double alturaEdif = botones.getAltura();

					//Se calculan los dos puntos del frente del edificio,
					// primero el mas cercano a la esquina y luego el otro.
					//Para ello se llevan a cabo 2 intersecciones.

					Coordinate esquinaElegida = botones.getEsquinaElegida();
					LineSegment cuadraElegida = botones.getCuadraElegida();
					if (!(cuadraElegida.p0.equals(esquinaElegida) || cuadraElegida.p1
							.equals(esquinaElegida))) {
						JOptionPane
								.showMessageDialog(
										contenedorPrincipal,
										"La esquina elegida no corresponde con la cuadra",
										"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}

					GeometryFactory fabrica = new GeometryFactory();
					Point puntoUno, puntoDos;

					if (distanciaEsq > 0) {
						BufferOp bufOp = new BufferOp(fabrica
								.createPoint(esquinaElegida));
						bufOp.setEndCapStyle(BufferOp.CAP_ROUND);
						Polygon circulo = (Polygon) bufOp
								.getResultGeometry(distanciaEsq);
						puntoUno = (Point) circulo
								.getExteriorRing()
								.intersection(
										fabrica
												.createLineString(new Coordinate[] {
														cuadraElegida
																.getCoordinate(0),
														cuadraElegida
																.getCoordinate(1) }));
					} else {
						puntoUno = fabrica.createPoint(esquinaElegida);
					}
					BufferOp bufOp = new BufferOp(fabrica
							.createPoint(esquinaElegida));
					bufOp.setEndCapStyle(BufferOp.CAP_ROUND);

					Polygon circulo = (Polygon) bufOp
							.getResultGeometry(distanciaEsq + anchoEdif);
					boolean exagerado = false;
					if (circulo.getExteriorRing().intersects(
							fabrica.createLineString(new Coordinate[] {
									cuadraElegida.getCoordinate(0),
									cuadraElegida.getCoordinate(1) }))) {
						puntoDos = (Point) circulo
								.getExteriorRing()
								.intersection(
										fabrica
												.createLineString(new Coordinate[] {
														cuadraElegida
																.getCoordinate(0),
														cuadraElegida
																.getCoordinate(1) }));
					} else {
						exagerado = true;
						puntoDos = fabrica.createPoint(cuadraElegida.p0);
						if (cuadraElegida.p0.equals(esquinaElegida)) {
							puntoDos = fabrica.createPoint(cuadraElegida.p1);
						}
					}

					//Se usa el dato de la profundidad para hallar el edificio
					LineString frente = fabrica
							.createLineString(new Coordinate[] {
									puntoUno.getCoordinate(),
									puntoDos.getCoordinate() });
					bufOp = new BufferOp(frente);
					bufOp.setEndCapStyle(BufferOp.CAP_BUTT);
					if (exagerado)
						bufOp.setEndCapStyle(BufferOp.CAP_SQUARE); //si exageró
																   // es por
																   // algo

					//Se agrega el nuevo edificio a la colección y se muestra
					// en el mapa

					FeatureReader lectorEdificios = mapa.capaEdificios
							.getFeatureSource().getFeatures().reader();
					Feature aux;
					Feature manzanaElegida = botones.getManzanaElegida();
					Polygon auxEdif;
					String auxManzana;
					Double auxAltura;
					FeatureCollection edificiosSacar = FeatureCollections
							.newCollection();
					FeatureCollection edificiosAgregar = FeatureCollections
							.newCollection();
					//Geometry copiaEdificio = edificio.intersection(edificio);
					// //tengo una geometry igual a edificio
					Geometry copiaEdificio = bufOp.getResultGeometry(profEdif)
							.intersection(botones.getPoligono());
					//pero antes de agregarlo nos fijamos si intersecciona con
					// algun otro edificio ya creado
					while (lectorEdificios.hasNext()) {
						aux = lectorEdificios.next();
						//auxManzana = (String)aux.getAttribute("manzana");

						Geometry auxGeom = (Geometry) aux
								.getAttribute("the_geom");
						if (auxGeom.getClass().equals(
								com.vividsolutions.jts.geom.MultiPolygon.class)) {
							auxEdif = (Polygon) ((MultiPolygon) auxGeom)
									.getGeometryN(0);
						} else {
							auxEdif = (Polygon) auxGeom;
						}
						auxAltura = (Double) aux.getAttribute("altura");

						//if(manzanaElegida.getID().equals(auxManzana)){ //si
						// intersecciona, debo elegir uno para asignar en la
						// interseccion
						if (copiaEdificio.intersects(auxEdif)) {
							//Object[] posibilidades = {copiaEdificio,
							// auxEdif};
							String nuevo = Edificio
									.getString((Polygon) copiaEdificio);
							String viejo = Edificio.getString(auxEdif);
							String[] posibilidades = { nuevo, viejo };
							//Object[] posibilidades = {copiaEdificio,
							// auxEdif};
							String dialogo = "El nuevo edificio se intersecciona con alguna de los ya presentes.\n Elija si en la intersección desea que permanezca el otro edificio o si \n desea sustituir esa zona con el recién creado (la primer opción es el nuevo)\n ";
							//Geometry eleccion =
							// (Geometry)JOptionPane.showInputDialog(contenedorPrincipal,
							// dialogo, "Elección", JOptionPane.WARNING_MESSAGE,
							// null, posibilidades, copiaEdificio);
							String eleccion = (String) JOptionPane
									.showInputDialog(contenedorPrincipal,
											dialogo, "Elección",
											JOptionPane.WARNING_MESSAGE, null,
											posibilidades, nuevo);
							Geometry geometriaAuxiliar;
							if (eleccion.equals(viejo)) {//igual si no eligió ninguno salta un nullpointerexception
														 // y se va al catch sin haber hecho ningún cambio
								copiaEdificio = copiaEdificio
										.difference(auxEdif);
							} else {
								//edificiosSacar.agregarEdificio(auxEdif,auxAltura.doubleValue(),manzana);
								edificiosSacar.add(aux);
								geometriaAuxiliar = auxEdif
										.difference(copiaEdificio);
								if (geometriaAuxiliar
										.getClass()
										.equals(
												com.vividsolutions.jts.geom.Polygon.class)) {
									edificiosAgregar.add(new Edificio(
											(Polygon) (geometriaAuxiliar),
											auxAltura.doubleValue(),
											manzanaElegida.getID())
											.getFeature());
									//edificiosAgregar.agregarEdificio((Polygon)(geometriaAuxiliar),auxAltura.doubleValue(),manzanaElegida.getID());
								} else if (geometriaAuxiliar
										.getClass()
										.equals(
												com.vividsolutions.jts.geom.MultiPolygon.class)) {
									for (int i = 0; i < ((MultiPolygon) geometriaAuxiliar)
											.getNumGeometries(); i++) {
										edificiosAgregar
												.add(new Edificio(
														(Polygon) (((MultiPolygon) geometriaAuxiliar)
																.getGeometryN(i)),
														auxAltura.doubleValue(),
														manzanaElegida.getID())
														.getFeature());
									}
								}

								////botones.getEdificios().agregarEdificio(auxEdif,auxAltura.doubleValue(),manzana);
								////botones.getEdificios().agregarEdificio(edificio,botones.getAltura(),manzana);

							}
						}
					}
					//}

					if (copiaEdificio.getClass().equals(
							com.vividsolutions.jts.geom.Polygon.class)) {
						edificiosAgregar.add(new Edificio(
								(Polygon) (copiaEdificio), alturaEdif,
								manzanaElegida.getID()).getFeature());
					} else if (copiaEdificio.getClass().equals(
							com.vividsolutions.jts.geom.MultiPolygon.class)) {
						for (int i = 0; i < ((MultiPolygon) copiaEdificio)
								.getNumGeometries(); i++) {
							edificiosAgregar.add(new Edificio(
									(Polygon) (((MultiPolygon) copiaEdificio)
											.getGeometryN(i)), alturaEdif,
									manzanaElegida.getID()).getFeature());
						}
					}

					edificios.removeAll(edificiosSacar);
					FeatureIterator lector = edificiosAgregar.features();
					Feature auxFeature;
					while (lector.hasNext()) {
						auxFeature = lector.next();
						edificios.add(new Edificio((Polygon) auxFeature
								.getAttribute("the_geom"), ((Double) auxFeature
								.getAttribute("altura")).doubleValue(),
								manzanaElegida.getID()).getFeature());
					}

					CapaVectorial capaEdificios = new CapaVectorial(edificios);
					//capaEdificios.setStyle(EstiloEdificios.getEstiloAlturas());
					capaEdificios.setStyle(new EstiloEdificios());
					mapa.removeLayer(MapaEdificios.INDICE_EDIFICIOS);
					mapa
							.addLayer(MapaEdificios.INDICE_EDIFICIOS,
									capaEdificios);
					mapa.capaEdificios = capaEdificios;

					mapa.capaManzanaElegida.recargarEstilo();
					mapa.capaCuadraElegida.vaciar();
					mapa.capaEsquinaElegida.vaciar();

					//mp.reset();
					mp.updateUI();
					mp.repaint();
					mp.revalidate();

					botones.setPanelHabilitado(false);

				} catch (EdificioMalIngresadoException ee) {
					JOptionPane
							.showMessageDialog(contenedorPrincipal, ee
									.getMessage(), "Error",
									JOptionPane.WARNING_MESSAGE);
				} catch (Exception eex) {
					JOptionPane
							.showMessageDialog(
									contenedorPrincipal,
									"Hubo un error al agregar el edificio.\n"
											+ "Por favor verifique los datos ingresados.",
									"Error", JOptionPane.ERROR_MESSAGE);
					eex.printStackTrace(System.out);
				}
			} else if (e.getSource().equals(botones.getEliminar())) {

				int opcionElegida = JOptionPane.showConfirmDialog(
						contenedorPrincipal,
						"¿Está seguro que desea eliminar el edificio?",
						"Eliminar", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.WARNING_MESSAGE);
				if (opcionElegida == JOptionPane.OK_OPTION) {
					edificios.remove(botones.getEdificio());
					mapa.capaEdificios.getFeatureCollection().remove(
							botones.getEdificio());
					mapa.capaEdificioElegido.vaciar();
					mapa.capaEdificios.recargarEstilo();
				}

			} else if (e.getSource().equals(botones.getListaEsquinas())) {

				GeometryFactory gf = new GeometryFactory();
				Point esquina = gf.createPoint(botones.getEsquinaElegida());

				mapa.capaEsquinaElegida.vaciar();
				mapa.capaEsquinaElegida.agregar(new Esquina(esquina));
				mapa.capaEsquinaElegida.recargarEstilo();

			} else if (e.getSource().equals(botones.getListaCuadras())) {

				GeometryFactory gf = new GeometryFactory();
				Coordinate[] coordenadas = { (botones.getCuadraElegida()).p0,
						(botones.getCuadraElegida()).p1 };

				mapa.capaCuadraElegida.vaciar();
				mapa.capaCuadraElegida.agregar(new Cuadra(gf
						.createLineString(coordenadas)));
				mapa.capaCuadraElegida.recargarEstilo();

			}

			if (e.getSource().equals(botones.getGuardar())) {
				Archivos archivos = new Archivos();
				File archivoEdif = archivos.guardarArchivo("", "shp",
						"Archivos shp");

				if (archivoEdif != null) {
					EscritorFeatures.escribirShpEdificios(edificios,
							archivoEdif);
					linkEdificios = archivoEdif.toURL();

				}
			}

			if (e.getSource().equals(botones.getSalir())) {
				int opcionElegida = JOptionPane
						.showConfirmDialog(
								contenedorPrincipal,
								"¿Está seguro que desea salir?\n"
										+ "Perderá todos los cambios que no haya guardado.",
								"Salir", JOptionPane.OK_CANCEL_OPTION,
								JOptionPane.WARNING_MESSAGE);
				if (opcionElegida == JOptionPane.YES_OPTION) {
					contenedorPrincipal.setVisible(false);
					contenedorPrincipal.dispose();
				}
			}

		} catch (Exception z) {
			z.printStackTrace(System.out);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		boolean dentroManzana = false;
		boolean dentroEdificio = false;
		try {
			Point2D punto = ((GeoMouseEvent) e).getMapCoordinate(null);

			//mapa.removeLayer(MapaEdificios.INDICE_MANZANA_SELECCIONADA);//no
			// hay manzanas elegidas
			//DefaultMapLayer capa = new
			// DefaultMapLayer(FeatureCollections.newCollection(),Demo2.estilizador("Polygon"));
			//mapa.addLayer(1,capa);//capa vacia de manzanas elegidas

			//mapa.removeLayer(5);//no hay edif elegidos
			//DefaultMapLayer capa2 = new
			// DefaultMapLayer(FeatureCollections.newCollection(),Demo2.estilizador("EdificioElegido"));
			//mapa.addLayer(5,capa2);

			mapa.capaManzanaElegida.recargarEstilo();
			mapa.capaManzanaElegida.vaciar();
			mapa.capaEdificioElegido.vaciar();

			FeatureSource source = mapa.capaManzanas.getFeatureSource();
			FeatureReader lector = source.getFeatures().reader();

			FeatureSource sourceEdificios = mapa.capaEdificios
					.getFeatureSource();
			FeatureReader lectorEdificios = sourceEdificios.getFeatures()
					.reader();

			while (lector.hasNext()) {

				GeometryFactory fabrica = new GeometryFactory();
				Feature fAux = lector.next();
				Geometry geometria = fAux.getDefaultGeometry();
				if (geometria.contains(fabrica.createPoint(new Coordinate(punto
						.getX(), punto.getY())))) {
					Polygon manzanaElegida;

					mapa.capaCuadraElegida.vaciar();
					mapa.capaEsquinaElegida.vaciar();

					if (geometria.getClass().equals(
							com.vividsolutions.jts.geom.Polygon.class)) {
						manzanaElegida = (Polygon) geometria;
					} else {
						manzanaElegida = (Polygon) ((MultiPolygon) geometria)
								.getGeometryN(0);
					}

					botones.setTextoManzana(manzanaElegida);
					botones.getAgregar().setEnabled(true);
					botones.setPanelHabilitado(false);
					botones.getEliminar().setEnabled(false);
					botones.setPoligono(manzanaElegida);
					botones.setManzanaElegida(fAux);

					//					FeatureCollectionSimple fcoleccion = new
					// FeatureCollectionSimple(manzanaElegida);

					//FeatureCollection fcoleccion =
					// FeatureCollections.newCollection();
					//AttributeType geom =
					// AttributeTypeFactory.newAttributeType("the_geom",Polygon.class);
					//FeatureType ftSeleccion =
					// FeatureTypeFactory.newFeatureType(new AttributeType[] {
					// geom }, "seleccion");
					//Feature fSeleccion = ftSeleccion.create(new Object[] {
					// manzanaElegida },"seleccionado");
					//fcoleccion.add(fSeleccion);

					//CapaVectorial capa = new
					// CapaVectorial(fcoleccion,Demo2.estilizador("Polygon"));
					//mapa.removeLayer(1);
					//mapa.addLayer(1,capa);

					if (!dentroEdificio) {
						mapa.capaManzanaElegida.agregar(new Manzana(
								manzanaElegida));
						mapa.capaManzanaElegida.recargarEstilo();
					}

					dentroManzana = true;

				}

			}
			while (lectorEdificios.hasNext()) {
				GeometryFactory fabrica = new GeometryFactory();
				Feature auxFeature = lectorEdificios.next();
				Geometry geometria = auxFeature.getDefaultGeometry();
				if (geometria.contains(fabrica.createPoint(new Coordinate(punto
						.getX(), punto.getY())))) {
					Polygon edificioElegido;
					if (geometria.getClass().equals(
							com.vividsolutions.jts.geom.Polygon.class)) {
						edificioElegido = (Polygon) geometria;
					} else {
						edificioElegido = (Polygon) ((MultiPolygon) geometria)
								.getGeometryN(0);
					}

					//FeatureCollectionSimple fcoleccion = new
					// FeatureCollectionSimple(edificioElegido);

					botones.setTextoEdificio(edificioElegido, Double
							.parseDouble(auxFeature.getAttribute("altura")
									.toString()));
					botones.getAgregar().setEnabled(false);
					botones.setPanelHabilitado(false);
					botones.getEliminar().setEnabled(true);
					botones.setEdificio(auxFeature);

					mapa.capaEdificioElegido.agregar(new Edificio(
							edificioElegido));
					mapa.capaEdificioElegido.recargarEstilo();
					dentroEdificio = true;
				}
			}

			if (!dentroManzana && !dentroEdificio) {
				botones.getAgregar().setEnabled(false);
				botones.getEliminar().setEnabled(false);
				botones.setPanelHabilitado(false);
			}

			//botones.getAgregar().setEnabled(dentroManzana);
			//botones.getEliminar().setEnabled(dentroEdificio);
			//while (!botones.getAgregar().isEnabled()){}

		} catch (Exception z) {
			z.printStackTrace(System.out);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseMoved(MouseEvent e) {
		Point2D punto = ((GeoMouseEvent) e).getMapCoordinate(null);
		barra.getTextoX().setText("X: " + ((int) (punto.getX() * 100)) / 100.0);
		barra.getTextoY().setText("Y: " + ((int) (punto.getY() * 100)) / 100.0);

	}

	/**
	 * Devuelve el linkEdificios.
	 */
	public URL getLinkEdificios() {
		return linkEdificios;
	}

	/**
	 * Devuelve el  linkManzanas.
	 */
	public URL getLinkManzanas() {
		return linkManzanas;
	}

	/**
	 *Devuelve la  FeatureCollection de edificios.
	 */
	public FeatureCollection getEdificios() {
		return edificios;
	}

	/**
	 *Devuelve la  FeatureCollection de manzanas.
	 */
	
	public FeatureCollection getManzanas() {
		return mapa.capaManzanas.getFeatureCollection();
	}
}
