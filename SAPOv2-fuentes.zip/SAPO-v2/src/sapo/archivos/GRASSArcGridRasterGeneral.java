package sapo.archivos;

import java.awt.image.WritableRaster;
import java.io.IOException;
import java.io.Reader;
import java.io.StreamTokenizer;
import java.net.URL;

import javax.media.jai.RasterFactory;

import org.geotools.data.arcgrid.GRASSArcGridRaster;

/**
 * Esta clase corrige algunos problemas de la clase org.geotools.data.arcgrid.GRASSArcGridRaster
 * @author Grupo de proyecto SAPO
 */

public class GRASSArcGridRasterGeneral extends GRASSArcGridRaster {

	private double pasoX;

	public GRASSArcGridRasterGeneral(URL arg0) throws IOException {
		super(arg0);
	}

	@Override
	public WritableRaster readRaster() throws IOException {
		// open reader and make tokenizer
		Reader reader = openReader();
		StreamTokenizer st = new StreamTokenizer(reader);

		// parse header
		parseHeader(st);

		// reconfigure tokenizer
		st.resetSyntax();
		st.parseNumbers();
		st.whitespaceChars(' ', ' ');
		st.whitespaceChars(' ', '\t');
		st.whitespaceChars('\n', '\n');
		st.whitespaceChars('\r', '\r'); //linefeed (on windows only?)
		st.whitespaceChars('\f', '\f'); //form feed (on printers????)

		st.eolIsSignificant(false);
		st.ordinaryChars('E', 'E');
		st.ordinaryChars('*', '*');

		// allocate raster, for now this is done with floating point data,
		// though eventually it should be configurable
		WritableRaster raster = RasterFactory.createBandedRaster(
				java.awt.image.DataBuffer.TYPE_FLOAT, getNCols(), getNRows(),
				1, null);

		// Read values from grid and put into raster.
		// Values must be numbers, which may be simple <num>, or expressed
		// in scientific notation <num>E<exp>.
		// The following loop can read both, even if mixed.
		// The loop expects a token to be read already
		st.nextToken();

		this.maxValue = -Long.MAX_VALUE; //necesario para corregir el bug del
										 // máximo como Long.MIN_VALUE

		for (int y = 0; y < getNRows(); y++) {
			for (int x = 0; x < getNCols(); x++) {
				// this call always reads the next token
				double d = readCell(st, x, y);

				// mask no data values with NaN
				if (!Double.isNaN(d)) {
					minValue = Math.min(minValue, d);
					maxValue = Math.max(maxValue, d);
				}

				// set the value at x,y in band 0 to the parsed value
				raster.setSample(x, y, 0, d);
			}
		}

		reader.close();

		return raster;
	}

	private double readCell(StreamTokenizer st, int x, int y)
			throws IOException {

		double d = 0;

		// read a token, expected: a number of the null marker
		switch (st.ttype) {
		case StreamTokenizer.TT_NUMBER:
			d = (float) st.nval;

			break;

		case StreamTokenizer.TT_EOF:
			throw new IOException("Unexpected EOF at " + x + y);

		default:

			if (st.ttype == '*' || st.sval.equalsIgnoreCase(NO_DATA_MARKER)) {
				st.nextToken();
				return Double.NaN;
			} else {
				throw new IOException("Unknown token " + st.ttype);
			}
		}

		// read another. May be an exponent of this number.
		// If its not an exponent, its the next number. Fall through
		// and token is prefetched for next loop...
		switch (st.nextToken()) {
		case 'e':
		case 'E':

			if (st.ttype != StreamTokenizer.TT_NUMBER) {
				throw new IOException("Expected exponent at " + x + y);
			}

			// calculate
			d = d * Math.pow(10.0, st.nval);

			// prefetch for next loop
			st.nextToken();

			break;

		case '*':
		case StreamTokenizer.TT_NUMBER:
		case StreamTokenizer.TT_EOL:
		case StreamTokenizer.TT_EOF:
			break;

		default:
			st.nextToken(); //ESTE FUE EL CAMBIO REALIZADO
		}
		return d;
	}

	@Override
	protected void parseHeader(StreamTokenizer st) throws IOException {
		// make sure tokenizer is set up right
		st.resetSyntax();
		st.eolIsSignificant(true);
		st.whitespaceChars(0, ' ');
		st.whitespaceChars(':', ':');
		st.wordChars('a', 'z');
		st.wordChars('A', 'Z');
		st.wordChars('_', '_');
		st.wordChars('*', '*');
		st.parseNumbers();

		double north = 0;
		double south = 0;
		double east = 0;
		double west = 0;

		// read lines while the next token is not a number
		while (st.nextToken() != StreamTokenizer.TT_NUMBER) {
			if (st.ttype == StreamTokenizer.TT_WORD) {
				String key = st.sval;

				if (NO_DATA_MARKER.equalsIgnoreCase(key)) {
					break;
				}

				if (st.nextToken() != StreamTokenizer.TT_NUMBER) {
					throw new IOException("Expected number after " + key);
				}

				double val = st.nval;

				if (COLS.equalsIgnoreCase(key)) {
					nCols = (int) val;
				} else if (ROWS.equalsIgnoreCase(key)) {
					nRows = (int) val;
				} else if (NORTH.equalsIgnoreCase(key)) {
					north = readHeaderDouble(st);
				} else if (SOUTH.equalsIgnoreCase(key)) {
					south = readHeaderDouble(st);
				} else if (EAST.equalsIgnoreCase(key)) {
					east = readHeaderDouble(st);
				} else if (WEST.equalsIgnoreCase(key)) {
					west = readHeaderDouble(st);
				} else {
					// ignore extra fields for now
					// are there ever any?
				}

				if (st.nextToken() != StreamTokenizer.TT_EOL) {
					throw new IOException("Expected new line, not " + st.sval);
				}
			} else {
				throw new IOException("Exected word token");
			}
		}

		st.pushBack();

		xllCorner = west;
		yllCorner = south;
		cellSize = (north - south) / nRows;
		pasoX = (east - west) / nCols; //ESTE ES EL CAMBIO
	}

	//A G R E G A D O S:

	/**
	 * @return Returns the pasoX.
	 */
	public double getPasoX() {
		return pasoX;
	}

	public double getPasoY() {
		return this.cellSize;
	}

}