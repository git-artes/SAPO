package sapo.archivos;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * Esta clase permite filtrar la visualizacion de archivos a seleccionar
 * @author Grupo de proyecto SAPO
 */

public class FiltroArchivo extends FileFilter implements java.io.FileFilter {

	String[] extensiones;

	String descripcion;

	/**
	 * Permite filtrar la visualizacion de archivos a seleccionar
	 * 
	 * @param extension
	 *            Extension del archivo
	 * @param descripcion
	 *            Descripcion del tipo de archivo
	 */
	public FiltroArchivo(String extension, String descripcion) {
		this.extensiones = new String[] { extension };
		this.descripcion = descripcion;
	}

	/**
	 * Permite filtrar la visualizacion de archivos a seleccionar
	 * 
	 * @param extensiones
	 *            Extensiones posibles del archivo
	 * @param descripcion
	 *            Descripcion del tipo de archivo
	 */
	public FiltroArchivo(String[] extensiones, String descripcion) {
		this.extensiones = extensiones;
		this.descripcion = descripcion;
	}

	/**
	 * @see javax.swing.filechooser.FileFilter#accept(java.io.File)
	 */
	@Override
	public boolean accept(File f) {
		if (f.isDirectory()) {
			return true;
		}
		String extension = f.getName();
		String[] aux = extension.split("\\p{Punct}");
		if (aux.length >= 1)
			extension = aux[aux.length - 1];
		for (int i = 0; i < extensiones.length; i++) {
			if (extension.equals(extensiones[i])) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @see javax.swing.filechooser.FileFilter#getdescripcion()
	 *  
	 */

	@Override
	public String getDescription() {
		return descripcion;
	}
}